<?php
/**
 * app端个人中心页面
 * */
namespace App\Controller;
use Think\Controller;
class UcenterController extends ApiController {
    //我的团队页面
    public function tuandui(){
        if(IS_POST){
            $code = I('code');
            $page = I('page',1);
            $num  = 10;
            $start = ($page-1)*$num;
            $user = M('wx_user')->where(array('invitation_code'=>$code))->find();
            $uid = $user['id'];
            $member_level=$user['member_level'];
            //判断用户等级2表示运营商，3表示区域合伙人
            if($member_level==2){
                //先查询所有下级运营商
                $sql = "select ID from daili_wx_user where member_agent=$uid and member_level=2";
                $res = M('wx_user')->query($sql);
                if($res){
                    foreach ($res as $key=>$val){
                       $str_id .= $val['id'].',';
                    }
                    $str_id=rtrim($str_id,',');
                    $sql = "select * from daili_wx_user where member_agent=$uid or member_agent in ($str_id) order by reg_app_time desc,SubscribeTime desc limit $start,$num";
                }else{
                    $sql = "select * from daili_wx_user where member_agent=$uid order by reg_app_time desc,SubscribeTime desc limit $start,$num";
                }
                $res = M('wx_user')->query($sql);
                if($res){
                    foreach ($res as $key=>$val){
                        $user_id = $val['id'];
                        //查询下级的人数
                        $user_num = M('wx_user')->where(array('Pid'=>$user_id))->count();
                        //查询总贡献金
                        //先查作为运营商的收益
                        $sql = "select sum(b.agent_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=$user_id and b.agent_id=$uid";
                        $sum1 = M('a_order')->query($sql);
                        $sum1 = $sum1[0]['sum'];
                        //再查作为上级运营商的收益
                        $sql = "select sum(b.shangji_agent_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=$user_id and b.shangji_agent_id=$uid";
                        $sum2 = M('a_order')->query($sql);
                        $sum2 = $sum2[0]['sum'];
                        $sum  = $sum1+$sum2;
                        $data[$key]['id']=$val['id'];
                        $data[$key]['user_num']=$user_num;
                        $data[$key]['sum']=round($sum,2);
                        $data[$key]['phone']=substr($val['phone'],0,3).'****'.substr($val['phone'],6,4);
                        $data[$key]['name']=$val['name'] ? $val['name'] : '无';
                        switch($val['member_level']){
                            case -1:
                                $member_level='普通粉丝';
                                break;
                            case 0:
                                $member_level='会员';
                                break;
                            case 1:
                                $member_level='超级会员';
                                break;
                            case 2:
                                $member_level='运营商';
                                break;
                            case 3:
                                $member_level='区域合伙人';
                                break;
                        }
                        $data[$key]['member_level']=$member_level;
                    }
                }
            }
            if($member_level==3){
                $sql = "select * from daili_wx_user where member_area=$uid order by reg_app_time desc,SubscribeTime desc limit $start,$num";
                $res = M('wx_user')->query($sql);
                if($res){
                    foreach ($res as $key=>$val){
                        $user_id = $val['id'];
                        //查询下级人数
                        $user_num=M('wx_user')->where(array('Pid'=>$user_id))->count();
                        //查询总贡献金
                        $sql = "select sum(b.area_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=$user_id";
                        $sum = M('a_order')->query($sql);
                        $sum = $sum[0]['sum'];
                        $data[$key]['id']=$val['id'];
                        $data[$key]['user_num']=$user_num;
                        $data[$key]['sum']=round($sum,2);
                        $data[$key]['phone']=substr($val['phone'],0,3).'****'.substr($val['phone'],6,4);
                        $data[$key]['name']=$val['name'] ? $val['name'] : '无';
                        switch($val['member_level']){
                            case -1:
                                $member_level='普通粉丝';
                                break;
                            case 0:
                                $member_level='会员';
                                break;
                            case 1:
                                $member_level='超级会员';
                                break;
                            case 2:
                                $member_level='运营商';
                                break;
                            case 3:
                                $member_level='区域合伙人';
                                break;
                        }
                        $data[$key]['member_level']=$member_level;
                    }
                }
            }
            $res = array(
                'num'=>$num,
                'page'=>$page+1,
                'data'=>$data
            );
            $this->ajaxReturn($res);
        }else{
            //根据用户邀请码查询用户信息
            $code = I('code');
            $this->assign('code',$code);
            $this->display();
        }
    }
    //运营商查看订单页面
    public function order_list(){
        if(IS_POST){
            $code = I('code');
            $uid  = I('uid');
            $page = I('page',1);
            $user = M('wx_user')->where(array('invitation_code'=>$code))->find();
            $userid=$user['id'];
            $num = 10;
            $start = ($page-1)*$num;
            $sql ="select a.Pay,a.Title,a.CreateTime,a.CompleteTime,a.OrderNum,a.OrderStatue,a.ItemID,b.agent_shouyi,b.agent_id,b.shangji_agent_shouyi,b.shangji_agent_id,b.area_shouyi,b.area_id from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=$uid order by a.CreateTime desc limit $start,$num";
            $res = M('a_order')->query($sql);
            foreach ($res as $key=>$val){
                $item_info=get_item_infos($val['itemid']);
                $res[$key]['pic']=$item_info['pict_url'];
                if($userid==$val['agent_id']){
                    $res[$key]['shouyi']=round($val['agent_shouyi'],2);
                }elseif($userid==$val['shangji_agent_id']){
                    $res[$key]['shouyi']=round($val['shangji_agent_shouyi'],2);
                }elseif($userid==$val['area_id']){
                    $res[$key]['shouyi']=round($val['area_shouyi'],2);
                }else{
                    $res[$key]['shouyi']=0;
                }
                $res[$key]['createtime']=date('Y-m-d H:i:s',$val['createtime']);
                $res[$key]['completetime']=$val['completetime'] ? date('Y-m-d H:i:s',$val['completetime']) : '';
            }
            $arr = array(
                'code'=>$code,
                'num'=>$num,
                'uid'=>$uid,
                'page'=>$page+1,
                'data'=>$res
            );
            $this->ajaxReturn($arr);
        }else{
            $code = I('code');
            $uid  = I('uid');
            $this->assign('uid',$uid);
            $this->assign('code',$code);
            $this->display();
        }
    }
}