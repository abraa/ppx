<?php
/**
 * app端个人中心页面
 * */
namespace App\Controller;
use Think\Controller;
class CiJiApiController extends Controller {
    public function _initialize(){
        $key = I('apikey');
        if($key != 'd80150809e0b4b2cc65fa1f5b64e8542' && $key != md5($key)){
            $arr = array(
                'code'=>0,
                'msg'=>'key值错误',
            );
            $this->ajaxReturn($arr);
        }
    }
    //已经支付了99元订单接口
    public function order_list(){
        $page = I('page',1,intval);//分页，默认一页20条数据,默认从1开始
        if($page<=1){
            $page = 1;
        }
        $start_time = I('start_time');//付款开始时间 格式2018-04-21
        $end_time   = I('end_time');//付款结束时间 格式2018-04-21
        $sort       = I('sort');//排序默认时间正序排列，1表示倒序排列
        $num = 20;
        $start = $num*($page-1);
        $where ="";
        if($start_time && !$end_time){
            $str_start_time = strtotime($start_time);
            $where = " and b.time>=$str_start_time";
        }
        if(!$start_time && $end_time){
            $str_end_time = strtotime($end_time);
            $where = " and b.time<=$str_end_time";
        }
        if($start_time && $end_time){
            $str_start_time = strtotime($start_time);
            $str_end_time   = strtotime($end_time);
            $where = " and b.time between $str_start_time and $str_end_time";
        }
        $limit =" limit $start,$num";
        if($sort==1){
            $order =" order by a.pay_time desc";
        }else{
            $order =" order by a.pay_time asc";
        }
        $sql = "select 
                    a.id,
                    a.uid,
                    a.trade_no,
                    a.out_trade_no,
                    a.total_amount,
                    a.order_statue,
                    a.pay_time,
                    b.phone,
                    b.name,
                    b.address,
                    b.statue
                from daili_a_upgrade_order as a left join daili_receiving_address as b on a.uid=b.uid where a.order_statue=1 and a.total_amount>=99 $where group by b.uid $order $limit";
        $res = M('a_upgrade_order')->query($sql);
        $this->ajaxReturn($res);
    }
    //用户物流状态修改
    public function get_express_info(){
        $uid = I('out_trade_no');            //用户ID
        //根据订单好查询用户ID
        $order = M('a_upgrade_order')->where(array('out_trade_no'=>$uid))->find();
        if(!$order){
            $arr = array(
                'code'=>0,
                'msg'=>'订单号不存在'
            );
            $this->ajaxReturn($arr);
        }
        $uid = $order['uid'];
        $num = I('express_num');    //快递单号
        $express_name=I('express_name');//快递名称
        $start_time =strtotime(I('delivery_time'));//发货时间
        
        if(!$num){
            $arr = array(
                'code'=>0,
                'msg'=>'快递单号必填'
            );
            $this->ajaxReturn($arr);
        }
        if(!$num){
            $arr = array(
                'code'=>0,
                'msg'=>'快递名称必填'
            );
            $this->ajaxReturn($arr);
        }
        if(!$start_time){
            $arr = array(
                'code'=>0,
                'msg'=>'发货时间必填'
            );
            $this->ajaxReturn($arr);
        }
        $save_data = array(
            'num'=>$num,
            'express_name'=>$express_name,
            'start_time'=>$start_time,
            'statue'=>1,
        );
        $res = M('receiving_address')->where(array('uid'=>$uid))->save($save_data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'快递信息更新成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'快递信息更新失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //修改为非店主
    public function update(){
        $phone=I('phone');
        if(!$phone){
            $arr = array(
                'code'=>0,
                'msg'=>'请输入手机号'
            );
            $this->ajaxReturn($arr);
        }
        $res = M('wx_user')->where(array('Phone'=>$phone))->save(array('member_level'=>0));
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'修改非店主成功'
            );
            //删除店主地址
            M('receiving_address')->where(array('uid'=>$res['id']))->delete();
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'修改非店主失败'
            );
        }
        echo '<pre>';
        print_r($arr);
    }
}