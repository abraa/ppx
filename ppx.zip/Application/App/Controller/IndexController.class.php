<?php
namespace App\Controller;
use Think\Controller;
class IndexController extends ApiController {

    //校验当前访问的是否是app 不是则挂掉
    public function check_agent(){
        $android_zdd=strpos($_SERVER["HTTP_USER_AGENT"],'android_ppx');
        $ios_zdd=strpos($_SERVER["HTTP_USER_AGENT"],'ios_ppx');
        if(!$android_zdd){
            if(!$ios_zdd){
                header("Content-type: text/html; charset=utf-8");
                echo "请在客户端打开";
                exit;
            }
        }
    }

    /***下载页面相关  开始***/
    //
    public function download(){
        $code = I('code');
        $statue = I('statue',0,'intval');

        $iphone=strpos($_SERVER["HTTP_USER_AGENT"],'iPhone');
        $ipad=strpos($_SERVER["HTTP_USER_AGENT"],'iPad');
        if($iphone || $ipad){
            $where['app_type'] = 2;
            $app_type = 2;
        }else{
            $where['app_type'] = 1;
            $app_type = 1;
        }

        $info = M('a_app_version')->where($where)->order('id desc')->limit(1)->find();
        $agent=strpos($_SERVER["HTTP_USER_AGENT"],'MicroMessenger');
        $uid = M('wx_user')->where(array('invitation_code'=>$code))->getField('ID');
        if($statue == 1){
            if(!$agent){
                if(!empty($uid)){
                    $res = $this->add_statistics($uid,1);
                    if($res){
                        header("Location:".$info['download_url']);
                    }
                }else{
                    header("Location:".$info['download_url']);
                }
            }
        }else{
            if($agent){
                header("Location:".U('download')."?statue=1&code=$code");
            }
        }
        $this->assign('code',$code);
        $this->assign('info',$info);
        $this->assign('app_type',$app_type);
        $this->display();
    }
    //
    public function download_test(){
        $code = I('code');
        $statue = I('statue',0,'intval');
    
        $iphone=strpos($_SERVER["HTTP_USER_AGENT"],'iPhone');
        $ipad=strpos($_SERVER["HTTP_USER_AGENT"],'iPad');
        if($iphone || $ipad){
            $where['app_type'] = 2;
            $app_type = 2;
        }else{
            $where['app_type'] = 1;
            $app_type = 1;
        }
    
        $info = M('a_app_version')->where($where)->order('id desc')->limit(1)->find();
        $agent=strpos($_SERVER["HTTP_USER_AGENT"],'MicroMessenger');
        $uid = M('wx_user')->where(array('invitation_code'=>$code))->getField('ID');
        if($statue == 1){
            if(!$agent){
                if(!empty($uid)){
                    $res = $this->add_statistics($uid,1);
                    if($res){
                        header("Location:".$info['download_url']);
                    }
                }else{
                    header("Location:".$info['download_url']);
                }
            }
        }else{
            if($agent){
                header("Location:".U('download_test')."?statue=1&code=$code");
            }
        }
        $this->assign('code',$code);
        $this->assign('info',$info);
        $this->assign('app_type',$app_type);
        $this->display();
    }
    //
    public function ios_download(){
        if(IS_POST){
            $code = I('post.code');
            $uid = M('wx_user')->where(array('invitation_code'=>$code))->getField('ID');
            if(!empty($uid)){
                $res = $this->add_statistics($uid,1);
            }
            $this->ajaxReturn(
                array('statue'=>1)
            );
        }
    }
    //
    public function android_download(){
        if(IS_POST){
            $code = I('post.code');
            $uid = M('wx_user')->where(array('invitation_code'=>$code))->getField('ID');
            if(!empty($uid)){
                $res = $this->add_statistics($uid,1);
            }
            $this->ajaxReturn(
                array('statue'=>1)
            );
        }
    }
    //
    public function person_download(){
        $code = I('code','',trim);
        $code = $code==""?'ssfx2018':$code;
//        $code = "ssfx2018";
        $statue = I('statue',0,'intval');
        $iphone=strpos($_SERVER["HTTP_USER_AGENT"],'iPhone');
        $ipad=strpos($_SERVER["HTTP_USER_AGENT"],'iPad');
        if($iphone || $ipad){
            $where['app_type'] = 2;
        }else{
            $where['app_type'] = 1;
        }
        $info = M('a_app_version')->where($where)->order('id desc')->limit(1)->find();
        $agent=strpos($_SERVER["HTTP_USER_AGENT"],'MicroMessenger');
        $uid = M('wx_user')->where(array('invitation_code'=>$code))->getField('ID');
        if($statue == 1){
            if(!$agent){
                if(!empty($uid)){
                    $res = $this->add_statistics($uid,1);
                    if($res){
                        header("Location:".$info['download_url']);
                    }
                }else{
                    header("Location:".$info['download_url']);
                }
            }
        }else{
            if($agent){
                header("Location:".U('person_download',array('statue'=>1,'code'=>$code)));
            }
        }
        $this->assign('code',$code);
        $this->assign('info',$info);
        $this->display();
    }
    /***下载页面相关  结束***/

    /***活动页面接口 开始***/
    //获取年货淘口令
    public function get_nianhuo_tkl(){
        if(IS_POST){
            $code = I('post.code');
            if(empty($code)){
                $this->ajaxReturn(
                    array(
                        'status'=>'0',
                        'info'=>'获取用户信息失败，请重新加载当前界面'
                    )
                );
            }else{
                $tkl = S('nh_'.$code);
                if(empty($tkl)){
                    //年货节链接
                    //$zc_url = "https://s.click.taobao.com/t?e=m%3D2%26s%3Dat0aFC6Lx9EcQipKwQzePCperVdZeJviK7Vc7tFgwiFRAdhuF14FMRprnxXlRfjF2XPP23XswEPiCpeCUkeJc3yKwiqD2WK0Bmf7LSR66ajpQQIEh%2F3WMYgaseAKBk0cTbU9KzMTtxpe7auY0HPYWszlTEcWhO9mE4x9Ko%2BWnjHEGBqPx1WSLKboO%2FB0dA4zx7rPaxSL0Q0nMO22JBnGDuzhVPnTzc0OgSkC4vs2mL3og4bQ%2B91EOA5HpwU%2B2fYHhFPLTqqXYrRqevP%2Bn1iWzI4nZdlWtg%2FJ4whBO50KuMrGDmntuH4VtA%3D%3D";
                    //拉取新人活动链接
                    $zc_url = "http://s.click.taobao.com/t?e=m%3D2%26s%3DqvlK6Ub4JjccQipKwQzePCperVdZeJviK7Vc7tFgwiFRAdhuF14FMRw%2BF0av814IG%2FN6Jx5YutMzuTGl041QAsSYAZizgQYrnaYpFBIfC%2F3Z%2FNxlvga2vBjnMyd067ZZ4OkDaRSOIN2iZ%2BQMlGz6FQ%3D%3D";
                    $users = M('wx_user')->where(array('invitation_code'=>$code))->find();
                    $pid = $users['tgwid']==""?"mm_33702067_36264112_129592722":$users['tgwid'];
                    $zc_url = $zc_url."&pid=".$pid.'&cpsrc=yhly_yhlytb';
                    //$tkls = $this->itemsTKLing('', '年货节超级红包',$zc_url);
                    $tkls = $this->itemsTKLing('', '超级好货0元购',$zc_url);
                    $nh_tkl= json_decode($tkls,true);
                    if(empty($nh_tkl['data']['model'])){
                        $this->ajaxReturn(
                            array(
                                'status'=>'0',
                                'info'=>'获取淘口令失败，请重新加载当前界面'
                            )
                        );
                    }else{
                        S('nh_'.$code,$nh_tkl['data']['model']);
                        $this->ajaxReturn(
                            array(
                                'status'=>1,
                                'info'=>'年货节超级红包每日可抢：'.$nh_tkl['data']['model']
                            )
                        );
                    }
                }else{
                    $this->ajaxReturn(
                        array(
                            'status'=>1,
                            'info'=>'年货节超级红包每日可抢：'.$tkl
                        )
                    );
                }
            }
        }
    }
    //超级好货0元购活动
    public function get_buy(){
        if(IS_POST){
            $code = I('post.code');
            if(empty($code)){
                $this->ajaxReturn(
                    array(
                        'status'=>'0',
                        'info'=>'获取用户信息失败，请重新加载当前界面'
                    )
                );
            }else{
                $tkl = S('buy_'.$code);
                if(empty($tkl)){
                    //拉取新人活动链接
                    $zc_url = "https://mos.m.taobao.com/activity_newer?from=tool&sight=yhly";
                    $users = M('wx_user')->where(array('invitation_code'=>$code))->find();
                    $pid = $users['tgwid']==""?"mm_33702067_36264112_129592722":$users['tgwid'];
                    $zc_url = $zc_url."&pid=".$pid;
                    $tkls = $this->shoufeiTKLing('', '超级好货0元购',$zc_url);
                    $nh_tkl= json_decode($tkls,true);
                    if(empty($nh_tkl['result'])){
                        $this->ajaxReturn(
                            array(
                                'status'=>'0',
                                'info'=>'获取淘口令失败，请重新加载当前界面'
                            )
                        );
                    }else{
                        S('buy_'.$code,$nh_tkl['result']);
                        $this->ajaxReturn(
                            array(
                                'status'=>1,
                                'info'=>$nh_tkl['result']
                            )
                        );
                    }
                }else{
                    $this->ajaxReturn(
                        array(
                            'status'=>1,
                            'info'=>$tkl
                        )
                    );
                }
            }
        }
    }
    //妇女节活动
    public function get_women_buy(){
        if(IS_POST){
            $code = I('post.code');
            if(empty($code)){
                $this->ajaxReturn(
                    array(
                        'status'=>'0',
                        'info'=>'获取用户信息失败，请重新加载当前界面'
                    )
                );
            }else{
                $tkl = S('38_buy_'.$code);
                if(empty($tkl)){
                    //拉取新人活动链接
                    $zc_url = "https://s.click.taobao.com/t?e=m%3D2%26s%3Dqvn29nj3A8AcQipKwQzePCperVdZeJviK7Vc7tFgwiFRAdhuF14FMbFXlvcTq7z12XPP23XswEPiCpeCUkeJc3yKwiqD2WK0Bmf7LSR66agynDOG7DdOVfB0z8qlrv%2BjIOoxaTwwbqtICD7BBQSQLWfjkSvFgPxzFlK8cfBdY27LQPEJLPAWAV3WV7X8X8sdxgxdTc00KD8%3D&cpssrc=yhly_yhlytb";
                    $users = M('wx_user')->where(array('invitation_code'=>$code))->find();
                    $pid = $users['tgwid']==""?"mm_33702067_36264112_129592722":$users['tgwid'];
                    $zc_url = $zc_url."&pid=".$pid;
                    $img = "http://img.taokehelp.cn/Uploads/ITEM_IMG/2018-03-05/5a9cf7fdbf664.jpg";
                    $data = array(
                        'title'=>'3.8超级红包火爆来袭',
                        'url'=>$zc_url,
                        'logo'=>$img
                    );
                    $tkls = taokouling_new($data);
                    if(empty($tkls)){
                        $this->ajaxReturn(
                            array(
                                'status'=>'0',
                                'info'=>'获取淘口令失败，请重新加载当前界面'
                            )
                        );
                    }else{
                        S('38_buy_'.$code,$tkls);
                        $this->ajaxReturn(
                            array(
                                'status'=>1,
                                'info'=>$tkls
                            )
                        );
                    }
                }else{
                    $this->ajaxReturn(
                        array(
                            'status'=>1,
                            'info'=>$tkl
                        )
                    );
                }
            }
        }
    }
    //拉新活动
    public function api_get_laxin_msg(){
        if(IS_POST){
            $code = I('post.code');
            $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
            $arr = explode('_',$userinfo['tgwid']);
            $res = M('a_config_authorize')
                ->field('daili_a_config_authorize.access_token,daili_a_config_authorize.taobao_user_nick,daili_a_config_authorize.id')
                ->where('daili_a_alimama.AliMaMaID='.$arr[1])
                ->join(' left join daili_a_alimama on daili_a_config_authorize.taobao_user_nick = daili_a_alimama.Name')
                ->order('daili_a_config_authorize.id desc')
                ->limit(1)->select();
            $sessionKey =$res[0]['access_token'];
            $resp = get_new_tb_user(1,$userinfo['adid'],$userinfo['mediaid'],$sessionKey);
            $data = array();
            if(empty($resp['results']['data']['results']['map_data'])){
                $arr = array(
                    'statue'=>0,
                    'data'=>''
                );
            }else{
                $data =array_merge($data,$resp['results']['data']['results']['map_data']);
                $page=3;
                if($resp['results']['data']['has_next']!='false'){
                    for($i=2;$i<$page;$i++){
                        $resps = get_new_tb_user($i,$userinfo['adid'],$userinfo['mediaid'],$sessionKey);
                        if($resps['results']['data']['has_next']!='false'){
                            $data =array_merge($data,$resps['results']['data']['results']['map_data']);
                            $page=$page+1;
                        }else{
                            $data =array_merge($data,$resps['results']['data']['results']['map_data']);
                        }
                    }
                }
                $arr = array(
                    'statue'=>1,
                    'data'=>$data
                );
            }
            $this->ajaxReturn($arr);
        }
    }
    /***活动页面接口 结束***/

    /***页面部分  开始***/
    //分享商品领券页面
    public function details(){
        $numid = I('numid');
        $code = I('code');
        $open = I('open','','intval');
        if(empty($numid)){
            $this->error("缺少商品参数");
        }
        if(empty($code)){
            $this->error("缺少参数");
        }
        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($userinfo)){
            $this->error("参数信息错误");
        }

        $shopinfo = $this->get_shopdetails($numid);
        $shop = M('a_items','daili_','DB_DAILI_READ')->where(array('num_iid'=>$numid))->find();
        $ress = $this->get_couponinfo($numid,$userinfo['mediaid'],$userinfo['adid'],$shop['youhuiquan']);
        $tkl = json_decode($this->itemsTKLing($shopinfo['pict_url'],$shopinfo['title'],$ress['coupon_click_url']),true);
        $this->set_up_log($ress['coupon_click_url'],$userinfo['gzhtoken'],$tkl['data']['model'],$numid,'',$userinfo['phone'],$userinfo['alimamaid']);
        $infos = M('a_app_version','daili_','DB_READ')->order('id desc')->limit(1)->find();

        $agent=strpos($_SERVER["HTTP_USER_AGENT"],'MicroMessenger');
        if(!$agent){
            header("Location:".$ress['coupon_click_url']);
        }
//        $statue = I('statue',0,intval);
//        $agent=strpos($_SERVER["HTTP_USER_AGENT"],'MicroMessenger');

//        if($statue == 1){
//            if(!$agent){
////                header("Location:".$infos['download_url']);
//                header("Location:".U('details',array('open'=>$open,'statue'=>1,'code'=>$code,'numid'=>$numid)));
//            }
//        }else{
//            if($agent){
//                header("Location:".U('details',array('open'=>$open,'statue'=>1,'code'=>$code,'numid'=>$numid)));
//            }
//        }
        $this->assign('tkl',$tkl['data']['model']);
        $this->assign('ehy_url',$ress['coupon_click_url']);
        $this->assign('info',$shopinfo);
        $this->assign('infos',$infos);
        $this->assign('numid',$numid);
        $this->assign('open',$open);
        $this->assign('code',$code);
        $this->display();
    }
    //代理中心页面
    public function wx_daili(){
//        $this->check_agent();
        $code = I('code');
        $token1 = $this->get_token(array($code));
        $token2 = $this->get_token(array($code,4,2));
        $token3 = $this->get_token(array($code,3,1));
        $token4 = $this->get_token(array($code,4,1));
        $token5 = $this->get_token(array($code,1,1));
        $token6 = $this->get_token(array($code,2,1));
        $token7 = $this->get_token(array($code,4,3));
        $this->assign('token7',$token7);
        $token8 = $this->get_token(array($code,3,2));
        $this->assign('token8',$token8);
        $token9 = $this->get_token(array($code,1));
        $this->assign('token9',$token9);
        $token10 = $this->get_token(array($code,2));
        $this->assign('token10',$token10);
        $token11 = $this->get_token(array($code,3));
        $this->assign('token11',$token11);
        $token12 = $this->get_token(array($code,1,2));
        $this->assign('token12',$token12);
        $token13 = $this->get_token(array($code,2,2));
        $this->assign('token13',$token13);
        $this->assign('token7',$token7);
        $this->assign('token1',$token1);
        $this->assign('token2',$token2);
        $this->assign('token3',$token3);
        $this->assign('token4',$token4);
        $this->assign('token5',$token5);
        $this->assign('token6',$token6);
        $this->assign('code',$code);
        $this->display();
    }

    public function wx_daili2(){
        $code = I('code');
        $this->assign('code',$code);
        $this->display();
    }
   //邀请代理奖励
    public function reward(){
        if(IS_POST){
            $page = I('post.page',1,'intval');
            $type = I('get.type',1,'intval');
            $code = I('code');
            $wxuser = M('wx_user');

            $my_id = $wxuser->where(array('invitation_code'=>$code))->getField('ID');
            //查询所有下级代理
            $user = M('b_jiangli')->field('daili_b_jiangli.Money,daili_wx_user.HeaderPic,daili_wx_user.NickName,daili_wx_user.Name,daili_wx_user.Phone,daili_wx_user.ID')
                ->where(array('daili_b_jiangli.UID'=>$my_id))
                ->join('left join daili_wx_user on daili_b_jiangli.XiaJiUID=daili_wx_user.ID')
                ->order('daili_b_jiangli.Time desc')
                ->page($page,20)
                ->select();
            foreach($user as $k=>$v){
                $user[$k]['name'] = $v['name']==""?"未知":$v['name'];
                $user[$k]['phone'] = $v['phone']==""?"未知":$v['phone'];
            }
            if($type == 1){
                if(empty($user)){
                    $data = array(
                        'content'=>$user,
                        'status'=>2
                    );
                }else{
                    $data = array(
                        'content'=>$user,
                        'status'=>1
                    );
                }
                $this->ajaxReturn($data);
            }elseif($type == 2){
                //查询所有提现奖励金成功的信息
                $where['daili_a_tixian.UID']=$my_id;
                $where['daili_a_tixian.Statue']=1;
                $where['daili_a_tixian.Type']=2;
                $where['daili_wx_user.ID']=$my_id;
                $join = " left join  daili_wx_user on daili_a_tixian.UID = daili_wx_user.ID";
                $field = "daili_wx_user.NickName,daili_wx_user.HeaderPic,daili_a_tixian.JinE";
                $tx_info = M('a_tixian')->field($field)->join($join)->where($where)->page($page,20)->select();
                foreach($tx_info as $k1=>$v1){
                    $tx_info[$k1]['reward'] = sprintf("%.2f",$v1['jine']*0.05);
                }
                if(empty($tx_info)){
                    $data = array(
                        'content'=>$tx_info,
                        'status'=>2
                    );
                }else{
                    $data = array(
                        'content'=>$tx_info,
                        'status'=>1
                    );
                }
                $this->ajaxReturn($data);
            }
        }else{
            $code = I('code');
            $type = I('get.type',1,'intval');
            $this->assign('code',$code);
            $this->assign('type',$type);
            $this->display();
        }
    }
    //活动奖励
    public function active_reward(){
        if(IS_POST){
            $page = I('post.page',1,'intval');
            $code = I('code');
            $wxuser = M('wx_user');
            $sql = "select a.*,c.ShouYiBi as shouyibi from daili_wx_user as a left join daili_a_media b on a.GzhToken=b.token left join daili_a_config_copy as c on b.ID=c.MediaID where a.invitation_code='$code'";
            //$userinfo = $wxuser->where(array('invitation_code'=>$code))->find();
            $userinfo = $wxuser->query($sql);
            $userinfo = $userinfo[0];
            $shouyibi = $userinfo['shouyibi']/100;
            $qudao_name=$userinfo['medianame'];
            $adid = $userinfo['adid'];
            $active = M('a_active_qudao')->where(array('statue'=>1,'token'=>$userinfo['gzhtoken']))->page($page,20)->select();
            if(empty($active)){
                $data = array(
                    'content'=>'',
                    'status'=>0
                );
            }else{
                foreach($active as $k=>$v){
                    $start_time = $v['start_time'];
                    $end_time   = $v['end_time'];
                    //根据活动查询用户完成情况
                    switch($v['active_id']){
                        case 1:
                            //查询完成情况
                            $sql="select count(a.ID) as count from daili_a_order as a
                                where a.MediaName='$qudao_name' 
                                and a.OrderStatue<>'订单失效' 
                                and (a.CreateTime between $start_time and $end_time)
                                and a.AdID='$adid'
                            ";
                            $count=M('a_order')->query($sql);
                            $user_complete=$count[0]['count'];
                            $active[$k]['complete']=$v['complete'].'单';
                             
                            $active[$k]['user_complete']=round($user_complete,2).'单';
                             
                            break;
                        case 5:
                            $sql = "select sum(b.ShouYi) as sum
                            from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID
                            where a.MediaName='$qudao_name'
                            and a.OrderStatue<>'订单失效'
                            and (a.CreateTime between $start_time and $end_time)
                            and a.Adid='$adid'
                            ";
                            $count=M('a_order')->query($sql);
                            $arr_complete   = explode(',',$v['complete']);
                            sort($arr_complete);
                            $arr_reward     = explode(',',$v['reward']);
                            sort($arr_reward);
                            foreach ($arr_complete as $key=>$val){
                                $str .="完成".$val.'元、奖励'.$arr_reward[$key].'元，';
                            }
                            $active[$k]['complete']=rtrim($str,',');
                            $user_complete=$count[0]['sum'];
                            $active[$k]['user_complete']=round($user_complete,2).'元';
                             
                            break;
                    }
                    if(!$user_complete){
                        $user_complete=0;
                    }
                     //查询标题
                    $a = M('a_active')->where(array('id'=>$v['active_id']))->find();
                    $active[$k]['title']=$a['title'];
                    $active[$k]['content']=$a['content'];
                    $statue_res = M('a_active_complete')->where(array('uid'=>$userinfo['id'],'active_id'=>$v['id']))->find();
                    if($v['start_time']>time()){
                        $statue='<font color="white" style="background:#e85656;border-radius:15px;padding:5px;">未开始</font>';
                    }
                    if($v['start_time']<=time() && $v['end_time']>time()){
                        $statue='<font color="white" style="background:#e85656;border-radius:15px;padding:5px;">进行中</font>';
                    }
                    if($v['end_time']<time()){
                        $statue='<font color="green" style="background:#e85656;border-radius:15px;padding:5px;">已结束</font>';
                    }
                    $active[$k]['st']=date('Y-m-d H:i',$start_time);
                    $active[$k]['et']=date('Y-m-d H:i',$end_time);
                    $active[$k]['complete_statue'] = $statue;
                    $active[$k]['get_reward'] = $statue_res['reward']==""?"0.00":$statue_res['reward'];
                }
                $data = array(
                    'content'=>$active,
                    'status'=>1
                );
            }
            $this->ajaxReturn($data);
        }else{
            $code = I('code','','trim');
            $this->assign('code',$code);
            $this->display();
        }
    }
    //我的资料修改
    public function my_info(){
        if(IS_POST){
            $name = I('post.name','',trim);
            $alipay = I('post.alipay','',trim);
            $code = I('get.code');
//            if(empty($name) || empty($alipay)){
//                $this->ajaxReturn(array('error'=>0,'msg'=>'真实姓名或支付宝账号不能为空'));
//                exit;
//            }
            if(!empty($name)){
                $data['Name']=$name;
            }
            if(!empty($alipay)){
                $data['Alipay']=$alipay;
            }
            if(empty($code)){
                $this->ajaxReturn(array('error'=>0,'msg'=>'获取用户信息失败，请退出重进'));
                exit;
            }
            $res1 =  M('wx_user')->where(array('invitation_code'=>$code))->save($data);
            if($res1){
                $this->ajaxReturn(array('error'=>1,'msg'=>"修改成功"));
            }else{
                $this->ajaxReturn(array('error'=>0,'msg'=>'您没有修改任何资料'));
            }
        }else{
            $code = I('code');
            $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
            $this->assign('userinfo',$userinfo);
            $this->assign('code',$code);
            $this->display();
        }
    }
    //手机端提现申请页面
    public function tixian(){
        if(IS_POST){
            $money = I('post.money',0,'intval');
            $code = I('get.code');
            $type = I('get.type','','trim');
            $info = M('wx_user')->where(array('invitation_code'=>$code))->find();
            if($info['dongjie']==1){
                $arr = array(
                    'msg'=>'余额已经冻结，请联系客服解冻后提现',
                    'error'=>1,
                );
                $this->ajaxReturn($arr);
            }
            if($info['id'] == $info['kefu_id'] && $info['member_level']<2){
                $arr = array(
                    'msg'=>"您的角色是客服，不能提现！",
                    'error'=>1
                );
                $this->ajaxReturn($arr);
            }

            if($money<1){
                $arr = array(
                    'msg'=>"您的提现金额必须为整数或大于0！",
                    'error'=>1
                );
                $this->ajaxReturn($arr);
            }

            //查询当前公众号的最低提现金额
            $gzh_id = M('a_media')->where(array('token'=>$info['gzhtoken']))->getField('id');
            $tx_je = M('a_config_copy')->where(array('MediaID'=>$gzh_id))->getField('ZuiDiTiXian');
            $tx_je = $tx_je==''?100:$tx_je;
            if($type == 'reward'){
                $info['yu_e'] =substr(sprintf("%.3f",$info['rewardyue']),0,-1);
                $infos = M('a_tixian')->where(array('UID'=>$info['id'],'Statue'=>0,'Type'=>2))->find();
            }else{
                $info['yu_e'] =substr(sprintf("%.3f",$info['yue']),0,-1);
                $infos = M('a_tixian')->where(array('UID'=>$info['id'],'Statue'=>"0",'Type'=>1))->find();
            }
            $statue = empty($infos)?0:1;
            $types = ($type=='reward')?2:($type=='')?1:3;
            if($types == 3){
                $arr = array(
                    'msg'=>"提现数据类型异常，请刷新页面重试！",
                    'error'=>1
                );
                $this->ajaxReturn($arr);
            }

            if($statue=="1"){
                $arr = array(
                    'msg'=>"你有正在审核的提现操作，请等待审核后在进行操作",
                    'error'=>1
                );
                $this->ajaxReturn($arr);
            }
            if($money<$tx_je){
                $arr = array(
                    'msg'=>"提现金额必须大于等于".$tx_je,
                    'error'=>1
                );
                $this->ajaxReturn($arr);
            }
            if($money> $info['yu_e']){
                $arr = array(
                    'msg'=>"提现金额不得大于可用余额",
                    'error'=>1
                );
                $this->ajaxReturn($arr);
            }

            $tx = M('a_tixian');
            $tx->startTrans();
            $tx->add(
                array(
                    'UID'=>$info['id'],
                    'JinE'=>$money,
                    'Time'=>time(),
                    'Statue'=>0,
                    'Remark'=>'',
                    'Type'=>$types
                )
            );
            if($tx){
                $tx->commit();
                $arr = array(
                    'msg'=>"提现申请成功",
                    'error'=>0
                );
            }else{
                $tx->rollback();
                $arr = array(
                    'msg'=>"提现申请失败",
                    'error'=>1
                );
            }
            $this->ajaxReturn($arr);

        }else{
            $code = I('get.code');
            $type = I('get.type','',trim);
            $info = M('wx_user')->where(array('invitation_code'=>$code))->find();
            if($type == 'reward'){
                $info['yu_e'] =substr(sprintf("%.3f",$info['rewardyue']),0,-1);
                $infos = M('a_tixian')->where(array('UID'=>$info['id'],'Statue'=>0,'Type'=>2))->find();
            }else{
                $info['yu_e'] =substr(sprintf("%.3f",$info['yue']),0,-1);
                $infos = M('a_tixian')->where(array('UID'=>$info['id'],'Statue'=>0,'Type'=>1))->find();
            }
            if($info['id'] == $info['kefu_id'] && $info['member_level']<2){
                $info['yu_e'] = 0.00;
            }
            //查询当前公众号的最低提现金额
            $gzh_id = M('a_media')->where(array('token'=>$info['gzhtoken']))->getField('id');
            $tx_je = M('a_config_copy')->where(array('MediaID'=>$gzh_id))->getField('ZuiDiTiXian');
            $tx_je = $tx_je==''?100:$tx_je;

            $statue = empty($infos)?0:1;
            $this->assign('info',$info);
            $this->assign('type',$type);
            $this->assign('statue',$statue);
            $this->assign('tx_je',$tx_je);
            $this->assign('code',$code);
            $this->display();
        }
    }
    //手机端提现列表页面
    public function tixian_list(){
        if(IS_POST){
            $code = I('code');
            $page = I('page');
            $user = M('wx_user')->where(array('invitation_code'=>$code))->find();
            $info = M('a_tixian')->where(array('UID'=>$user['id']))->page($page,20)->order('Time desc')->select();
            foreach($info as $k=>$v){
                $info[$k]['tx_time'] = date('Y/m/d H:i:s',$v['time']);
                $info[$k]['tx_statue'] = $v['statue']==1?'提现成功':(($v['statue']==0)?'待审核':'提现失败');
                $info[$k]['tx_type'] = $v['type']==1?'普通提现':'奖励金提现';
                $info[$k]['color'] = $v['statue']==1?'color:green':'color:red';
            }
            if(empty($info)){
                $arr =  array(
                    'content'=>'',
                    'status'=>2
                );
            }else{
                $arr =  array(
                    'content'=>$info,
                    'status'=>1
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $code =I('code');
            $token = $this->get_token(array($code));
            $this->assign('code',$code);
            $this->assign('token',$token);
            $this->display();
        }
    }

    //结算明细(后期需要改动)
    public function jiesuanmx(){
        $code = I('code');
        $user = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        //定义查询日期（按天查询）
        //本月时间
        $month_start = mktime(0,0,0,date('m'),1,date('Y'));
        $month_last =  mktime(23,59,59,date('m'),date('t'),date('Y'));
        //上个月时间
        $t = time();
        $lastmonth_start = mktime(0,0,0,date("m",$t)-1,1,date("Y",$t));
        $lastmonth_last = mktime(23,59,59,date("m",$t)-1,date("t",$lastmonth_start),date("Y",$t));
        $lastmonth_days =  date("t",strtotime('date("Y",$t)-(date("m",$t)-1)'));
//        $lastmonth_days = cal_days_in_month(CAL_GREGORIAN, (date("m",$t)-1), (date("Y",$t)));

        if($user['member_level']==2){
            $month_sql = "select daili_a_shouyi.*,daili_a_order.CompleteTime from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.UID="
                .$user['id']." or daili_a_shouyi.ShangJiUID=".$user['id']." or daili_a_shouyi.ShangShangJiUID="
                .$user['id']." ) and daili_a_order.CreateTime between $month_start and $month_last  order by daili_a_order.CompleteTime desc";
            $lastmonth_sql = "select daili_a_shouyi.*,daili_a_order.CompleteTime from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.UID="
                .$user['id']." or daili_a_shouyi.ShangJiUID=".$user['id']." or daili_a_shouyi.ShangShangJiUID="
                .$user['id']." ) and daili_a_order.CreateTime between $lastmonth_start and $lastmonth_last  order by daili_a_order.CompleteTime desc";
        }elseif($user['member_level']==3){
            $month_sql = "select daili_a_shouyi.*,daili_a_order.CompleteTime from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.area_id="
                .$user['id']." or daili_a_shouyi.UID=".$user['id'].") and daili_a_order.CreateTime between $month_start and $month_last   order by daili_a_order.CompleteTime desc";
            $lastmonth_sql = "select daili_a_shouyi.*,daili_a_order.CompleteTime from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.area_id="
                .$user['id']." or daili_a_shouyi.UID=".$user['id'].") and daili_a_order.CreateTime between $lastmonth_start and $lastmonth_last  order by daili_a_order.CompleteTime desc";
        }else{
            $month_sql = "select daili_a_shouyi.*,daili_a_order.CompleteTime from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.UID="
                        .$user['id']." or daili_a_shouyi.ShangJiUID=".$user['id']
                .") and daili_a_order.CreateTime between $month_start and $month_last  order by daili_a_order.CompleteTime desc";
            $lastmonth_sql = "select daili_a_shouyi.*,daili_a_order.CompleteTime from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.UID="
                .$user['id']." or daili_a_shouyi.ShangJiUID=".$user['id']
                .") and daili_a_order.CreateTime between $lastmonth_start and $lastmonth_last  order by daili_a_order.CompleteTime desc";
        }
        $month_info = M('a_order','daili_','DB_READ')->query($month_sql);
        $lastmonth_info = M('a_order','daili_','DB_READ')->query($lastmonth_sql);
        $info = array();
        $infos = array();
        if(empty($month_info)){
            for($i = date('d');$i>=1;$i--){
                $key = date('Y')."-".((date("m",$t)-1+1))."-".$i;
                $info[$key]['money']=0;
            }
        }else{
            foreach($month_info as $k=>$v){
                for($i = date('d');$i>=1;$i--){
                    $key = date('Y')."-".((date("m",$t)-1+1))."-".$i;
                    if($v['completetime']>=mktime(0,0,0,date('m'),$i,date('Y')) && $v['completetime']<=mktime(23,59,59,date('m'),$i,date('Y'))){
                        if($user['member_level']==2){
                            $month_sqls = "select sum(daili_a_shouyi.ShangJiShouYi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.ShangJiUID="
                                .$user['id']." ) and daili_a_order.ID=".$v['orderid'];
                            $month_sqls2 = "select sum(daili_a_shouyi.ShouYi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.UID="
                                .$user['id']." ) and daili_a_order.ID=".$v['orderid'];
                            $month_sqls3 = "select sum(daili_a_shouyi.ShangShangJiShouYi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and ( daili_a_shouyi.ShangShangJiUID="
                                .$user['id']." ) and daili_a_order.ID=".$v['orderid'];
                            $moneys = M('a_order','daili_','DB_READ')->query($month_sqls);
                            $moneys2 = M('a_order','daili_','DB_READ')->query($month_sqls2);
                            $moneys3 = M('a_order','daili_','DB_READ')->query($month_sqls3);
                            $sum = $moneys[0]['sum1']+$moneys2[0]['sum1']+$moneys3[0]['sum1'];
                        }elseif($user['member_level']==3){
                            $month_sqls = "select sum(daili_a_shouyi.agent_shouyi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.area_id="
                                .$user['id'].") and daili_a_order.ID =".$v['orderid'];
                            $month_sqls2 = "select sum(daili_a_shouyi.ShouYi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.UID="
                                .$user['id'].") and daili_a_order.ID =".$v['orderid'];
                            $moneys = M('a_order','daili_','DB_READ')->query($month_sqls);
                            $moneys2 = M('a_order','daili_','DB_READ')->query($month_sqls2);
                            $sum = $moneys[0]['sum1']+$moneys2[0]['sum1'];
                        }else{
                            $month_sqls = "select sum(daili_a_shouyi.ShouYi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.UID="
                                .$user['id'].") and daili_a_order.ID= ".$v['orderid'];
                            $month_sqls2 = "select sum(daili_a_shouyi.ShangJiShouYi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.ShangJiUID=".$user['id']
                                .") and daili_a_order.ID= ".$v['orderid'];
                            $moneys = M('a_order','daili_','DB_READ')->query($month_sqls);
                            $moneys2 = M('a_order','daili_','DB_READ')->query($month_sqls2);
                            $sum = $moneys[0]['sum1']+$moneys2[0]['sum1'];
                        }
                        $info[$key]['money']+=sprintf("%.2f",$sum);
                    }else{
                        $info[$key]['money']=0;
                    }
                }
            }
        }

        if(empty($lastmonth_info)){
            for($j = $lastmonth_days;$j>=1;$j--){
                $keys = (date("Y",$t))."-".(date("m",$t)-1)."-".$j;
                $infos[$keys]['money']=0;
            }
        }else{
            foreach($lastmonth_info as $k=>$v){
                for($j = $lastmonth_days;$j>=1;$j--){
                    $keys = (date("Y",$t))."-".(date("m",$t)-1)."-".$j;
                    if($v['completetime']>=mktime(0,0,0,date("m",$t)-1,$i,(date("Y",$t))) && $v['completetime']<=mktime(23,59,59,date("m",$t)-1,$i,(date("Y",$t)))){
                        if($user['member_level']==2){
                            $month_sqls = "select sum(daili_a_shouyi.ShangJiShouYi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.ShangJiUID="
                                .$user['id']." ) and daili_a_order.ID=".$v['orderid'];
                            $month_sqls2 = "select sum(daili_a_shouyi.ShouYi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.UID="
                                .$user['id']." ) and daili_a_order.ID=".$v['orderid'];
                            $month_sqls3 = "select sum(daili_a_shouyi.ShangShangJiShouYi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and ( daili_a_shouyi.ShangShangJiUID="
                                .$user['id']." ) and daili_a_order.ID=".$v['orderid'];
                            $moneys = M('a_order','daili_','DB_READ')->query($month_sqls);
                            $moneys2 = M('a_order','daili_','DB_READ')->query($month_sqls2);
                            $moneys3 = M('a_order','daili_','DB_READ')->query($month_sqls3);
                            $sum = $moneys[0]['sum1']+$moneys2[0]['sum1']+$moneys3[0]['sum1'];
                        }elseif($user['member_level']==3){
                            $month_sqls = "select sum(daili_a_shouyi.agent_shouyi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.area_id="
                                .$user['id'].") and daili_a_order.ID =".$v['orderid'];
                            $month_sqls2 = "select sum(daili_a_shouyi.ShouYi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.UID="
                                .$user['id'].") and daili_a_order.ID =".$v['orderid'];
                            $moneys = M('a_order','daili_','DB_READ')->query($month_sqls);
                            $moneys2 = M('a_order','daili_','DB_READ')->query($month_sqls2);
                            $sum = $moneys[0]['sum1']+$moneys2[0]['sum1'];
                        }else{
                            $month_sqls = "select sum(daili_a_shouyi.ShouYi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.UID="
                                .$user['id'].") and daili_a_order.ID= ".$v['orderid'];
                            $month_sqls2 = "select sum(daili_a_shouyi.ShangJiShouYi) as sum1 from daili_a_order
                  left join daili_a_shouyi on daili_a_order.ID = daili_a_shouyi.OrderID where daili_a_order.OrderStatue='订单结算' and (daili_a_shouyi.ShangJiUID=".$user['id']
                                .") and daili_a_order.ID= ".$v['orderid'];
                            $moneys = M('a_order','daili_','DB_READ')->query($month_sqls);
                            $moneys2 = M('a_order','daili_','DB_READ')->query($month_sqls2);
                            $sum = $moneys[0]['sum1']+$moneys2[0]['sum1'];
                        }
                        $infos[$keys]['money']+=sprintf("%.2f",$sum);
                    }else{
                        $infos[$keys]['money']=0;
                    }
                }
            }
        }
        $this->assign('info',$info);
        $this->assign('infos',$infos);
        $this->assign('month',(date("m",$t)-1+1));
        $this->assign('lastmonth',(date("m",$t)-1));
        $this->display();
    }

    //邀请奖励  新版本
    public function fans2_yys(){
        //根据用户邀请码查询用户信息
        $code = I('code');
        $type = I('type',1,'intval');
        $page = I('page',1,'intval');
        $token = $this->get_token(array('code'=>$code,'type'=>$type,1));
        $this->assign('code',$code);
        $this->assign('type',$type);
        $this->assign('page',$page);
        $this->assign('token',$token);
        $this->display();
    }
    
    //我的下级代理
    public function fans2(){
        $code = I('code');
        $page = I('page');
        $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
        $type = I('get.type',1,'intval');
        $parame1 = array($code,1,1);
        $parame2 = array($code,2,1);
        $parame3 = array($code,3,1);
        $token1 = $this->get_token($parame1);
        $token2 = $this->get_token($parame2);
        $token3 = $this->get_token($parame3);
        $this->assign('token1',$token1);
        $this->assign('token2',$token2);
        $this->assign('token3',$token3);
        $this->assign('type',$type);
        $this->assign('code',$code);
        $this->assign('page',$page);
        $this->display();
    }
    //我的下下级代理
    public function details_fs(){
        $code = I('code');
        $page = I('page');
        $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
        $type = I('get.type',1,'intval');
        $this->assign('type',$type);
        $this->assign('code',$code);
        $this->assign('page',$page);
        $this->display();
    }

    public function fans_fs(){
        $code = I('code');
        $page = I('page');
        $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
        $type = I('get.type',1,'intval');
        $this->assign('type',$type);
        $this->assign('code',$code);
        $this->assign('page',$page);
        $this->display();
    }
    
    //手机端订单页面
    public function my_order(){

        $code =  I('code');
        $page = I('apge',1,'intval');
        $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
        $is_show = $userinfo['member_level']>1?0:1;
        $statue = I('get.statue',0,'intval');
        $time = I('get.time',0,'intval');
        $team = I('get.team',0,'intval');
        $this->assign('team',$team);
        $this->assign('code',$code);
        $this->assign('time',$time);
        $this->assign('statue',$statue);
        $this->assign('is_show',$is_show);
        $this->assign('page',$page);
        $token0 = $this->get_token(array($code));
        $this->assign('token0',$token0);
        $token1 = $this->get_token(array($code,0));
        $this->assign('token1',$token1);
        
        $token2 = $this->get_token(array($code,1));
        $this->assign('token2',$token2);
        
        $token3 = $this->get_token(array($code,$team,0));
        $this->assign('token3',$token3);
        $token4 = $this->get_token(array($code,$team,1));
        $this->assign('token4',$token4);
        $token5 = $this->get_token(array($code,$team,2));
        $this->assign('token5',$token5);
        $token6 = $this->get_token(array($code,$team,3));
        $this->assign('token6',$token6);
        $token7 = $this->get_token(array($code,$team,4));
        $this->assign('token7',$token7);
        
        $token8 = $this->get_token(array($code,$time,$team,1));
        $this->assign('token8',$token8);
        $token9 = $this->get_token(array($code,$time,$team,2));
        $this->assign('token9',$token9);
        $token10 = $this->get_token(array($code,$time,$team,3));
        $this->assign('token10',$token10);
        $token11 = $this->get_token(array($code,$time,$team,4));
        $this->assign('token11',$token11);
        $token12 = $this->get_token(array($code,$time,$statue,$team,$page));
        $this->assign('token12',$token12);
        $this->display();
    }
    //直播间
    public function live_room(){
        $code = I('code');
        $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
        $info = M('a_zhibo_items','daili_','DB_DAILI_READ')->where("token = '".$userinfo['gzhtoken']."' and send_time<=".time())->order('send_time desc')->page(1,10)->select();
        if(empty($info)){
            $info = M('a_zhibo_items','daili_','DB_DAILI_READ')->where("token = 'gh_90c6882faaf9' and send_time<=".time())->order('send_time desc')->page(1,10)->select();
        }
        $file = getcwd().'/Application/Home/Conf/'.$userinfo['gzhtoken'].'_server_conf.php';
        $config = include($file);
        $space_time = $config['space_time']>0?$config['space_time']:600;
        $this->assign('space_time',$space_time);
        $count = count($info)>1?(count($info)-1):0;
        $this->assign('code',$code);
        $this->assign('find_time',time());
        $this->assign('info',array_reverse($info));
        $this->assign('itemid',$info[$count]['id']);
        $this->display();
    }
    //
    public function get_user_pic(){
        $code = I('code');
        $info = M('wx_user')->where(array('invitation_code'=>$code))->find();
        $count = M('wx_user')->field('ID,HeaderPic')->where()->count();
        $count = ($count/20)>1?($count/20):1;
        $find_count = rand(1,$count);
        $list = M('wx_user')->field('ID,HeaderPic')->where()->page($find_count,20)->select();
        $this->ajaxReturn(
            array(
                'data'=>array(
                    'code'=>'login',
                    'user_list'=>$list,
                    'user_count'=>count($list)
                )
            )
        );
    }
    //支付宝信息设置
    public function zhifubao_set(){
        if(IS_POST){
            $code = I('post.code');
            if(empty($code)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'获取用户信息失败，请返回重试！'
                    )
                );
            }
            $alipay = I('post.alipay','','trim');
            $username = I('post.name','','trim');
            if(empty($alipay) || empty($username)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'支付宝账号或姓名不能为空'
                    )
                );
            }
            $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
            if(empty($userinfo)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'获取用户信息错误，请返回重试！'
                    )
                );
            }
           M('wx_user')->where(array('invitation_code'=>$code))->save(array('Alipay'=>$alipay,'Name'=>$username));
            $this->ajaxReturn(
                array(
                    'statue'=>1,
                    'msg'=>'操作成功！'
                )
            );
        }else{
            $code = I('code');
            $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
            $this->assign('code',$code);
            $this->assign('userinfo',$userinfo);
            $this->display();
        }
    }
    //
    public function get_new_data(){
        $code = I('code');
        $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
        $this->assign('userinfo',$userinfo);
        $this->display();
    }
    //常见问题页面
    public function question(){
        $this->display();
    }
    //会员升级页面
    public function member_upgrade(){
        $code = I('code');
        $this->assign('code',$code);
        $this->display();
    }



    /***********************  H5接口 开始  ******************************/

    /***收益数据开始***/
    /*
    * 收益首页api
    * 接口方法：wx_daili_api
    * 参数
    * 1、code：用户code
    * 返回数据：用户信息(userinfo)、提现金额(tixian)、余额(yu_e)、会员等级(member_level_info)、
    * 邀请代理奖励上限金额(max_money)、邀请代理奖励金额(money)、活动奖励(active_money)
    * */
    public function wx_daili_api(){
        $this->check_token();
        $code = I('code');
        //验证当前用户是否存在我们的数据库中
        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($userinfo) || $userinfo['statue']!=1){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'无效用户'
                )
            );
        }
        $member_level_msg = $this->get_level_msg($userinfo['member_level']);
        $str_id = "";
        $uid = $userinfo['id'];
        $member_level = $userinfo['member_level'];
//销售经理
        if($member_level==2){
            //先查询所有下级
            $res = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>$uid))->select();
            foreach ($res as $key=>$val){
                $str_id .= $val['id'].',';
            }
            $str_id=rtrim($str_id,',');
            if(empty($str_id)){
                $str_id =$uid;
            }
            $sql_1 = "select sum((SELECT sum(b.ShangShangJiShouYi) AS sum FROM daili_a_order AS a LEFT JOIN daili_a_shouyi AS b ON a.ID = b.OrderID WHERE b.UID = c.ID AND b.ShangShangJiUID = $uid)) AS sum1 from daili_wx_user as c where c.Pid=$uid or c.Pid in ($str_id)";
            $sql_2 = "select sum((SELECT sum(b.ShangJiShouYi) AS sum FROM daili_a_order AS a LEFT JOIN daili_a_shouyi AS b ON a.ID = b.OrderID WHERE b.UID = c.ID AND b.ShangJiUID = $uid)) AS sum1 from daili_wx_user as c where c.Pid=$uid or c.Pid in ($str_id)";
            $res1 = M('wx_user','daili_','DB_READ')->query($sql_1);
//            $sum1 = 0;
//            foreach($res1 as $k=>$v){
//                $sum1+=$v['sum1'];
//            }
            $res2 = M('wx_user','daili_','DB_READ')->query($sql_2);
//            $sum2 = 0;
//            foreach($res2 as $k1=>$v1){
//                $sum2+=$v1['sum1'];
//            }
//            $sum_all = $sum1+$sum2;
            $sum_all = $res1[0]['sum1'] + $res2[0]['sum1'];
        }elseif($member_level==3){  //服务经理
            $sql_1 = "select sum((select sum(b.area_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=c.ID)) as sum1 from daili_wx_user as c where c.member_area=$uid";
//            $sql_2 = "select (SELECT sum(b.ShangJiShouYi) AS sum FROM daili_a_order AS a LEFT JOIN daili_a_shouyi AS b ON a.ID = b.OrderID WHERE b.UID = c.ID AND b.ShangJiUID = $uid) AS sum1 from daili_wx_user as c where c.Pid=$uid";
            $res1 = M('wx_user','daili_','DB_READ')->query($sql_1);
//            $sum1 = 0;
//            foreach($res1 as $k=>$v){
//                $sum1+=$v['sum1'];
//            }
//            $sum_all = $sum1;
            $sum_all = $res1[0]['sum1'];
        }else {
            $sql_1 = "select sum((SELECT sum(b.ShangJiShouYi) FROM daili_a_order AS a LEFT JOIN daili_a_shouyi AS b ON a.ID = b.OrderID WHERE b.UID = c.ID AND b.ShangJiUID = $uid )) AS sum1 from daili_wx_user as c where c.Pid=$uid";
            $res1 = M('wx_user', 'daili_', 'DB_READ')->query($sql_1);
//            $sum_all = 0;
//            foreach($res1 as $k=>$v){
//                $sum_all+=$v['sum1'];
//            }
            $sum_all = $res1[0]['sum1'];
        }
        $arr = array(
            'yaoqinghuiyuan_jiangli'    =>sprintf("%.2f",$userinfo['yaoqinghuiyuan_jiangli']),
            'yaoqingdianzhu_jiangli'    =>sprintf("%.2f",$userinfo['yaoqingdianzhu_jiangli']),
            'yu_e'    =>sprintf("%.2f",($userinfo['yue'])),
            'member_level_info'=>$member_level_msg,
            'team_sum'=>sprintf("%.2f",$sum_all),
            'userinfo'=>$userinfo,
        );
        $this->ajaxReturn(
            array(
                'data'=>$arr,
                'statue'=>1,
                'msg'=>'获取成功'
            )
        );
    }

    /*
       * 获取收益数据
       * 接口方法：get_income
       * 参数
       * 1、code：用户code   2、time_type：时间筛选  3、statue：收益状态
       * 注释：
       * 1、time_type：【1、今日  2、昨日 3、本月  4、上月  】
       * 2、statue：【1、预估 2、结算】
       * 返回数据：自身(first)、代理(second)、总和(sum)、自身贡献数量(first_order_count)、代理贡献数量(second_order_count)
       * */
    public function get_income(){
        $this->check_token();
        $code = I('code','','trim');
        $time_type = I('time_type',1,'intval');
        $statue = I('statue',1,'intval');
        if($time_type<1 || $time_type>4){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'时间参数错误，请刷新重试'
                )
            );
        }
        if($statue<1 || $statue>2){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'类型参数错误，请刷新重试'
                )
            );
        }
        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($userinfo) || $userinfo['statue']!=1){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'无效用户'
                )
            );
        }
        switch ($time_type){
            case 1:
                //今日时间
                $time_start = mktime(0,0,0,date('m'),date('d'),date('Y'));
                $time_last  = mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
                break;
            case 2:
                //昨日时间
                $time_start=mktime(0,0,0,date('m'),date('d')-1,date('Y'));
                $time_last=mktime(0,0,0,date('m'),date('d'),date('Y'))-1;
                break;
            case 3:
                //本月时间
                $time_start = mktime(0,0,0,date('m'),1,date('Y'));
                $time_last =  mktime(23,59,59,date('m'),date('t'),date('Y'));
                break;
            case 4:
                //上个月时间
                $t = time();
                $time_start = mktime(0,0,0,date("m",$t)-1,1,date("Y",$t));
                $time_last = mktime(23,59,59,date("m",$t)-1,date("t",$time_start),date("Y",$t));
                break;
        }

        switch($statue){
            case 1:
                //
                $where_order_statue = "";
                $where_order_time = " a.CreateTime between $time_start and $time_last";
                break;
            case 2:
                //CompleteTime
                $where_order_statue = " and a.OrderStatue='订单结算'";
                $where_order_time = " a.CompleteTime between $time_start and $time_last";
                break;
        }
        //本人
        $first_sql = "select sum(b.ShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.UID = ".$userinfo['id'];
        $first_sums = M('a_order')->query($first_sql);
        $first_income = $first_sums[0]['sum'];
        //本人订单数
        $first_count_sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.UID = ".$userinfo['id'];
        $first_order_counts = M('a_order')->query($first_count_sql);
        $first_order_count = $first_order_counts[0]['count'];
        //二级
        //计算团队收益

        if($userinfo['member_level']<2){
            $team_sql = "select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.ShangJiUID = ".$userinfo['id'];
            $team_sums = M('a_order')->query($team_sql);
            $team_income = $team_sums[0]['sum'];
            $count_sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.ShangJiUID = ".$userinfo['id'];
            $order_counts = M('a_order')->query($count_sql);
            $order_count = $order_counts[0]['count'];
        }elseif($userinfo['member_level']==2){
            $str_id = "";
            $p_str_id="";
            //先查询所有下级
            $res1 = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>$userinfo['id']))->select();
            if(!empty($res1)){
                foreach ($res1 as $key=>$val){
                    $str_id .= $val['id'].',';
                }
                $str_id=rtrim($str_id,',');
                //查询下下级
                $res2 = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>array('in',$str_id)))->select();
                foreach ($res2 as $keys=>$vals){
                    $p_str_id .= $vals['id'].',';
                }
                $p_str_id=rtrim($p_str_id,',');
                $team_sql = "select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi"
                    ." as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.UID in ($str_id) AND b.ShangJiUID=".$userinfo['id'];
                $team_sums = M('a_order')->query($team_sql);
                if(!empty($p_str_id)){
                    $team_sql2 = "select sum(b.ShangShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi"
                        ." as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.UID in ($p_str_id) AND b.ShangShangJiUID=".$userinfo['id'];
                    $team_sums2 = M('a_order')->query($team_sql2);
                    $team_income = $team_sums[0]['sum']+ $team_sums2[0]['sum'];
                }else{
                    $team_income = $team_sums[0]['sum'];
                }

                $count_sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi"
                    ." as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.UID in ($str_id) AND ( b.ShangJiUID=".$userinfo['id'].")";
                $count_sql2 = "select count(*) as count from daili_a_order as a left join daili_a_shouyi"
                    ." as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.UID in ($p_str_id) AND ( b.ShangShangJiUID=".$userinfo['id'].")";
                $order_counts = M('a_order')->query($count_sql);
                $order_counts2 = M('a_order')->query($count_sql2);
                $order_count = $order_counts[0]['count']+$order_counts2[0]['count'];
            }
        }elseif($userinfo['member_level']==3){
            $res1 = M('wx_user','daili_','DB_READ')
                ->field('ID')
                ->where(array('member_area'=>$userinfo['id']))
                ->select();
            $str_ids = "";
            foreach ($res1 as $k=>$v){
                $str_ids .= $v['id'].',';
            }
            $str_ids=rtrim($str_ids,',');
            $team_sql = "select sum(b.area_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.UID in ($str_ids)";
            $team_sums = M('a_order')->query($team_sql);
            $team_income = $team_sums[0]['sum'];
            $count_sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.UID in ($str_ids)";
            $order_counts = M('a_order')->query($count_sql);
            $order_count = $order_counts[0]['count'];
        }
        //汇总
        $this->ajaxReturn(
            array(
                'msg'=>"ok",
                'statue'=>1,
                'all_income'=>($first_income+$team_income)>0?sprintf("%.2f",($first_income+$team_income)):0,
                'order_count'=>($first_order_count+$order_count)>0?($first_order_count+$order_count):0
            )
        );
    }

    /*
     * 获取所有收益
     * 接口方法：get_all_shouyi
     * 参数
     * 1、code：用户code
     * 返回数据：所有收益(all_shouyi)
     * */
    public function get_all_shouyi(){
        $code = I('code');
        //验证当前用户是否存在我们的数据库中
        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        $tixian = M('a_tixian','daili_','DB_READ')->where(array('UID'=>$userinfo['id'],'Statue'=>1))->sum('JinE');
        $this->ajaxReturn(
            array(
                'msg'=>"ok",
                'statue'=>1,
                'all_shouyi'=>($userinfo['yue']+$tixian)>0?sprintf("%.2f",($userinfo['yue']+$tixian)):0
            )
        );
    }

    /*
     * 获取节省金额
     * 接口方法：get_save_money
     * 参数
     * 1、code：用户code
     * 返回数据：节省金额(save_money)
     * */
    public function get_save_money(){
        $code = I('code');
        //验证当前用户是否存在我们的数据库中
        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        $this->ajaxReturn(
            array(
                'msg'=>"ok",
                'statue'=>1,
                'save_money'=>$userinfo['save_money']>0?sprintf("%.2f",$userinfo['save_money']):0
            )
        );
    }

    /***收益数据结束***/


    /***团队、订单数据 开始***/
    /*
     * 获取团队奖励数据
     * 参数
     * 1、code：用户code   2、type：查询数据类型 3、page：页数
     * 注释：type：【1、全部  2、直属粉丝  3、推荐粉丝】
     * */
    public function get_team_data(){
        $code = I('code');
        $page = I('page',1,'intval');
        $num  = 10;
        $user = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        $type = I('type',1,'intval');
        //粉丝列表查询
        if($type==2){ //直属粉丝
            $reason = "您未成为店主，无法得到奖励金";
            $join = " left join daili_b_jiangli on daili_wx_user.ID = daili_b_jiangli.XiaJiUID";
            $res = M('wx_user','daili_','DB_READ')
                ->field('daili_wx_user.ID as userid,daili_wx_user.member_level,daili_wx_user.PID,daili_wx_user.reg_app_time,
                        daili_wx_user.Phone,daili_b_jiangli.*')
                ->where(array('daili_wx_user.Pid'=>$user['id'],'daili_b_jiangli.type'=>2))
                ->join($join)
                ->order('daili_wx_user.reg_app_time desc')
                ->page($page,$num)
                ->select();
            foreach($res as $k=>$v){
                $res[$k]['identity'] = $this->get_level_msg($v['member_level']);
                $res[$k]['reg_time'] = date('Y-m-d',$v['reg_app_time']);
                $res[$k]['user_phone'] = substr($v['phone'],0,3).'****'.substr($v['phone'],7,5);
                $res[$k]['count'] = M('wx_user','daili_','DB_READ')->where(array('Pid'=>$v['id']))->count();
                $res[$k]['reason'] = $v['statue']==0?$reason:"";
            }
            $vip = M('wx_user','daili_','DB_READ')->where(array('Pid'=>$user['id'],'member_level'=>0))->count();
            $dz = M('wx_user','daili_','DB_READ')->where(array('Pid'=>$user['id'],'member_level'=>1))->count();
        }elseif($type==3){  //下下级
            $str_id = "";
            //先查询所有下级
            $res1 = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>$user['id']))->select();
            foreach ($res1 as $key=>$val){
                $str_id .= $val['id'].',';
            }
            $str_id=rtrim($str_id,',');

            if(!empty($res1)){
                $res = M('wx_user','daili_','DB_READ')
                    ->where(array('Pid'=>array('in',$str_id)))
                    ->page($page,$num)
                    ->order('reg_app_time desc,SubscribeTime desc')
                    ->select();
                foreach($res as $k=>$v){
                    $res[$k]['identity'] = $this->get_level_msg($v['member_level']);
                    $res[$k]['reg_time'] = date('Y-m-d',$v['reg_app_time']);
                    $res[$k]['user_phone'] = substr($v['phone'],0,3).'****'.substr($v['phone'],7,5);
                    $res[$k]['count'] = M('wx_user','daili_','DB_READ')->where(array('Pid'=>$v['id']))->count();
                }
                $vip = M('wx_user','daili_','DB_READ')->where(array('Pid'=>array('in',$str_id),'member_level'=>0))->count();
                $dz = M('wx_user','daili_','DB_READ')->where(array('Pid'=>array('in',$str_id),'member_level'=>1))->count();
            }else{
                $res = "";
            }
        }else{  //全部
            $str_id = "";
            //先查询所有下级
            $res1 = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>$user['id']))->select();

            foreach ($res1 as $key=>$val){
                $str_id .= $val['id'].',';
            }
            $str_id=rtrim($str_id,',');
            if(empty($str_id)){
                $str_id = $user['id'];
            }
            if(!empty($res1)){
                $res = M('wx_user','daili_','DB_READ')
                    ->where("Pid=".$user['id']." or Pid in(".$str_id.")")
                    ->page($page,$num)
                    ->order('reg_app_time desc,SubscribeTime desc')
                    ->select();
                foreach($res as $k=>$v){
                    $res[$k]['identity'] = $this->get_level_msg($v['member_level']);
                    $res[$k]['reg_time'] = date('Y-m-d',$v['reg_app_time']);
                    $res[$k]['user_phone'] = substr($v['phone'],0,3).'****'.substr($v['phone'],7,5);
                    $res[$k]['count'] = M('wx_user','daili_','DB_READ')->where(array('Pid'=>$v['id']))->count();
                }

                $vip = M('wx_user','daili_','DB_READ')->where("(Pid=".$user['id']." or Pid in(".$str_id.")) and member_level=0")->count();
                $dz = M('wx_user','daili_','DB_READ')->where("(Pid=".$user['id']." or Pid in(".$str_id.")) and member_level=1")->count();
            }else{
                $res = "";
            }
        }

        $arr = array(
            'vip_count'=>$vip>0?$vip:0,
            'dz_count'=>$dz>0?$dz:0,
            'info'=>$res
        );
        $this->ajaxReturn($arr);
    }

    /*
     * 获取团队数据
     * 参数
     * 1、code：用户code   2、type：查询数据类型 3、page：页数
     * 注释：type：【1、全部  2、直属粉丝  3、推荐粉丝】
     * */
    public function get_team_datas(){
        $this->check_token();
        $code = I('code');
        $page = I('page',1,'intval');
        $num  = 10;
        $user = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        $type = I('type',1,'intval');
        //粉丝列表查询
        if($type==2){ //直属粉丝
            $res = M('wx_user','daili_','DB_READ')
                ->field('daili_wx_user.ID as userid,daili_wx_user.member_level,daili_wx_user.HeaderPic,
                daili_wx_user.PID,daili_wx_user.reg_app_time,daili_wx_user.Phone')
                ->where(array('daili_wx_user.Pid'=>$user['id']))
                ->order('daili_wx_user.reg_app_time desc')
                ->page($page,$num)
                ->select();
            foreach($res as $k=>$v){
                $res[$k]['identity'] = $this->get_level_msg($v['member_level']);
                $res[$k]['reg_time'] = date('Y-m-d',$v['reg_app_time']);
                $res[$k]['user_phone'] = substr($v['phone'],0,3).'****'.substr($v['phone'],7,5);
                $res[$k]['count'] = M('wx_user','daili_','DB_READ')->where(array('Pid'=>$v['id']))->count();
            }
            $page_nums = M('wx_user','daili_','DB_READ')
                ->where(array('daili_wx_user.Pid'=>$user['id']))
                ->count();
            $page_num = ceil($page_nums/$num);
            $vip = M('wx_user','daili_','DB_READ')->where(array('Pid'=>$user['id'],'member_level'=>0))->count();
            $dz = M('wx_user','daili_','DB_READ')->where(array('Pid'=>$user['id'],'member_level'=>1))->count();
        }elseif($type==3){  //下下级
            $str_id = "";
            //先查询所有下级
            $res1 = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>$user['id']))->select();
            foreach ($res1 as $key=>$val){
                $str_id .= $val['id'].',';
            }
            $str_id=rtrim($str_id,',');

            if(!empty($res1)){
                $res = M('wx_user','daili_','DB_READ')
                    ->where(array('Pid'=>array('in',$str_id)))
                    ->page($page,$num)
                    ->order('reg_app_time desc,SubscribeTime desc')
                    ->select();
                foreach($res as $k=>$v){
                    $res[$k]['identity'] = $this->get_level_msg($v['member_level']);
                    $res[$k]['reg_time'] = date('Y-m-d',$v['reg_app_time']);
                    $res[$k]['user_phone'] = substr($v['phone'],0,3).'****'.substr($v['phone'],7,5);
                    $res[$k]['count'] = M('wx_user','daili_','DB_READ')->where(array('Pid'=>$v['id']))->count();
                }
                $page_nums = M('wx_user','daili_','DB_READ')
                    ->where(array('Pid'=>array('in',$str_id)))
                    ->count();
                $page_num = ceil($page_nums/$num);
                $vip = M('wx_user','daili_','DB_READ')->where(array('Pid'=>array('in',$str_id),'member_level'=>0))->count();
                $dz = M('wx_user','daili_','DB_READ')->where(array('Pid'=>array('in',$str_id),'member_level'=>1))->count();
            }else{
                $res = "";
            }
        }else{  //全部
            $str_id = "";
            //先查询所有下级
            $res1 = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>$user['id']))->select();

            foreach ($res1 as $key=>$val){
                $str_id .= $val['id'].',';
            }
            $str_id=rtrim($str_id,',');
            if(empty($str_id)){
                $str_id = $user['id'];
            }
            if(!empty($res1)){
                $res = M('wx_user','daili_','DB_READ')
                    ->where("Pid=".$user['id']." or Pid in(".$str_id.")")
                    ->page($page,$num)
                    ->order('reg_app_time desc,SubscribeTime desc')
                    ->select();
                foreach($res as $k=>$v){
                    $res[$k]['identity'] = $this->get_level_msg($v['member_level']);
                    $res[$k]['reg_time'] = date('Y-m-d',$v['reg_app_time']);
                    $res[$k]['user_phone'] = substr($v['phone'],0,3).'****'.substr($v['phone'],7,5);
                    $res[$k]['count'] = M('wx_user','daili_','DB_READ')->where(array('Pid'=>$v['id']))->count();
                }
                $page_nums = M('wx_user','daili_','DB_READ')
                    ->where("Pid=".$user['id']." or Pid in(".$str_id.")")
                    ->count();
                $page_num = ceil($page_nums/$num);
                $vip = M('wx_user','daili_','DB_READ')->where("(Pid=".$user['id']." or Pid in(".$str_id.")) and member_level=0")->count();
                $dz = M('wx_user','daili_','DB_READ')->where("(Pid=".$user['id']." or Pid in(".$str_id.")) and member_level=1")->count();
            }else{
                $res = "";
            }
        }

        $arr = array(
            'vip_count'=>$vip>0?$vip:0,
            'dz_count'=>$dz>0?$dz:0,
            'page_num'=>$page_num,
            'info'=>$res
        );
        $this->ajaxReturn($arr);
    }

    /*
     * 获取我的订单数据
     * 参数
     * 1、code：用户code   2、team：团队类型筛选 3、page：页数 4、time：时间类型 5、statue：状态
     * 注释：
     * team：【1、团队订单。默认为空】   time：【1、今日 2、昨日 3、本月 4、上月。默认为空】  statue：【1、订单付款 2、订单结算 3、订单失效 。默认为空】
     * */
    public function get_myorder_data(){
        $this->check_token();
        $page = I('page',1,'intval');
        $statue = I('statue',0,'intval');
        $time = I('time',0,'intval');
        $team = I('team',0,'intval');
        $code =  I('code','','trim');
        if(empty($code)){
            $this->ajaxReturn(
                array(
                    'msg'=>'用户参数获取失败',
                    'statue'=>2
                )
            );
        }
        $user = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($user)){
            $this->ajaxReturn(
                array(
                    'msg'=>'获取用户信息失败',
                    'statue'=>2
                )
            );
        }


        switch($time){
            case 1:
                $time_start = mktime(0,0,0,date('m'),date('d'),date('Y'));
                $time_last  = mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
            break;
            case 2:
                $time_start = mktime(0,0,0,date('m'),date('d')-1,date('Y'));
                $time_last = mktime(0,0,0,date('m'),date('d'),date('Y'))-1;
                break;
            case 3:
                $time_start = mktime(0,0,0,date('m'),1,date('Y'));
                $time_last =  mktime(23,59,59,date('m'),date('t'),date('Y'));
                break;
            case 4:
                $t = time();
                $time_start = mktime(0,0,0,date("m",$t)-1,1,date("Y",$t));
                $time_last = mktime(23,59,59,date("m",$t)-1,date("t",$time_start),date("Y",$t));
                break;
            default:
                $time_start = strtotime('2018-01-01');
                $time_last  = time();
        }

        switch($statue){
            case 2:
                $where['daili_a_order.OrderStatue'] = "订单付款";
                $where['daili_a_order.CreateTime'] = array('between',array($time_start,$time_last));

                $wheres = " and daili_a_order.OrderStatue='订单付款' and daili_a_order.CreateTime between $time_start and $time_last";
                break;
            case 3:
                $where['daili_a_order.OrderStatue']  = "订单结算";
                $where['daili_a_order.CompleteTime'] = array('between',array($time_start,$time_last));
                $wheres = " and daili_a_order.OrderStatue='订单结算' and daili_a_order.CompleteTime between $time_start and $time_last";
                break;
            case 4:
                $where['daili_a_order.OrderStatue'] = "订单失效";
                $where['daili_a_order.CreateTime'] = array('between',array($time_start,$time_last));
                $wheres = " and daili_a_order.OrderStatue='订单失效' and daili_a_order.CreateTime between $time_start and $time_last";
                break;
            default:
                $where['daili_a_order.CreateTime'] = array('between',array($time_start,$time_last));
                $wheres = "  and daili_a_order.CreateTime between $time_start and $time_last";
        }
        //验证当前用户是否存在我们的数据库中
        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();

        if($team==1){
            if($user['member_level']==2){
                $where = "(daili_a_shouyi.ShangJiUID=".$userinfo['id']." or daili_a_shouyi.ShangShangJiUID=".$userinfo['id'].") $wheres";
                $field = 'daili_a_shouyi.ShangJiUID,daili_a_shouyi.ShangShangJiUID,daili_a_shouyi.ShouYi,daili_a_shouyi.ShangJiShouYi,daili_a_shouyi.ShangShangJiShouYi,daili_a_shouyi.area_shouyi,daili_a_order.OrderStatue,daili_a_order.Title,daili_a_order.ItemID,'
                    .'daili_a_order.CompleteTime,daili_a_order.CreateTime,daili_a_order.OrderNum,daili_a_order.Pay,daili_a_shouyi.UID,daili_a_order.IMG';
                $join = 'left join daili_a_shouyi on daili_a_shouyi.OrderID=daili_a_order.ID';
                $order = 'daili_a_order.CreateTime desc';
                $info = M('a_order','daili_','DB_READ')->field($field)->where($where)->join($join)->page($page,20)->order($order)->select();
            }elseif($user['member_level']==3){
                $where = "daili_a_shouyi.area_id=".$userinfo['id'].$wheres;
                $field = 'daili_a_shouyi.ShangJiUID,daili_a_shouyi.ShangShangJiUID,daili_a_shouyi.area_id,daili_a_shouyi.ShouYi,daili_a_shouyi.ShangJiShouYi,daili_a_shouyi.ShangShangJiShouYi,daili_a_shouyi.area_shouyi,daili_a_order.OrderStatue,daili_a_order.Title,daili_a_order.ItemID,'
                    .'daili_a_order.CompleteTime,daili_a_order.CreateTime,daili_a_order.OrderNum,daili_a_order.Pay,daili_a_shouyi.UID,daili_a_order.IMG';
                $join = 'left join daili_a_shouyi on daili_a_shouyi.OrderID=daili_a_order.ID';
                $order = 'daili_a_order.CreateTime desc';
                $info = M('a_order','daili_','DB_READ')->field($field)->where($where)->join($join)->page($page,20)->order($order)->select();
            }else{
                $where = "daili_a_shouyi.ShangJiUID=".$userinfo['id'].$wheres;
                $field = 'daili_a_shouyi.ShangJiUID,daili_a_shouyi.ShangShangJiUID,daili_a_shouyi.ShouYi,daili_a_shouyi.ShangJiShouYi,daili_a_shouyi.ShangShangJiShouYi,daili_a_shouyi.area_shouyi,daili_a_order.OrderStatue,daili_a_order.Title,daili_a_order.ItemID,'
                    .'daili_a_order.CompleteTime,daili_a_order.CreateTime,daili_a_order.OrderNum,daili_a_order.Pay,daili_a_shouyi.UID,daili_a_order.IMG';
                $join = 'left join daili_a_shouyi on daili_a_shouyi.OrderID=daili_a_order.ID';
                $order = 'daili_a_order.CreateTime desc';
                $info = M('a_order','daili_','DB_READ')->field($field)->where($where)->join($join)->page($page,20)->order($order)->select();
            }

        }else{
            $where = "daili_a_shouyi.UID=".$userinfo['id'].$wheres;
            $field = 'daili_a_shouyi.ShouYi,daili_a_shouyi.ShangJiShouYi,daili_a_shouyi.ShangShangJiShouYi,daili_a_shouyi.area_shouyi,daili_a_order.OrderStatue,daili_a_order.Title,daili_a_order.ItemID,'
                .'daili_a_order.CompleteTime,daili_a_order.CreateTime,daili_a_order.OrderNum,daili_a_order.Pay,daili_a_shouyi.UID,daili_a_order.IMG';
            $join = 'left join daili_a_shouyi on daili_a_shouyi.OrderID=daili_a_order.ID';
            $order = 'daili_a_order.CreateTime desc';
            $info = M('a_order','daili_','DB_READ')->field($field)->where($where)->join($join)->page($page,20)->order($order)->select();
        }
        foreach($info as $k=>$v){
            $iteminfo = get_item_infos($v['itemid']);
            $info[$k]['img']=$iteminfo['pict_url'].'_200x200.jpg';
            $info[$k]['creat_time'] = date('Y-m-d H:i:s',$v['createtime']);
            $info[$k]['complete_time'] = ($v['completetime']==''||$v['completetime']==0)?'':date('Y-m-d H:i:s',$v['completetime']);
            if($user['member_level']==2){
                if($v['shangjiuid']==$userinfo['id']){
                    $shouyi = $v['shangjishouyi'];
                }elseif($v['shangshangjiuid']==$userinfo['id']){
                    $shouyi = $v['shangshangjishouyi'];
                }
                $info[$k]['shouyi'] = ($team==1)?sprintf("%.2f",$shouyi):sprintf("%.2f",$v['shouyi']);
            }elseif($user['member_level']==3){
                $info[$k]['shouyi'] = ($team==1)?sprintf("%.2f",$v['area_shouyi']):sprintf("%.2f",$v['shouyi']);
            }else{
                $info[$k]['shouyi'] = ($team==1)?sprintf("%.2f",$v['shangjishouyi']):sprintf("%.2f",$v['shouyi']);
            }

            unset($v['createtime']);
            unset($v['completetime']);
        }
        if(empty($info)){
            $arr = array(
                'content'=>'',
                'statue'=>3
            );
        }else{
            $arr = array(
                'content'=>$info,
                'statue'=>1,
                'is_show'=>($user['member_level']>1?1:0),
            );
        }
        $this->ajaxReturn($arr);
    }

    /*
     * 获取运营商下的用户数据
     * 参数
     * 1、code：用户code   2、team：团队类型筛选 3、page：页数 4、time：时间类型 5、statue：状态
     * 注释：
     * team：【1、团队订单。默认为空】   time：【1、今日 2、昨日 3、本月 4、上月。默认为空】  statue：【1、订单付款 2、订单结算 3、订单失效 。默认为空】
     * */
    public function get_teamorder_data(){
        $code = I('code');
        $uid  = I('uid');
        $page = I('page',1);
        $user = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        $userid=$user['id'];
        $num = 10;
        $start = ($page-1)*$num;
        $sql ="select a.Pay,a.Title,a.CreateTime,a.CompleteTime,a.OrderNum,a.OrderStatue,a.ItemID,b.agent_shouyi,b.agent_id,b.shangji_agent_shouyi,b.shangji_agent_id,b.area_shouyi,b.area_id from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=$uid order by a.CreateTime desc limit $start,$num";
        $res = M('a_order','daili_','DB_READ')->query($sql);
        foreach ($res as $key=>$val){
            $item_info=get_item_infos($val['itemid']);
            $res[$key]['pic']=$item_info['pict_url'];
            if($userid==$val['agent_id']){
                $res[$key]['shouyi']=round($val['agent_shouyi'],2);
            }elseif($userid==$val['shangji_agent_id']){
                $res[$key]['shouyi']=round($val['shangji_agent_shouyi'],2);
            }elseif($userid==$val['area_id']){
                $res[$key]['shouyi']=round($val['area_shouyi'],2);
            }else{
                $res[$key]['shouyi']=0;
            }
            $res[$key]['createtime']=date('Y-m-d H:i:s',$val['createtime']);
            $res[$key]['completetime']=$val['completetime'] ? date('Y-m-d H:i:s',$val['completetime']) : '';
        }
        if(empty($res)){
            $arr = array(
                'code'=>$code,
                'num'=>$num,
                'uid'=>$uid,
                'page'=>$page,
                'data'=>$res,
                'statue'=>0,
                'msg'=>'没有更多的数据'
            );
        }else{
            $arr = array(
                'code'=>$code,
                'num'=>$num,
                'uid'=>$uid,
                'page'=>$page+1,
                'data'=>$res,
                'statue'=>1,
                'msg'=>'请求成功'
            );
        }

        $this->ajaxReturn($arr);
    }

    /*
     * 奖励金数据
     * 参数
     * 1、code：用户code   2、type：奖励类型 3、page：页数
     * 注释：
     * type：【1、邀请下级  2、店主奖励  3、团队奖励】
     * */
    public function get_reward_list_api(){
        $this->check_token();
        $code = I('code','','trim');
        $type = I('type',1,'intval');
        $page = I('page',1,'intval');
        $num = 10;
        if(empty($code)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'获取用户参数错误'
                )
            );
            exit;
        }
        $user = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($user)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'不存在该用户'
                )
            );
            exit;
        }
        if($type == 1){    //邀请下级奖励查询
            $join = " left join daili_b_jiangli on daili_wx_user.ID = daili_b_jiangli.XiaJiUID";
            $userinfo = M('wx_user','daili_','DB_READ')
                        ->field('daili_wx_user.ID,daili_wx_user.member_level,daili_wx_user.reg_app_time,
                        daili_wx_user.HeaderPic,daili_wx_user.Name,daili_wx_user.Phone,daili_b_jiangli.*')
                        ->where(array('daili_wx_user.Pid'=>$user['id'],'daili_b_jiangli.type'=>1))
                        ->join($join)
                        ->order('daili_b_jiangli.Time desc')
                        ->page($page,$num)
                        ->select();
            $page_nums = M('wx_user','daili_','DB_READ')
                ->where(array('daili_wx_user.Pid'=>$user['id'],'daili_b_jiangli.type'=>1))
                ->join($join)
                ->count();
            $page_num = ceil($page_nums/$num);
            $reason = "当前用户下单金额未达到".C('PAY_MONEY')."元";
            foreach($userinfo as $k=>$v){
                $userinfo[$k]['tel'] = substr($v['phone'],0,3).'****'.substr($v['phone'],7,5);
                $userinfo[$k]['identity'] = $this->get_level_msg($v['member_level']);
                $userinfo[$k]['count'] = M('wx_user','daili_','DB_READ')->where(array('Pid'=>$v['id']))->count();
                $userinfo[$k]['reason'] = $v['statue']==0?$reason:"";
                $userinfo[$k]['reg_times'] = date("Y-m-d",$v['reg_app_time']);
            }
            $reward_count = M('wx_user','daili_','DB_READ')
                ->where(array('daili_wx_user.Pid'=>$user['id'],'daili_b_jiangli.type'=>1))
                ->join($join)
                ->count();
            $reward_sum = M('wx_user','daili_','DB_READ')
                ->where(array('daili_wx_user.Pid'=>$user['id'],'daili_b_jiangli.type'=>1))
                ->join($join)
                ->sum('daili_b_jiangli.Money');
        }elseif($type==2){   //邀请店主奖励查询
            $reason = "您未成为店主，无法得到奖励金";
            $join = " left join daili_b_jiangli on daili_wx_user.ID = daili_b_jiangli.XiaJiUID";
            $userinfo = M('wx_user','daili_','DB_READ')
                ->field('daili_wx_user.ID,daili_wx_user.member_level,daili_wx_user.reg_app_time,
                daili_wx_user.HeaderPic,daili_wx_user.Name,daili_wx_user.Phone,daili_b_jiangli.*')
                ->where(array('daili_wx_user.Pid'=>$user['id'],'daili_b_jiangli.type'=>2))
                ->join($join)
                ->order('daili_b_jiangli.Time desc')
                ->page($page,$num)
                ->select();
            $page_nums = M('wx_user','daili_','DB_READ')
                ->where(array('daili_wx_user.Pid'=>$user['id'],'daili_b_jiangli.type'=>2))
                ->join($join)
                ->count();
            $page_num = ceil($page_nums/$num);
            $reward_count = M('wx_user','daili_','DB_READ')
                ->field('daili_wx_user.ID,daili_wx_user.member_level,
                        daili_wx_user.Phone,daili_b_jiangli.*')
                ->where(array('daili_wx_user.Pid'=>$user['id'],'daili_b_jiangli.type'=>2))
                ->join($join)
                ->count();
            $reward_sum = M('wx_user','daili_','DB_READ')
                ->where(array('daili_wx_user.Pid'=>$user['id'],'daili_b_jiangli.type'=>2))
                ->join($join)
                ->sum('daili_b_jiangli.Money');
            foreach($userinfo as $k=>$v){
                $userinfo[$k]['tel'] = substr($v['phone'],0,3).'****'.substr($v['phone'],7,5);
                $userinfo[$k]['identity'] = $this->get_level_msg($v['member_level']);
                $userinfo[$k]['count'] = M('wx_user','daili_','DB_READ')->where(array('Pid'=>$v['id']))->count();;
                $userinfo[$k]['reason'] = $v['statue']==0?$reason:"";
                $userinfo[$k]['reg_times'] = date("Y-m-d",$v['reg_app_time']);
            }
        }elseif($type==3){   //邀请团队奖励查询
            if($user['member_level']==2){   //销售经理
                $str_id = "";
                //先查询所有下级
                $res1 = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>$user['id']))->select();
                foreach ($res1 as $key=>$val){
                    $str_id .= $val['id'].',';
                }
                $str_id=rtrim($str_id,',');
                if(empty($str_id)){
                    $str_id = $user['id'];
                }
                if(!empty($res1)){
                    //查询下下级
                    $res = M('wx_user','daili_','DB_READ')
                        ->where(" Pid=".$user['id']." or  Pid in(".$str_id.")")
                        ->page($page,$num)
                        ->order('reg_app_time desc,SubscribeTime desc')
                        ->select();
                    $page_nums = M('wx_user','daili_','DB_READ')
                        ->where(" Pid=".$user['id']." or  Pid in(".$str_id.")")
                        ->count();
                    $page_num = ceil($page_nums/$num);
                    if($res){
                        foreach ($res as $keys=>$vals){
                            $user_id = $vals['id'];
                            //查询下级的人数
                            $user_num = M('wx_user')->where(array('Pid'=>$user_id))->count();
                            //查询总贡献金
                            //再查作为上级的收益
                            $sql = "select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=$user_id AND b.ShangJiUID=".$user['id'];
                            $sum1 = M('a_order')->query($sql);
                            $sum1 = $sum1[0]['sum'];
                            //再查作为上上级的收益
                            $sql = "select sum(b.ShangShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=$user_id AND b.ShangShangJiUID=".$user['id'];
                            $sum2 = M('a_order')->query($sql);
                            $sum2 = $sum2[0]['sum'];
                            $sum  = $sum1+$sum2;
                            $userinfo[$keys]['id']=$vals['id'];
                            $userinfo[$keys]['count']=$user_num;
                            $userinfo[$keys]['money']=round($sum,2);
                            $userinfo[$keys]['phone']=substr($vals['phone'],0,3).'****'.substr($vals['phone'],7,5);
                            $userinfo[$keys]['tel']=substr($vals['phone'],0,3).'****'.substr($vals['phone'],7,5);
                            $userinfo[$keys]['name']=$val['name'] ? $val['name'] : '无';
                            $userinfo[$keys]['identity'] = $this->get_level_msg($vals['member_level']);
                            $userinfo[$keys]['reg_times'] = date("Y-m-d",$vals['reg_app_time']);
                            $userinfo[$keys]['reason'] = "";
                            $userinfo[$keys]['statue'] = 1;
                        }
                    }
                    $reward_count = M('wx_user','daili_','DB_READ')
                        ->where("Pid=".$user['id']." or Pid in(".$str_id.")")
                        ->count();
                    $str_ids = "";

                    $ress= M('wx_user','daili_','DB_READ')
                        ->where(" Pid=".$user['id']." or  Pid in(".$str_id.")")
                        ->select();
                    foreach ($ress as $k=>$v){
                        $str_ids .= $v['id'].',';
                    }

                    $str_ids=rtrim($str_ids,',');
                    if(!empty($str_ids)){
                        $sql = "select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi"
                            ." as b on a.ID=b.OrderID where b.UID in ($str_ids) AND b.ShangJiUID=".$user['id'] ;
                        $sql2 = "select sum(b.ShangShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi"
                            ." as b on a.ID=b.OrderID where b.UID in ($str_ids) AND b.ShangShangJiUID=".$user['id'] ;
                        $reward_sums = M('a_order')->query($sql);
                        $reward_sums2 = M('a_order')->query($sql2);
                        $reward_sum = $reward_sums[0]['sum']+ $reward_sums2[0]['sum'];
                    }else{
                        $reward_sum = 0;
                    }
                }
            }elseif($user['member_level']==3){  //服务经理
                $userinfo = M('wx_user')
                        ->field('ID,Name,Phone,member_level,reg_app_time,HeaderPic')
                        ->where(array('member_area'=>$user['id']))
                        ->order('reg_app_time desc,SubscribeTime desc')
                        ->page($page,$num)
                        ->select();
                $page_nums = M('wx_user')
                    ->where(array('member_area'=>$user['id']))
                    ->count();
                $page_num = ceil($page_nums/$num);
                $str_ids = "";
                $userinfos = M('wx_user')
                    ->field('ID,Name,Phone,member_level,reg_app_time,HeaderPic')
                    ->where(array('member_area'=>$user['id']))
                    ->select();
                foreach ($userinfos as $k=>$v){
                    $str_ids .= $v['id'].',';
                }
                $str_ids=rtrim($str_ids,',');
                $reward_count = M('wx_user')
                    ->where(array('member_area'=>$user['id']))
                    ->count();
                $sql = "select sum(b.area_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID in ($str_ids)";
                $reward_sums = M('a_order')->query($sql);
                $reward_sum = $reward_sums[0]['sum'];
                if($userinfo){
                    foreach ($userinfo as $key=>$val){
                        $user_id = $val['id'];
                        //查询下级人数
                        $user_num=M('wx_user')->where(array('Pid'=>$user_id))->count();
                        //查询总贡献金
                        $sql = "select sum(b.area_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=$user_id";
                        $sum = M('a_order')->query($sql);
                        $sum = $sum[0]['sum'];
                        $userinfo[$key]['count']=$user_num;
                        $userinfo[$key]['money']=round($sum,2);
                        $userinfo[$key]['phone']=substr($val['phone'],0,3).'****'.substr($val['phone'],7,5);
                        $userinfo[$key]['tel']=substr($val['phone'],0,3).'****'.substr($val['phone'],7,5);
                        $userinfo[$key]['name']=$val['name'] ? $val['name'] : '无';
                        $userinfo[$key]['identity'] = $this->get_level_msg($val['member_level']);
                        $userinfo[$key]['reason'] = "";
                        $userinfo[$key]['reg_times'] = date("Y-m-d",$val['reg_app_time']);
                    }
                }
            }else{  //店主及会员
                $userinfo = M('wx_user')
                    ->field('ID,Name,Phone,member_level,reg_app_time,HeaderPic')
                    ->where(array('Pid'=>$user['id']))
                    ->order('reg_app_time desc,SubscribeTime desc')
                    ->page($page,$num)
                    ->select();
                $page_nums = M('wx_user')
                    ->where(array('Pid'=>$user['id']))
                    ->count();
                $page_num = ceil($page_nums/$num);
                $str_ids = "";
                $userinfos = M('wx_user')
                    ->field('ID,Name,Phone,member_level,reg_app_time,HeaderPic')
                    ->where(array('Pid'=>$user['id']))
                    ->select();
                foreach ($userinfos as $k=>$v){
                    $str_ids .= $v['id'].',';
                }
                $str_ids=rtrim($str_ids,',');
                $reward_count = M('wx_user')
                    ->where(array('Pid'=>$user['id']))
                    ->count();
                $sql = "select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID in ($str_ids) AND b.ShangJiUID=".$user['id'];
                $reward_sums = M('a_order')->query($sql);
                $reward_sum = $reward_sums[0]['sum'];
                if($userinfo){
                    foreach ($userinfo as $key=>$val){
                        $user_id = $val['id'];
                        //查询下级人数
                        $user_num=M('wx_user')->where(array('Pid'=>$user_id))->count();
                        //查询总贡献金
                        $sql = "select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=$user_id AND b.ShangJiUID=".$user['id'];
                        $sum = M('a_order')->query($sql);
                        $sum = $sum[0]['sum'];
                        $userinfo[$key]['count']=$user_num;
                        $userinfo[$key]['money']=round($sum,2);
                        $userinfo[$key]['phone']=substr($val['phone'],0,3).'****'.substr($val['phone'],7,5);
                        $userinfo[$key]['tel']=substr($val['phone'],0,3).'****'.substr($val['phone'],7,5);
                        $userinfo[$key]['reg_times'] = date("Y-m-d",$val['reg_app_time']);
                        $userinfo[$key]['name']=$val['name'] ? $val['name'] : '无';
                        $userinfo[$key]['identity'] = $this->get_level_msg($val['member_level']);
                        $userinfo[$key]['reason'] = "";
                    }
                }
            }
        }else{

        }

        $this->ajaxReturn(
            array(
                'data'=>$userinfo,
                'reward_count'=>$reward_count>0?$reward_count:0,
                'reward_sum'=>$reward_sum>0?sprintf("%.2f",$reward_sum):0,
                'page_num'=>$page_num,
                'statue'=>1
            )
        );
    }
    /***团队、订单数据   结束***/

    /***会员升级介绍   开始***/
    /*
     * 获取身份升级的支付金额参数
     * 参数
     * 1、code：用户code
     * */
    public function get_upgrade_data(){
        $code = I('code');
        if(empty($code)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'用户参数错误'
                )
            );
        }else{
            //查询逻辑  暂定
            $this->ajaxReturn(
                array(
                    'statue'=>1,
                    'pay_money'=>99
                )
            );
        }
    }
    /***会员升级介绍   结束***/

    /***直播间   开始***/

    //直播间接口1
    public function live_room_data(){
        if(IS_POST){
            $id = I('post.id',0,'intval');
            $code = I('post.code','','trim');
            $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
//            if($userinfo['gzhtoken']=='gh_b676e24225c8' || $userinfo['gzhtoken']=='gh_b676e24225c8' || $userinfo['gzhtoken']=='gh_b676e24225c8'){
//                $where ="id <".$id." and ( token='gh_b676e24225c8' or token='gh_b676e24225c8'  or token='gh_b676e24225c8 )'";
//            }else{
//                $where ="id <".$id." and token='".$userinfo['gzhtoken']."'";
//            }
            $where ="id <".$id." and token='".$userinfo['gzhtoken']."'";
            $info = M('a_zhibo_items','daili_','DB_DAILI_READ')->where($where)->order('send_time desc')->limit(10)->select();
            if(empty($info)){
                $info = M('a_zhibo_items','daili_','DB_DAILI_READ')->where("id <".$id." and token='gh_90c6882faaf9'" )->order('send_time desc')->limit(10)->select();
            }
            //$info = M('a_items')->where('id <'.$id)->order('id desc')->limit(10)->select();
            $count = count($info)>1?(count($info)-1):0;
            $this->ajaxReturn(
                array(
                    'info'=>array_reverse($info),
                    'statue'=>1,
                    'itemid'=>$info[$count]['id']
                )
            );
        }
    }
    //直播间接口2
    public function live_room_update(){
        if(IS_POST){
            $code = I('post.code','','trim');
            $time = I('post.find_time',time(),'intval');
            $last_time = time();
            $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
            $where ="send_time >".$time." and  send_time<=".$last_time." and token='".$userinfo['gzhtoken']."'";
            $info = M('a_zhibo_items','daili_','DB_DAILI_READ')->where($where)->order('send_time asc')->select();
            if(empty($info)){
                $info = M('a_zhibo_items','daili_','DB_DAILI_READ')->where("send_time >=".$time." and  send_time<= ".$last_time." and token='gh_90c6882faaf9'" )->order('send_time asc')->select();
            }
            $count = count($info)>1?(count($info)-1):0;
            if(!empty($info)){
                $this->ajaxReturn(
                    array(
                        'info'=>array_reverse($info),
                        'statue'=>1,
                        'find_time'=>$last_time,
                        'count'=>$count,
                    )
                );
            }else{
                $this->ajaxReturn(
                    array(
                        'info'=>'',
                        'statue'=>0,
                        'find_time'=>$last_time,
                        'count'=>$count
                    )
                );
            }

        }
    }
    //直播间接口3
    public function get_liveroom_coupon(){
        if(IS_POST){
            $itemid = I('post.id');
            $code = I('post.code');
            $shopinfo = M('a_zhibo_items','daili_','DB_DAILI_READ')->where(array('id'=>$itemid))->find();
            $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
            if(empty($shopinfo)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'不存在该商品'
                    )
                );
            }
            if(empty($userinfo)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'邀请码错误'
                    )
                );
            }
            $r = S('get_liveroom_coupon'.$itemid.$code);
            if(!$r){
                $gzh_id = M('a_media')->where(array('token'=>$userinfo['gzhtoken']))->getField('id');
                $ress = $this->get_couponinfo($shopinfo['num_iid'],$userinfo['mediaid'],$userinfo['adid'],$shopinfo['youhuiquan']);
                $tkl = json_decode($this->itemsTKLing($shopinfo['pic_url'],$shopinfo['title'],$ress['coupon_click_url']),true);
                $this->set_up_log($ress['coupon_click_url'],$userinfo['gzhtoken'],$tkl['data']['model'],$shopinfo['num_iid'],'',$userinfo['phone'],$gzh_id['new_alimama_id']);
                $r = array(
                    'statue'=>1,
                    'info'=>$shopinfo,
                    'tkl'=>$tkl['data']['model'],
                    'ehy'=>$ress['coupon_click_url']
                );
                S('get_liveroom_coupon'.$itemid.$code,$r);
                $this->ajaxReturn($r);
            }else{
                $this->ajaxReturn($r);
            }
        }
    }
    //直播间接口4
    public function get_liveroom_shopinfo(){
        if(IS_POST){
            $numid = I('post.numid');
            $info = M('a_zhibo_items','daili_','DB_DAILI_READ')->field('num_iid,pic_url,title,price,volume,youhuiquan_je,movie_url,recommend_reason')->where(array('num_iid'=>$numid))->find();
            $this->ajaxReturn(
                array(
                    'info'=>$info
                )
            );
        }
    }

    /***直播间   结束***/




    /***公用方法   开始***/
    /*
     * 获取用户等级身份
     * 参数
     * 1、$data：用户等级值
     * */
    public function get_level_msg($data){
        switch($data){
            case -1:
                $member_level='游客';
                break;
            case 0:
                $member_level='会员';
                break;
            case 1:
                $member_level='店主';
                break;
            case 2:
                $member_level='服务经理';
                break;
            case 3:
                $member_level='区域合伙人';
                break;
        }
        return $member_level;
    }
    /***公用方法   结束***/
    //APP个人中心分享商城页面
    public function fx_index_app(){
        if(IS_POST){
            $page = I('post.page',1,intval);
            $app_item = M('a_items','daili_','DB_DAILI_READ');
            $sort = I('get.sort');
            switch($sort){
                case 'volume':$order = "volume desc,ordid asc";break;
        
                case 'price':$order = "coupon_price asc,ordid asc";break;
        
                case 'yhq':$order = "youhuiquan_je desc,ordid asc";break;
        
                default:$order = "ordid asc,id desc,youhuiquan_je desc";
            }
            $infos = $app_item->where(array('daili_url'=>array('neq',''),'commission_rate'=>array('GT',10000)))->page($page,20)->order($order)->select();
            $arr = array(
                'status'=>1,
                'content'=>$infos
            );
            $this->ajaxReturn($arr);exit;
        }else{
            $code = I('get.code');
            if(empty($code)){
                $this->error("邀请码参数丢失");
                exit;
            }
            $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
            $sort = I('get.sort');
            $cate = M('a_cate')->where('is_show = 1')->order('sort asc')->select();
            $lunbotu = M('a_lunbotu','daili_','DB_DAILI_READ')->where('type=1')->order('ordid asc')->select();
            $gzh = M('a_media')->where(array('token'=>$token))->find();
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
            $fx_url = $protocol.$_SERVER[HTTP_HOST];
            $this->assign('fx_url',$fx_url);
            $this->assign('gzh',$gzh);
            $this->assign('code',$code);
            $this->assign('lunbotu',$lunbotu);
            $this->assign('cate',$cate);
            $this->assign('pid',$userinfo['id']);
            $this->assign('sort',$sort);
            $this->display();
        }
    }
    //分享普通商品列表页
    public function fx_newcate_app(){
        if(IS_POST){
            $pid = I('get.pid');
            $cateid = I('get.cateid');
            $key = I('get.key');
            $sort = I('get.sort');
            $page = I('post.page',1,intval);
            $price1 = I('get.price1');
            $price2 = I('get.price2');
            if(!empty($price1) && !empty($price2)){
                $where['coupon_price'] = array('between',array($price1,$price2));
            }else{
                if(!empty($price1) && empty($price2)){
                    $where['coupon_price'] = array('EGT',$price1);
                }elseif(empty($price1) && !empty($price2)){
                    $where['coupon_price'] = array('ELT',$price2);
                }
            }
            if(!empty($cateid)){$where['cate_id']=$cateid;}
            if(!empty($key)){$where['title']=array('like','%'.$key.'%');}
            $where['pass'] = 1;
            $where['daili_url'] = array('neq','');
            $where['commission_rate'] = array('GT',10000);
            $app_item = M('a_items','daili_','DB_DAILI_READ');
            switch($sort){
                case 'volume':$order = "volume desc,id desc";break;
    
                case 'price':$order = "coupon_price asc";break;
    
                case 'yhq':$order = "youhuiquan_je desc";break;
    
                default:$order = "id desc,volume desc,youhuiquan_je desc";
            }
            $infos = $app_item->where($where)->page($page,20)->order($order)->select();
            $arr = array(
                'status'=>1,
                'content'=>$infos,
                'uid'=>$pid
            );
            $this->ajaxReturn($arr);exit;
        }else{
            $code = I('get.code');
            if(empty($code)){
                $this->error("参数丢失");
                exit;
            }
            $price1 = I('get.price1');
            $price2 = I('get.price2');
            $pid = I('get.pid',0,intval);
            $cateid = I('get.cateid');
            $key = I('get.key');
            $sort = I('get.sort');
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
            $fx_url = $protocol.$_SERVER[HTTP_HOST];
            $this->assign('fx_url',$fx_url);
            $this->assign('pid',$pid);
            $this->assign('code',$code);
            $this->assign('cateid',$cateid);
            $this->assign('key',$key);
            $this->assign('sort',$sort);
            $this->assign('price1',$price1);
            $this->assign('price2',$price2);
            $this->display();
        }
    }
    //分享普通商品详情页
    public function fx_details_app(){
        $code = I('get.code');
        //验证是否为微信浏览器
        $agent=strpos($_SERVER["HTTP_USER_AGENT"],'MicroMessenger');
        if(!$agent){
            $this->assign('agent',0);
        }else{
            $this->assign('agent',1);
        }
        if(empty($code)){
            $this->assign('msg','参数丢失！');
            $this->display();exit;
        }
        $num_iid = I('get.itemid');
        $pid = I('get.uid',0,intval);
        //查询用户信息
        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        $tgwid = $userinfo['tgwid'];
        $tgw_arr = explode('_',$tgwid);
        $token = $userinfo['gzhtoken'];
        //获取当前公众号信息
        $gzh_id = M('a_media')->where(array('token'=>$token))->getField('id');
        //获取当前公众号的佣金比
        $ratio = M('a_config_copy')->where(array('MediaID'=>$gzh_id))->getField('ShouYiBi');
        $info  = M('a_items','daili_','DB_DAILI_READ')->where(array('num_iid'=>$num_iid))->find();
        $infos = M('a_items','daili_','DB_DAILI_READ')->where(array('cate_id'=>$info['cate_id']))->limit(6)->select();
        $ress = $this->get_couponinfo($num_iid,$tgw_arr[2],$tgw_arr[3],$info['youhuiquan']);
        //$ress = $this->change_couponinfo($code,'',$pid,$num_iid,$info['youhuiquan'],1);
        if(empty($ress['coupon_click_url'])){
            $this->assign('msg','商品失效，请浏览其他商品');
            $this->display();
            exit;
        }
        $res_tb_ling = $this->itemsTKLing($info['pic_url'], $info['title'], $ress['coupon_click_url']);
        $res_tb_ling = json_decode($res_tb_ling, true);
        $tkl = $res_tb_ling['data']['model'];
        //$this->set_up_log($ress['coupon_click_url'],'app',$tkl,$num_iid,$info['recommend_reason'],$arr['account'],$arr['alimama_pid']);
        $commission_rate = $ress['max_commission_rate']*100;
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        $fx_url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $res = add_pid_log($arr['userinfo']['id'],$arr['alimama_pid'],$num_iid,$info['daili_url'],$ress['coupon_click_url'],'fx_details','app',$code,"$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");
        $info['ratio'] = sprintf("%.2f",($info['coupon_price']*$commission_rate/10000*0.9*$ratio/100));
        $pid = ($arr['userinfo']['id'] =="")?$pid:$arr['userinfo']['id'];
        $info['tkl'] =$tkl;
        $this->assign('fx_url',$fx_url);
        $this->assign('info',$info);
        $this->assign('url',$ress['coupon_click_url']);
        $this->assign('infos',$infos);
        $this->assign('pid',$pid);
        $this->assign('code',$code);
        $this->display();
    }
    //文档查看页面
    public function view(){
        $id = I('id');
        $res = M('article')->where(array('id'=>$id))->find();
        $this->assign('res',$res);
        $this->display();
    }
    //APP下部分中间会员按钮
    public function huiyuan(){
        $code = I('code');
        $parame = array($code);
        $token = $this->get_token($parame);
        //查询用户信息
        $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
        if($userinfo['member_level']==0){
            $url = C('APP_API_URL')."/Index/is_dianzhu?code=$code&token=$token";
        }elseif($userinfo['member_level']==1){
            $url = C('APP_API_URL')."/Index/is_dianzhu2?code=$code&token=$token";
        }else{
            $url = C('APP_API_URL')."/Index/is_dianzhu1?code=$code&token=$token";
        }
        $this->assign('userinfo',$userinfo);
        $this->assign('url',$url);
        $this->display();
    }
    //用户为会员页面
    public function is_dianzhu(){
        $code = I('code');
        //查询用户
        $parame = array($code);
        $token = $this->get_token($parame);
        
        $user = M('wx_user')->where(array('invitation_code'=>$code))->find();
        $img=C('LOCAL_IMG_URL').'/Uploads/fls2.png';
        $bth_img=C('LOCAL_IMG_URL').'/Uploads/fls_btn.png';
        $this->assign('img',$img); 
        $this->assign('btn_img',$bth_img);
        $url = C('APP_API_URL')."/Index/member_upgrade?code=$code&token=$token";
        $this->assign('url',$url);
        $this->display();
    }
    //用户为店主页面
    public function is_dianzhu1(){
        $code = I('code');
        //查询用户
        $user = M('wx_user')->where(array('invitation_code'=>$code))->find();
        //查询下级和下下级店主用户数量
        $res = M('wx_user')->where(array('member_level'=>1,'Pid'=>$user['id']))->select();
        $count = 0;
        foreach ($res as $key=>$val){
            $result = M('wx_user')->where(array('member_level'=>1,'Pid'=>$val['id']))->count();
            $count += $result;
        }
        $count =$count+count($res);
        $img=C('LOCAL_IMG_URL').'/Uploads/fw3.png';
        $bth_img=C('LOCAL_IMG_URL').'/Uploads/fls_btn.png';
        $this->assign('img',$img);
        $this->assign('btn_img',$bth_img);
        $this->assign('count',$count);
        $this->assign('member_level',$user['member_level']);
        $this->display();
    }
    //用户为销售经理
    public function is_dianzhu2(){
        $code = I('code');
        //查询用户
        $user = M('wx_user')->where(array('invitation_code'=>$code))->find();
        //查询下级和下下级店主用户数量
        $res = M('wx_user')->where(array('member_level'=>1,'Pid'=>$user['id']))->select();
        $count = 0;
        foreach ($res as $key=>$val){
            $result = M('wx_user')->where(array('member_level'=>1,'Pid'=>$val['id']))->count();
            $count += $result;
        }
        $count =$count+count($res);
        $img=C('LOCAL_IMG_URL').'/Uploads/xs.png';
        
        $bth_img=C('LOCAL_IMG_URL').'/Uploads/fls_btn.png';
        $this->assign('img',$img);
        $this->assign('btn_img',$bth_img);
        $this->assign('count',$count);
        $this->assign('member_level',$user['member_level']);
        $this->display();
    }
}