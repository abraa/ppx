<?php
namespace App\Controller;
use Think\Controller;
class ApiController extends Controller {
    public $config0;
    public $config1;
    public $config2;
    public $config3;
    public function _initialize(){
        S(array(
                'type'=>'Memcache',
                'host'=>'127.0.0.1',
                'port'=>'11211',
                'prefix'=>'think',
                'expire'=>3
            )
        );
        $ip = get_client_ip();

        //查询会员配置
        $res = M('a_config_copy','daili_','DB_READ')->select();
        foreach ($res as $key=>$val){
            $config0[$val['token']]=$val;
        }
        $this->config0=$config0;
        //查询店主配置
        $res = M('wx_user_level','daili_','DB_READ')->where(array('member_level'=>1))->select();
        foreach ($res as $key=>$val){
            $config1[$val['token']]=$val;
        }
        $this->config1=$config1;
        //查询销售经理配置
        $res = M('wx_user_level','daili_','DB_READ')->where(array('member_level'=>2))->select();
        foreach ($res as $key=>$val){
            $config1[$val['token']]=$val;
        }
        $this->config2=$config2;
        //查询服务经理配置
        $res = M('wx_user_level','daili_','DB_READ')->where(array('member_level'=>3))->select();
        foreach ($res as $key=>$val){
            $config3[$val['token']]=$val;
        }
        $this->config1=$config3;
    }
    //获取域名
    public function get_url(){
        $arr = array(
            array('url'=>'http://app.gelohui.cn','statue'=>1,'code'=>'wce6zcjd'),
            //array('url'=>'http://app.jikuaida.cn','statue'=>1,'code'=>'wce6zcjd')
            //无效不能用array('url'=>'http://app.sopianyi.com','statue'=>1,'code'=>'wce6zcjd')
            //array('url'=>'http://app.leader678.com','statue'=>1,'code'=>'wce6zcjd')
            //array('url'=>'http://app.yinfafa.cn','statue'=>1,'code'=>'wce6zcjd')
        );
        $this->ajaxReturn($arr);
    }

    public function send_code(){
        $code = I('code');
        $ios = I('a');
        $is_ios = ($ios=="test")?"0":"1";
        $res = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($res)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'不存在该代理用户'
                )
            );
        }else{
            $this->add_statistics($res['id'],2,$is_ios);
            $this->ajaxReturn(
                array(
                    'statue'=>1,
                    'msg'=>'成功'
                )
            );
        }
    }

    /* 首页部分 开始 */

    /**
     * 首页  轮播图查询、商品分类查询、商品列表查询
     *  参数 ：
     * 1、page：页数
     *  接口地址：
     * 注释：当页数大于1时，只返回商品数据
     * */
    public function index(){
        $this->check_token_app();
        $code = I('code');
        $page = I('page',1,'intval');
        $users = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        $token = $users['gzhtoken'];
        //查询用户等级获取pid，分成比等信息
        if($users){
            $user_level = get_level($users['id'],$users['member_level'],$token);
            
            $daili_rate = ($user_level['b_level1']/100)*0.9;
        }
        //今日时间
        $now_start = mktime(0,0,0,date('m'),date('d'),date('Y'));
        $now_last  = mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
        $add_log = M('a_app_index_log','daili_','DB_READ')->where(array('code'=>$code,'token'=>$tokens,'add_time'=>array('between',array($now_start,$now_last))))->find();
        if(empty($add_log)){
            $ip_address = get_client_ip();
            import('Org.Net.IpLocation');// 导入IpLocation类
            $ip = new \IpLocation('UTFWry.dat'); // 实例化类 参数表示IP地址库文件
            $area = $ip->getlocation($ip_address); // 获取某个IP地址所在的位置
            $ip_city = $area['country'];
            $add_data = array(
                'code'=>$code,
                'token'=>$tokens,
                'add_time'=>time(),
                'ip'=>$ip_address,
                'country'=>$ip_city,
                'last_visit_time'=>time()
            );
            M('a_app_index_log')->add($add_data);
        }else{
            M('a_app_index_log')->where(array('id'=>$add_log['id']))->save(array('last_visit_time'=>time()));
        }
       
        $r = S('r'.$page.$code);
        if(!$r){
            $user = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
            $token = $user['gzhtoken'];
            $file = getcwd().'/Application/Home/Conf/'.$token.'_conf.php';
            if(is_file($file)){
                $config = include($file);
                $config['a']=$config['aa'];
                unset($config['aa']);
            }else{
                $config = array(
                    'share_title'=>'有你想象的优惠，比你想象的更省钱，更多优惠，下载赚多多即可享受',
                    'is_show_shop'=>1,//是否显示分享我的商城  1显示 0不显示
                    'a'=>0,           //苹果上面是否使用百川领券跳转0否 1是
                    'b'=>0,           //是否不使用友盟分享微博1不使用 0使用
                    'c'=>1,           //是否具体分享页优先使用友盟微博分享 1是0否
                    'd'=>0,           //是否显示今日新品，9块钱9包邮，好券优选，品牌爆款 1是 0 否
                    'is_show_live'=>1,//是否显示直播

                );
            }
            //根据code查询用户
            if($page<=1){
                $arr_token =array('gh_26c51afe50df','gh_b676e24225c8','chuankeyouhui2');
                if(in_array($token,$arr_token)){
                    $w['type'] = 1;
                    $w['id']=array('neq',51);
                    $w['token']=array('in',$arr_token);
                    $lbt = M('a_lunbotu','daili_','DB_DAILI_READ')->field('id,title,pic_url,url,text')->where($w)->order('ordid asc')->select();
                    if(!$lbt){
                        $lbt = M('a_lunbotu','daili_','DB_DAILI_READ')->field('id,title,pic_url,url,text')->where(array('type'=>1,'token'=>'gh_90c6882faaf9','id'=>array('neq',51)))->order('ordid asc')->select();
                    }
                    //查询启动图
                    $start_pic = M('pic','daili_','DB_READ')->where(array('token'=>array('in',$arr_token)))->order('time desc')->find();
                }else{
                    //根据token查询轮播图
                    $lbt = M('a_lunbotu','daili_','DB_DAILI_READ')->field('id,title,pic_url,url,text')->where(array('type'=>1,'token'=>$token,'id'=>array('neq',51)))->order('ordid asc')->select();
                    if(!$lbt){
                        $lbt = M('a_lunbotu','daili_','DB_DAILI_READ')->field('id,title,pic_url,url,text')->where(array('type'=>1,'token'=>'gh_90c6882faaf9','id'=>array('neq',51)))->order('ordid asc')->select();
                    }
                    //查询启动图
                    $start_pic = M('pic','daili_','DB_READ')->where(array('token'=>$token))->order('time desc')->find();
                }
                foreach ($lbt as $key=>$val){
                    if($val['url']){
                        $lbt[$key]['text']='';
                        $pid = $user['tgwid']==""?"mm_33702067_36264112_129592722":$user['tgwid'];
                        if(strpos($val['url'],'?')===false){
//                            $lbt[$key]['url'] = $val['url']."/pid/".$pid;
//                            unset($val['url']);
                        }else{
                            $lbt[$key]['url'] = $val['url']."&pid=".$pid;
                            unset($val['url']);
                        }

                    }
                }
                $type = M('a_cate','daili_','DB_READ')->field('id,name,cateimg,keywords')->where(array('is_show'=>1))->order('sort asc')->select();
                if($start_pic){
                    $start_pic=$start_pic['pic_url'];
                }else{
                    $start_pic=M('pic','daili_','DB_READ')->order('time desc')->find();
                    if($start_pic){
                        $start_pic=$start_pic['pic_url'];
                    }else{
                        $start_pic="";
                    }
                }
            }else{
                $lbt = "";
                $type = "";
                $start_pic="";
            }
            $count = M('a_items','daili_','DB_DAILI_READ')->where(array('commission_rate'=>array('GT',15000)))->count();
            $page_num = ceil($count/20);
            $shopinfo = M('a_items','daili_','DB_DAILI_READ')->field('id,short_title,volume,commission_rate,pic_url,coupon_price,price,youhuiquan_je,num_iid,shop_type,movie_url')->where(array('commission_rate'=>array('GT',15000)))->order('ordid asc,id desc')->page($page,20)->select();
            $shoptype_pic = M('a_shoptype_pic','daili_','DB_DAILI_READ')->order('sort asc')->select();
            $bk_list=array();
            $zhuanchang_area=array();
            foreach ($shoptype_pic as $val){
                if($val['type']=='版块'){
                    $bk_list[]=$val;
                }
                if($val['type']=='专题'){
                    if($val['url']){
                        $val['url'] = $val['url'].'&code='.$code;
                    }
                    $val['img'] = $val['shoptype_pic'];
                    $val['type']= $val['type_new'];
                    unset($val['shoptype_pic']);
                    unset($val['type_new']);
                    $zhuanchang_area[]=$val;
                }
                if($val['type']=='新版块'){
                    $val['img'] = $val['shoptype_pic'];
                    $val['type']= $val['type_new'];
                    unset($val['shoptype_pic']);
                    unset($val['type_new']);
                    $new_bk_list[]=$val;
                }
                if($val['type']=='新版块1'){
                    $val['img'] = $val['shoptype_pic'];
                    $val['type']= $val['type_new'];
                    unset($val['shoptype_pic']);
                    unset($val['type_new']);
                    $new_bk_list1[]=$val;
                }
            }

            /* //获取当前公众号信息
            $gzh_id = M('a_media')->where(array('token'=>$user['gzhtoken']))->getField('id');
            //获取当前公众号的佣金比
            $ratio = M('a_config_copy')->where(array('MediaID'=>$gzh_id))->getField('ShouYiBi');
            $daili_rate = 0.9*$ratio/100; */
            if(!$token){
                $token='gh_90c6882faaf9';
            }
            $huiyuan=M('wx_huiyuan_page','daili_','DB_READ')->where(array('token'=>$token))->select();

            $count_user = M('wx_user','daili_','DB_READ')->count();
            $count_user = $count_user*22;
            $count_money= round(time()/111);
            $r = array(
                'config'=>$config,
                'lbt'=>$lbt,
                'type'=>$type,
                'start_pic'=>$start_pic,
                'data'=>array(
                    'count'=>$count,
                    'page_sum'=>$page_num,
                    'page'=>$page,
                    'shopinfo'=>$shopinfo,
                    'pic'=>array(
                        1=>$bk_list[0]['shoptype_pic'],
                        2=>$bk_list[1]['shoptype_pic'],
                        3=>$bk_list[2]['shoptype_pic'],
                        4=>$bk_list[3]['shoptype_pic'],
                    ),
                    'zhuanchang_area'=>$zhuanchang_area,//专题
                    'new_bk'=>$new_bk_list,//新版块
                    'new_bk1'=>$new_bk_list1,
                    'daili_rate'=>$daili_rate>0?$daili_rate:0,
                    'huiyuan'=>$huiyuan,
                    'load_data'=>array(
                        'count_user'=>$count_user,
                        'count_money'=>$count_money
                    )
                )
            );
            S('r'.$page.$code,$r);
        }
        $this->ajaxReturn($r);
    }

    //统计app的激活量
    public function tongji_jihuo(){
        $platform = I('platform');
        $sys_version = I('sys_version');
        $equipment_id    = I('equipment_id');
        $phone_models    = I('phone_models');
        $app_version     = I('app_version');
        $application_name= I('application_name');
        $app_channel     = I('app_channel');
        $is_wifi         = I('is_wifi');
        $package_name    = I('package_name');
        $ip_address = get_client_ip();
        import('Org.Net.IpLocation');// 导入IpLocation类
        $Ip = new \IpLocation('UTFWry.dat'); // 实例化类 参数表示IP地址库文件
        $area = $Ip->getlocation($ip_address); // 获取某个IP地址所在的位置
        //echo '<pre>';
        //print_r($area);exit;
        $ip_city = $area['country'];
        $data = array(
            'platform'=>$platform,
            'sys_version'=>$sys_version,
            'equipment_id'   =>$equipment_id,
            'phone_models'   =>$phone_models,
            'app_version'    =>$app_version,
            'application_name'=>$application_name,
            'app_channel'    =>$app_channel,
            'is_wifi'        =>$is_wifi,
            'ip_address'     =>$ip_address,
            'ip_city'        =>$ip_city,
            'package_name'   =>$package_name,
            'add_time'       =>time()
        );
        $where = array(
            'platform'=>$platform,
            'equipment_id'=>$equipment_id,
            'package_name'=>$package_name
        );
        $res = M('app_tongji_jihuo')->where($where)->find();
        if(!$res){
            $res = M('app_tongji_jihuo')->add($data);
        }
        $data1 = array(
            'platform'=>$platform,
            'equipment_id'=>$equipment_id,
            'package_name'=>$package_name,
            'is_wifi'=>$is_wifi,
            'start_time'=>time(),
        );
        $res1 =M('app_tongji_zaixian')->add($data1);
        if($res && $res1){
            $arr = array(
                'code'=>1,
                'msg'=>'添加成功',
                'id'=>$res1
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg' =>'添加失败'
            );
        }
        echo json_encode($arr);
    }
    //统计在线的时常
    public function tongji_zaixian(){
    
        $equipment_id    = I('equipment_id');
        $package_name    = I('package_name');
        $id              = I('id');
        $is_wifi         = I('is_wifi');
        $data = array(
            'equipment_id'=>$equipment_id,
            'pachage_name'=>$package_name,
            'end_time'=>time()
        );
        $res = M('app_tongji_zaixian')->where('id='.$id)->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'调用成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg' =>'调用失败'
            );
        }
        echo json_encode($arr);
    }
    //APP端上传用户头像
    public function uploadimg(){
        $code=I('code');
        $photo=I('photo');
        $user=M('wx_user');
        $exist=$user->where(array('invitation_code'=>$code))->find();
        if(empty($exist)){
            $arr = array(
                'code'=>0,
                'msg'=>'code参数错误'
            );
            $this->ajaxReturn($arr);
        }
        $time=time();
        $file=getcwd()."/Uploads/user_imgs/$code"."_"."$time.jpg";
        
        $url = C('LOCAL_IMG_URL')."/Uploads/user_imgs/$code"."_"."$time.jpg";
        $img=base64_decode($photo);
        $a=file_put_contents($file, $img);
        if($a){
            $d=array(
                'ID'=>$exist['id'],
                'HeaderPic'=>$url,
            );
            $res = M('wx_user')->save($d);
            if($res){
                $arr = array(
                    'code'=>1,
                    'img_path'=>$url,
                    'msg'=>'上传成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'上传失败'
                );
            }
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'图片上传失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    /**
     * 单个轮播图详情查询
     *  参数 ：
     * 1、id：轮播图id  2、page：页数（默认为1） 3、sort：排序
     * 接口地址：http://app.taokehelp.cn/Api/lbt_details
     * 注释：
     * 一、sort参数：（默认为空，1、1 =>券后  2、2=>销量  3、3=>超优惠）
     * */
    public function lbt_details(){
        $id = I('id');
        $sorts = I('sort');
        $page = I('page',1,'intval');
        $r = S('lbt_details'.$id.$sorts.$page);
        if(!$r){
            $sort = $sorts == 1?"coupon_price asc":($sorts == 2?"volume desc":($sorts == 3?"youhuiquan_je desc":""));
            $order = ($sort=="")?"ordid asc,id desc":$sort.",ordid asc,id desc";
            $where['_string'] = 'FIND_IN_SET('.$id.',type_id)';
            $count = M('a_items','daili_','DB_DAILI_READ')->where($where)->count();
            $page_num = ceil($count/20);
            $shopinfo = M('a_items','daili_','DB_DAILI_READ')->field('id,short_title,volume,pic_url,coupon_price,price,youhuiquan_je,num_iid,shop_type,commission_rate')->where($where)->order($order)->page($page,20)->select();
            $r = array(
                'statue'=>1,
                'msg'=>'成功',
                'data'=>array(
                    'count'=>$count,
                    'page_sum'=>$page_num,
                    'page'=>$page,
                    'shopinfo'=>$shopinfo
                )
            );
            S('lbt_details'.$id.$sorts.$page,$r);
        }
        $this->ajaxReturn($r);
    }

    /**
     *  各种分类下的商品列表
     *  参数 ：
     * 1、type：数据类型（例如：今日上新、爆款等） 2、shoptype_id：商品分类id  3、sort：排序 4、page：页数
     * 接口地址：http://app.taokehelp.cn/Api/get_type_shopdetails
     * 注释：
     *  一、type参数：(1、1 =>今日上新  2、2=>9.9包邮  3、3=>好券优选  4、4=>人气宝贝
     *  5、5=>品牌爆款  6、6=>聚划算  7、7=>淘抢购  8、8=>爆单款 9、9=>大额券  10、10=>好货疯抢  11、11=>视频商品)
     *  二、shoptype_id参数：（分类的id）
     *  三、sort参数：（默认为空，1、1 =>券后  2、2=>销量  3、3=>超优惠）
     *  四、page参数：（页数，默认为1）
     * */
    public function get_type_shopdetails(){
        $type = I('type');
        $shoptype_id = I('shoptype_id');
        $sorts = I('sort');
        $page = I('page',1,'intval');
        $str_key = md5("get_type_shopdetails?type=$type&shoptype_id=$shoptype_id&sorts=$sorts&page=$page");
        $r = S($str_key);
        if(!$r){
            $sort = $sorts == 1?"coupon_price asc":($sorts == 2?"volume desc":($sorts == 3?"youhuiquan_je desc":""));
            $where['commission_rate'] = array('GT',15000);
            $order = "ordid asc,id desc";
            $where['coupon_price'] = array('GT',0);
            switch ($type){
                case '1'://今日上新
                    $order ="add_time desc,ABS(`coupon_price`-50) asc";
                    $order = ($sort=="")?$order:($sort.",".$order);
                    break;
                case '2'://9.9包邮
                    $where['_string'] = 'coupon_price<=9.9';
                    //                $where['coupon_price'] = array('ELT',9.9);
                    $order = ($sort=="")?$order:($sort.",".$order);
                    break;
                case '3'://好券优选
                    $where['youhuiquan_je'] = array('GT',5);
                    $order = ($sort=="")?$order:($sort.",".$order);
                    break;
                case '4'://人气宝贝
                    $where[''] = "";
                    $order = ($sort=="")?$order:($sort.",".$order);
                    break;
                case '5'://品牌爆款
                    $where['coupon_price'] = array('gt',50);
                    $where['shop_type']='B';
                    $order ="volume desc,add_time desc";
                    $order = ($sort=="")?$order:($sort.",".$order);
                    break;
                case '6'://聚划算
                    $where['activity'] = "聚划算";
                    $order = ($sort=="")?$order:($sort.",".$order);
                    break;
                case '7'://淘抢购
                    $where['activity'] = "淘抢购";
                    $order = ($sort=="")?$order:($sort.",".$order);
                    break;
                case '8'://爆单款
                    if($sort==""){
                        $where['coupon_price'] = array('gt',50);
                    }
                    $where['shop_type']='B';
                    $order ="volume desc,add_time desc";
                    $order = ($sort=="")?$order:($sort.",".$order);
                    break;
                case '9'://大额券
                    $where['youhuiquan_je'] = array('GT',100);
                    $order = ($sort=="")?$order:($sort.",".$order);
                    break;
                case '10'://好货疯抢
                    $order = ($sort=="")?$order:($sort.",".$order);
                    $where['commission_rate'] = array('GT',15000);
                    //$where['coupon_price'] = array('ELT',20);
                    $where['coupon_price'] = array('between',array('0.01','20'));
                    break;
                case '11'://视频商品
                    $order = ($sort=="")?$order:($sort.",".$order);
                    $where['commission_rate'] = array('GT',15000);
                    $where['movie_url'] = array('EXP','IS NOT NULL');
                    break;
                default:
                    $type_id = ($shoptype_id==32)?4:$shoptype_id;
                    $where['cate_id'] = $type_id;
                    $order = ($sort=="")?$order:($sort.",".$order);
                    break;
            }
            // $where['coupon_price'] = array('GT',0);
            $count = M('a_items','daili_','DB_DAILI_READ')->where($where)->count();
            $page_num = ceil($count/20);
            $shopinfo = M('a_items','daili_','DB_DAILI_READ')->field('id,short_title,volume,pic_url,coupon_price,price,youhuiquan_je,num_iid,shop_type,movie_url,commission_rate')->where($where)->order($order)->page($page,20)->select();
            $r = array(
                'data'=>array(
                    'count'=>$count,
                    'page_sum'=>$page_num,
                    'page'=>$page,
                    'shopinfo'=>$shopinfo,
                )
            );
            S($str_key,$r);
        }
        $this->ajaxReturn($r);
    }


    /**
     * 好券搜索
     *  参数 ：
     * 1、key：关键词  2、sort：排序  3、page：页数  4、is_record：是否记录搜索记录（1代表记录，不记录不传值）
     * 5、mac_address：Mac地址（可不传）   6、is_only：【1：匹配，默认不填】【匹配15字以上标题数据】 7：cateid：分类id
     * 8、code：邀请码
     * 接口地址：http://app.taokehelp.cn/Api/find_shop
     *  注释：
     *  一、sort参数：（默认为空，1、1 =>券后  2、2=>销量  3、3=>超优惠）
     *  二、page参数：（页数，默认为1）
     * */
    public function find_shop(){
        $key = str_replace(' ','',str_replace("\n","",I('key')));
        $key = str_replace('瓷肌','',$key);
        $sorts = I('sort');
        $page = I('page',1,'intval');
        $cateid = I('cateid','','intval');
        $is_only = I('is_only');
        $is_record = I('is_record');
        $mac_address = I('mac_address');
        $code = I('code');
        $users = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if($users){
            $user_level = get_level($users['id'],$user['member_level'],$users['gzhtoken']);
            $daili_rate = ($user_level['b_level1']/100)*0.9;
        }
        $r = S('find_shop'.$key.$sorts.$page.$cateid.$is_only.$is_record.$mac_address.$code);
        $r='';
        if(!$r){
            if(!$key){
                $this->ajaxReturn(array('statue'=>0,'msg'=>'请输入关键词'));exit;
            }
            //用于超级分类
            if($cateid){
                /* $key_str = "";
                if($is_only==1){
                    $key_str .= ' ( title like "%'.$key.'%")';
                }else{
                    $arr_key = $this->get_arr_key($key);
                    sort($arr_key);
                    if(!empty($arr_key)){
                        for($i=0;$i<count($arr_key);$i++){
                            if($i<(count($arr_key)-1)){
                                $key_str.='( title like "%'.$arr_key[$i].'%") AND ';
                            }else{
                                $key_str.=' ( title like "%'.$arr_key[$i].'%")';
                            }
                        }
                    }
                }
                $cateid = $cateid==32?4:$cateid;
                $where['cate_id'] = $cateid;
                $sort = $sorts == 1?"coupon_price asc":($sorts == 2?"volume desc":($sorts == 3?"youhuiquan_je desc":""));
                $order = ($sort=="")?"id desc":$sort.",id desc";
                //        $where['commission_rate'] = array('GT',15000);
                $where['_string'] = $key_str;
                $count = M('a_items','daili_','DB_DAILI_READ')->where($where)->count();
                $page_num = ceil($count/20); */
                //$shopinfo = M('a_items','daili_','DB_DAILI_READ')->field('id,short_title,volume,pic_url,coupon_price,price,youhuiquan_je,num_iid,shop_type,movie_url,commission_rate')->where($where)->order($order)->page($page,20)->select();
                //查询当前分类是上级和上上级
                $sql = "select b.name as b_name,c.name as c_name from daili_a_cate_third as a left join daili_a_cate_second as b on a.pid = b.id  left join daili_a_cate as c on b.pid = c.id where a.id=$cateid";
                
                $res = M('a_cate_third')->query($sql);
                $key_all = $res[0]['c_name'].$res[0]['b_name'].$key;
                $search = A('Home/UseXs');
                $shopinfo  = $search->search_items($key_all,$sorts,$page);
                $shopinfo  = $shopinfo['items'];
                if(count($shopinfo)<20){
                    $api_url = C('GXZL_API_URL')."/Index/taobao_tbk_sc_material_optional.html?page=%s&sort=%s&key=%s";
                    switch ($sorts){
                        case 1:
                            $sorts_="price_asc";
                            break;
                        case 2:
                            $sorts_="total_sales_desc";
                            break;
                        case 3:
                            $sorts_="tk_total_sales_desc";
                            break;
                    }
                    $res = vget(sprintf($api_url,$page,$sorts_,$key));
                    $res = json_decode($res,true);
                    if($shopinfo){
                        $shopinfo = array_merge($shopinfo,$res);
                    }else{
                        $shopinfo = $res;
                    }
                }
                foreach ($shopinfo as $key=>$val){
                    if(strpos($val['title'],'瓷肌')){
                        unset($shopinfo[$key]);
                    }
                }
                $r = array(
                    'statue'=>1,
                    'msg'=>'成功',
                    'data'=>array(
                        'key'=>$key,
                        'count'=>$count,
                        'page_sum'=>$page_num,
                        'page'=>$page,
                        'shopinfo'=>$shopinfo,
                        'daili_rate'=>$daili_rate>0?$daili_rate:0
                    )
                );
            }else{
                //用于关键词搜索
                $search = A('Home/UseXs');
                $ress  = $search->search_items($key,$sorts,$page);
                if(count($ress['items'])<20){
                    $api_url = C('GXZL_API_URL')."/Index/taobao_tbk_sc_material_optional.html?page=%s&sort=%s&key=%s";
                    switch ($sorts){
                        case 1:
                            $sorts="price_asc";
                            break;
                        case 2:
                            $sorts="total_sales_desc";
                            break;
                        case 3:
                            $sorts="tk_total_sales_desc";
                            break;
                    }
                    $res = vget(sprintf($api_url,$page,$sorts,$key));
                    $res = json_decode($res,true);
                    if($ress['items']){
                        $result = array_merge($ress['items'],$res);
                    }else{
                        $result = $res;
                    }
                }else{
                    $result = $ress['items'];

                }
                foreach ($result as $key=>$val){
                    if(strpos('a'.$val['title'],'瓷肌')){
                        unset($result[$key]);
                    }
                }
                $r = array(
                    'statue'=>1,
                    'msg'=>'成功',
                    'data'=>array(
                        'key'=>$key,
                        'count'=>$ress['count'],
                        'page_sum'=>$ress['count_page'],
                        'page'=>$page,
                        'shopinfo'=>$result,
                        'daili_rate'=>$daili_rate>0?$daili_rate:0
                    )
                );
            }
            S('find_shop'.$key.$sorts.$page.$cateid.$is_only.$is_record.$mac_address,$r);
        }
        $this->ajaxReturn($r);
    }

    /**
     * 热门搜索关键词
     *  参数 ：
     * 接口地址：http://app.taokehelp.cn/Api/searchkey
     * */

    public function searchkey(){
        $search = A('Home/UseXs');
        $res = $search->hot();
        $arr = array(
            'data'=>$res
        );
        $this->ajaxReturn($arr);
    }
    /* 首页部分 结束 */


    /* 好券疯抢部分 开始 */

    /**
     * 好券疯抢
     *  参数 ：
     * 1、sort：排序  2、page：页数
     * 接口地址：http://app.taokehelp.cn/Api/haoquan
     *  注释：
     *  一、sort参数：（默认为空，1、1 =>券后  2、2=>销量  3、3=>超优惠）
     *  二、page参数：（页数，默认为1）
     * */
    public function haoquan(){
        $sorts = I('sort');
        $page = I('page',1,'intval');
        $r = S('haoquan'.$sorts.$page);
        if(!$r){
            $sort = $sorts == 1?"coupon_price asc":($sorts == 2?"volume desc":($sorts == 3?"youhuiquan_je desc":""));
            $order = ($sort=="")?"id desc":$sort.",id desc";
            $where['commission_rate'] = array('GT',15000);
            $where['coupon_price'] = array('between',array('0.01','20'));
            //$where['coupon_price'] = array('ELT',20);
            $count = M('a_items','daili_','DB_DAILI_READ')->where($where)->count();
            $page_num = ceil($count/20);
            $shopinfo = M('a_items','daili_','DB_DAILI_READ')->field('id,short_title,volume,pic_url,coupon_price,price,youhuiquan_je,num_iid,shop_type,movie_url,commission_rate')->where($where)->order($order)->page($page,20)->select();
            $r = array(
                'statue'=>1,
                'msg'=>'成功',
                'data'=>array(
                    'count'=>$count,
                    'page_sum'=>$page_num,
                    'page'=>$page,
                    'shopinfo'=>$shopinfo
                )
            );
            S('haoquan'.$sorts.$page,$r);
        }
        $this->ajaxReturn($r);
    }

    /* 好券疯抢部分 结束 */


    /* 个人中心部分 开始 */

    /**
     * 代理登录登录验证
     *  参数 ：
     *  1、username：用户名  2、password：密码
     * 接口地址：http://app.taokehelp.cn/Api/login
     * */
    public function login(){
        $username = I('username','','trim');
        $password = I('password','','trim');
        $where['_string']="(Phone='$username' or username='$username') and password='$password'";
        $userinfo = M('wx_user','daili_','DB_READ')->where($where)->find();
        
        if(empty($userinfo)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'用户名或密码错误'
                )
            );
        }else{
            $arr = array(
                'statue'=>1,
                'msg'=>'成功',
            );
            $arr+=$this->get_userinfo_api($userinfo['invitation_code']);
            $this->ajaxReturn($arr);
        }
    }

    /**
     * 代理收益中心
     *  参数 ：
     *  1、code：邀请码
     * 接口地址：http://app.taokehelp.cn/Api/usercenter
     * */
    public function usercenter(){
        $code = I('code');
        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($userinfo)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'不存在该用户信息'
                )
            );
            exit;
        }
        $arr = array(
            'statue'=>1,
        );
        $arr+=$this->get_userinfo_api($code);
        $this->ajaxReturn($arr);
    }



    /**
     * 邀请代理奖励
     *  参数 ：
     *  1、code：邀请码  2、页数【默认为1】
     * 接口地址：http://app.taokehelp.cn/Api/reward
     * */
    public function reward(){
        $page = I('page',1,'intval');
        $wxuser = M('wx_user','daili_','DB_READ');
        $code = I('get.code');

        $my_id = $wxuser->where(array('invitation_code'=>$code))->getField('ID');
        //查询所有下级代理
        $user = M('b_jiangli','daili_','DB_READ')->field('daili_b_jiangli.Money,daili_wx_user.*')
            ->where(array('daili_b_jiangli.UID'=>$my_id))
            ->join('left join daili_wx_user on daili_b_jiangli.XiaJiUID=daili_wx_user.ID')
            ->order('daili_b_jiangli.Time desc')
            ->page($page,10)
            ->select();
        $data = array(
            'data'=>$user,
            'statue'=>1
        );
        $this->ajaxReturn($data);
    }

    /**
     * 我的订单
     *  参数 ：
     *  1、code：邀请码  2、username：用户名  3、page：页数（默认为1） 4、statue：订单状态【默认为0】 5、time：时间状态【默认为0】
     * 接口地址：http://app.taokehelp.cn/Api/myorder
     * 注释：
     * 1、statue：（0、全部   2、订单付款  3、订单结算  4、订单失效）
     * 2、time：  （0、全部  2、今日  3、昨日 4、本月）
     * */
    public function myorder(){
        $code = I('code');
        //验证当前用户是否存在我们的数据库中
        $uid = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->getField('ID');
        if(empty($uid)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'不存在该代理'
                )
            );
        }
        $page = I('page',1,'intval');
        $statue = I('statue',0,'intval');
        $time = I('time',0,'intval');
        //今日时间
        $now_start = mktime(0,0,0,date('m'),date('d'),date('Y'));
        $now_last  = mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
        //昨日时间
        $yes_start = mktime(0,0,0,date('m'),date('d')-1,date('Y'));
        $yes_last = mktime(0,0,0,date('m'),date('d'),date('Y'))-1;
        //本月时间
        $month_start = mktime(0,0,0,date('m'),1,date('Y'));
        $month_last =  mktime(23,59,59,date('m'),date('t'),date('Y'));
        switch($time){
            case 2:$where['daili_a_shouyi.CreateTime'] = array('between',array($now_start,$now_last));break;
            case 3:$where['daili_a_shouyi.CreateTime']  = array('between',array($yes_start,$yes_last));break;
            case 4:$where['daili_a_shouyi.CreateTime'] = array('between',array($month_start,$month_last));break;
            default:;
        }
        switch($statue){
            case 2:$where['daili_a_order.OrderStatue'] = "订单付款";break;
            case 3:$where['daili_a_order.OrderStatue']  = "订单结算";break;
            case 4:$where['daili_a_order.OrderStatue'] = "订单失效";break;
            default:;
        }
//        $where['_string'] = " (daili_a_shouyi.UID=$uid) OR (daili_a_shouyi.ShangJiUID=$uid) OR (daili_a_shouyi.ShangShangJiUID=$uid)";
        $where['_string'] = " (daili_a_shouyi.UID=$uid) ";
        $field = 'daili_a_shouyi.ShouYi,daili_a_shouyi.CreateTime,daili_a_order.OrderStatue,daili_a_order.Title,daili_a_order.ItemID,'
            .'daili_a_order.CompleteTime,daili_a_order.OrderNum,daili_a_order.Pay,daili_a_shouyi.UID,daili_a_order.IMG';
        $join = 'left join daili_a_order on daili_a_shouyi.OrderID=daili_a_order.ID';
        $order = 'daili_a_order.CreateTime desc';
        $info = M('a_shouyi','daili_','DB_READ')->field($field)->where($where)->join($join)->page($page,10)->order($order)->select();
        foreach($info as $k=>$v){
            $info[$k]['creat_time'] = date('Y-m-d H:i:s',$v['createtime']);
            $info[$k]['complete_time'] = ($v['completetime']==''||$v['completetime']==0)?'':date('Y-m-d H:i:s',$v['completetime']);
            $info[$k]['shouyi'] = sprintf("%.2f",$v['shouyi']);
            unset($v['createtime']);
            unset($v['completetime']);
        }
        $arr = array(
            'data'=>$info,
            'statue'=>1
        );
        $this->ajaxReturn($arr);
    }


    /**
     * 提现
     *  参数 ：
     *  1、code：邀请码  2、username：用户名  3、money：提现金额
     * 接口地址：http://app.taokehelp.cn/Api/withdrawals
     * */
    public function withdrawals(){
        $code = I('code');
        $info = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($info)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'不存在该用户'
                )
            );
        }
        $money = I('money',0,floatval);
        //查询当前公众号的最低提现金额
        $gzh_id = M('a_media','daili_','DB_READ')->where(array('token'=>$info['gzhtoken']))->getField('id');
        $tx_je = M('a_config_copy','daili_','DB_READ')->where(array('MediaID'=>$gzh_id))->getField('ZuiDiTiXian');
        $tx_je = $tx_je==''?100:$tx_je;
        $info['yu_e'] =substr(sprintf("%.3f",$info['yue']),0,-1);
        unset($info['yue']);
        $infos = M('a_tixian','daili_','DB_READ')->where(array('UID'=>$info['id'],'Statue'=>"0",'Type'=>1))->find();
        $statue = empty($infos)?0:1;
        if($statue=="1"){
            $arr = array(
                'msg'=>"你有正在审核的提现操作，请等待审核后在进行操作",
                'statue'=>0
            );
            $this->ajaxReturn($arr);
            exit;
        }
        if($money<$tx_je){
            $arr = array(
                'msg'=>"提现金额必须大于等于".$tx_je,
                'statue'=>0
            );
            $this->ajaxReturn($arr);
        }
        if($money> $info['yu_e']){
            $arr = array(
                'msg'=>"提现金额不得大于可用余额",
                'statue'=>0
            );
            $this->ajaxReturn($arr);
        }

        $tx = M('a_tixian');
        $tx->startTrans();
        $tx->add(
            array(
                'UID'=>$info['id'],
                'JinE'=>$money,
                'Time'=>time(),
                'Statue'=>0,
                'Remark'=>'',
                'Type'=>1
            )
        );
        if($tx){
            $tx->commit();
            $arr = array(
                'msg'=>"提现申请成功",
                'statue'=>1
            );
        }else{
            $tx->rollback();
            $arr = array(
                'msg'=>"提现申请失败",
                'statue'=>0
            );
        }
        $this->ajaxReturn($arr);
    }


    /**
     * 提现记录
     *  参数 ：
     *  1、code：邀请码  2、username：用户名 3、page：页数【默认为1】
     * 接口地址：http://app.taokehelp.cn/Api/withdrawals_list
     * */
    public function withdrawals_list(){
        $code = I('code');
        $user = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($user)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'不存在该用户'
                )
            );
        }
        $page = I('page',1,'intval');
        $info = M('a_tixian','daili_','DB_READ')->where(array('UID'=>$user['id']))->page($page,20)->order('Time desc')->select();
        foreach($info as $k=>$v){
            $info[$k]['tx_time'] = date('Y-m-d H:i:s',$v['time']);
            $info[$k]['tx_statue'] = $v['statue']==1?'提现成功':(($v['statue']==0)?'待审核':'提现失败');
            $info[$k]['tx_type'] = $v['type']==1?'普通提现':'奖励金提现';
        }
        $arr =  array(
            'data'=>$info,
            'statue'=>1
        );
        $this->ajaxReturn($arr);
    }


    /**
     * 我的下线
     *  参数 ：
     *  1、code：邀请码  2、username：用户名 3、page：页数【默认为1】 4、type：下级分类【默认为1】
     * 接口地址：http://app.taokehelp.cn/Api/fans
     * 注释
     * type：1：下级  2：下下级
     * */
    public function fans(){
        $page = I('page',1,'intval');
        $type = I('type',1,'intval');
        $code = I('code');
        $wxuser = M('wx_user','daili_','DB_READ');
        $my_id = $wxuser->where(array('invitation_code'=>$code))->getField('ID');
        if(empty($my_id)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'不存在该用户'
                )
            );
            exit;
        }
        $arr = array();
        //查询所有下级代理
        $user = $wxuser->where(array('Pid'=>$my_id,'Statue'=>1))->page($page,20)->select();
        foreach($user as $k=>$v){
            $uid = $v['id'];
            $sql ="select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.ShangJiUID=$my_id and b.OrderStatue=1 and b.UID=$uid";
            $r = M('a_order','daili_','DB_READ')->query($sql);
            $xj_sum = $r[0]['sum'];
            //$xj_sum = M('a_shouyi')->where(array('ShangJiUID'=>$my_id,'OrderStatue'=>1,'UID'=>$v['id']))->sum('ShangJiShouYi');
            $user[$k]['money'] = sprintf("%.2f",$xj_sum);
            $user[$k]['daili_statue'] = ($v['statue']=='1'?'代理':'非代理');
            //组装所有下级代理id
//            $arr[$k] = $v['id'];
        }
        $user_pid = $wxuser->where(array('Pid'=>$my_id,'Statue'=>1))->select();
        foreach($user_pid as $kid=>$vid){
            $arr[] = $vid['id'];
        }

        if($type == 1){
            $data = array(
                'data'=>$user,
                'statue'=>1,
            );
            $this->ajaxReturn($data);
        }elseif($type == 2){
            //查询所有下下级代理
            if(!empty($arr)){
                $users = $wxuser->where(array('Pid'=>array('in',$arr),'Statue'=>1))->page($page,20)->select();
                foreach($users as $k1=>$v1){
                    $uid = $v1['id'];
                    $sql ="select sum(b.ShangShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.ShangShangJiUID=$my_id and b.OrderStatue=1 and b.UID=$uid";
                    $r = M('a_order','daili_','DB_READ')->query($sql);
                    $xxj_sum = $r[0]['sum'];
                    //$xxj_sum = M('a_shouyi')->where(array('ShangShangJiUID'=>$my_id,'OrderStatue'=>1,'UID'=>$v1['id']))->sum('ShangShangJiShouYi');
                    $users[$k1]['money']  = sprintf("%.2f",$xxj_sum);
                    $users[$k1]['daili_statue']  =  ($v1['statue']=='1'?'代理':'非代理');
                }
                $data = array(
                    'data'=>$users,
                    'statue'=>1,
                );
            }else{
                $users = array();
                $data = array(
                    'data'=>$users,
                    'statue'=>1
                );
            }
            $this->ajaxReturn($data);
        }
    }

    /**
     * 客服列表
     *  参数 ：
     * 接口地址：http://app.taokehelp.cn/Api/kefu
     * */
    public function kefu(){
        $res = M('a_app_kefu','daili_','DB_READ')->field('id,nickname,tel,qq,wx_num')->where(array('statue'=>1))->select();
        $this->ajaxReturn(
            array(
                'statue'=>1,
                'data'=>$res
            )
        );
    }


    /**
     *  个人资料编辑
     *  参数 ：1、alipay：支付宝账号  2、name：姓名  3、code：邀请码
     * 接口地址：http://app.taokehelp.cn/Api/edit_personinfo
     * */
    public function edit_personinfo(){
        $alipay = I('alipay','','trim');
        $name = I('name','','trim');
        $code = I('code');
        if(empty($alipay) || empty($name)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>"支付宝账号或姓名不能为空"
                )
            );
        }
        if(empty($code)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>"邀请码参数丢失"
                )
            );
        }
        $res = M('wx_user')->where(array('invitation_code'=>$code))->save(array('Alipay'=>$alipay,'Name'=>$name));
        if($res){
            $this->ajaxReturn(
                array(
                    'statue'=>1,
                    'msg'=>"修改成功"
                )
            );
        }else{
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>"修改失败"
                )
            );
        }
    }

    /**
     *  修改密码
     *  参数 ：1、password：密码  2、code：邀请码  3、phone
     * 接口地址：http://app.taokehelp.cn/Api/edit_password
     * */
    public function edit_password(){
        $password = str_replace(' ','',I('password'));
        $phone = str_replace(' ','',I('phone'));
        $verify = str_replace(' ','',I('verify'));
        if(empty($phone)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>"手机号不能为空"
                )
            );
        }
        if(empty($password)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>"密码不能为空"
                )
            );
        }
        //判断验证码是否失效
        $w = array(
            'phone'=>$phone,
            'verify'=>$verify,
        );
        $info = M('web_verify','daili_','DB_READ')->where($w)->order('id desc')->find();
        if(!$info){
            $arr = array(
                'statue'=>0,
                'msg'=>'验证码错误',
            );
            $this->ajaxReturn($arr);
        }
        if(time()-$info['time']>900){
            $arr = array(
                'statue'=>0,
                'msg'=>'验证码过期',
            );
            $this->ajaxReturn($arr);
        }
        $res = M('wx_user','daili_','DB_READ')->where(array('Phone'=>$phone))->find();
        if(!$res){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>"手机号不存在"
                )
            );
        }
        if($res['password'] == $password){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>"原密码与新密码相同"
                )
            );
        }else{
            $data = M('wx_user')->where(array('Phone'=>$phone))->save(array('password'=>$password));
            if($data){
                $this->ajaxReturn(
                    array(
                        'statue'=>1,
                        'msg'=>"修改成功"
                    )
                );
            }else{
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>"修改失败"
                    )
                );
            }
        }
    }


    
    /**
     *  app注册成为代理新接口
     *  参数 ：1、code：邀请码  2、username：用户名 3、password：密码 4、phone：手机号 5、is_app:【0：微信用户 1：安卓 2：iOS 3：后台 4：提供给客户api的】
     * 接口地址：http://app.taokehelp.cn/Api/daili_reg
     * */
    public function daili_reg_new(){
        $code = str_replace(' ','',I('code'));
        $is_app = I('is_app',1,'intval');
        $password =str_replace(' ','',I('password'));
        $reg_phone = I('reg_phone','','trim');
        //邀请者的手机号
        if(!empty($reg_phone)){
            //查询当前填写的上级手机号的code
            $code = M('wx_user')->where(array('Phone'=>$reg_phone))->getField('invitation_code');
            if(empty($code)){
                $arr = array(
                    'code'=>0,
                    'msg'=>'不存在该邀请者手机号'
                );
                $this->ajaxReturn($arr);
            }
        }
        
        if(preg_match("/[\'.,:;*?~`!@#$%^&+=)(<>{}]|\]|\[|\/|\\\|\"|\|/",$password)){
            $arr = array(
                'code'=>0,
                'msg'=>'密码请用数字或大小写字母'
            );
            $this->ajaxReturn($arr);
        }
        if(strlen($password)<6){
            $arr = array(
                'code'=>0,
                'msg'=>'密码长度不得小于6个字符'
            );
            $this->ajaxReturn($arr);
        }
        if(strlen($password)>20){
            $arr = array(
                'code'=>0,
                'msg'=>'密码长度不得大于20个字符'
            );
            $this->ajaxReturn($arr);
        }
        $phone = str_replace(' ','',I('phone'));
        $user = M('wx_user')->where(array('Phone'=>$phone))->find();
        if($user){
            $arr = array(
                'code'=>0,
                'msg'=>'手机号已经注册'
            );
            $this->ajaxReturn($arr);
        }
        $verify = str_replace(' ','',I('verify'));
        $log = array(
            'content'=>"code:$code,password:$password,phone:$phone,verify:$verify",
            'type'=>'用户注册参数'
        );
        M('z_logtest')->add($log);
        if(empty($code)){
            $this->ajaxReturn(array('staute'=>0,'msg'=>'邀请码不能为空'));
        }
        if(empty($password)){
            $this->ajaxReturn(array('staute'=>0,'msg'=>'密码不能为空'));
        }
        if(empty($phone)){
            $this->ajaxReturn(array('staute'=>0,'msg'=>'手机号不能为空'));
        }
        if(empty($verify)){
            $this->ajaxReturn(array('staute'=>0,'msg'=>'验证码不能为空'));
        }
        //判断验证码是否失效
        $w = array(
            'phone'=>$phone,
            'verify'=>$verify,
        );
        $info = M('web_verify','daili_','DB_READ')->where($w)->order('id desc')->find();
        if(!$info){
            $arr = array(
                'code'=>0,
                'msg'=>'验证码错误',
            );
            $this->ajaxReturn($arr);
        }
        if(time()-$info['time']>900){
            $arr = array(
                'statue'=>0,
                'msg'=>'验证码过期',
            );
            $this->ajaxReturn($arr);
        }
        $info = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($info)){
            $this->ajaxReturn(array('staute'=>0,'msg'=>'邀请码无效'));
        }
        $member_level=$info['member_level'];
        if($member_level==2){
            $member_agent=$info['id'];
            $member_area =$info['member_area'];
        }elseif($member_level==3){
            $member_agent=$info['member_agent'];
            $member_area=$info['id'];
        }else{
            $member_agent=$info['member_agent'];
            $member_area=$info['member_area'];
        }
        $url = C('GXZL_API_URL')."/index/taobao_tbk_adzone_create?&siteid=%s&adzone=%s";
        //查询用户所在渠道
        $qudao = M('a_media')->where(array('token'=>$info['gzhtoken']))->find();
        $site_id = $info['mediaid'];
        $adzone_id=$qudao['qudao_name'].$phone;
        $res = vget(sprintf($url,trim($site_id),trim($adzone_id)));
        $ress = json_decode($res,true);
        $tgwid = $ress['pid'];
        if(empty($tgwid)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'创建推广位失败'
                )
            );
            exit;
        }
        $arr_tgwid = explode('_',$tgwid);
        $mediaid = $arr_tgwid[2];
        $adid    = $arr_tgwid[3];
        $data = array(
            'Pid'=>$info['id'],
            'Phone'=>$phone,
            'TgwID'=>$tgwid,
            'MediaID'=>$mediaid,
            'password'=>$password,
            'kefu_id'=>$info['kefu_id'],
            'Statue'=>1,
            'GzhToken'=>$info['gzhtoken'],
            'MediaName'=>$info['medianame'],
            'MediaTableID'=>$info['mediatableid'],
            'AdID'=>$adid,
            'AdName'=>$adzone_id,
            'is_app'=>$is_app,
            'reg_app_time'=>time(),
            'member_agent'=>$member_agent,
            'member_area'=>$member_area,
            'invitation_code'=>set_invitation_code(),
        );
        $arr_res = M('wx_user')->add($data);
        if($arr_res){
            $this->add_statistics($info['id'],3,$is_app);
            $token = $info['gzhtoken'];
            $config = $this->config0;
            $config = $config[$token];
            //用户通过代理审核查询用户是否有上级代理有就加奖励
            if($info['id']){
                $jiangli=array(
                    'UID'=>$info['id'],
                    'XiaJiUID'=>$arr_res,
                    'Money'=>$config['yaoqingjiangli'],
                    'Time'=>time(),
                    'type'=>1,
                );
                M('b_jiangli')->add($jiangli);
            }
            $userinfo = M('wx_user','daili_','DB_READ')->where(array('ID'=>$arr_res))->find();
            $arr = array(
                'statue'=>1,
                'msg'=>'亲，你已经注册成功，开始省钱赚钱啦！'
            );
            $arr+=$this->get_userinfo_api($userinfo['invitation_code']);
            $this->ajaxReturn($arr);
            exit;
        }else{
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'申请注册失败，请重试'
                )
            );
            exit;
        }
    }


    /**
     *  短信验证码
     *  参数 ：1、phone：手机号
     * 接口地址：http://app.taokehelp.cn/Api/telephoneSms
     * */
    public function telephoneSms(){
        //您的验证码是：【变量】。请不要把验证码泄露给其他人。如非本人操作，可不用理会！
        $length = 6;
        $min = pow(10 , ($length - 1));
        $max = pow(10, $length) - 1;
        $code = rand($min, $max);//生成一个6位数的随机验证码
        $phone = str_replace(' ','',I('phone'));
        /* //注册的时候查询数据库中手机号是否已经注册了
        $user = M('wx_user','daili_','DB_READ')->where(array('Phone'=>$phone))->find();
        if($user){
            $arr = array(
                'code'=>0,
                'msg'=>'该手机号已经注册'
            );
            $this->ajaxReturn($arr);
        } */
        //查询发送验证码的次数
        $w = array(
            'time'=>array('between',array(strtotime(date('Y-m-d',time())),strtotime(date('Y-m-d',time()))+24*3600)),
            'phone'=>$phone,
        );
        $count = M('web_verify','daili_','DB_READ')->where($w)->count();
        if($count>=5){
            $arr = array(
                'statue'=>0,
                'msg'=>'同一个手机号一天最多只能获取5次验证码',
            );
            $this->ajaxReturn($arr);
        }
        Vendor('SmsDemo');
        $obj = new \SmsDemo;
        $res = $obj->sendSms($phone,$code);
        if($res->Message=='OK'){
            $data = array(
                'verify'=>intval($code),
                'phone'=>$phone,
                'time'=>time(),
            );
            M('web_verify')->add($data);
            $arr = array(
                'statue'=>1,
                'msg'=>'验证码发送成功'
            );
            $this->ajaxReturn($arr);
        }else{
            $arr = array(
                'statue'=>0,
                'msg'=>'验证码发送失败'
            );
            $this->ajaxReturn($arr);
        }
    }

    /* 个人中心部分 结束 */


    /* 商品详情部分 开始 */

    /**
     * 商品详情
     *  参数 ：
     *  1、id：数据库items表的id
     * 接口地址：http://app.taokehelp.cn/Api/shopdetails
     * */
    public function shopdetails(){
        $id = I('id');
        $r = S('shopdetails'.$id);
        if(!$r){
            $shopinfo = M('a_items','daili_','DB_DAILI_READ')->field('id,cate_id,num_iid,pic_url,short_title,title,price,volume,coupon_price,shop_type,youhuiquan_je,recommend_reason,movie_url,commission_rate')
                ->where(array('id'=>$id))
                ->find();
            if(empty($shopinfo)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'不存在该商品'
                    )
                );
            }
            $info = $this->get_shopdetails($shopinfo['num_iid']);
            $shopinfo['pic_list'] = $info['small_images']['string']==""?array():$info['small_images']['string'];
            //查询猜你喜欢部分【按照别人的APP 查询10个商品】
            $where['short_title']  = array('like', '%'.$shopinfo['short_title'].'%');
            $where['cate_id'] = $shopinfo['cate_id'];
            $where['type_id'] = $shopinfo['type_id'];
            $where['_logic'] = 'or';
            $map['_complex'] = $where;
            $like_shop = M('a_items','daili_','DB_DAILI_READ')->field('id,num_iid,cate_id,short_title,coupon_price,pic_url,youhuiquan_je,volume,movie_url,commission_rate')->where($map)->order('id desc')->limit(10)->select();
            $r=array(
                'data'=>array(
                    'shopdetails'=>$shopinfo,
                    'likeshop'=>$like_shop,
                    'info'=>$info
                ),
                'statue'=>1
            );
            S('shopdetails'.$id,$r);
        }
        $this->ajaxReturn($r);
    }

    /**
     * 超级搜商品详情
     *  参数 ：
     *  1、numid：商品id
     * 接口地址：http://app.taokehelp.cn/Api/tb_shopdetails
     * */
    public function tb_shopdetails(){
        $numid = I('numId');
        $r = S('tb_shopdetails'.$numid);
        if(!$r){
            $info = $this->get_shopdetails($numid);
            $shopinfo['pic_list'] = $info['small_images']['string']==""?array():$info['small_images']['string'];
            //查询猜你喜欢部分【按照别人的APP 查询10个商品】
            //$where['title']  = array('like', '%'.$shopinfo['title'].'%');
            $like_shop = M('a_items','daili_','DB_DAILI_READ')->field('id,num_iid,cate_id,short_title,coupon_price,pic_url,youhuiquan_je,volume,movie_url,commission_rate')->where(array('ordid'=>array('elt',100)))->order('rand()')->limit(10)->select();
            $r = array(
                'data'=>array(
                    'shopdetails'=>$shopinfo,
                    'likeshop'=>$like_shop,
                ),
                'statue'=>1
            );
            S('tb_shopdetails'.$numid,$r);
        }
        $this->ajaxReturn($r);
    }



    /**
     * 超级搜商品详情【小程序版本】
     *  参数 ：
     *  1、numid：商品id 2、coupon_price  3、yh_je  4、price
     * 接口地址：http://app.taokehelp.cn/Api/tb_shopdetails_xcx
     * */
    public function tb_shopdetails_xcx(){
        $numid = I('numid');
        $code = I('code');
        $coupon_price = I('coupon_price');
        $price = I('price');
        $yh_je = I('yh_je');
        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($userinfo)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'邀请码信息错误'
                )
            );
            exit;
        }
        $info = $this->get_shopdetails($numid);
        $infos = M('a_items','daili_','DB_DAILI_READ')->where(array('num_iid'=>$numid))->find();
        $ress = $this->get_couponinfo($numid,$userinfo['mediaid'],$userinfo['adid'],$infos['youhuiquan']);
        $tkl = $this->itemsTKLing($info['pict_url'], $info['title'], $ress['coupon_click_url']);
        $tkls = json_decode($tkl,true);
 
        if(!empty($infos)){
            $info['recommend_reason'] = $infos['recommend_reason'];
        }
        $info['youhuiquan_je'] = $yh_je;
        $info['coupon_price'] = $coupon_price;
        $info['price'] = $price;
        $info['tkl'] = $tkls['data']['model'];
        $this->ajaxReturn(
            array(
                'data'=>array(
                    'info'=>$info,
                ),
                'statue'=>1
            )
        );
    }


    /**
     * 获取二合一优惠券链接以及代理收入
     *  参数 ：
     *  1、code：邀请码  2、numid：商品id
     * 接口地址：http://app.taokehelp.cn/Api/get_coupon_url
     * */
    public function get_coupon_url(){
        set_time_limit(0);
        $numid = I('numid');
        $code = I('code');
        $r = S('get_coupon_url'.$numid.$code);
        if(!$r){
            $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();

            if(empty($userinfo)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'邀请码信息错误'
                    )
                );
                exit;
            }

            $shop = M('a_items','daili_','DB_DAILI_READ')->where(array('num_iid'=>$numid))->find();
            
            $ress = $this->get_couponinfo($numid,$userinfo['mediaid'],$userinfo['adid'],$shop['youhuiquan']);
            
            if($ress['coupon_info']){
                $str = explode("元",$ress['coupon_info']);
                $coupon_first = preg_replace('/\D/s', '', $str[0]);
                $coupon_last = preg_replace('/\D/s', '', $str[1]);
                $youhuiquan_je = $shop['youhuiquan_je']==""?($coupon_last>0?$coupon_last:$shop['youhuiquan_je']):$shop['youhuiquan_je'];
            }else{
                $youhuiquan_je=0;
            }
            /* //获取当前公众号信息
            $gzh_id = M('a_media')->where(array('token'=>$userinfo['gzhtoken']))->getField('id');
            //获取当前公众号的佣金比
            $ratio = M('a_config_copy')->where(array('MediaID'=>$gzh_id))->getField('ShouYiBi');
             */
            //查询用户等级获取pid，分成比等信息
            if($userinfo){
                $user_level = get_level($userinfo['id'],$userinfo['member_level'],$userinfo['gzhtoken']);
                $daili_rate = ($user_level['b_level1']/100)*0.9;
                //查询其他等级的收益
                $member_level=$user_level['member_level'];
                $token = $userinfo['gzhtoken'];
                if($member_level==1){
                    //查询普通会员的收益
                    $r = M('a_config_copy','daili_','DB_READ')->query("select a.ShouYiBi from daili_a_config_copy as a left join daili_a_media as b on a.MediaID=b.id where b.token='$token'");
                    $r = $r[0];
                    $a = array(
                        'level'=>1,
                        'level_str'=>'超级会员',
                        'shouyi'=>$user_level['b_level1'],
                        'daili_rate'=>($ress['max_commission_rate']*100/10000)*($user_level['b_level1']/100)*0.9
                    );
                    $b = array(
                        'level'=>0,
                        'level_str'=>'会员',
                        'shouyi'=>$r['shouyibi'],
                        'daili_rate'=>($ress['max_commission_rate']*100/10000)*($r['shouyibi']/100)*0.9
                    );
                }
                if($member_level==0){
                    //查询黄金合伙人的收益比
                    $r = M('wx_user_level','daili_','DB_READ')->query("select a.level1 from daili_wx_user_level as a where a.token='$token' and member_level=1");
                    $r = $r[0];
                    $a = array(
                        'level'=>1,
                        'level_str'=>'超级会员',
                        'shouyi'=>$r['level1'],
                        'daili_rate'=>($ress['max_commission_rate']*100/10000)*($r['level1']/100)*0.9
                    );
                    $b = array(
                        'level'=>0,
                        'level_str'=>'会员',
                        'shouyi'=>$user_level['b_level1'],
                        'daili_rate'=>($ress['max_commission_rate']*100/10000)*($user_level['b_level1']/100)*0.9
                    );
                }
                $other_shouyi=array($a,$b);
            }
            $daili_rate = $ress['max_commission_rate']*100/10000*$daili_rate;
            $tkl = "";
            //$this->set_up_log($ress['coupon_click_url'],$userinfo['gzhtoken'],$tkl,$numid,'',$userinfo['phone'],$gzh_id['new_alimama_id']);
            if(!$ress){
                $ress=array();
                $this->ajaxReturn(array(
                    'statue'=>0,
                    'data'=>array()
                ));
            }
            $r = array(
                'statue'=>1,
                'data'=>array(
                    'ehy'=>$ress,
                    'daili_rate'=>$daili_rate,
                    'daili_rate_new'=>$other_shouyi,
                    'youhuiquan_je'=>$youhuiquan_je
                )
            );
            S('get_coupon_url'.$numid.$code,$r);
        }
        $this->ajaxReturn($r);

    }
    
    /* 商品详情部分 结束 */

    /* 获取用户收货地址*/
    public function get_receiving_address(){
        $code   = I('code');
        $user   = M('wx_user')->where(array('invitation_code'=>$code))->find();
        if(!$user){
            $arr = array(
                'statue'=>0,
                'msg'=>'邀请码错误用户不存在'
            );
            $this->ajaxReturn($arr);
        }
        $phone  = I('phone');
        $name   = urldecode(I('name'));
        $address= urldecode(I('address'));
        $address_info = M('receiving_address')->where(array('uid'=>$user['id']))->find();
        if($address_info){
            $data = array(
                'phone'=>$phone,
                'name'=>$name,
                'address'=>$address,
                'time'=>time()
            );
            $res = M('receiving_address')->where(array('uid'=>$user['id']))->save($data);
        }else{
            $data = array(
                'uid'=>$user['id'],
                'phone'=>$phone,
                'name'=>$name,
                'address'=>$address,
                'time'=>time()
            );
            $res = M('receiving_address')->add($data);
        }
        if($res){
            $arr = array(
                'statue'=>1,
            );
            $arr+=$this->get_userinfo_api($code);
        }else{
            $arr = array(
                'statue'=>0,
                'msg'=>'添加收货地址失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    
    /* 超级分类部分 开始 */

    /**
     * 超级分类
     *  参数 ：
     * 接口地址：http://app.taokehelp.cn/Api/supercate
     * */
    public function supercate(){
        $r = S('supercate');
        if(!$r){
            $arr = array();
            $cate = M('a_cate','daili_','DB_DAILI_READ')->order('sort asc')->where(array('is_show'=>1))->select();
            foreach($cate as $k=>$v){
                $cate_second = M('a_cate_second','daili_','DB_DAILI_READ')->where(array('pid'=>$v['id']))->select();
                if(!empty($cate_second)){
                    foreach($cate_second as $key=>$val){
                        $cate_third = M('a_cate_third','daili_','DB_DAILI_READ')->where(array('pid'=>$val['id']))->select();
                        $cate_second[$key]['other'] = empty($cate_third)?"":$cate_third;
                    }
                }
                $cate[$k]['other'] = empty($cate_second)?$arr:$cate_second;
            }
            foreach ($cate as $key=>$val){
                if($val['keywords']=='more'){
                    unset($cate[$key]);
                }
            }
            $r = array(
                'statue'=>1,
                'data'=>array_values($cate)
            );
            S('supercate',$r);
        }

        $this->ajaxReturn($r);
    }

    /* 超级分类部分 结束 */

    /* 分享 开始 */

    /**
     * 快速分享
     *  参数 ：1、numid：商品id   2、code：邀请码  3、download：是否开启下载【默认为空   1：开启】
     * 接口地址：http://app.taokehelp.cn/Api/quick_share
     * */
    public function quick_share(){
        $numid = I('numid');
        $code = I('code');
        $download = I('download','','intval');
        $r = S('quick_share'.$numid.$code.$download);
        if(!$r){
            if(empty($numid)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'缺少商品参数'
                    )
                );
            }
            if(empty($code)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'缺少参数'
                    )
                );
            }
            $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
            if(empty($userinfo)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'参数信息错误'
                    )
                );
            }

            $shopinfo = $this->get_shopdetails($numid);
            //通过接口获取二合一链接和高佣金比
            $shop = M('a_items','daili_','DB_DAILI_READ')->where(array('num_iid'=>$numid))->find();
            $ress = $this->get_couponinfo($numid,$userinfo['mediaid'],$userinfo['adid'],$shop['youhuiquan']);
            if(!empty($shop)){
                $shopinfo['price'] = $shop['price'];
                $shopinfo['coupon_price'] = $shop['coupon_price'];
                $shopinfo['youhuiquan_je'] = $shop['youhuiquan_je'];
            }else{
                $str = explode("元",$ress['coupon_info']);
                $coupon_first = preg_replace('/\D/s', '', $str[0]);
                $coupon_last = preg_replace('/\D/s', '', $str[1]);
                $shopinfo['price'] = $shopinfo['zk_final_price'];
                if($shopinfo['zk_final_price']>=$coupon_first){
                    $shopinfo['coupon_price'] = $shopinfo['zk_final_price']-$coupon_last;
                    $shopinfo['youhuiquan_je'] = $coupon_last;
                }else{
                    $shopinfo['coupon_price'] = $shopinfo['zk_final_price'];
                    $shopinfo['youhuiquan_je'] = 0;
                }
            }

            $tkl = "";
            //$this->set_up_log($ress['coupon_click_url'],$userinfo['gzhtoken'],$tkl,$numid,'',$userinfo['phone'],$res['alimamaid']);
            $title = "【券后".sprintf("%.2f",$shopinfo['coupon_price'])."/原价".$shopinfo['zk_final_price']."】".$shopinfo['title'];
            $open_download = $download==1?"&open=1":"";
            $r =array(
                'statue'=>1,
                'title'=>$title,
                'describe'=>$shop['recommend_reason'],
                'url'=>"http://".$_SERVER['HTTP_HOST']."/Index/details?code=".$code."&numid=".$numid.$open_download,
                'pic'=>$shopinfo['pict_url']
            );
        }
        $this->ajaxReturn($r);

    }

    /**
     * 具体分享
     *  参数 ：1、numid：商品id   2、code：邀请码 3、download：是否开启下载【默认为空   1：开启】 4:type：系统类型 【1：安卓】
     * 接口地址：http://app.taokehelp.cn/Api/details_share
     * */
    public function details_share(){
        $numid = I('numid');
        $code = I('code');
        $type = I('type');
        $download = I('download','','intval');
        $r = S('details_share'.$numid.$code.$type.$download);
        if(!$r){
            if(empty($numid)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'缺少商品参数'
                    )
                );
            }
            if(empty($code)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'缺少参数'
                    )
                );
            }
            $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
            if(empty($userinfo)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'参数信息错误'
                    )
                );
            }

            $shopinfo = $this->get_shopdetails($numid);
            //通过接口获取二合一链接和高佣金比
            $shop = M('a_items','daili_','DB_DAILI_READ')->where(array('num_iid'=>$numid))->find();
            $ress = $this->get_couponinfo($numid,$userinfo['mediaid'],$userinfo['adid'],$shop['youhuiquan']);
            if(!empty($shop)){
                $shopinfo['price'] = $shop['price'];
                $shopinfo['coupon_price'] = $shop['coupon_price'];
                $shopinfo['youhuiquan_je'] = $shop['youhuiquan_je'];
            }else{
                $str = explode("元",$ress['coupon_info']);
                $coupon_first = preg_replace('/\D/s', '', $str[0]);
                $coupon_last = preg_replace('/\D/s', '', $str[1]);
                $shopinfo['price'] = $shopinfo['zk_final_price'];
                if($shopinfo['zk_final_price']>=$coupon_first){
                    $shopinfo['coupon_price'] = $shopinfo['zk_final_price']-$coupon_last;
                    $shopinfo['youhuiquan_je'] = $coupon_last;
                }else{
                    $shopinfo['coupon_price'] = $shopinfo['zk_final_price'];
                    $shopinfo['youhuiquan_je'] = 0;
                }
            }
            $open_download = $download==1?"&open=1":"";
            $tkl = json_decode($this->itemsTKLing($shopinfo['pict_url'],$shopinfo['title'],$ress['coupon_click_url']),true);
            //$this->set_up_log($ress['coupon_click_url'],$userinfo['gzhtoken'],$tkl['data']['model'],$numid,'',$userinfo['phone'],$userinfo['alimamaid']);
            if($type == 1){
                if(!empty($shop['recommend_reason'])){
                    $recommend_reason="";
                    //$recommend_reason = "【推荐理由】".$shop['recommend_reason']."\n ------------- \n";
                }else{
                    $recommend_reason="";
                }

                $text2 = "【商品】".$shopinfo['title']." \n"."【原价】".$shopinfo['price']."元"."\n"."【㊙quan】".$shopinfo['youhuiquan_je']."元\n"
                    ."【quan后价】".$shopinfo['coupon_price']."元 \n"."【❤】".$tkl['data']['model']."\n "."【❤】".$tkl['data']['model'].$recommend_reason
                    // ."下单链接："."http://".$_SERVER['HTTP_HOST']."/Index/details?code=".$code."&numid=".$numid.$open_download."\n"
                    ."【商品领券下单】长按复制这条信息，打开【手机TaoBao 🎁 】可领券并下单";
                $text1 = "【商品】".$shopinfo['title']." \n"."【原价】".$shopinfo['price']."元"."\n"."【㊙quan】".$shopinfo['youhuiquan_je']."元\n"
                    ."【quan后价】".$shopinfo['coupon_price']."元 "."\n "."【❤】".$tkl['data']['model']."\n ".$recommend_reason
                    ."【商品领券下单】长按复制这条信息，打开【手机TaoBao 🎁 】可领券并下单";
                //  ."下单链接："."http://".$_SERVER['HTTP_HOST']."/Index/details?code=".$code."&numid=".$numid.$open_download;
                $text = "【商品】".$shopinfo['title']." \n"."【原价】".$shopinfo['price']."元"."\n"."【㊙quan】".$shopinfo['youhuiquan_je']."元\n"
                    ."【quan后价】".$shopinfo['coupon_price']."元 \n"."【❤】".$tkl['data']['model']."\n ".$recommend_reason
                    ."【商品领券下单】长按复制这条信息，打开【手机TaoBao 🎁 】可领券并下单";
            }else{
                if(!empty($shop['recommend_reason'])){
                    $recommend_reason="";
                    //$recommend_reason = "【推荐理由】".$shop['recommend_reason']."<br> ------------- <br>";
                }else{
                    $recommend_reason="";
                }
                $text2 = "【商品】".$shopinfo['title']." <br>"."【原价】".$shopinfo['price']."元"."<br>"."【㊙quan】".$shopinfo['youhuiquan_je']."元<br>"
                    ."【quan后价】".$shopinfo['coupon_price']."元 <br>"."【❤】".$tkl['data']['model']."<br> "."【❤】".$tkl['data']['model'].$recommend_reason
                    //  ."下单链接："."http://".$_SERVER['HTTP_HOST']."/Index/details?code=".$code."&numid=".$numid.$open_download."<br>"
                    ."【商品领券下单】长按复制这条信息，打开【手机TaoBao 🎁 】可领券并下单";
                $text1 = "【商品】".$shopinfo['title']." <br>"."【原价】".$shopinfo['price']."元"."<br>"."【㊙quan】".$shopinfo['youhuiquan_je']."元<br>"
                    ."【quan后价】".$shopinfo['coupon_price']."元 <br>"."【❤】".$tkl['data']['model']."<br>".$recommend_reason
                    ."【商品领券下单】长按复制这条信息，打开【手机TaoBao 🎁 】可领券并下单";
                // ."下单链接："."http://".$_SERVER['HTTP_HOST']."/Index/details?code=".$code."&numid=".$numid.$open_download;
                $text = "【商品】".$shopinfo['title']." <br>"."【原价】".$shopinfo['price']."元"."<br>"."【㊙quan】".$shopinfo['youhuiquan_je']."元<br>"
                    ."【quan后价】".$shopinfo['coupon_price']."元 <br>"."【❤】".$tkl['data']['model']."<br>".$recommend_reason
                    ."【商品领券下单】长按复制这条信息，打开【手机TaoBao 🎁 】可领券并下单";
            }

            //记录到浏览日志
            $arr = array(
                'code'=>$code,
                'numid'=>$numid,
                'text'=>$text,
                'text1'=>$text1,
                'text2'=>$text2,
                'coupon_click_url'=>$ress['coupon_click_url'],
                'coupon_info'=>$ress,
                'tkl_info'=>$tkl,
                'tkl'=>$tkl['data']['model'],
                'from'=>'app商品分享,http://'.$_SERVER['HTTP_HOST'].'/Api/details_share',
                'time'=>date('Y-m-d H:i:s',time())
            );
            $res = M('pid_log')->add(
                array(
                    'uid'=>$userinfo['id'],
                    'add_time'=>time(),
                    'openid'=>$userinfo['openid'],
                    'log_info'=>json_encode($arr)
                )
            );
            if($res){
                $r=array(
                    'statue'=>1,
                    'text'=>$text,
                    'text1'=>$text1,
                    'text2'=>$text2,
                    'url'=>"http://".$_SERVER['HTTP_HOST']."/Index/details?code=".$code."&numid=".$numid.$open_download,
                    'pic'=>$shopinfo['pict_url'],
                    'type'=>$type
                );
                S('details_share'.$numid.$code.$type.$download,$r);

            }
        }
        $this->ajaxReturn($r);
    }

    //判断用户有没有正在提现中的
    public function check_tixian(){
        $code = I('code');
        $user = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        $tixian = M('a_tixian')->where(array('UID'=>$user['id'],'Statue'=>0))->find();
        if($tixian){
            $arr = array(
                'code'=>0,
                'url'=>C('APP_API_URL').'/Index/tixian_list.html?code='.$code
            );
        }else{
            $arr = array(
                'code'=>1
            );
        }
        $this->ajaxReturn($arr);
    }
    /* 分享 结束 */
    
    /* 版本检测 开始 */
    /**
     * 版本检测
     *  参数 ：1、type:版本类型【默认为空  1：ios】
     * 接口地址：http://app.taokehelp.cn/Api/check_version
     * */
    public function check_version(){
        $type = I('type','','intval');
        $where['app_type'] = $type==1?2:1;
        $res = M('a_app_version','daili_','DB_READ')->where($where)->order('id desc')->limit(1)->find();
        $this->ajaxReturn(
            array(
                'data'=>$res,
                'statue'=>1
            )
        );
    }

    /* 版本检测 结束 */



    //通过接口获取二合一链接和高佣金比
    public function get_couponinfo($itemid,$site_id,$adzone_id,$youhuiquan){
        $url = C('GXZL_API_URL')."/Index/taobao_tbk_privilege_get_daili?item_id=%s&site_id=%s&adzone_id=%s&youhuiquan=%s";
        $res = vget(sprintf($url,trim($itemid),trim($site_id),trim($adzone_id),urlencode($youhuiquan)));
        $ress = json_decode($res,true);
        return $ress;
    }

    //调用上行日志接口
    public function set_up_log($youhuiquan,$token,$tkl,$num_id,$text,$account,$pid){
        $url = C('GXZL_API_URL')."/Index/taobao_tbk_data_report?tbkurl=%s&token=%s&kouling=%s&itemid=%s&text=%s&account=%s&pid=%s";
        $res = vget(sprintf($url,urlencode($youhuiquan),trim($token),trim($tkl),trim($num_id),trim($text),trim($account),trim($pid)));
        $ress = json_decode($res,true);
        return $ress;
    }

    /* 转淘口令
     * $pic_url 图片链接
     * $title 标题
     * $ehy_url 二合一链接
     *  */
    public function itemsTKLing($pic_url, $title, $ehy_url){
        $str = substr( $title, 0, 1 );
        if($str =="@"){
            $title = substr($title,1);
        }
        $api_url = C('GXZL_API_URL').'/Index/taobao_wireless_share_tpwd_create';
        $postData['logo'] = urlencode($pic_url);
        $postData['title'] = urlencode($title);
        $postData['url'] = urlencode($ehy_url);
        $res = $this->curl_post($api_url, $postData);
        return $res;
    }


    /**
     *  curl post
     **/
    public function curl_post($url, $data = null) {
        $ch = curl_init ();
        curl_setopt ( $ch, CURLOPT_URL, $url ); // 设置访问的url地址
        curl_setopt ( $ch, CURLOPT_CUSTOMREQUEST, "POST" );
        curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
        curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, FALSE );
        curl_setopt ( $ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36' );

        $data && curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data );
        curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
        $tmpInfo = curl_exec ( $ch );
        if (curl_errno ( $ch )) {
            return curl_error ( $ch );
        }
        curl_close ( $ch );
        return $tmpInfo;
    }


    //获取商品详情接口
    public function get_shopdetails($itemid){
        $url = C('GXZL_API_URL')."/Index/taobao_tbk_item_info_get?itemid=%s";
        $res = vget(sprintf($url,trim($itemid)));
        $ress = json_decode($res,true);
        return $ress;
    }

    //分词接口
    public function get_arr_key($str){
        $url = C('GXZL_API_URL')."/Index/spstr?str=%s";
        $res = vget(sprintf($url,urlencode(trim($str))));
        $ress = json_decode($res,true);
        return $ress;
    }

    //注册日志
    public function reg_log($data,$phone){
        M('a_reg_log')->add(array(
            'add_time'=>time(),
            'username'=>$phone,
            'log_data'=>json_encode($data)
        ));
    }

    //记录app下载、激活
    //参数说明：【type：1、下载  2、激活(用户) 3、注册】
    public function add_statistics($uid,$type,$is_ios){
        $info = M('a_app_statistics')->where(array('uid'=>$uid))->find();
        if($type == 1){
            if(empty($info)){
                M('a_app_statistics')->add(
                    array(
                        'uid'=>$uid,
                        //'download_count'=>1,
                        //'activation_count'=>1,
                        'reg_count'=>1
                    )
                );
            }else{
                M('a_app_statistics')->where(array('uid'=>$uid))->save(
                    array(
                        'reg_count'=>($info['reg_count']+1),
                    )
                );
            }
        }elseif($type == 2){
            M('a_app_statistics')->add(
                array(
                    'add_time'=>time(),
                    'uid'=>$uid,
                    'type'=>1,
                    'app_type'=>$is_ios
                )
            );
            if(empty($info)){
                M('a_app_statistics')->add(
                    array(
                        'uid'=>$uid,
                        'activation_count'=>1
                    )
                );
            }else{
                M('a_app_statistics')->where(array('uid'=>$uid))->save(
                    array(
                        'activation_count'=>($info['activation_count']+1)
                    )
                );
            }
        }else{
            if(empty($info)){
                M('a_app_statistics')->add(
                    array(
                        'uid'=>$uid,
                        'reg_count'=>1
                    )
                );
            }else{
                M('a_app_statistics')->where(array('uid'=>$uid))->save(
                    array(
                        'reg_count'=>($info['reg_count']+1)
                    )
                );
            }
        }
        return true;
    }


    /**
     * 转链开关
     *
     * 接口地址：http://app.taokehelp.cn/Api/zl_switch
     * */
    public  function  zl_switch(){
        $this->ajaxReturn(
            array(
                'data'=>0
            )
        );
    }

    /**
     * 小程序jsonp数据转换
     *
     * 接口地址：http://app.taokehelp.cn/Api/change_jsonp_xcx
     * */
    public function change_jsonp_xcx(){
        $info = I('info','','trim');
        $a = json_decode($info,true);
        $b = substr($a['data'],9);
        $c = substr($b,0,-1);
        $d = json_decode($c,true);
        $this->ajaxReturn(
            array(
                'images'=>$d['data']['images'],
            )
        );
    }

    /**
     * redis测试
     * */
    public function test(){
        $res = M('a_config_copy','daili_','DB_READ')->select();
        foreach ($res as $key=>$val){
            $config[$val['token']]=$val;
        }
        echo '<pre>';
        print_r($config);
        print_r(M('a_config_copy','daili_','DB_READ'));
        exit;
        $redis = new \Redis();
        $redis->connect('127.0.0.1', 6379);
        //存储数据到列表中
        $arr = array(
            1,2,3
        );
        $redis->lpush("tutorial-list", $arr);
        $redis->lpush("tutorial-list", "Mongodb");
        $redis->lpush("tutorial-list", "Mysql");
        // 获取存储的数据并输出
        $arList = $redis->lrange("tutorial-list", 0 ,10);
        echo '<pre>';
        print_r($arList);
    }


    public function getimg_test(){
        $itemid = "561365983055";
        $url = "https://hws.m.taobao.com/cache/mtop.wdetail.getItemDescx/4.1/?data=%7Bitem_num_id%3A"
            ."%s"."%7D&type=jsonp&dataType=jsonp";
        $res = vget(sprintf($url,trim($itemid)));
        $ress = json_decode($res,true);
        var_dump($ress);
    }

    public function diuba_dbredirect($code,$integral,$type){
        $appkey = '3UrpitPYo8WQ9HBPXWC1vXQYVTGy';
        $appsecret = '2tCArDmjYAKCP93CewMsXPDiB532';
        switch($type){
            case 1:$redirect = "https%3A%2F%2Factivity.m.duiba.com.cn%2Fsignactivity%2Findex%3Fid%3D90%26dpm%3D43018.41.1.0%26dcm%3D216.90.51.0%26appKey%3D3UrpitPYo8WQ9HBPXWC1vXQYVTGy%26open4share%3Dtongdun";
                break;
            case 3:$redirect = "";
                break;
            default:$redirect=I('get.dbredirect');
        }

        import('Org.Others.JiFen');// 导入JiFen类
        $jifen= new \JiFen(); // 实例化类
        $url=$jifen->buildRedirectAutoLoginRequest($appkey,$appsecret,$code,$integral,urldecode($redirect));
        header("Location:".$url);
    }

    /* 签到+加积分（本平台的）接口
    * $code
    * $type 1：签到   2：加积分
    *  */
    public function sign_api(){
        set_time_limit(0);
        $code = I('code');
        $type = I('type',1,'intval');
        $userinfo = M('wx_user')->where(array('invitation_code'=>$code))->find();
        if(empty($userinfo)){
            $this->ajaxReturn(
                array(
                    'msg'=>'不存在该用户',
                    'statue'=>0
                )
            );
        }
        if($type==2){
            $res = M('wx_user')->where(array('invitation_code'=>$code))->save(array('user_sign'=>($userinfo['user_sign']+1)));
            $add_res = M('a_sign_log')->add(
                array(
                    'code'=>$userinfo['invitation_code'],
                    'credits'=>1,
                    'ordernum'=>'',
                    'description'=>'分享商品',
                    'sign_type'=>'',
                    'add_time'=>'',
                    'sys_time'=>time(),
                    'data_json'=>'',
                )
            );
            if($res){
                $this->ajaxReturn(
                    array(
                        'msg'=>'',
                        'statue'=>1
                    )
                );
            }
        }
        $this->diuba_dbredirect($code,$userinfo['user_sign'],$type);
    }
    //同步积分添加
    public function add_sign(){
        $appkey = '3UrpitPYo8WQ9HBPXWC1vXQYVTGy';
        $appsecret = '2tCArDmjYAKCP93CewMsXPDiB532';
        import('Org.Others.JiFen');// 导入JiFen类
        $jifen= new \JiFen(); // 实例化类
        $request_array = $_GET;
        $res = $jifen->addCreditsConsume($appkey,$appsecret,$request_array);
        if(!empty($res)){
            $userinfo = M('wx_user')->where(array('invitation_code'=>$res['uid']))->find();
            if(empty($userinfo)){
                echo json_encode(array(
                    'status'=>'fail',
                    'errorMessage'=>'没有匹配到当前用户',
                    'bizId'=>$res['orderNum'],
                    'credits'=>$res['credits']
                ));exit;
            }
            $save_res = M('wx_user')->where(array('invitation_code'=>$res['uid']))->save(array('user_sign'=>($userinfo['user_sign']+$res['credits'])));
            $add_res = M('a_sign_log')->add(
                array(
                    'code'=>$res['uid'],
                    'credits'=>$res['credits'],
                    'ordernum'=>$res['orderNum'],
                    'description'=>$res['description'],
                    'sign_type'=>$res['type'],
                    'add_time'=>$res['timestamp'],
                    'sys_time'=>time(),
                    'data_json'=>json_encode($res)
                )
            );
            if($save_res){
                echo json_encode(array(
                    'status'=>'ok',
                    'errorMessage'=>'',
                    'bizId'=>$res['orderNum'],
                    'credits'=>$res['credits']
                ));exit;
            }else{
                echo json_encode(array(
                    'status'=>'fail',
                    'errorMessage'=>'增加积分失败',
                    'bizId'=>$res['orderNum'],
                    'credits'=>$res['credits']
                ));exit;
            }
        }else{
            echo json_encode(array(
                'status'=>'fail',
                'errorMessage'=>'网络异常,增加积分失败',
                'bizId'=>$res['orderNum'],
                'credits'=>$res['credits']
            ));exit;
        }
    }

    public function notice_sign(){

    }

    //同步积分消耗
    public function use_sign(){
        $appkey = '3UrpitPYo8WQ9HBPXWC1vXQYVTGy';
        $appsecret = '2tCArDmjYAKCP93CewMsXPDiB532';
        import('Org.Others.JiFen');// 导入JiFen类
        $jifen= new \JiFen(); // 实例化类
        $request_array = $_GET;
        $res = $jifen->parseCreditConsume($appkey,$appsecret,$request_array);
        if(!empty($res)){
            $userinfo = M('wx_user')->where(array('invitation_code'=>$res['uid']))->find();
            if(empty($userinfo)){
                echo json_encode(array(
                    'status'=>'fail',
                    'errorMessage'=>'没有匹配到当前用户',
                    'bizId'=>$res['orderNum'],
                    'credits'=>$res['credits']
                ));exit;
            }
            if($userinfo['user_sign']<$res['credits']){
                echo json_encode(array(
                    'status'=>'fail',
                    'errorMessage'=>'积分不足，使用积分失败',
                    'bizId'=>$res['orderNum'],
                    'credits'=>$res['credits']
                ));exit;
            }
            $save_res = M('wx_user')->where(array('invitation_code'=>$res['uid']))->save(array('user_sign'=>($userinfo['user_sign']-$res['credits'])));
            $add_res = M('a_use_sign_log')->add(
                array(
                    'code'=>$res['uid'],
                    'credits'=>$res['credits'],
                    'ordernum'=>$res['orderNum'],
                    'description'=>$res['description'],
                    'sign_type'=>$res['type'],
                    'add_time'=>$res['timestamp'],
                    'faceprice'=>$res['facePrice'],
                    'params'=>$res['params'],
                    'waitaudit'=>$res['waitAudit'],
                    'type'=>$res['type'],
                    'sys_time'=>time(),
                    'data_json'=>json_encode($res)
                )
            );
            if($save_res){
                echo json_encode(array(
                    'status'=>'ok',
                    'errorMessage'=>'',
                    'bizId'=>$res['orderNum'],
                    'credits'=>$res['credits']
                ));exit;
            }else{
                echo json_encode(array(
                    'status'=>'fail',
                    'errorMessage'=>'使用积分失败',
                    'credits'=>$res['credits'],
                    'bizId'=>$res['orderNum'],
                ));exit;
            }
        }else{
            echo json_encode(array(
                'status'=>'fail',
                'errorMessage'=>'网络异常,使用积分失败',
                'bizId'=>$res['orderNum'],
                'credits'=>$res['credits']
            ));exit;
        }
    }
    //微淘文档列表数据接口
    public function weitao_list(){
        $code = I('code');
        $p    = I('p',1);
        $num = 10;
        $start = ($p-1)*$num;
        if($code){
            $sql = "select count(*) as count from daili_a_weitao as a left join daili_wx_user as b on a.token=b.GzhToken where a.isshow=1 and b.invitation_code='$code'";
            $count = M('a_weitao','daili_','DB_DAILI_READ')->query($sql);
            $count = $count[0]['count'];
            if($count<=0){
                $sql = "select count(*) as count from daili_a_weitao where isshow=1 and token='gh_90c6882faaf9'";
                $count = M('a_weitao','daili_','DB_DAILI_READ')->query($sql);
                $count = $count[0]['count'];
                $count_page = ceil($count/$num);
                $sql="select id,title,add_time,ordid,pic_url,url,view,author,share from daili_a_weitao where isshow=1 and token='gh_90c6882faaf9' order by ordid asc,add_time desc limit $start,$num";
                $list = M('a_weitao','daili_','DB_DAILI_READ')->query($sql);
            }else{
                $count_page = ceil($count/$num);
                $sql="select a.id,a.title,a.add_time,a.ordid,a.pic_url,a.url,a.view,a.author,a.share from daili_a_weitao as a left join daili_wx_user as b on a.token=b.GzhToken where a.isshow=1 and b.invitation_code='$code' order by ordid asc,add_time desc limit $start,$num";
                $list = M('a_weitao','daili_','DB_DAILI_READ')->query($sql);
            }
        }else{
            $count = M('a_weitao','daili_','DB_DAILI_READ')->where(array('isshow'=>1))->count();
            $count_page = ceil($count/$num);
            $sql="select id,title,add_time,ordid,pic_url,url,view,author,share from daili_a_weitao where isshow=1 order by ordid asc,add_time desc limit $start,$num";
            $list = M('a_weitao','daili_','DB_DAILI_READ')->query($sql);
        }
        $res = array(
            'count'=>$count,
            'count_page'=>$count_page,
            'page_num'=>$num,
            'list'=>$list
        );
        $this->ajaxReturn($res);
    }
    //微淘详情页面
    public function weitao_info(){
        $id = I('id');
        $p = I('p',1);
        $num = 10;
        $start=($p-1)*$num;
        $info = M('a_weitao','daili_','DB_DAILI_READ')->where(array('id'=>$id))->find();
        $text = $info['text'];
        $text = str_replace('?tp=webp','',$text);
        $info['text']=str_replace('src="/ueditor','src="http://home.taokehelp.cn/ueditor',$text);
        if(!$info){
            $arr = array(
                'code'=>0,
                'msg'=>'参数错误'
            );
            $this->ajaxReturn($arr);
        }
        $weitao_id = $info['id'];
        $sql = "select * from daili_a_items where FIND_IN_SET($weitao_id,weitao_id) order by ordid asc,add_time desc limit $start,$num";
        $items=M('a_items','daili_','DB_DAILI_READ')->query($sql);
        if($p==1){
            $arr = array(
                'info'=>$info,
                'items'=>$items
            );
            M('a_weitao','daili_','DB_DAILI')->where(array('id'=>$id))->setInc('view');
        }else{
            $arr = array(
                'items'=>$items
            );
        }
        $this->ajaxReturn($arr);
    }
    //APP调用的发圈商品列表
    public function faquan_items(){
        $p    = I('page',1);
        $code = I('code');
        $res = S('faquan_item'.$code.$p);
        if(!$res){
            //根据code查询用户信息
            $user = M('wx_user')->field('GzhToken,TgwID,username,member_level')->where(array('invitation_code'=>$code))->find();
            /* if($user['gzhtoken']=='gh_26c51afe50df' || $user['gzhtoken']=='chuankeyouhui2' || $user['gzhtoken']=='gh_b676e24225c8'){
                //根据token查询用户ID
                $u = M('user')->field('id')->where(array('token'=>'gh_26c51afe50df'))->select();
            }else{
                $u = M('user')->field('id')->where(array('token'=>'gh_90c6882faaf9'))->select();
            } */
            $u = M('user')->field('id')->select();
            foreach ($u as $key=>$val){
                $uid .= $val['id'].',';
            }
            //查询渠道配置信息
            $token = $user['gzhtoken'];
            $member_level=$user['member_level'];
    
            if($member_level==1){
                $sql = "select a.* from daili_wx_user_level as a left join daili_a_media as b on a.token=b.token where b.token='$token'  and a.member_level=1";
                $media = M('wx_user_level')->query($sql);
                $shouyibi = $media[0]['level1'];
                //普通会员收入
                $sql = "select a.* from daili_a_config_copy as a left join daili_a_media as b on a.MediaID=b.id where b.token='$token'";
                $media = M('a_config_copy')->query($sql);
                $putong_shouyibi = $media[0]['shouyibi'];
            }elseif($member_level==2){
                $sql = "select a.* from daili_wx_user_level as a left join daili_a_media as b on a.token=b.token where b.token='$token'  and a.member_level=2";
                $media = M('wx_user_level')->query($sql);
                $shouyibi = $media[0]['level1'];
            }elseif($member_level==3){
                $sql = "select a.* from daili_wx_user_level as a left join daili_a_media as b on a.token=b.token where b.token='$token'  and a.member_level=3";
                $media = M('wx_user_level')->query($sql);
                $shouyibi = $media[0]['level1'];
            }else{
                $sql = "select a.* from daili_a_config_copy as a left join daili_a_media as b on a.MediaID=b.id where b.token='$token'";
                $media = M('a_config_copy')->query($sql);
                $shouyibi = $media[0]['shouyibi'];
                //超级会员收益
                $sql = "select a.* from daili_wx_user_level as a left join daili_a_media as b on a.token=b.token where b.token='$token'  and a.member_level=1";
                $media = M('wx_user_level')->query($sql);
                $chaoji_shouyibi = $media[0]['level1'];
            }
            //echo $shouyibi;exit;
            $uid = rtrim($uid,',');
            $num = 5;
            $start = ($p-1)*$num;
            $time = 12*3600;
            if($uid){
                $sql = "select * from daili_wx_faquan where uid in ($uid) order by add_time desc limit $start,$num";
            }else{
                $sql = "select * from daili_wx_faquan order by add_time desc limit $start,$num";
            }
            $res = M('wx_faquan','daili_','DB_DAILI_READ')->query($sql);
            foreach ($res as $key=>$val){
                //判断有没有口令
                if(empty($val['tj_reson'])){
                    $text = $val['title'];
                }else{
                    $text = $val['tj_reson'];
                }
                $res[$key]['title']=json_decode($val['title']);
                $replay = json_decode($val['replay']);
                //查询淘口令
                $k = M('wx_faquan_kouling','daili_','DB_DAILI_READ')->where(array('table_id'=>$val['id'],'item_id'=>$val['num_iid'],'pid'=>$user['tgwid']))->order('add_time desc')->find();
                if(!$k['kouling'] || ($k['kouling'] && (time()-$k['add_time']>$time))){
                    $r = $this->app_zhuanlian($val['id'],$val['num_iid'],$val['youhuiquan'],$user['tgwid'],$user['token'],$text,$user['username'],$val['title'],$val['pic']);
                    $res[$key]['b_kouling']=$r['kouling'];
                    $res[$key]['b_ehy_url']=$r['ehy_url'];
                    $res[$key]['b_short_url']=$r['short_url'];
                    $res[$key]['b_pid']=$val['b_pid'];
                    $res[$key]['b_add_time']=time();
                    $commission_rate=$r['commission_rate'];
                    $kouling = $r['kouling'];
                }else{
                    $res[$key]['b_kouling']=$k['kouling'];
                    $res[$key]['b_ehy_url']=$k['ehy_url'];
                    $res[$key]['b_short_url']=$k['short_url'];
                    $res[$key]['b_pid']=$k['pid'];
                    $res[$key]['b_add_time']=$k['add_time'];
                    $commission_rate=$k['commission_rate'];
                    $kouling = $k['kouling'];
                }
                $qudao_shouyi=($shouyibi/100)*0.9*$val['price']*($commission_rate/100);
                if($member_level==0){
                    $a = array(
                        'level'=>1,
                        'level_str'=>'超级会员',
                        'shouyi'=>$chaoji_shouyibi,
                        'daili_rate'=>round(($chaoji_shouyibi/100)*0.9*$val['price']*($commission_rate/100),2)
                    );
                    $b = array(
                        'level'=>0,
                        'level_str'=>'会员',
                        'shouyi'=>$shouyibi,
                        'daili_rate'=>round(($shouyibi/100)*0.9*$val['price']*($commission_rate/100),2)
                    );
                }
                if($member_level==1){
                    $a = array(
                        'level'=>1,
                        'level_str'=>'超级会员',
                        'shouyi'=>$shouyibi,
                        'daili_rate'=>round(($shouyibi/100)*0.9*$val['price']*($commission_rate/100),2)
                    );
                    $b = array(
                        'level'=>0,
                        'level_str'=>'会员',
                        'shouyi'=>$putong_shouyibi,
                        'daili_rate'=>round(($putong_shouyibi/100)*0.9*$val['price']*($commission_rate/100),2)
                    );
                }
                $other_shouyi=array($a,$b);
                if(strpos($replay,'【淘口令】')){
                    $replay = str_replace('【淘口令】',$kouling,$replay);
                }else{
                    $replay .= $kouling;
                }
                $res[$key]['pic']=explode(',',rtrim($val['pic'],','));
    
                $a=array(
                    $replay,$val['tj_reson']
                );
                $res[$key]['replay']=array_filter($a);
                $qudao = M('user')->where(array('id'=>$val['uid']))->find();
                if(!$qudao){
                    $qudao['name']='拼拼侠';
                }
                $res[$key]['qudao_name']=$qudao['name'];
                $res[$key]['qudao_pic']=$qudao['pic'];
                $res[$key]['qudao_shouyi']=round($qudao_shouyi,2);
                $res[$key]['qudao_shouyi_new']=$other_shouyi;
            }
        }
        $this->ajaxReturn($res);
    }
    //内部调用转链接口
    /**
     * $num_iid     商品ID
     * $quan        商品优惠券
     * $pid         推广位id
     * $token       公众号token
     * $text        推荐理由
     * $account     账号
     * taobao_tbk_privilege_get_daili   转高佣链接接口
     * taobao_tbk_data_report           上行日志接口
     * */
    private function app_zhuanlian($id,$itemid,$quan,$pid,$token,$text,$account,$title,$pic){
        $arr_pid = explode('_',$pid);
        $adzone_id = $arr_pid[3];
        $site_id   = $arr_pid[2];
        $quan=urlencode($quan);
        $url = C('GXZL_API_URL')."/Index/taobao_tbk_privilege_get_daili?youhuiquan=$quan&item_id=$itemid&adzone_id=$adzone_id&site_id=$site_id";
        $res = curl_get($url);
        $click_url = $res['coupon_click_url'];
        $commission_rate = $res['max_commission_rate'];
        if($click_url){
            $tbkurl=urlencode($click_url);
            $url = str_replace('http://','https://',$click_url);
            //获取短连接
            $url = C('DWZ_API_URL')."/tkbGetDWZ?url=".urlencode($url)."&itemid=$itemid";
            $shorturl_arr = curl_get($url);
            $shorturl = $shorturl_arr['msg'];
            $taokouling  = $shorturl_arr['kouling'];
            $tkl = urlencode($taokouling);
            if(!$shorturl){
                $arr = array('code'=>0,'msg'=>'生成短网址失败');
                return $arr;
            }
            $commission = $res['max_commission_rate'];
            
            $d = array(
                'item_id'=>$itemid,
                'pid'=>$pid,
                'kouling'=>$taokouling,
                'ehy_url'=>$click_url,
                'add_time'=>time(),
                'short_url'=>$shorturl,
                'table_id'=>$id,
                'commission_rate'=>$commission_rate
            );
            M('wx_faquan_kouling','daili_','DB_DAILI')->add($d);
            return $d;
        }else{
            $d = array(
                'code'=>0,
                'msg'=>'转链接失败'
            );
            return $d;
        }
    }
    //品牌商品数据
    public function brand_items(){
        $p = I('p',1);
        $num = 5;
        $start = ($p-1)*$num;
        $brand = array();
        $ads = array();

        if($p<=1){
            $brand = M('a_brand','daili_','DB_DAILI_READ')->where(array('isshow'=>1))->order('ordid asc,id desc')->select();
            foreach ($brand as $key=>$val){
                $where['_string'] = 'FIND_IN_SET('.$val['id'].',brand_id)';
                $r = M('a_items','daili_','DB_DAILI_READ')->where($where)->limit(0,3)->select();
                $brand[$key]['items']=$r;
            }
            $items = M('a_items','daili_','DB_DAILI_READ')->where(array('_string'=>'brand_id is not null'))->limit(0,$num)->order('ordid asc,add_time desc')->select();
            $ads = array(
                'title'=>'',
                'pic'=>'',
                'url'=>''
            );
        }else{
            $items = M('a_items','daili_','DB_DAILI_READ')->where(array('_string'=>'brand_id is not null'))->limit($start,$num)->order('ordid asc,add_time desc')->select();
        }

        $arr = array(
            'brand'=>$brand,
            'items'=>$items,
            //'ads'=>$ads
        );
        $this->ajaxReturn($arr);
    }
    //查询品牌下的所有数据
    public function brand_lists(){
        $p = I('p',1);
        $id= I('id');
        $type=I('t');
        $num = 10;
        $start=($p-1)*$num;
        $where['_string'] = 'FIND_IN_SET('.$id.',brand_id)';
        $res = M('a_items','daili_','DB_DAILI_READ')->where($where)->limit($start,$num)->select();
        $this->ajaxReturn($res);
    }
    //判断手机号是否注册
    public function check_phone(){
        $phone = I('phone');

        $res = M('wx_user','daili_','DB_READ')->where(array('Phone'=>$phone))->find();
        if(!$res){
            $arr = array(
                'code'=>1,
                'msg'=>'手机号可用'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'手机号已经注册'
            );
        }
        $this->ajaxReturn($arr);
    }

    //联系客服接口
    public function kefu_info(){
        $code = I('code');
        //根据code查询用户信息
        $user = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        $token = $user['gzhtoken'];
        $kefuid = $user['kefu_id'];
        if($kefuid){
            //如果有客服就显示客服微信号
            $kefu = M('wx_user','daili_','DB_READ')->where(array('ID'=>$kefuid))->find();
            $wxnum = $kefu['wxnum'];
            $img = $kefu['kefu_qrcode'];
        }else{
            //查询这个渠道的一个客服且有微信号的
            $sql = "select * from daili_wx_user where GzhToken='$token' and kefu_id=ID and WxNum is not null limit 0,1";
            $kefu=M('wx_user','daili_','DB_READ')->query($sql);
            $wxnum = $kefu[0]['wxnum'];
            $img = $kefu[0]['kefu_qrcode'];
        }
        $this->ajaxReturn(array('code'=>1,'msg'=>$wxnum,'img_url'=>$img,'text'=>'专属客服微信'));
    }

    /***支付模块  开始***/
    /*
     * 生成订单--支付宝
     * 参数：1、code ：用户自身邀请码  2、total_amount：支付金额
     * */
    public function set_order(){
        $this->check_token();
        $url="http://";
        $url .= $_SERVER ['HTTP_HOST'];
        $code = I('code');
        $total_amount = I('total_amount',0,'floatval');
        if(empty($code)){
            $this->ajaxReturn(
                array(
                    'msg'=>'邀请码参数为空',
                    'statue'=>0
                )
            );
        }
        if($code!="ynyrt2c9"){
            if($total_amount<99){
                $this->ajaxReturn(
                    array(
                        'msg'=>'支付金额异常',
                        'statue'=>0
                    )
                );
            }
        }

        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($userinfo)){
            $this->ajaxReturn(
                array(
                    'msg'=>'不存在该用户',
                    'statue'=>0
                )
            );
        }else{
            if($userinfo['member_level']>0){
                $this->ajaxReturn(
                    array(
                        'msg'=>'该用户无需升级',
                        'statue'=>0
                    )
                );
            }
        }
        if($total_amount<=0){
            $this->ajaxReturn(
                array(
                    'msg'=>'支付金额异常',
                    'statue'=>0
                )
            );
        }

        Vendor('AopSdk',VENDOR_PATH.C('Vendor_alipay_file'));
        $aop = new \AopClient;
        $aop->gatewayUrl = "https://openapi.alipay.com/gateway.do";
        $aop->appId = C('alipay_appid');
        $aop->rsaPrivateKey = C('rsaPrivateKey');
        $aop->format = "json";
        $aop->charset = "UTF-8";
        $aop->signType = "RSA2";
        $aop->alipayrsaPublicKey = C('alipayrsaPublicKey');
        //实例化具体API对应的request类,类名称和接口名称对应,当前调用接口名称：alipay.trade.app.pay
        $request = new \AlipayTradeAppPayRequest();
        $body = "店主福利社";
        $subject = "升级店主";
        $out_trade_no = date('YmdHis',time()).$code.rand(1000,9999);
        $data = array(
            'add_time'=>time(),
            'uid'=>$userinfo['id'],
            'invitation_code'=>$code,
            'out_trade_no'=>$out_trade_no,
            'total_amount'=>$total_amount
        );
        M('a_upgrade_order')->add($data);
//SDK已经封装掉了公共参数，这里只需要传入业务参数
        $bizcontent = "{\"body\":\"$body\","
            . "\"subject\": \"$subject\","
            . "\"out_trade_no\": \"$out_trade_no\","
            . "\"timeout_express\": \"30m\","
            . "\"total_amount\": \"$total_amount\","
            . "\"product_code\":\"QUICK_MSECURITY_PAY\""
            . "}";
        $request->setNotifyUrl($url."/Api/callback_order");  //商户外网可以访问的异步地址
        $request->setBizContent($bizcontent);
//这里和普通的接口调用不同，使用的是sdkExecute
        $response = $aop->sdkExecute($request);
//htmlspecialchars是为了输出到页面时防止被浏览器将关键参数html转义，实际打印到日志以及http传输不会有这个问题
        echo $response;
//        echo htmlspecialchars($response);//就是orderString 可以直接给客户端请求，无需再做处理。
    }

    /*
    * 校验订单--支付宝
    * 参数 1、code ：用户自身邀请码  2、out_trade_no：商家订单号  3、trade_no：支付宝交易号
    * */
    public function check_order(){
        $this->check_token();
        $code = I('code');
        $out_trade_no = I('out_trade_no','','trim');
        $trade_no = I('trade_no','','trim');
        Vendor('AopSdk',VENDOR_PATH.C('Vendor_alipay_file'));
        $aop = new \AopClient ();
        $aop->gatewayUrl = 'https://openapi.alipay.com/gateway.do';
        $aop->appId = C('alipay_appid');
        $aop->rsaPrivateKey = C('rsaPrivateKey');
        $aop->alipayrsaPublicKey=C('alipayrsaPublicKey');
        $aop->apiVersion = '1.0';
        $aop->signType = 'RSA2';
        $aop->postCharset='UTF-8';
        $aop->format='json';
        $request = new \AlipayTradeQueryRequest ();
        $request->setBizContent("{" .
            "\"out_trade_no\":\"$out_trade_no\"," .
            "\"trade_no\":\"$trade_no\"" .
            "  }");
        $result = $aop->execute ( $request);
        $result =  json_decode( json_encode( $result),true);
        //成功操作
        $orderinfo = M('a_upgrade_order')->where(array('invitation_code'=>$code,'out_trade_no'=>$out_trade_no))->find();

        if(empty($orderinfo)){
            $this->ajaxReturn(
                array(
                    'statue'=>0,
                    'msg'=>'该用户不存在该订单'
                )
            );
        }else{

            //接口查询成功状态
            if($result['alipay_trade_query_response']['trade_status']=="TRADE_SUCCESS"){
                $res = M('a_upgrade_order')
                        ->where(array('invitation_code'=>$code,'out_trade_no'=>$out_trade_no))
                        ->save(array(
                            'pay_time'=>strtotime($result['alipay_trade_query_response']['send_pay_date']),
                            'order_statue'=>1,
                            'trade_no'=>$result['alipay_trade_query_response']['trade_no'],
                        ));
                    //同步奖励
                    $this->update_user_lever_reward($code,$out_trade_no);
                    $arr = array(
                        'statue'=>1,
                        'msg'=>"匹配成功",
                    );
                    $arr+=$this->get_userinfo_api($code);
                    M('a_test_log')->add(
                        array('type'=>4,
                            'msg_info'=>json_encode(array(
                            'out_trade_no'=>$out_trade_no,
                            'trade_no'=>$trade_no,
                            'code'=>$code,
                            'result'=>$result
                        )))
                    );
                    $this->ajaxReturn($arr);
            }else{
                M('a_test_log')->add(
                    array('type'=>1,
                        'msg_info'=>json_encode(array(
                        'out_trade_no'=>$out_trade_no,
                        'trade_no'=>$trade_no,
                        'code'=>$code
                    )))
                );
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>$result['alipay_trade_query_response']['sub_msg'],
                        'data'=>array(
                            'out_trade_no'=>$out_trade_no,
                            'trade_no'=>$trade_no,
                            'code'=>$code
                        )
                    )
                );
            }
        }
    }
    /*
    * 异步回调订单，更新用户身份--支付宝
    * */
    public function callback_order(){
        Vendor('AopSdk',VENDOR_PATH.C('Vendor_alipay_file'));
        $aop = new \AopClient;
        $aop->alipayrsaPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArX2xz6j0SLO+0YAI07jq+mulZR20BxwtCQbfTGjGNDEauJLJ05f/3mogmbKvlz1MtZMuODgaggnvq+kQDjsdnzPyHOpRkS43Rr6JtP51O5QAc7jx+oHsWcxDG2nUuqb5IBf5FWvPiuiyO1daeZA7nDJbD+h5MA+C3Bzo4hVqsocu/KVi/gjWqc0NnvhA8EUPyq3Yx/Wj8aXQs6bV+fTNv0tklu4RGhyDUcrH6fkWlyE9mC98lq31E/rrQZJvkeKqkxmo3DMNUWgAFL/erg3+ycgAM6jz3EznPZkXCRQg907Cbj5rqF8jmcBFUt688D4+wsS77d2+9PS1T5I4RQhZUwIDAQAB";
        $flag = $aop->rsaCheckV1($_POST, NULL, "RSA2");
        $_POST['flag'] = $flag;
        M('a_test_log')->add(
            array('type'=>2,'msg_info'=>json_encode($_POST))
        );
        if($flag){
            if($_POST['trade_status'] == "TRADE_SUCCESS"){
                // 修改订单支付状态
                $res = M('a_upgrade_order')
                    ->where(array('out_trade_no'=>$_POST['out_trade_no']))
                    ->save(array(
                        'pay_time'=>strtotime($_POST['gmt_payment']),
                        'order_statue'=>1,
                        'trade_no'=>$_POST['trade_no'],
                    ));
                $this->update_user_lever_reward('',$_POST['out_trade_no']);
                $this->update_user_member_level($_POST['out_trade_no']);
            }
        }else{
            //验证失败
        }
    }

    /*
     * 生成订单--微信
     * 参数：1、code ：用户自身邀请码  2、total_amount：支付金额
     * */
    public function set_order_wx(){
        $this->check_token();
        $url="http://";
        $url .= $_SERVER ['HTTP_HOST'];
        $code = I('code');
        $total_amount = I('total_amount',0,'floatval');
        if(empty($code)){
            $this->ajaxReturn(
                array(
                    'msg'=>'邀请码参数为空',
                    'statue'=>0
                )
            );
        }
        if($code !="ynyrt2c9" && $code != '4jy96r8h' && $code != '2bj4mg6t'){
            if($total_amount<99){
                $this->ajaxReturn(
                    array(
                        'msg'=>'支付金额异常',
                        'statue'=>0
                    )
                );
            }
        }
        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        if(empty($userinfo)){
            $this->ajaxReturn(
                array(
                    'msg'=>'不存在该用户',
                    'statue'=>0
                )
            );
        }else{
            if($userinfo['member_level']>0){
                $this->ajaxReturn(
                    array(
                        'msg'=>'该用户无需升级',
                        'statue'=>0
                    )
                );
            }
        }
        if($total_amount<=0){
            $this->ajaxReturn(
                array(
                    'msg'=>'支付金额异常',
                    'statue'=>0
                )
            );
        }
        $out_trade_no = date('YmdHis',time()).$code.rand(1000,9999);
        $data = array(
            'add_time'=>time(),
            'uid'=>$userinfo['id'],
            'invitation_code'=>$code,
            'out_trade_no'=>$out_trade_no,
            'total_amount'=>$total_amount,
            'pay_channel'=>1
        );
        M('a_upgrade_order')->add($data);
        $this->ajaxReturn(
            array(
                'statue'=>1,
                'out_trade_no'=>$out_trade_no,
            )
        );
    }


    /*
    * 校验订单--微信
    * 参数 1、code ：用户自身邀请码  2、trade_no：微信交易号
    * */
    public function check_order_wx(){

    }


    /*
    * 异步回调订单，更新用户身份--微信
    * */
    public function callback_order_wx(){
        header("Content-type:text/html;charset=utf-8");
        //接收微信发过来的数据
        $xml = $GLOBALS['HTTP_RAW_POST_DATA'];
        //接收微信发过来的数据
        $ob=simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA);
        $json  = json_encode($ob);
        $configData = json_decode($json, true);
        //获取所有的key值并且排序
        $keys=array_keys($configData);
        sort($keys);
        $res='';
        for($i=0;$i<count($keys);$i++){
            if(strcmp($keys[$i], 'sign')!=0)
            {
                $res=$res.$keys[$i].'='.$configData[$keys[$i]].'&';
            }
        }
        $sign=strtoupper(md5($res.'key=ae812107077f984738fff2326e252b32'));
        if(strcmp($configData['sign'], $sign)!=0){
            //key值不对应 返回 给微信服务器返回失败状态
            $xml=<<<XML
<?xml version='1.0' encoding='utf-8'?>
<xml>
</xml>
XML;
            $xml = simplexml_load_string($xml);
            $xml->addChild('return_code','<![CDATA[FAIL]]>');
            $xml->addChild('return_msg','<![CDATA[签名失败]]>');
            echo $xml->asXML();
            return;exit;
        }else{
            //更新订单
            M('a_upgrade_order')
                ->where(array('out_trade_no'=>$configData['out_trade_no']))
                ->save(array(
                    'pay_time'=>strtotime($configData['time_end']),
                    'order_statue'=>1,
                    'wx_trade_no'=>$configData['transaction_id'],
                ));
            //同步奖励
            $this->update_user_lever_reward('',$configData['out_trade_no']);
            $this->update_user_member_level($configData['out_trade_no']);
            M('a_test_log')->add(
                array('type'=>5,
                    'msg_info'=>json_encode(array(
                        'out_trade_no'=>$configData['out_trade_no'],
                        'wx_trade_no'=>$configData['transaction_id'],
                        'result'=>$configData
                    )))
            );

            //给微信服务器返回成功状态
            $xml=<<<XML
<?xml version='1.0' encoding='utf-8'?>
<xml>
</xml>
XML;
            $xml = simplexml_load_string($xml);
            $xml->addChild('return_code','<![CDATA[SUCCESS]]>');
            $xml->addChild('return_msg','<![CDATA[OK]]>');
            echo $xml->asXML();
        }
    }

    /***支付模块  结束***/


    /*** 公共方法 开始 ***/

    /*
     * 用于接口参数安全检测(app)
     * */
    public function check_token_app(){
        $str_url = "";
        if(IS_POST){
            $arr_url=I('post.');
            foreach($arr_url as $key=>$val){
                if($key !='token'){
                    $str_url .=$val;
                }
            }
            $token = $arr_url['token'];
        }else{
            $token = $_GET['token'];
            $url = $_SERVER['REQUEST_URI'];
            $arr_url = explode('?',$url);
            $arr_url = $arr_url[1];
            $arr_url = explode('&',$arr_url);
            foreach($arr_url as $val){
                $array_url = explode('=',$val);
                if($array_url[0] !='token'){
                    $str_url .=$array_url[1];
                }
            }
        }
        $str = $str_url.'pinpinxia2018$';
        $service_token = md5(md5($str));
        if($token!=$service_token){
            $arr = array(
                'code'=>'fali',
                'msg' =>'token验证错误'
            );
            $this->ajaxReturn($arr);
            exit;
        }
    }

    /*
     * 用于接口参数安全检测(H5)
     * */
    public function check_token(){
        $str_url = "";
        if(IS_POST){
            $arr_url=I('post.');
            foreach($arr_url as $key=>$val){
                if($key !='token'){
                    if($key=='page'){
                        $val=1;
                    }
                    $str_url .=$val;
                }
            }
            $token = $arr_url['token'];
        }else{
            $token = $_GET['token'];
            $url = $_SERVER['REQUEST_URI'];
            $arr_url = explode('?',$url);
            $arr_url = $arr_url[1];
            $arr_url = explode('&',$arr_url);
            foreach($arr_url as $val){
                $array_url = explode('=',$val);
                if($array_url[0]=='page'){
                    $array_url[1]=1;
                }
                if($array_url[0] !='token'){
                    $str_url .=$array_url[1];
                }
            }
        }
        $str = $str_url.'pinpinxia2018$';
        $service_token = md5(md5($str));
        if($token!=$service_token){
            $arr = array(
                'code'=>'fali',
                'msg' =>'token验证错误'
            );
            $this->ajaxReturn($arr);
            exit;
        }
    }

    /*
     * 获取当前用户的各个参数
     * 参数：code
     * 返回值：用户信息、比例、本月预估、今日预估
     * */
    public function get_userinfo_api($code){
        $str_id = "";
        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();

        $address = M('receiving_address')->where(array('uid'=>$userinfo['id']))->find();
        if($address){
            if($address['phone'] && $address['name'] && $address['address']){
                $userinfo['receiving_address']=1;  //表示填写地址
                $userinfo['address_info']=$address;
            }else{
                $userinfo['receiving_address']=0;//表示没有填写地址
            }
        }else{
            $userinfo['receiving_address']=0;//表示没有填写地址
        }
        //今日时间
        $now_start = mktime(0,0,0,date('m'),date('d'),date('Y'));
        $now_last  = mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
        //本月时间
        $month_begin = mktime(0,0,0,date('m'),1,date('Y'));
        $month_end =  mktime(23,59,59,date('m'),date('t'),date('Y'));
        $now_first_yg = M('a_order','daili_','DB_READ')
            ->where(array('daili_a_shouyi.UID'=>$userinfo['id'],
                'daili_a_order.CreateTime'=>array('between',array($now_start,$now_last))))
            ->join(" left join daili_a_shouyi on daili_a_order.ID =  daili_a_shouyi.OrderID ")
            ->sum('daili_a_shouyi.ShouYi');

        $month_first_yg = M('a_order','daili_','DB_READ')
            ->where(array('daili_a_shouyi.UID'=>$userinfo['id'],
                'daili_a_order.CreateTime'=>array('between',array($month_begin,$month_end))))
            ->join(" left join daili_a_shouyi on daili_a_order.ID =  daili_a_shouyi.OrderID ")
            ->sum('daili_a_shouyi.ShouYi');
        //计算团队收益
        if($userinfo['member_level']<2){
            //
            $now_sql = "select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.CreateTime between $now_start and $now_last  and b.ShangJiUID = ".$userinfo['id'];
            $now_sums = M('a_order')->query($now_sql);
            $now_second_yg = $now_sums[0]['sum'];
            //
            $month_sql = "select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.CreateTime between $month_begin and $month_end  and b.ShangJiUID = ".$userinfo['id'];
            $month_sums = M('a_order')->query($month_sql);
            $month_second_yg = $month_sums[0]['sum'];
        }elseif($userinfo['member_level']==2){
            $str_id = "";
            $p_str_id="";
            //先查询所有下级
            $res1 = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>$userinfo['id']))->select();
            if(!empty($res1)){
                foreach ($res1 as $key=>$val){
                    $str_id .= $val['id'].',';
                }
                $str_id=rtrim($str_id,',');
                //查询下下级
                $res2 = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>array('in',$str_id)))->select();
                foreach ($res2 as $keys=>$vals){
                    $p_str_id .= $vals['id'].',';
                }
                $p_str_id=rtrim($p_str_id,',');
                //
                $now_sql = "select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi"
                    ." as b on a.ID=b.OrderID where a.CreateTime between $now_start and $now_last  and b.UID in ($str_id) AND b.ShangJiUID=".$userinfo['id'];
                $now_sums = M('a_order')->query($now_sql);
                if(!empty($p_str_id)){
                    $now_sql2 = "select sum(b.ShangShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi"
                        ." as b on a.ID=b.OrderID where a.CreateTime between $now_start and $now_last  and b.UID in ($p_str_id) AND b.ShangShangJiUID=".$userinfo['id'];
                    $now_sums2 = M('a_order')->query($now_sql2);
                    $now_second_yg = $now_sums[0]['sum']+ $now_sums2[0]['sum'];
                }else{
                    $now_second_yg = $now_sums[0]['sum'];
                }
                //
                $month_sql = "select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi"
                    ." as b on a.ID=b.OrderID where a.CreateTime between $month_begin and $month_end  and b.UID in ($str_id) AND b.ShangJiUID=".$userinfo['id'];
                $month_sums = M('a_order')->query($month_sql);
                if(!empty($p_str_id)){
                    $month_sql2 = "select sum(b.ShangShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi"
                        ." as b on a.ID=b.OrderID where a.CreateTime between $month_begin and $month_end  and b.UID in ($p_str_id) AND b.ShangShangJiUID=".$userinfo['id'];
                    $month_sums2 = M('a_order')->query($month_sql2);
                    $month_second_yg = $month_sums[0]['sum']+ $month_sums2[0]['sum'];
                }else{
                    $month_second_yg = $month_sums[0]['sum'];
                }
            }
        }elseif($userinfo['member_level']==3){
            $res1 = M('wx_user','daili_','DB_READ')
                ->field('ID')
                ->where(array('member_area'=>$userinfo['id']))
                ->select();
            $str_ids = "";
            foreach ($res1 as $k=>$v){
                $str_ids .= $v['id'].',';
            }
            $str_ids=rtrim($str_ids,',');
            //
            $now_sql = "select sum(b.area_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.CreateTime between $now_start and $now_last  and b.UID in ($str_ids)";
            $now_sums = M('a_order')->query($now_sql);
            $now_second_yg = $now_sums[0]['sum'];
            //
            $month_sql = "select sum(b.area_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.CreateTime between $month_begin and $month_end  and b.UID in ($str_ids)";
            $month_sums = M('a_order')->query($month_sql);
            $month_second_yg = $month_sums[0]['sum'];
        }



        //会员和店主数量查询
        if($userinfo['member_level']<=2){
            //先查询所有下级
            $res1 = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>$userinfo['id']))->select();
            foreach ($res1 as $key=>$val){
                $str_id .= $val['id'].',';
            }
            $str_id=rtrim($str_id,',');
            if(empty($str_id)){
                $str_id = $userinfo['id'];
            }
            $team_count = M('wx_user','daili_','DB_READ')
                ->where("(Pid=".$userinfo['id']." or Pid in(".$str_id.") )")
                ->count();
        }elseif($userinfo['member_level']==3){
            $team_count = M('wx_user','daili_','DB_READ')->where(array('member_area'=>$userinfo['id']))->count();
        }

        if($userinfo['member_level']==-1){
            $userinfo['member_level_str']='拼拼侠粉丝';
        }elseif($userinfo['member_level']==0){
            $userinfo['member_level_str']='会员';
        }elseif($userinfo['member_level']==1){
            $userinfo['member_level_str']='店主';
        }elseif($userinfo['member_level']==2){
            $userinfo['member_level_str']='销售经理';
        }elseif($userinfo['member_level']==3){
            $userinfo['member_level_str']='服务经理';
        }

        $user_level = get_level($userinfo['id'],$userinfo['member_level'],$userinfo['token']);
        $daili_rate = ($user_level['b_level1']/100)*0.9;
        $tixian_yue = M('a_tixian','daili_','DB_READ')->where(array('UID'=>$userinfo['id'],'Statue'=>0))->sum('JinE');
        $userinfo['yue'] = $userinfo['yue']-$tixian_yue;
        $arr = array(
            'userinfo'=>$userinfo,
            'all_month_yg'=>($month_first_yg+$month_second_yg)>0?sprintf("%.2f",($month_first_yg+$month_second_yg)):0,
            'all_today_yg'=>($now_first_yg+$now_second_yg)>0?sprintf("%.2f",($now_first_yg+$now_second_yg)):0,
            'team_count'=>$team_count>0?$team_count:0,
            'daili_rate'=>$daili_rate
        );
        return $arr;
    }

    /*
     * 更新成为店主等级，同步升级奖励
     * 参数：code  ordernum
     * */
    public function update_user_lever_reward($code,$ordernum){
        if(!empty($code)){
            $user = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
            $order = M('a_upgrade_order','daili_','DB_READ')->where(array('invitation_code'=>$code,'out_trade_no'=>$ordernum))->find();
        }else{
            //根据订单查询所属用户
            $order = M('a_upgrade_order','daili_','DB_READ')->where(array('out_trade_no'=>$ordernum))->find();
            $user = M('wx_user','daili_','DB_READ')->where(array('ID'=>$order['uid']))->find();
        }
        M('wx_user')->where(array('invitation_code'=>$user['invitation_code']))->save(array('member_level'=>1));
        $sj_user = M('wx_user','daili_','DB_READ')->where(array('ID'=>$user['pid']))->find();
        if($sj_user){
            $get_shouyi_statue = $sj_user['member_level']>0?1:0;
            $member_level = $sj_user['member_level']<2?1:$sj_user['member_level'];
            //查询奖励配置
            $config = M('wx_user_level','daili_','DB_READ')->field('yaoqingjiangli')->where(array('token'=>$user['gzhtoken'],'member_level'=>$member_level))->find();
            //分配奖励
            $jl_info = M('b_jiangli','daili_','DB_READ')->where(array('UID'=>$sj_user['id'],'XiaJiUID'=>$user['id'],'type'=>2))->find();
//            $jl_info = M('b_jiangli','daili_','DB_READ')->where(array('UID'=>$sj_user['id'],'XiaJiUID'=>$user['id'],'orderid'=>$order['id'],'type'=>2))->find();
            if(empty($jl_info)){
                $add = array(
                    'UID'=>$sj_user['id'],
                    'XiaJiUID'=>$user['id'],
                    'Money'=>$config['yaoqingjiangli'],
                    'Time'=>time(),
                    'statue'=>$get_shouyi_statue,
                    'type'=>2,
                    'orderid'=>$order['id'],
                    'operation_time'=>$sj_user['member_level']>0?time():'',
                );
                M('b_jiangli')->add($add);
                //更新店主奖励余额
                if($sj_user['member_level']>0){
                    M('wx_user')->where(array('ID'=>$sj_user['id']))->save(array(
                        'yaoqingdianzhu_jiangli'=>($sj_user['yaoqingdianzhu_jiangli']+$config['yaoqingjiangli'])
                    ));
                }
                //更新当前支付用户的所有下级支付的奖励状态
                $jl_infos = M('b_jiangli','daili_','DB_READ')->where(array('UID'=>$user['id'],'statue'=>0,'type'=>2))->select();
                foreach($jl_infos as $k1=>$v1){
                    M('b_jiangli')->where(array('ID'=>$v1['id']))->save(array('statue'=>1));
                    $yaoqingdianzhu_jiangli = M('wx_user','daili_','DB_READ')->where(array('ID'=>$user['id']))->getField('yaoqingdianzhu_jiangli');
                    M('wx_user')->where(array('ID'=>$user['id']))->save(array(
                        'yaoqingdianzhu_jiangli'=>($yaoqingdianzhu_jiangli+$v1['money'])
                    ));
                }
            }

            M('a_test_log')->add(
                array(
                    'type'=>3,
                    'msg_info'=>json_encode(array(
                    'code'=>$user['invitation_code'],
                    'UID'=>$sj_user['id'],
                    'XiaJiUID'=>$user['id'],
                    'Money'=>$config['yaoqingjiangli'],
                    'Time'=>time(),
                    'statue'=>$get_shouyi_statue,
                    'orderid'=>$order['id'],
                    'sj_member_level'=>$sj_user['member_level'],
                    'add'=>$add,
                    'sql'=>M('wx_user_level','daili_','DB_READ')->getLastSql(),
                )))
            );
        }
    }

    /*
     * 更新上级用户等级
     * 参数： ordernum
     * */
    public function update_user_member_level($ordernum){
        $str_id = "";
        //根据订单查询所属用户
        $order = M('a_upgrade_order','daili_','DB_READ')->where(array('out_trade_no'=>$ordernum))->find();
        $user = M('wx_user','daili_','DB_READ')->where(array('ID'=>$order['uid']))->find();
        $sj_user = M('wx_user','daili_','DB_READ')->where(array('ID'=>$user['pid']))->find();
        $res1 = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>$sj_user['id']))->select();
        foreach ($res1 as $key=>$val){
            $str_id .= $val['id'].',';
        }
        $str_id=rtrim($str_id,',');
        if(empty($str_id)){
            $str_id = $user['id'];
        }
        $count = M('wx_user','daili_','DB_READ')
            ->where("Pid=".$user['id']." or Pid in(".$str_id.") and member_level=1")
            ->count();
        if($sj_user['member_level']==1){
            if($count>=100){
                M('wx_user')->where(array('ID'=>$sj_user['id']))->save(array('member_level'=>2));
            }
        }elseif($sj_user['member_level']==2){
            if($count>=1000){
                M('wx_user')->where(array('ID'=>$sj_user['id']))->save(array('member_level'=>3));
            }
        }else{

        }
    }

    //生成链接验证token
    public function get_token($parame){
        $str = "";
        foreach ($parame as $key=>$val){
            $str .= $val;
        }
        $str .= 'pinpinxia2018$';
        $token = md5(md5($str));
        return $token;
    }

    /*
     * 查询上月 (个人及团队总收益+邀请奖励) 值
     * 参数  code
     * */
    public function find_lastmonth_income_sum($code){
        set_time_limit(0);
        $str_id = "";
        $p_str_id = "";
        //上个月时间
        $t = time();
        $time_start = mktime(0,0,0,date("m",$t)-1,1,date("Y",$t));
        $time_last = mktime(23,59,59,date("m",$t)-1,date("t",$time_start),date("Y",$t));
        //查询用户信息
        $userinfo = M('wx_user','daili_','DB_READ')->where(array('invitation_code'=>$code))->find();
        //查询当前用户的所有下级
        $p_userinfo = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>$userinfo['id']))->select();
        foreach ($p_userinfo as $key=>$val){
            $str_id .= $val['id'].',';
        }
        $str_id=rtrim($str_id,',');
        $where_order_statue = " and a.OrderStatue='订单结算'";
        $where_order_time = " a.CompleteTime between $time_start and $time_last";
        //本人
        $first_sql = "select sum(b.ShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.UID = ".$userinfo['id'];
        $first_sums = M('a_order')->query($first_sql);
        $first_income = $first_sums[0]['sum'];
        //根据用户等级 ，查询上月团队的收益总和
        if($userinfo['member_level']==2){  //销售经理
            if(!empty($str_id)){
                //查询下下级
                $res2 = M('wx_user','daili_','DB_READ')->field('ID')->where(array('Pid'=>array('in',$str_id)))->select();
                foreach ($res2 as $keys=>$vals){
                    $p_str_id .= $vals['id'].',';
                }
                $p_str_id=rtrim($p_str_id,',');
                $team_sql = "select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi"
                    ." as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.UID in ($str_id) AND b.ShangJiUID=".$userinfo['id'];
                $team_sums = M('a_order')->query($team_sql);
                if(!empty($p_str_id)){
                    $team_sql2 = "select sum(b.ShangShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi"
                        ." as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.UID in ($p_str_id) AND b.ShangShangJiUID=".$userinfo['id'];
                    $team_sums2 = M('a_order')->query($team_sql2);
                    $team_income = $team_sums[0]['sum']+ $team_sums2[0]['sum'];
                }else{
                    $team_income = $team_sums[0]['sum'];
                }
            }else{
                $team_income = 0;
            }

        }elseif($userinfo['member_level']==3){  //服务经理
            $res1 = M('wx_user','daili_','DB_READ')
                ->field('ID')
                ->where(array('member_area'=>$userinfo['id']))
                ->select();
            $str_ids = "";
            foreach ($res1 as $k=>$v){
                $str_ids .= $v['id'].',';
            }
            $str_ids=rtrim($str_ids,',');
            if(!empty($str_ids)){
                $team_sql = "select sum(b.area_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where_order_time $where_order_statue and b.UID in ($str_ids)";
                $team_sums = M('a_order')->query($team_sql);
                $team_income = $team_sums[0]['sum'];
            }else{
                $team_income = 0;
            }

        }else{
            if(!empty($str_id)){
                $where = " and b.uid in ($str_id)";
            }
            $team_sql = "select sum(b.ShangJiShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where_order_time $where_order_statue $where and b.ShangJiUID = ".$userinfo['id'];
            $team_sums = M('a_order')->query($team_sql);
            $team_income = $team_sums[0]['sum'];
        }
        //查询上月邀请下级提供的奖励金总和
        $reward_sum = 0;
        if(!empty($str_id)){
            $reward_sql = "select sum(daili_b_jiangli.Money) as sum1 from daili_b_jiangli where UID="
                .$userinfo['id']." and XiaJiUID in ($str_id) and operation_time between $time_start and $time_last and statue=1 and (type=1 OR type=2)";
            $reward_info = M('b_jiangli','daili_','DB_READ')->query($reward_sql);
            $reward_sum = $reward_info[0]['sum1'];
        }
        $money = $reward_sum+$team_income+$first_income;
        $arr = array(
            'reward_sum'=>$reward_sum>0?$reward_sum:0,
            'my_income'=>$first_income>0?$first_income:0,
            'team_income'=>$team_income>0?$team_income:0,
            'all_income'=>($team_income+$first_income)>0?($team_income+$first_income):0,
            'money'=>$money>0?$money:0
        );
        return $arr;
    }

    /*** 公共方法 结束 ***/






    /*** 计划任务系列  开始 ***/

    /*
     * 每月检测 销售经理、服务经理的下级销售经理的业绩，同步更新当前用户的奖励
     * */
    public function get_sale_level_reward(){
        set_time_limit(0);
        if(date('d')<21 && date('d')>22){
            $this->ajaxReturn(
                array('statue'=>0,'msg'=>'没到时间')
            );
            exit;
        }
        $count = M('wx_user','daili_','DB_READ')->where("member_level>=2")->count();
        $count_page = ceil($count/100);
        for($i = 1;$i<=$count_page;$i++){
            //查询用户信息
            $userinfo = M('wx_user','daili_','DB_READ')->where("member_level>=2")->page($i,100)->select();
            if(!empty($userinfo)){
                foreach($userinfo as $k=>$v){
                        //查询当前用户所属渠道的奖励配置
                        $config = M('wx_user_level','daili_','DB_READ')
                            ->field('complete,reward,jianglibi')
                            ->where(array('member_level'=>$v['member_level'],'token'=>$v['gzhtoken']))
                            ->find();
                        if($v['member_level']==2){   //销售经理
                            //查询所有下级身份为销售经理的用户
                            $p_user = M('wx_user','daili_','DB_READ')->field('ID,invitation_code')->where(array('Pid'=>$v['id'],'member_level'=>2))->select();
                            if(!empty($p_user)){
                                var_dump($p_user);
                                foreach($p_user as $k1=>$v1){
                                    //查询当前下级销售团队的收益值
                                    $arr = $this->find_lastmonth_income_sum($v1['invitation_code']);
                                    var_dump($arr);
                                    if($arr['all_income']>=$config['complete']){
                                        //检测日志表是否存在已添加当前用户奖励的日志
                                        $log_res = M('a_sale_reward_log')->where(array('uid'=>$v['id'],'type'=>1,'add_y_m'=>date('Y-m',time()),'xiaji_uid'=>$v1['id']))->find();
                                        if(empty($log_res)){
                                            //实时查询应得奖励用户余额，并更新
                                            $user_info = M('wx_user','daili_','DB_READ')->field('ID,YuE')->where(array('ID'=>$v['id']))->find();
                                            $arr_data = array(
                                                'xiaji_id'=>$v1['id'],
                                                'uid'=>$v['id'],
                                                'type'=>1,
                                                'add_y_m'=>date('Y-m',time()),
                                                'log_info'=>json_encode(array(
                                                    'log_info'=>'处理'.(date('m')-1)."月的数据",
                                                    'old_yue'=>$user_info['yue'],
                                                    'save_yue'=>($user_info['yue']+$config['reward']),
                                                    'reward'=>$config['reward'],
                                                    'add_time'=>time()."+".date("Y-m-d H:i:s",time()),
                                                ))
                                            );
                                            $res = M('wx_user')->where(array('ID'=>$v['id']))->save(array('YuE'=>($user_info['yue']+$config['reward'])));
                                            M('a_sale_reward_log')->add($arr_data);
                                        }
                                    }
                                }
                            }
                        }elseif($v['member_level']==3){   //服务经理
                            //查询所有下级身份为服务经理的用户
                            $p_user = M('wx_user','daili_','DB_READ')->field('ID,invitation_code')->where(array('member_area'=>$v['id'],'member_level'=>3,'ID'=>array('neq',$v['id'])))->select();
                            if(!empty($p_user)){
                                foreach($p_user as $k1=>$v1){
                                    //查询当前下级服务经理团队的收益值
                                    $arr = $this->find_lastmonth_income_sum($v1['invitation_code']);
                                    if($arr['all_income']>=$config['complete']){
                                        //检测日志表是否存在已添加当前用户奖励的日志
                                        $log_res = M('a_sale_reward_log')->where(array('uid'=>$v['id'],'type'=>2,'add_y_m'=>date('Y-m',time()),'xiaji_uid'=>$v1['id']))->find();
                                        if(empty($log_res)){
                                            //实时查询应得奖励用户余额，并更新
                                            $user_info = M('wx_user','daili_','DB_READ')->field('ID,YuE')->where(array('ID'=>$v['id']))->find();
                                            $arr_data = array(
                                                'xiaji_id'=>$v1['id'],
                                                'uid'=>$v['id'],
                                                'type'=>2,
                                                'add_y_m'=>date('Y-m',time()),
                                                'log_info'=>json_encode(array(
                                                    'log_info'=>'处理'.(date('m')-1)."月的数据",
                                                    'old_yue'=>$user_info['yue'],
                                                    'save_yue'=>($user_info['yue']+$config['reward']+$arr['all_income']*$config['jianglibi']/100),
                                                    'reward'=>$config['reward'],
                                                    'add_time'=>time()."+".date("Y-m-d H:i:s",time()),
                                                ))
                                            );
                                            $res = M('wx_user')->where(array('ID'=>$v['id']))->save(array('YuE'=>($user_info['yue']+$config['reward']+$arr['all_income']*$config['jianglibi']/100)));
                                            M('a_sale_reward_log')->add($arr_data);
                                        }
                                    }
                                }
                            }
                        }else{  //无需执行

                        }
                }
            }
            sleep(1);
        }
        $this->ajaxReturn(array(
            'statue'=>1,
            'msg'=>'执行完毕'
        ));
    }

    /*
     * 每月定点更新所有用户的余额
     * */
    public function  update_user_yue(){
        if(date('d')!=22){
            $this->ajaxReturn(
                array('statue'=>0,'msg'=>'没到时间')
            );
            exit;
        }
        set_time_limit(0);
        $count = M('wx_user','daili_','DB_READ')->count();
        $count_page = ceil($count/100);

        for($i=1;$i<=$count_page;$i++){
            $userinfo = M('wx_user')->page($i,100)->order('member_level desc')->select();
            foreach($userinfo as $k=>$v){
                $arr = $this->find_lastmonth_income_sum($v['invitation_code']);
                //检测日志表是否存在已添加当前用户奖励的日志
                $log_res = M('a_user_yue_log')->where(array('uid'=>$v['id'],'add_y_m'=>date('Y-m',time())))->find();
                if(empty($log_res)){
                    //实时查询用户余额，并更新
                    $user_info = M('wx_user','daili_','DB_READ')->field('ID,YuE')->where(array('ID'=>$v['id']))->find();
                    $arr_data = array(
                        'uid'=>$v['id'],
                        'add_y_m'=>date('Y-m',time()),
                        'log_info'=>json_encode(array(
                            'log_info'=>'处理'.(date('m')-1)."月的数据",
                            'old_yue'=>$user_info['yue'],
                            'add_yue'=>$arr['money'],
                            'save_yue'=>($user_info['yue']+$arr['money']),
                            'add_time'=>time(),
                            'money_info'=>$arr,
                        ))
                    );
                    $res = M('wx_user')->where(array('ID'=>$v['id']))->save(array('YuE'=>($user_info['yue']+$arr['money'])));
                    M('a_user_yue_log')->add($arr_data);
                }
            }
            sleep(1);
        }
        $this->ajaxReturn(array(
            'statue'=>1,
            'msg'=>'执行完毕'
        ));
    }

    /*** 计划任务系列 结束 ***/



    /*** 测试方法   开始 ***/

    //更新邀请店主奖励
    public function update_user_dianzhu_reward(){
        $userinfo = M('wx_user')->select();
        foreach($userinfo as $k=>$v){
            if($v['member_level']>0){
                $money = M('b_jiangli')->where(array('UID'=>$v['id'],'statue'=>1,'type'=>2))->sum('Money');
                M('wx_user')->where(array('ID'=>$v['id']))->save(array('yaoqingdianzhu_jiangli'=>$money));
            }
        }
        echo "ok";
    }

    //更新邀请会员奖励
    public function update_user_huiyuan_reward(){
        $userinfo = M('wx_user')->select();
        foreach($userinfo as $k=>$v){
            $money = M('b_jiangli')->where(array('UID'=>$v['id'],'statue'=>1,'type'=>1))->sum('Money');
            M('wx_user')->where(array('ID'=>$v['id']))->save(array('yaoqinghuiyuan_jiangli'=>$money));
        }
        echo "ok";
    }

    //更新上下级关系和奖励表上下级关系
    public function update_pid_reward(){
        header("Content-type: text/html; charset=utf-8");
        $sj = I('sj_phone','','trim');
        $xj = I('xj_phone','','trim');
        if(empty($sj) || empty($xj)){
            echo "上下级手机号不能为空！";
            exit;
        }
        $sj_info = M('wx_user','daili_','DB_READ')->field('ID,Pid')->where(array('Phone'=>$sj))->find();
        $xj_info = M('wx_user','daili_','DB_READ')->field('ID,Pid')->where(array('Phone'=>$xj))->find();
        if(empty($sj_info)){
            echo "查询不到上级信息！";
            exit;
        }
        if(empty($xj_info)){
            echo "查询不到下级信息！";
            exit;
        }
        //查询下级奖励表数据
        $b_info = M('b_jiangli','daili_','DB_READ')->where(array('UID'=>$xj_info['pid'],'XiaJiUID'=>$xj_info['id']))->select();
        if(empty($xj_info)){
            echo "查询不到下级奖励表信息！";
            exit;
        }
        foreach($b_info as $k=>$v){
            M('b_jiangli')->where(array('ID'=>$v['id']))->save(array('UID'=>$sj_info['id']));
        }
        //更新下级信息
        M('wx_user')->where(array('ID'=>$xj_info['id']))->save(array('Pid'=>$sj_info['id']));
        echo "更新上下级完成  更新奖励表完成";
    }

    //更新支付0.01的奖励
    public function del_jl(){
        $jl = M('b_jiangli')->where(array('type'=>2))->select();
        foreach($jl as $k=>$v){
            $order_info = M('a_upgrade_order')->where(array('id'=>$v['orderid']))->find();
            if($order_info['total_amount'] == 0.01){
                M('b_jiangli')->where(array('ID'=>$v['id']))->save(array('Money'=>0));
                var_dump($v['id']);
            }
        }
        $this->test_count();
    }

    public function test_pid_count(){
        $str_id = "";
        $info = M('wx_user')->where(array('Pid'=>28))->select();

        foreach ($info as $key=>$val){
            $str_id .= $val['id'].',';
        }
        $str_id=rtrim($str_id,',');
        $count = M('wx_user')->where("Pid=28 or pid in ($str_id)")->count();
        echo M('wx_user')->getLastSql();
        var_dump($count);
    }

    public function del_data(){
        $res = M('wx_user')->where(array('Phone'=>13349922109))->select();
        foreach($res as $k=>$v){
            M('b_jiangli')->where(array('UID'=>$v['pid'],'XiaJiUID'=>$v['id'],'type'=>1))->delete();
            M('wx_user')->where(array('ID'=>$v['id']))->delete();
        }
       echo "ok";
    }

    /*** 测试方法   结束 ***/
}