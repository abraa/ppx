<?php return array (
  'token' => 'gh_d9f4f2988f69',
  'share_title' => '有你想象的优惠，比你想象的更省钱，更多优惠，下载赚多多即可享受',
  'is_show_shop' => '1',
  'aa' => '0',
  'b' => '0',
  'c' => '1',
  'd' => '1',
  'is_show_live' => '1',
);