<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    //后台登录页面
    public function index(){
        if(IS_POST){
            $user = str_replace(' ','',I('user'));
            $pass = str_replace(' ','',I('pwd'));
            $w = array(
                'name'=>$user,
                'pass'=>$pass
            );
            $user = M('user')->where($w)->find();
            if($user){
                $d=array(
                    'id'=>$user['id'],
                    'login_time'=>time()
                );
                M('user')->save($d);
                unset($user['pass']);
                session('user',$user);
                $arr = array(
                    'code'=>1,
                    'msg'=>'登录成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'登录失败，用户名或密码错误'
                );
            }
            $this->ajaxReturn($arr);
        }ELSE{
            $this->display();
        }
    }
    //用户退出页面
    public function logout(){
        session('user',null);
        $this->redirect('Index/index');
    }
   
    //轮播图文案显示页面
    public function page(){
        $id = I('id');
        $res = M('a_lunbotu')->where(array('id'=>$id))->find();
        $this->assign('res',$res);
        $this->display();
    }
    //文档查看页面
    public function view(){
        $id = I('id');
        $res = M('article')->where(array('id'=>$id))->find();
        $this->assign('res',$res);
        $this->display();
    }
    //常见问题页面
    public function question(){
        $this->display();
    }
    //微淘文章预览页面
    public function weitao_view(){
        $id = I('id');
        $res = M('a_weitao')->where(array('id'=>$id))->find();
        $res['text']=str_replace('?tp=webp','',$res['text']);
        $this->assign('res',$res);
        $this->display();
    }
}