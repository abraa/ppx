<?php
/**
 * 数据处理控制器
 * */
namespace Home\Controller;
use Think\Controller;
class UseXsController extends Controller {
    private $redis;
    private $xs_index;
    private $xs_doc;
    private $xs_search;
    //Linux中重建索引语句
    //util/Indexer.php items --source=mysql://pinpinxia:pinpinxia2018\$@rm-2ze73dowpcr78599azo.mysql.rds.aliyuncs.com/dailisystem/ --sql='select id,short_title,volume,pic_url,coupon_price,price,youhuiquan_je,num_iid,shop_type,movie_url,title,commission_rate from daili_a_items' --clean
    //重建索引后刷新
    //util/Indexer.php --flush items
    public function _initialize(){
        require_once '/data/wwwroot/default/xunsearch/sdk/php/lib/XS.php';
        $xs = new \XS('items');
        $this->xs_search=$xs->search;
        $this->xs_index=$xs->index;
        $doc = new \XSDocument();
        $this->xs_doc=$doc;
        //连接本地的 Redis 服务
        //$redis = new \Redis();
        //$redis->connect('127.0.0.1', 6379);
        //$this->redis = $redis;
    }
    public function get_curl($api_url){
        //实惠猪参数
        $data = array(
            'APPID: 1704261647308667',
            'APPKEY: 37522767b0efd6ed7daf6f1403ddc12d',
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $data);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        $result = curl_exec($ch);
        curl_close($ch);
        $arrResponse=json_decode($result,true);
        return $arrResponse;
    }
    //每天调用实惠猪接口采集12个分类下的所有商品
    public  function get_shz_shop_all(){
            require_once '/data/wwwroot/DailiSystem/ThinkPHP/Library/Vendor/shzSDK.php';
            $AppID = '1803011152529748';//填写申请的AppID
            
            $AppKey = '2425c9cdd3053f5cb2d8d3bfc99c93e1';//填写申请的AppKey
            
            $open = new \shzSDK($AppID,$AppKey);
            $cid = I('cid',1);
            $page= I('page',1);
            
            switch($cid){
                case 1:$c_id=1;$local_cate_id = 1;break;
                case 2:$c_id=2;$local_cate_id = 2;break;
                case 3:$c_id=3;$local_cate_id = 35;break;
                case 4:$c_id=4;$local_cate_id = 4;break;
                case 5:$c_id=5;$local_cate_id = 6;break;
                case 6:$c_id=6;$local_cate_id = 5;break;
                case 7:$c_id=7;$local_cate_id = 3;break;
                case 8:$c_id=8;$local_cate_id = 3;break;
                case 9:$c_id=9;$local_cate_id = 36;break;
                case 10:$c_id=10;$local_cate_id = 8;break;
                case 11:$c_id=11;$local_cate_id = 9;break;
                case 12:$c_id=12;$local_cate_id = 7;break;
            }
            //$api_url = "http://gateway.shihuizhu.net/open/goods/$c_id/$page";
            //$shop_info = $this->get_curl($api_url);
            $shop_info=$open->goods($c_id,$page);
            $shop_info = json_decode($shop_info);
            $shop_info = obj_to_arr($shop_info);
            //echo '<pre>';
            //print_r($shop_info);exit;
            $add_success    = 0;
            $add_fail       = 0;
            $add_no         = 0;
            $save_success   = 0;
            $save_fail      = 0;
            $save_no=0;
            if($shop_info['return'] != 0){
                $cid = 13;
                $page=1;
                $arr = array(
                    'add_success'=>$add_success,
                    'save_success'=>$save_success,
                    'add_fail'=>$add_fail,
                    'save_fail'=>$save_fail,
                    'add_no'=>$add_no,
                    'save_no'=>$save_no,
                    'page'=>$page,
                    'cid'=>$cid
                );
                $this->ajaxReturn($arr);
            }else{
                if($shop_info['return'] == 0 && $shop_info['pagecount']>0){
                    
                    $sum_data = count($shop_info['result']);
                        //检测该商品是否存在，如果存在不存在就添加
                        foreach($shop_info['result'] as $k2 =>$v2){
                            $data = array(
                                'num_iid'       => $v2['gid'],
                                'cate_id'       => $local_cate_id,
                                'short_title'   => $v2['sub_title'],
                                'title'         => $v2['title'],
                                'uname'         => '实惠猪',
                                'pic_url'       => strpos($v2['thumb'],'http') !== false ? $v2['thumb'] : 'http:'.$v2['thumb'],
                                'price'         => $v2['prime'],
                                'volume'        => $v2['final_sales'],
                                'commission'    => ($v2['ratio']/100)*$v2['price'],
                                'commission_rate'=>$v2['ratio']*10000,
                                'coupon_price'  => $v2['price'],
                                'ems'           => 1,
                                'shop_type'     => ($v2['site'] == 'tmall'?'B':($v2['site'] == 'taobao'?'C':'其他')),
                                'item_url'      =>$v2['url'],
                                'add_time'      =>time(),
                                'youhuiquan'    => $v2['coupon_url'],
                                'youhuiquan_je' => $v2['coupon_money'],
                                'has_youhuiquan'=> $v2['coupon'],
                                'recommend_reason'=>$v2['intro_foot'],
                                'daili_url'      =>$v2['new_url'],
                                'daili_statue'  =>2,
                                'coupon_update_time'=>time(),
                                'activity'=>$v2['activity'],
                                'movie_url'=>"http://cloud.video.taobao.com/play/u/1/p/1/e/6/t/1".$v2['video'].'.mp4'
                            );
                            $youhuiquan=$v2['coupon_url'];
                            if(strpos($youhuiquan,'shop.m.taobao.com') || strpos($youhuiquan,'market.m.taobao.com')){
                                continue;
                            }
                            //查询app_items表里面是否含有该商品
                            $res_info =  M('a_items')->where(array('num_iid'=>$v2['gid']))->find();
                            add_file_log('shz_items_all',$data);
                            if(empty($res_info)){
                                //插入数据
                                if(strpos($v2['coupon_url'],'activity')){
                                    $id = M('a_items')->add($data);
                                    if($id){
                                        $add_success += 1;
                                    }else{
                                        $add_fail += 1;
                                    }
                                    $xs_data = array(
                                        'id'=>$id,
                                        'short_title'=>$data['short_title'],
                                        'volume'=>$data['volume'],
                                        'pic_url'=>$data['pic_url'],
                                        'coupon_price'=>$data['coupon_price'],
                                        'price'=>$data['price'],
                                        'youhuiquan_je'=>$data['youhuiquan_je'],
                                        'num_iid'=>$data['num_iid'],
                                        'shop_type'=>$data['shop_type'],
                                        'movie_url'=>$data['movie_url'],
                                        'title'=>$data['title'],
                                        'commission_rate'=>$data['commission_rate']
                                    );
                                    $doc=$this->xs_doc;
                                    $doc->setFields($xs_data);
                                    $index=$this->xs_index;
                                    $index->add($doc);
                                    $index->flushIndex();
                                    //add_file_log('shz_items_add',$data);
                                }
                            }else{
                                $add_no += 1;
                                $youhuiquan_je = $res_info['youhuiquan_je'];
                                if($youhuiquan_je<$v2['coupon_money']){
                                    $s = M('a_items')->where(array('id'=>$res_info['id']))->save($data);
                                    if($s){
                                        $save_success += 1;
                                    }else{
                                        $save_fail += 1;
                                    }
                                    $xs_data = array(
                                        'id'=>$res_info['id'],
                                        'short_title'=>$res_info['short_title'],
                                        'volume'=>$res_info['volume'],
                                        'pic_url'=>$res_info['pic_url'],
                                        'coupon_price'=>$res_info['coupon_price'],
                                        'price'=>$res_info['price'],
                                        'youhuiquan_je'=>$res_info['youhuiquan_je'],
                                        'num_iid'=>$res_info['num_iid'],
                                        'shop_type'=>$res_info['shop_type'],
                                        'movie_url'=>$res_info['movie_url'],
                                        'title'=>$res_info['title'],
                                        'commission_rate'=>$res_info['commission_rate']
                                    );
                                    $doc=$this->xs_doc;
                                    $doc->setFields($xs_data);
                                    $index=$this->xs_index;
                                    $index->update($doc);
                                    $index->flushIndex();
                                    //add_file_log('shz_items_update',$data);
                                }else{
                                    $save_no +=1;
                                }
                            }
                        }
                        if($sum_data<100){
                            $cid = $cid+1;
                            $page = 1;
                        }else{
                            $page = $page + 1;
                        }
                        if($cid>12){
                            $cid = 1;
                            $page= 1;
                        }
                        $arr = array(
                            'add_success'=>$add_success,
                            'save_success'=>$save_success,
                            'add_fail'=>$add_fail,
                            'save_fail'=>$save_fail,
                            'add_no'=>$add_no,
                            'save_no'=>$save_no,
                            'page'=>$page,
                            'cid'=>$cid
                        );
                        $this->ajaxReturn($arr);
                        
                }else{
                    $this->send_msg('实惠猪');
                }
            }
    }
    //通过从大淘客接口获取所有商品
    public function get_dtk_shop_all(){
            $page = I('page',1);
            $shop_details_api = "http://api.dataoke.com/index.php?r=Port/index&type=total&appkey=c6tvb2t52s&v=2&page=".$page;
            $shop_details = $this->get_curl($shop_details_api);
            $data_sum = count($shop_details['result']);
            $add_success = 0;
            $add_fail    = 0;
            $add_no      = 0;
            $save_success= 0;
            $save_fail   = 0;
            $save_no     = 0;
            foreach($shop_details['result'] as $k2 =>$v2){
                $cate = $v2['Cid'];
                switch($cate){
                    case 1:$local_cate_id = 1;break;
                    case 2:$local_cate_id = 4;break;
                    case 3:$local_cate_id = 6;break;
                    case 4:$local_cate_id = 5;break;
                    case 5:$local_cate_id = 3;break;
                    case 6:$local_cate_id = 8;break;
                    case 7:$local_cate_id = 9;break;
                    case 8:$local_cate_id = 7;break;
                    case 9:$local_cate_id = 2;break;
                    case 10:$local_cate_id = 35;break;
                }
                $pic = $v2['Pic'];
                $youhuiquan=$v2['Quan_link'];
                $itemid = $v2['GoodsID'];
                $pattern ='/activity..?d=(\w+)/';
                preg_match($pattern , $youhuiquan , $matches);
                $activeid=$matches[1];
                $daili_url ="https://uland.taobao.com/coupon/edetail?activityId=$activeid&itemId=$itemid&pid=mm_116133360_35666802_126860353&src=YQT&dx=1";
               
                $data = array(
                    'num_iid'       => $v2['GoodsID'],
                    'cate_id'       => $local_cate_id,
                    'title'         => $v2['Title'],
                    'uname'         => '大淘客',
                    'pic_url'       => strpos($pic,'http') !== false ? $pic : 'http:'.$pic,
                    'price'         => $v2['Org_Price'],
                    'coupon_price'  => $v2['Price'],
                    'ems'           => 1,
                    'shop_type'     => ($v2['IsTmall'] == 1?'B':'C'),
                    'item_url'      =>"https://item.taobao.com/item.htm?id=".$v2['GoodsID'],
                    'add_time'      =>time(),
                    'youhuiquan'    => $v2['Quan_link'],
                    'youhuiquan_je' => $v2['Quan_price'],
                    'has_youhuiquan'=> $v2['Quan_surplus']>0?1:0,
                    'volume'        => $v2['Sales_num'],
                    'recommend_reason'=>$v2['Introduce'],
                    'short_title'   => $v2['D_title'],
                    'commission'    =>($v2['Commission']/100)*$v2['Price'],
                    'commission_rate'=>$v2['Commission']*10000,
                    'coupon_update_time'=>time(),
                    'daili_url'=>$daili_url,
                    'sellerid'=>$v2['SellerID'],
                );
                $youhuiquan=$v2['Quan_link'];
                if(strpos($youhuiquan,'shop.m.taobao.com') || strpos($youhuiquan,'market.m.taobao.com')){
                    continue;
                }
                add_file_log('dtk_items_all',$data);
                //检测该商品是否存在，不存在就添加
                $res_info =  M('a_items')->where(array('num_iid'=>$v2['GoodsID']))->find();
               
                if(empty($res_info)){
                    //插入数据
                    if(strpos($v2['Quan_link'],'activity')){
                        $id = M('a_items')->add($data);
                        if($id){
                            $add_success+=1;
                        }else{
                            $add_fail+=1;
                        }
                        $xs_data = array(
                                    'id'=>$id,
                                    'short_title'=>$data['short_title'],
                                    'volume'=>$data['volume'],
                                    'pic_url'=>$data['pic_url'],
                                    'coupon_price'=>$data['coupon_price'],
                                    'price'=>$data['price'],
                                    'youhuiquan_je'=>$data['youhuiquan_je'],
                                    'num_iid'=>$data['num_iid'],
                                    'shop_type'=>$data['shop_type'],
                                    'movie_url'=>$data['movie_url'],
                                    'title'=>$data['title'],
                                    'commission_rate'=>$data['commission_rate']
                                );
                        $doc=$this->xs_doc;
                        $index=$this->xs_index;
                        $doc->setFields($xs_data);
                        $index->add($doc);
                        $index->flushIndex();
                        add_file_log('dtk_items_add',$data);
                    }
                }else{
                    $add_no += 1;
                    $youhuiquan_je = $res_info['youhuiquan_je'];
                    if($youhuiquan_je<$v2['Quan_price']){
                        $s = M('a_items')->where(array('id'=>$res_info['id']))->save($data);
                        if($s){
                            $save_success += 1;
                        }else{
                            $save_fail += 1;
                        }
                        $xs_data = array(
                                    'id'=>$res_info['id'],
                                    'short_title'=>$res_info['short_title'],
                                    'volume'=>$res_info['volume'],
                                    'pic_url'=>$res_info['pic_url'],
                                    'coupon_price'=>$res_info['coupon_price'],
                                    'price'=>$res_info['price'],
                                    'youhuiquan_je'=>$res_info['youhuiquan_je'],
                                    'num_iid'=>$res_info['num_iid'],
                                    'shop_type'=>$res_info['shop_type'],
                                    'movie_url'=>$res_info['movie_url'],
                                    'title'=>$res_info['title'],
                                    'commission_rate'=>$res_info['commission_rate']
                                );
                        $doc=$this->xs_doc;
                        $doc->setFields($xs_data);
                        $index=$this->xs_index;
                        $index->update($doc);
                        $index->flushIndex();
                        add_file_log('dtk_items_update',$data);
                    }else{
                        $save_no += 1;
                    }
                }
            }
            if($data_sum<50){
                $page = 1;
            }else{
                $page = $page+1;
            }
            $this->assign('add_success',$add_success);
            $this->assign('save_success',$save_success);
            $this->assign('add_fail',$add_fail);
            $this->assign('save_fail',$save_fail);
            $this->assign('add_no',$add_no);
            $this->assign('save_no',$save_no);
            $this->assign('page',$page);
            $this->assign('sum_data',$data_sum);
            $this->display();
        
    }
    
    //从淘客基地获取商品
    public  function get_tkjd_shop_all(){
        return false;
        $id = I('id');
        $shop_details_api = "http://api.tkjidi.com/getGoodsLink?appkey=5e582d1800f3d1fc8f6e9f3faa5ca10f&type=www_lingquan&page=1";
        $shop_details = $this->get_curl($shop_details_api);
        set_time_limit(0);
        for($i = 1;$i<100;$i++){
            //$shop_details_api = "http://api.tkjidi.com/getGoodsLink?appkey=5e582d1800f3d1fc8f6e9f3faa5ca10f&type=www_lingquan&page=".$i;
            $shop_details_api = "http://api.tkjidi.com/getGoodsLink?appkey=5e582d1800f3d1fc8f6e9f3faa5ca10f&type=classify&cid=1";
            $shop_details = $this->get_curl($shop_details_api);
            
            if($shop_details['status'] != 200){
                break;
            }else{
                //检测该商品是否存在，如果存在，则更新，否则添加
                foreach($shop_details['data'] as $k2 =>$v2){
                    /*****商品根据标题关键字分类start*****/
                    $title = $v2['goods_name'];
                    
                    /*****商品根据标题关键字分类end*****/
                    $pic = $v2['pic'];
                    $data = array(
                        'num_iid'       => $v2['goods_id'],
                        'title'         => $v2['goods_name'],
                        'uname'         => '淘客基地',
                        'pic_url'       => strpos($pic,'http') !== false ? $pic : 'http:'.$pic,
                        'price'         => $v2['price'],
                        'coupon_price'  => $v2['price_after_coupons'],
                        'ems'           => 1,
                        'shop_type'     => 'C',
                        'item_url'      =>$v2['goods_url'],
                        'add_time'      =>time(),
                        'youhuiquan'    => $v2['quan_link'],
                        'youhuiquan_je' => $v2['price_coupons'],
                        'has_youhuiquan'=> $v2['quan_shengyu']>0?1:0,
                        'volume'        => $v2['sales'],
                        'recommend_reason'=>$v2['quan_guid_content'],
                        //'short_title'   => $v2['goods_name'],
    
                    );
                    $youhuiquan=$v2['quan_link'];
                    if(strpos($youhuiquan,'shop.m.taobao.com') || strpos($youhuiquan,'market.m.taobao.com')){
                        continue;
                    }
                    if($data['coupon_price']<=500){
                        //查询app_items表里面是否含有该商品
                        $res_info =  M('a_items')->where(array('num_iid'=>$v2['goods_id']))->find();
                        if(empty($res_info)){
                            //插入数据
                            $id = M('a_items')->add($data);
                            $xs_data = array(
                                    'id'=>$id,
                                    'short_title'=>$data['short_title'],
                                    'volume'=>$data['volume'],
                                    'pic_url'=>$data['pic_url'],
                                    'coupon_price'=>$data['coupon_price'],
                                    'price'=>$data['price'],
                                    'youhuiquan_je'=>$data['youhuiquan_je'],
                                    'num_iid'=>$data['num_iid'],
                                    'shop_type'=>$data['shop_type'],
                                    'movie_url'=>$data['movie_url'],
                                    'title'=>$data['title'],
                                    'commission_rate'=>$data['commission_rate']
                                );
                            $doc=$this->xs_doc;
                            $index=$this->xs_index;
                            $doc->setFields($xs_data);
                            $index->add($doc);
                            $index->flushIndex();
                            $j++;
                        }
                    }
                }
            }
        }
    }
    /**
     * 获取轻淘客商品
     * */
    public function get_qtk_shop_all(){
            $page = I('page',1);
            $url ="http://openapi.qingtaoke.com/qingsoulist?sort=1&page=$page&page_size=100&app_key=M0Fnqzm9&v=1.0";
            $res=curl_get($url);
            if($res['er_code']==10000 && $res['er_msg']=='请求成功'){
                $data = $res['data']['list'];
                $data_sum = count($data);
                $add_success = 0;
                $add_fail    = 0;
                $add_no      = 0;
                $save_success= 0;
                $save_fail   = 0;
                $save_no     = 0;
                foreach ($data as $val){
                //2:母婴;3:美妆;4:居家;5:鞋包配饰;6:美食;
                //7:文体;8:家电数码;9:其他;10:女装;11:内衣;12:男装;
                    $cate = $val['goods_cat'];
                    switch ($cate){
                        case 2:$cateid=4;break;
                        case 3:$cateid=6;break;
                        case 4:$cateid=5;break;
                        case 5:$cateid=3;break;
                        case 6:$cateid=8;break;
                        case 7:$cateid=9;break;
                        case 8:$cateid=7;break;
                        case 10:$cateid=1;break;
                        case 11:$cateid=35;break;
                        case 12:$cateid=2;break;
                    }
                    if($val['is_tmall']==1){
                        $shop_type='B';
                    }else{
                        $shop_type="C";
                    }
                    $activeid = $val['coupon_id'];
                    $sellerid = $val['seller_id'];
                    $itemid   = $val['goods_id'];
                    //$youhuiquan="https://shop.m.taobao.com/shop/coupon.htm?activity_id=$activeid&seller_id=$sellerid";
                    $youhuiquan="https://uland.taobao.com/quan/detail?sellerId=$sellerid&activityId=$activeid";
                    $youhuiquan_je=$val['coupon_price'];
                    
                    $has_youhuiquan=1;
                    $daili_url ="https://uland.taobao.com/coupon/edetail?activityId=$activeid&itemId=$itemid&pid=mm_116133360_35666802_126860353&src=YQT&dx=1";
                    $pic = $val['goods_pic'].'_400x400.jpg'; 
                    if($val['is_ju']==1){
                        $activity='聚划算';
                    }
                    if($val['is_tqg']==1){
                        $activity='淘抢购';
                    }
                    $data = array(
                        'ordid'=>'99999',
                        'cate_id'=>$cateid,
                        'num_iid'=>$val['goods_id'],
                        'short_title'=>$val['goods_short_title'],
                        'title'=>$val['goods_title'],
                        'uname'=>'轻淘客',
                        'pic_url'=>strpos($pic,'http') !== false ? $pic : 'http:'.$pic,
                        'price'=>$val['goods_price'],
                        'volume'=>$val['goods_sales'],
                        'commission'=>($val['commission']/100)*($val['goods_price']-$val['coupon_price']),
                        'commission_rate'=>$val['commission']*10000,
                        'coupon_price'=>$val['goods_price']-$val['coupon_price'],
                        'shop_type'=>$shop_type,
                        'item_url'=>'https://item.taobao.com/item.htm?id='.$val['goods_id'],
                        'ems'=>'1',
                        'add_time'=>time(),
                        'youhuiquan'=>$youhuiquan,
                        'youhuiquan_je'=>$youhuiquan_je,
                        'has_youhuiquan'=>$has_youhuiquan,
                        'nick'=>'',
                        'sellerid'=>$val['seller_id'],
                        'recommend_reason'=>$val['goods_introduce'],
                        'desc_info_url'=>'',
                        'daili_url'=>$daili_url,
                        'daili_url_statue'=>'2',
                        'daili_shouru'=>'',
                        'coupon_end_time'=>strtotime($val['coupon_end_time']),
                        'coupon_start_time'=>strtotime($val['coupon_start_time']),
                        'coupon_update_time'=>time(),
                        'activity'=>$activity,
                        'sellerid'=>$val['seller_id'],
                    );
                    $youhuiquan=$youhuiquan;
                    if(strpos($youhuiquan,'shop.m.taobao.com') || strpos($youhuiquan,'market.m.taobao.com')){
                        continue;
                    }
                    $w['num_iid']=$val['goods_id'];
                    $w['youhuiquan']=array('like','%'.$activeid.'%');
                    $w['_logic']='or';
                    add_file_log('qtk_items_all',$item);
                    $res = M('a_items')->where($w)->find();
                    if(!$res){
                        if(strpos($youhuiquan,'activity')){
                            $id = M('a_items')->add($data);
                            if($id){
                                $add_success += 1;
                            }else{
                                $add_fail += 1;
                            }
                            $xs_data = array(
                                    'id'=>$id,
                                    'short_title'=>$data['short_title'],
                                    'volume'=>$data['volume'],
                                    'pic_url'=>$data['pic_url'],
                                    'coupon_price'=>$data['coupon_price'],
                                    'price'=>$data['price'],
                                    'youhuiquan_je'=>$data['youhuiquan_je'],
                                    'num_iid'=>$data['num_iid'],
                                    'shop_type'=>$data['shop_type'],
                                    'movie_url'=>$data['movie_url'],
                                    'title'=>$data['title'],
                                    'commission_rate'=>$data['commission_rate']
                                 );
                            $doc=$this->xs_doc;
                            $index=$this->xs_index;
                            $doc->setFields($xs_data);
                            $index->add($doc);
                            $index->flushIndex();
                            add_file_log('qtk_items_add',$item);
                        }
                    }else{
                        $add_no += 1;
                        $quan_je = $res['youhuiquan_je'];
                        if($quan_je<$youhuiquan_je){
                            $s = M('a_items')->where(array('id'=>$res['id']))->save($data);
                            if($s){
                                $save_success += 1;
                            }else{
                                $save_fail += 1;
                            }
                            $xs_data = array(
                                'id'=>$res['id'],
                                'short_title'=>$res['short_title'],
                                'volume'=>$res['volume'],
                                'pic_url'=>$res['pic_url'],
                                'coupon_price'=>$res['coupon_price'],
                                'price'=>$res['price'],
                                'youhuiquan_je'=>$res['youhuiquan_je'],
                                'num_iid'=>$res['num_iid'],
                                'shop_type'=>$res['shop_type'],
                                'movie_url'=>$res['movie_url'],
                                'title'=>$res['title'],
                                'commission_rate'=>$res['commission_rate']
                            );
                            $doc=$this->xs_doc;
                            $doc->setFields($xs_data);
                            $index=$this->xs_index;
                            $index->update($doc);
                            $index->flushIndex();
                            add_file_log('qtk_items_update',$item);
                        }else{
                            $save_no += 1;
                        }
                    }
                }
                
                if($data_sum<100){
                    $page = 1;
                }else{
                    $page = $page+1;
                }
                $this->assign('add_success',$add_success);
                $this->assign('save_success',$save_success);
                $this->assign('add_fail',$add_fail);
                $this->assign('save_fail',$save_fail);
                $this->assign('add_no',$add_no);
                $this->assign('save_no',$save_no);
                $this->assign('page',$page);
                $this->assign('sum_data',$data_sum);
                $this->display();
            }else{
                //发短信
                $this->send_msg('轻淘客');   
            }
    }
    /*
     * 获取懒懒淘客数据
     * */
    public function get_lltk_shop_all(){
        $cid = I('cid',1);
        switch ($cid){
            case 1: $c_id=1321; $cateid=1; break;
            case 2: $c_id=1322; $cateid=8; break;
            case 3: $c_id=1323; $cateid=5; break;
            case 4: $c_id=1324; $cateid=6; break;
            case 5: $c_id=1325; $cateid=5; break;
            case 6: $c_id=1326; $cateid=35;break;
            case 7: $c_id=1327; $cateid=2; break;
            case 8: $c_id=1328; $cateid=4; break;
            case 9: $c_id=1329; $cateid=7; break;
            case 10: $c_id=1330;$cateid=36;break;
        }
        $page = I('page',1);
        $add_success    = 0;
        $add_fail       = 0;
        $add_no         = 0;
        $save_success   = 0;
        $save_fail      = 0;
        $save_no=0;
        $url ="http://www.lanlanlife.com/product/itemList?apiKey=0f102a2fb1373c163613b3e3715091ec&cid=$c_id&page=$page&pagesize=10&sort=1";
        $res=curl_get($url);
        if($res['status']['code']==1001 && $res['status']['msg']=='ok'){
            $res = $res['result'];
            $res_num=count($res);
            foreach ($res as $val){
                if($val['shopType']=='tmall'){
                    $shop_type='B';
                }else{
                    $shop_type="C";
                }
                //$activeid = $val['coupon_id'];
                //$sellerid = $val['seller_id'];
                //$itemid   = $val['goods_id'];
                //$youhuiquan="https://shop.m.taobao.com/shop/coupon.htm?activity_id=$activeid&seller_id=$sellerid";
                $youhuiquan_je=$val['couponMoney'];
                $has_youhuiquan=1;
                $youhuiquan=$val['couponUrl'];
                $itemid = $val['itemId'];
                $pattern ='/activity..?d=(\w+)/';
                preg_match($pattern , $youhuiquan , $matches);
                $activeid=$matches[1];
                $daili_url ="https://uland.taobao.com/coupon/edetail?activityId=$activeid&itemId=$itemid&pid=mm_116133360_35666802_126860353&src=YQT&dx=1";
                if($val['activityType']==3){
                    $activity='聚划算';
                }
                if($val['activityType']==2){
                    $activity='淘抢购';
                }
                $data = array(
                    'ordid'=>'99999',
                    'cate_id'=>$cateid,
                    'num_iid'=>$val['itemId'],
                    'short_title'=>$val['shortTitle'],
                    'title'=>$val['title'],
                    'uname'=>'懒懒淘客',
                    'pic_url'=>$val['sendImage'],
                    'price'=>$val['price'],
                    'volume'=>$val['monthSales'],
                    'commission'=>($val['tkRates']/100)*$val['nowPrice'],
                    'commission_rate'=>$val['tkRates']*10000,
                    'coupon_price'=>$val['nowPrice'],
                    'shop_type'=>$shop_type,
                    'item_url'=>'https://item.taobao.com/item.htm?id='.$val['itemId'],
                    'ems'=>'1',
                    'add_time'=>time(),
                    'youhuiquan'=>$val['couponUrl'],
                    'youhuiquan_je'=>$val['couponMoney'],
                    'has_youhuiquan'=>$has_youhuiquan,
                    'nick'=>$val['sellerName'],
                    'sellerid'=>$val['sellerId'],
                    'recommend_reason'=>$val['recommend'],
                    'desc_info_url'=>'',
                    'daili_url'=>$daili_url,
                    'daili_url_statue'=>'2',
                    'daili_shouru'=>'',
                    'coupon_end_time'=>$val['couponEndTime'],
                    'coupon_start_time'=>$val['couponStartTime'],
                    'coupon_update_time'=>time(),
                    'activity'=>$activity,
                    'sellerid'=>$val['sellerId'],
                    'nick'=>$val['sellerName'],
                );
                $youhuiquan=$val['couponUrl'];
                if(strpos($youhuiquan,'shop.m.taobao.com') || strpos($youhuiquan,'market.m.taobao.com')){
                    continue;
                }
                $w['num_iid']=$val['itemId'];
                $w['youhuiquan']=array('like','%'.$activeid.'%');
                $w['_logic']='or';
                add_file_log('lltk_items_all',$item);
                $res = M('a_items')->where($w)->find();
                if(!$res){
                    if(strpos($youhuiquan,'activity')){
                        $id = M('a_items')->add($data);
                        if($id){
                            $add_success += 1;
                        }else{
                            $add_fail += 1;
                        }
                        $xs_data = array(
                            'id'=>$id,
                            'short_title'=>$data['short_title'],
                            'volume'=>$data['volume'],
                            'pic_url'=>$data['pic_url'],
                            'coupon_price'=>$data['coupon_price'],
                            'price'=>$data['price'],
                            'youhuiquan_je'=>$data['youhuiquan_je'],
                            'num_iid'=>$data['num_iid'],
                            'shop_type'=>$data['shop_type'],
                            'movie_url'=>$data['movie_url'],
                            'title'=>$data['title'],
                            'commission_rate'=>$data['commission_rate']
                        );
                        $doc=$this->xs_doc;
                        $index=$this->xs_index;
                        $doc->setFields($xs_data);
                        $index->add($doc);
                        $index->flushIndex();
                        add_file_log('lltk_items_add',$item);
                    }
                }else{
                    $add_no += 1;
                    $quan_je = $res['youhuiquan_je'];
                    if($quan_je<$youhuiquan_je){
                        $save = M('a_items')->where(array('id'=>$res['id']))->save($data);
                        if($save){
                            $save_success += 1;
                        }else{
                            $save_fail += 1;
                        }
                        $xs_data = array(
                            'id'=>$res['id'],
                            'short_title'=>$res['short_title'],
                            'volume'=>$res['volume'],
                            'pic_url'=>$res['pic_url'],
                            'coupon_price'=>$res['coupon_price'],
                            'price'=>$res['price'],
                            'youhuiquan_je'=>$res['youhuiquan_je'],
                            'num_iid'=>$res['num_iid'],
                            'shop_type'=>$res['shop_type'],
                            'movie_url'=>$res['movie_url'],
                            'title'=>$res['title'],
                            'commission_rate'=>$res['commission_rate']
                        );
                        $doc=$this->xs_doc;
                        $doc->setFields($xs_data);
                        $index=$this->xs_index;
                        $index->update($doc);
                        $index->flushIndex();
                        add_file_log('lltk_items_update',$item);
                    }else{
                        $save_no += 1;
                    }
                }
            }
            
            if($res_num<10){
                $cid = $cid+1;
                $page=1;
            }else{
                $page = $page+1;
            }
            $this->assign('add_success',$add_success);
            $this->assign('save_success',$save_success);
            $this->assign('add_fail',$add_fail);
            $this->assign('save_fail',$save_fail);
            $this->assign('add_no',$add_no);
            $this->assign('save_no',$save_no);
            $this->assign('page',$page);
            $this->assign('cid',$cid);
            $this->display();
        }else{
            $this->send_msg('懒懒淘客');
        }
    }
    /*
     * 查询最后更新优惠券的商品500条
     * */
    public function get_yhq_items(){
        $items = M('a_items')->field('id,youhuiquan,num_iid')->order('coupon_update_time asc,id asc')->limit(0,50)->select();
        $num1=0;
        $num2=0;
        foreach ($items as $key=>$val){
            $id = $val['id'];
            $quan = $val['youhuiquan'];
            $itemid = $val['num_iid'];
            $pattern ='/activity..?d=(\w+)/';
            $q=urldecode($quan);
            preg_match($pattern , $q , $matches);
            $activeid=$matches[1];
            $url = "http://api.olivecloud.cn/index/taobao_tbk_coupon_get?itemid=%s&activeid=%s";
            $res = vget(sprintf($url,$itemid,$activeid));
            $ress = json_decode($res,true);
            if($ress['data']['coupon_total_count']<=0){
                //优惠券失效
                $data = array('id'=>$id);
                $index = $this->xs_index;
                $index->del($id);
                $index->flushIndex();
                add_file_log('delete_items',$data);
                $res = M('a_items')->delete($id);
                $num1 += 1;
            }else{
                //优惠券未失效
                $d = array(
                    'id'=>$id,
                    'coupon_update_time'=>time()
                );
                $res = M('a_items')->save($d);
                $num2 +=1;
            }
        }
        echo "优惠券失效商品：$num1,优惠券未失效商品：$num2";
        //$this->assign('num1',$num1);
        //$this->assign('num2',$num2);
        //$this->display();
    }
    /*
     * 查询最后更新优惠券的商品50条
     * */
    public function get_shixiao_items(){
        $items = M('a_items')->field('id,num_iid')->order('item_update_time asc,id asc')->limit(0,50)->select();
        $num1=0;
        $num2=0;
        foreach ($items as $key=>$val){
            $id = $val['id'];
            $iid = $val['num_iid'];
            $iteminfo = get_item_infos($iid);
            if(empty($iteminfo)){
                //没有商品信息
                $data = array('id'=>$id);
                $index = $this->xs_index;
                $index->del($id);
                $index->flushIndex();
                add_file_log('delete_items',$data);
                $res = M('a_items')->delete($id);
                $num1 += 1;
            }else{
                //优惠券未失效
                $d = array(
                    'id'=>$id,
                    'item_update_time'=>time()
                );
                $res = M('a_items')->save($d);
                $num2 +=1;
            }
        }
        echo "下架商品：$num1,未下架商品：$num2";
        //$this->assign('num1',$num1);
        //$this->assign('num2',$num2);
        //$this->display();
    }
    /*
     * 把没有优惠券的商品状态更新删掉
     * */
    public function update_yhq_status($id,$type){
        //$id = I('id');
        //$type=I('type');//优惠券类型 1表示过期，2表示有效
        if($type==1){
            $data = array('id'=>$id);
            $index = $this->xs_index;
            $index->del($id);
            $index->flushIndex();
            add_file_log('delete_items',$data);
            $res = M('a_items')->delete($id);
        }else{
            $d = array(
                'id'=>$id,
                'coupon_update_time'=>time()
            );
            $res = M('a_items')->save($d);
        }
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'优惠券状态修改成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'优惠券状态修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //修改商品信息更新索引
    public function update_coupon_price(){
        $id = I('id');
        //查询数据
        $res = M('a_items')->where(array('id'=>$id))->find();
        $commission_rate=$res['commission_reate']/1000000;
        $value=I('value');
        $commission=$commission_rate*$value;
        $youhuiquan_je=$res['youhuiquan_je'];
        $price=$youhuiquan_je+$value;
        $data = array(
            'id'=>$id,
            'commission'=>$commission,
            'coupon_price'=>$value,
            'price'=>$price
        );
        $ress = M('a_items')->save($data);
        if($ress){
            $xs_data = array(
                'id'=>$res['id'],
                'short_title'=>$res['short_title'],
                'volume'=>$res['volume'],
                'pic_url'=>$res['pic_url'],
                'coupon_price'=>$value,
                'price'=>$price,
                'youhuiquan_je'=>$res['youhuiquan_je'],
                'num_iid'=>$res['num_iid'],
                'shop_type'=>$res['shop_type'],
                'movie_url'=>$res['movie_url'],
                'title'=>$res['title'],
                'commission_rate'=>$res['commission_rate']
            );
            $doc=$this->xs_doc;
            $doc->setFields($xs_data);
            $index=$this->xs_index;
            $index->update($doc);
            $index->flushIndex();
            $arr = array(
                'code'=>1,
                'msg'=>'修改成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //通过xunsearch搜索商品
    public function search_items($key,$type,$page){
        //$key=urldecode(I('key'));
        //$type=I('type');
        require_once '/data/wwwroot/default/xunsearch/sdk/php/lib/XS.php';
        $xs = new \XS('items');
        $index = $xs->index;
        $search = $xs->search;
        $total1 = $search->dbTotal;//获取索引库内的数据总数
        $search->setQuery($key)->setLimit(10,$total1)->search();
        $count  = $search->getLastCount();
        $num = 20;
        //$page=I('p',1);
        switch ($type){
            case 1:
                $sorts = array('coupon_price' => true);
                $search->setMultiSort($sorts);
                break;
            case 2:
                $sorts = array('volume' => false);
                $search->setMultiSort($sorts);
                break;
            case 3:
                $sorts = array('youhuiquan_je' => false);
                $search->setMultiSort($sorts);
                break;
        }
        $docs = $search->setQuery($key)->addWeight('title', $key)->setLimit($num,($page-1)*$num)->search(); // 执行搜索，将搜索结果文档保存在 $docs 数组中
        $count_page = ceil($count/$num);
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        foreach ($docs as $key=>$doc){
            //$short_title = $search->highlight($doc->short_title); // 高亮处理 subject 字段
            //$title = $search->highlight($doc->title); // 高亮处理 message 字段
            $data[$key]['id']=$doc->id;
            //$data[$key]['num']=$doc->rank();
            $data[$key]['short_title']=$doc->short_title;
            $data[$key]['title']=$doc->title;
            $data[$key]['volume']=$doc->volume;
            $data[$key]['price']=$doc->price;
            $data[$key]['coupon_price']=($doc->price)-($doc->youhuiquan_je);
            $data[$key]['youhuiquan_je']=$doc->youhuiquan_je;
            $data[$key]['num_iid']=$doc->num_iid;
            $data[$key]['shop_type']=$doc->shop_type;
            $data[$key]['movie_url']=$doc->movie_url;
            $data[$key]['pic_url']=$doc->pic_url;
            $data[$key]['commission_rate']=$doc->commission_rate;
        }
        $res = array(
            'total'=>$total1,
            'count_page'=>$count_page,
            'count'=>$count,
            'items'=>$data
        );
        return $res;
    }
    public function search_test(){
        $key=str_replace(' ','',str_replace("\n",'',I('key')));
        $type=1;
        $page=1;
        require_once '/data/wwwroot/default/xunsearch/sdk/php/lib/XS.php';
        $xs = new \XS('items');
        $index = $xs->index;
        $search = $xs->search;
        $total1 = $search->dbTotal;//获取索引库内的数据总数
        $search->setQuery($key)->setLimit(10,$total1)->search();
        $count  = $search->getLastCount();
        $num = 20;
        //$page=I('p',1);
        switch ($type){
            case 1:
                $sorts = array('coupon_price' => true);
                $search->setMultiSort($sorts);
                break;
            case 2:
                $sorts = array('volume' => false);
                $search->setMultiSort($sorts);
                break;
            case 3:
                $sorts = array('youhuiquan_je' => false);
                $search->setMultiSort($sorts);
                break;
        }
        $docs = $search->setQuery($key)->addWeight('title', $key)->setLimit($num,($page-1)*$num)->search(); // 执行搜索，将搜索结果文档保存在 $docs 数组中
        $count_page = ceil($count/$num);
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        foreach ($docs as $key=>$doc){
            //$short_title = $search->highlight($doc->short_title); // 高亮处理 subject 字段
            //$title = $search->highlight($doc->title); // 高亮处理 message 字段
            $data[$key]['id']=$doc->id;
            //$data[$key]['num']=$doc->rank();
            $data[$key]['short_title']=$doc->short_title;
            $data[$key]['title']=$doc->title;
            $data[$key]['volume']=$doc->volume;
            $data[$key]['price']=$doc->price;
            $data[$key]['coupon_price']=($doc->price)-($doc->youhuiquan_je);
            $data[$key]['youhuiquan_je']=$doc->youhuiquan_je;
            $data[$key]['num_iid']=$doc->num_iid;
            $data[$key]['shop_type']=$doc->shop_type;
            $data[$key]['movie_url']=$doc->movie_url;
            $data[$key]['pic_url']=$doc->pic_url;
            $data[$key]['commission_rate']=$doc->commission_rate;
        }
        $res = array(
            'total'=>$total1,
            'count_page'=>$count_page,
            'count'=>$count,
            'items'=>$data
        );
        echo '<pre>';
        print_r($res);
    }
    //获取热搜词
    public function hot(){
        $hotword = $this->xs_search->getHotQuery();
        foreach ($hotword as $key=>$val){
            $arr['num']=$val;
            $arr['keyword']=$key;
            $r[]=$arr;
        }
        $sort = array(
            'direction' => 'SORT_DESC', //排序顺序标志 SORT_DESC 降序；SORT_ASC 升序
            'field'     => 'num',       //排序字段
        );
        $arrSort = array();
        foreach($r AS $uniqid => $row){
            foreach($row AS $key=>$value){
                $arrSort[$key][$uniqid] = $value;
             }
        }
        if($sort['direction']){
             array_multisort($arrSort[$sort['field']], constant($sort['direction']), $r);
        }
        return $r;
    }
    public function hot_test(){
        $xs_search = $this->xs_search;
        $hotword = $xs_search->getHotQuery(6);
        echo '<pre>';
        $total = $xs_search->dbTotal;
        echo $total;
        echo '<br>';
        $total = $xs_search->getDbTotal();
        echo $total;
        echo '<br>';
        $count = $xs_search->count('毛呢大衣');
        print_r($count);
        echo '<br>';
        $words = $xs_search->getRelatedQuery('大衣', 10);
        echo '<pre>';
        print_r($words);
        print_r($hotword);exit;
        foreach ($hotword as $key=>$val){
            $arr['num']=$val;
            $arr['keyword']=$key;
            $r[]=$arr;
        }
        echo '<pre>';
        print_r($hotword);
    }
    /**
     * 删除数据
     * */
    public function del(){
        $table = I('table');
        $id = I('id');
        $res = M($table)->delete($id);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'删除成功'
            );
            $index=$this->xs_index;
            $index->del($id);
            $index->flushIndex();
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'删除失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //发短信的方法
    public function send_msg($type){
        $msg = "通知：$type接口采集商品程序停止请重新启动；";
        $target = "http://106.ihuyi.cn/webservice/sms.php?method=Submit";
        //多个手机号码请用英文,号隔开
        $post_data = "account=cf_yuwanqiao&password=ywq523350109&mobile=18771925960&content=".rawurlencode($msg);
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $target);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_NOBODY, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
        $return_str[] = curl_exec($curl);
        curl_close($curl);
    }
    //test
    public function test(){
        //$key=I('key');
        //require_once '/data/wwwroot/default/xunsearch/sdk/php/lib/XS.php';
        //$t = new \XSTokenizer();
        //echo '<pre>';
        //print_r($t);exit;
        $index = $this->xs_index;
        //$index->clean();
        //$index->beginRebuild();
        //$index->endRebuild();
        $search = $this->xs_search;
        $total1 = $search->dbTotal;//获取索引库内的数据总数
        $search->setQuery($key)->setLimit(10,$total1)->search();
        $count  = $search->getLastCount();
        echo $count;exit;
        echo '<hr>';
        $num = 1000;
        $page=I('p',1);
        switch ($type){
            case 1:
                $sorts = array('coupon_price' => true);
                $search->setMultiSort($sorts);
                break;
            case 2:
                $sorts = array('volume' => false);
                $search->setMultiSort($sorts);
                break;
            case 3:
                $sorts = array('youhuiquan_je' => false);
                $search->setMultiSort($sorts);
                break;
        }
        $docs = $search->setQuery($key)->addWeight('title', $key)->setLimit($num,($page-1)*$num)->search(); // 执行搜索，将搜索结果文档保存在 $docs 数组中
        $count_page = ceil($count/$num);
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        
        foreach ($docs as $key=>$doc){
            //$short_title = $search->highlight($doc->short_title); // 高亮处理 subject 字段
            //$title = $search->highlight($doc->title); // 高亮处理 message 字段
            $data[$key]['id']=$doc->id;
            $res =M('a_items','daili_','DB_DAILI')->where(array('id'=>$doc->id))->find();
            if($res){
                
            }else{
                
                echo $doc->id;
                $index->del($doc->id);
                $index->flushIndex();
                echo '<hr>';
            }
        }
        exit;
        $res = array(
            'total'=>$total1,
            'count_page'=>$count_page,
            'count'=>$count,
            'items'=>$data
        );
        echo '<pre>';
        print_r($res);exit;
        $this->ajaxReturn($res);
    }
}