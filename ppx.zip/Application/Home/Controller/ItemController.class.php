<?php
namespace Home\Controller;
use Think\Controller;
class ItemController extends BaseController {
    /**
     * 商品列表
     * */
    public function item_list(){
        $dataid = I('dataid');
        $key=I('key');
        $cate_id = I('cate');
        $low_price = I('low_price');
        $high_price= I('high_price');
        $p = I('p',1);
        $num = 100;
        $str_where=' where ';
        if($dataid){
            $str_where .= " a.id = '".$dataid."' or num_iid='".$dataid."'";
            $this->assign('dataid',$dataid);
        }else{
            if($key){
                $str_where .= " a.title like '%$key%' or a.short_title like '%$key%'"; 
                $this->assign('key',$key);
            }
        }
        
        if(is_numeric($low_price)){
            if($str_where !=' where '){
                $str_where .=' and ';
            }
            $str_where .= " a.coupon_price >= '$low_price'";
            $this->assign('low_price',$low_price);
        }
        if(is_numeric($high_price)){
            if($str_where !=' where '){
                $str_where.=' and ';
            }
            $str_where .= " a.coupon_price <= '$high_price'";
            $this->assign('high_price',$high_price);
        }
        if($cate_id){
            if($str_where !=' where '){
                $str_where.=' and ';
            }
            if($cate_id=='-1'){
                $str_where .=' a.movie_url is not null';
            }else{
                $str_where .=' a.cate_id='.$cate_id;
            }
            $this->assign('cate_id',$cate_id);
        }
        if($str_where ==' where '){
            $str_where = '';
        }
        $sql   = "select count(*) as count from daili_a_items as a $str_where";
        
        $count = M('a_items','daili_','DB_DAILI_READ')->query($sql);
        $count = $count[0]['count'];
        $Page  = new \Think\Page($count,$num);
        $show  = $Page->show();
        $start = ($p-1)*$num;
        $end   = $num;
        $sql = "select a.*,replace(a.pic_url,'_400x400.jpg','') as b_pic_url,ROUND((a.commission_rate/1000000)*(a.coupon_price),2) as b_commission,trim(TRAILING '0' FROM a.commission_rate/10000) as a_commission_rate,b.name as b_cate from daili_a_items as a left join daili_a_cate as b on a.cate_id = b.id $str_where order by a.ordid asc,a.id desc limit $start,$end";
        //$list  = M('a_items')->where()->order('ordid asc,add_time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        
        $list = M('a_items','daili_','DB_DAILI_READ')->query($sql);
        
        //echo '<pre>';
        //print_r($list);exit;
        //查询分类
        $cate = M('a_cate')->field('id,name')->order('sort asc')->select();
        $this->assign('cate',$cate);
        
        $this->assign('list',$list);
        $this->assign('count',$count);
        $this->assign('page',$show);
        $this->assign('p',$p);
        $this->display();
    }
    //专题列表
    //专场列表和轮播图列表
    public function lunbotu(){
        $qd = I('qudao');
        if($qd){
            $search_token="'".$qd."'";
        }else{
            $search_token=$this->str_t;
        }
        $sql ="select a.*,b.qudao_name as qudao from daili_a_lunbotu as a left join daili_a_media as b on a.token=b.token where a.type=1 and a.token in ($search_token) order by a.ordid asc";
        $lunbotu = M('a_lunbotu','daili_','DB_DAILI')->query($sql);
        $this->assign('lunbotu',$lunbotu);
        $this->assign('type',1);
        $this->assign('qudao',$qd);
        $this->display('zhuanti');
    }
    //获取轮播图信息
    public function get_lunbotu(){
        $id = I('id');
        $res = M('a_lunbotu')->field('text')->where(array('id'=>$id))->find();
        $this->ajaxReturn($res);
    }
    //其他专场列表
    public function zhuangti(){
        $list = M('a_shoptype_pic')->where(array('type'=>'专题'))->order('sort asc')->select();
        $this->assign('res',$list);
        $this->display();
    }
    //添加轮播图
    public function add_zhuanchang(){
            $id = I('id');
            if($id){
                $res = M('a_lunbotu')->where(array('id'=>$id))->find();
                $this->assign('res',$res);
            }
            $type=I('type');
            $this->assign('type',$type);
            $this->display();
    }
    
    //更新id查询下面的数据
    public function items(){
        $id = I('id');
        $p = I('p');
        if(!$p){
            $p = 1;
        }
        
        $where['_string']="FIND_IN_SET($id,type_id)";
        $count= M('a_items')->where($where)->count();// 查询满足要求的总记录数
        $page_num = 50;
        $Page       = new \Think\Page($count,$page_num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = M('a_items')->where($where)->order('ordid asc,add_time desc,has_youhuiquan desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        foreach($search_data as $key=>$val) {
            $Page->parameter[$key] = $val;
        }
        $show       = $Page->show();// 分页显示输出
        
        foreach ($list as $key=>$val){
            //查询商品分类
            if($val['cate_id']){
                $cate = M('a_cate')->where('id='.$val['cate_id'])->find();
                if($cate){
                    $list[$key]['cate']=$cate['name'];
                }else{
                    $list[$key]['cate']='其他';
                }
            }else{
                $list[$key]['cate']='其他';
            }
            $list[$key]['commission'] = ($val['commission_rate']/1000000)*$val['coupon_price'];
            $list[$key]['commission_rate']=$val['commission_rate']/10000;
            $pic_str = $val['pic_url'];
            if(substr($pic_str,0,4) != 'http'){
                $list[$key]['pic_url']='http://tejia.aili.com/data/upload/item'.$val['pic_url'];
            }
            $zhuanchang_id = $val['type_id'];
            if($zhuanchang_id){
                $zhuanchang = M('a_lunbotu')->field('id,title')->where('id in('.$zhuanchang_id.')')->select();
                $title='';
                foreach ($zhuanchang as $k=>$v){
                    $title .= $v['title'].'<br>';
                }
                $list[$key]['type_id']=$val['id'];
                $list[$key]['type_title']=$title;
            }else{
                $list[$key]['type_title']='无';
            }
        }
        $this->assign('list',$list);
        $this->assign('page',$show);
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('id',$id);
        $this->display();
    }
    //查询微淘文章下面的数据
    public function items_weitao(){
        $id = I('id');
        $p = I('p');
        if(!$p){
            $p = 1;
        }
    
        $where['_string']="FIND_IN_SET($id,weitao_id)";
        $count= M('a_items')->where($where)->count();// 查询满足要求的总记录数
        $page_num = 50;
        $Page       = new \Think\Page($count,$page_num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = M('a_items')->where($where)->order('ordid asc,add_time desc,has_youhuiquan desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        foreach($search_data as $key=>$val) {
            $Page->parameter[$key] = $val;
        }
        $show       = $Page->show();// 分页显示输出
    
        foreach ($list as $key=>$val){
            //查询商品分类
            if($val['cate_id']){
                $cate = M('a_cate')->where('id='.$val['cate_id'])->find();
                if($cate){
                    $list[$key]['cate']=$cate['name'];
                }else{
                    $list[$key]['cate']='其他';
                }
            }else{
                $list[$key]['cate']='其他';
            }
            $list[$key]['commission'] = ($val['commission_rate']/1000000)*$val['coupon_price'];
            $list[$key]['commission_rate']=$val['commission_rate']/10000;
            $pic_str = $val['pic_url'];
            if(substr($pic_str,0,4) != 'http'){
                $list[$key]['pic_url']='http://tejia.aili.com/data/upload/item'.$val['pic_url'];
            }
            $zhuanchang_id = $val['weitao_id'];
            if($zhuanchang_id){
                $zhuanchang = M('a_weitao')->field('id,title')->where('id in ('.$zhuanchang_id.')')->select();
                $title='';
                foreach ($zhuanchang as $k=>$v){
                    $title .= $v['title'].'<br>';
                }
                $list[$key]['weitao_id']=$val['weitao_id'];
                $list[$key]['weitao_title']=$title;
            }else{
                $list[$key]['weitao_title']='无';
            }
        }
        $this->assign('list',$list);
        $this->assign('page',$show);
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('id',$id);
        $this->display();
    }
    //查询品牌下面的数据
    public function items_brand(){
        $id = I('id');
        $p = I('p');
        if(!$p){
            $p = 1;
        }
    
        $where['_string']="FIND_IN_SET($id,brand_id)";
        $count= M('a_items')->where($where)->count();// 查询满足要求的总记录数
        $page_num = 50;
        $Page       = new \Think\Page($count,$page_num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = M('a_items')->where($where)->order('ordid asc,add_time desc,has_youhuiquan desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        foreach($search_data as $key=>$val) {
            $Page->parameter[$key] = $val;
        }
        $show       = $Page->show();// 分页显示输出
    
        foreach ($list as $key=>$val){
            //查询商品分类
            if($val['cate_id']){
                $cate = M('a_cate')->where('id='.$val['cate_id'])->find();
                if($cate){
                    $list[$key]['cate']=$cate['name'];
                }else{
                    $list[$key]['cate']='其他';
                }
            }else{
                $list[$key]['cate']='其他';
            }
            $list[$key]['commission'] = ($val['commission_rate']/1000000)*$val['coupon_price'];
            $list[$key]['commission_rate']=$val['commission_rate']/10000;
            $pic_str = $val['pic_url'];
            if(substr($pic_str,0,4) != 'http'){
                $list[$key]['pic_url']='http://tejia.aili.com/data/upload/item'.$val['pic_url'];
            }
            $zhuanchang_id = $val['brand_id'];
            if($zhuanchang_id){
                $zhuanchang = M('a_brand')->field('id,title')->where('id in ('.$zhuanchang_id.')')->select();
                $title='';
                foreach ($zhuanchang as $k=>$v){
                    $title .= $v['title'].'<br>';
                }
                $list[$key]['brand_id']=$val['brand_id'];
                $list[$key]['brand_title']=$title;
            }else{
                $list[$key]['brand_title']='无';
            }
        }
        $this->assign('list',$list);
        $this->assign('page',$show);
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('id',$id);
        $this->display();
    }
    //分类列表
    public function cate_list(){
        $res = M('a_cate')->order('sort asc')->select();
        $this->assign('res',$res);
        $this->display();
    }
    //添加分类
    public function add_cate(){
        if(IS_POST){
            $title = I('title');
            $img = I('img');
            $is_show = I('is_show');
            $sort = I('sort');
            $data = array(
                'name'=>$title,
                'cateimg'=>$img,
                'sort'=>$sort,
                'is_show'=>$is_show
            );
            $res = M('a_cate')->add($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'添加成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $id = I('id');
            $this->assign('id',$id);
            $this->display();
        }
    }
    //二级分类
    //分类列表
    public function second_cate_list(){
        $id = I('first_id');
        //echo $id;exit;
        $res = M('a_cate_second')->where(array('pid'=>$id))->order('sort asc')->select();
        $this->assign('first_id',$id);
        
        $this->assign('res',$res);
        $this->display();
    }
    //添加分类
    public function second_add_cate(){
        if(IS_POST){
            $title = I('title');
            //$img = I('img');
            $is_show = I('is_show');
            $sort = I('sort');
            $pid = I('id');
            $data = array(
                'name'=>$title,
                //'cateimg'=>$img,
                'sort'=>$sort,
                'is_show'=>$is_show,
                'pid'=>$pid
            );
            $res = M('a_cate_second')->add($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'添加成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $id = I('first_id');
            $this->assign('first_id',$id);
            $this->display();
        }
    }
    //三级分类
    //分类列表
    public function third_cate_list(){
        $first_id = I('first_id');
        $second_id = I('second_id');
        $res = M('a_cate_third')->where(array('pid'=>$second_id))->order('sort asc')->select();
        $this->assign('res',$res);
        $this->assign('first_id',$first_id);
        $this->assign('second_id',$second_id);
        $this->display();
    }
    //添加分类
    public function third_add_cate(){
        if(IS_POST){
            $title = I('title');
            $img = I('img');
            $is_show = I('is_show');
            $sort = I('sort');
            $pid = I('id');
            $data = array(
                'name'=>$title,
                'cateimg'=>$img,
                'sort'=>$sort,
                'is_show'=>$is_show,
                'pid'=>$pid
            );
            $res = M('a_cate_third')->add($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'添加成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $first_id = I('first_id');
            $this->assign('first_id',$first_id);
            $second_id = I('second_id');
            $this->assign('second_id',$second_id);
            $this->display();
        }
    }
    //后台发圈功能
    public function faquan_item(){
        $user = session('user');
        $uid  = $user['id'];
        //根据UID查询token
        $dataid = I('dataid');
        $token = $user['token'];
        //根据token查询uid
        $u = M('user')->field('id')->where(array('token'=>$token))->select();
        foreach ($u as $key=>$val){
            $str_uid .= $val['id'].',';
        }
        $str_uid = rtrim($str_uid,',');
        $this->assign('dataid',$dataid);
        $key=I('key');
        $p = I('p',1);
        $num = 50;
        $str_where=' where ';
        if($dataid){
            $str_where .= ' a.id = '.$dataid.' or num_iid='.$dataid;
        }else{
            if($key){
                $str_where .= " a.title like '%$key%'"; 
                $this->assign('key',$key);
            }
        }
        if($str_where ==' where '){
            $str_where = '';
        }
        if($str_where){
            if($token){
                $str_where .=" and a.uid in ($str_uid)";
            }
        }else{
            if($uid != 1){
                $str_where .="where a.uid in ($str_uid)";
            }
        }
        $sql   = "select count(*) as count from daili_wx_faquan as a $str_where";
        $count = M('wx_faquan')->query($sql);
        $count = $count[0]['count'];
        $Page  = new \Think\Page($count,$num);
        $show  = $Page->show();
        $start = ($p-1)*$num;
        $end   = $num;
        $sql = "select a.*,b.name as add_user from daili_wx_faquan as a left join daili_user as b on a.uid = b.id $str_where order by a.id desc limit $start,$end";
        
        $list = M('wx_faquan')->query($sql);
        foreach ($list as $key=>$val){
            $list[$key]['pic']=explode(',',rtrim($val['pic'],','));
            $list[$key]['title']=json_decode($val['title']);
            $list[$key]['replay']=json_decode($val['replay']);
        }
        $this->assign('list',$list);
        $this->assign('count',$count);
        $this->assign('page',$show);
        $this->assign('p',$p);
        $this->display();
    }
    //添加发圈商品
    public function add_faquan_item(){
        if(IS_POST){
            $data = I('post.');
            $data['num_iid']=str_replace(' ','',$data['num_iid']);
            $itemid = $data['num_iid'];
            $user = $this->user;
            $token = $user['token'];
            $data['uid']=$user['id'];
            $data['add_time']=time();
            //echo '<pre>';
            //print_r($data);exit;
            $data['replay']=json_encode($data['replay']);
            $data['title']=json_encode($data['title']);
            $data['youhuiquan']=str_replace('amp;','',$data['youhuiquan']);
            /* $pid="mm_33702067_36264112_138708429";
            $arr_pid = explode('_',$pid);
            $adzone_id = $arr_pid[3];
            $site_id   = $arr_pid[2];
            $quan=urlencode($data['youhuiquan']);
            $url = "http://api.olivecloud.cn/index/taobao_tbk_privilege_get_daili?youhuiquan=$quan&item_id=$itemid&adzone_id=$adzone_id&site_id=$site_id";
            $res = curl_get($url);
            $click_url = $res['coupon_click_url'];
            $commission_rate = $res['max_commission_rate'];
            if($click_url){
                $tbkurl=urlencode($click_url);
                $url = str_replace('http://','https://',$click_url);
                //获取短连接
                $url = "http://dwz.olivecloud.cn/tkbGetDWZ?url=".urlencode($url)."&itemid=$itemid";
                $shorturl_arr = curl_get($url);
                $shorturl = $shorturl_arr['msg'];
                $taokouling  = $shorturl_arr['kouling'];
                $tkl = urlencode($taokouling);
                if(!$shorturl){
                    $arr = array('code'=>0,'msg'=>'生成短网址失败');
                    return $arr;
                }
                $commission = $res['max_commission_rate'];
                //调用上行日志接口
                $report_api ="http://api.olivecloud.cn/index/taobao_tbk_data_report?";
                $report_api .="tbkurl=$tbkurl&";
                $report_api .="token=$token&";
                $report_api .="itemid=$itemid&";
                //$report_api .="text=&";
                $report_api .="kouling=$tkl&";
                $report_api .="account=$account&";
                $report_api .="pid=$pid";
                //echo $report_api;exit;
                curl_get($report_api);
            } */
            
            $r = M('wx_faquan')->add($data);
            if($r){
                $arr = array(
                    'code'=>1,
                    'msg'=>'添加发圈商品成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加发圈商品失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $this->display();
        }
    }
    //批量删除发圈商品
    public function del_piliang(){
        $ids = I('ids');
        $w['id']=array('in',$ids);
        $r = M('wx_faquan')->where($w)->delete();
        if($r){
            $arr = array(
                'code'=>1,
                'msg'=>'删除成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'删除失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //编辑发圈商品
    public function edit_faquan_item(){
        if(IS_POST){
            $data = I('post.');
            $data['replay']=json_encode($data['replay']);
            $data['title']=json_encode($data['title']);
            $data['youhuiquan']=str_replace('amp;','',$data['youhuiquan']);
            $data['add_time']=time();
            $user = $this->user;
            $data['uid']=$user['id'];
            $r = M('wx_faquan')->save($data);
            if($r){
                $arr = array(
                    'code'=>1,
                    'msg'=>'编辑发圈商品成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'编辑发圈商品失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $id = I('id');
            $res = M('wx_faquan')->where(array('id'=>$id))->find();
            $pic = explode(',',rtrim($res['pic'],','));
            $res['pic_r']=$pic;
            $res['replay']=json_decode($res['replay']);
            $res['title']=json_decode($res['title']);
            $this->assign('res',$res);
            $this->display();
        }
    }
    //秒杀精选商品
    public function miaosha(){
        $p = I('p',1);
        $num = 20;
        $start = ($p-1)*$num;
        $count = M('a_items_miaosha')->count();
        $page = new \Think\Page($count,$num);
        $show = $page->show();
        $res = M('a_items_miaosha')->order('id desc')->limit($page->firstRow.','.$page->listRows)->select();
        
        $this->assign('count',$count);
        $this->assign('list',$res);
        $this->assign('page',$show);
        $this->display();
    }
    //添加秒杀商品
    public function add_miaosha_item(){
        if(IS_POST){
            $data = I('post.');
            $data['time']=time();
            $data['pic']=rtrim($data['pic'],',');
            $data['youhuiquan']=str_replace('amp;','',$data['youhuiquan']);
            $data['coupon_price']=$data['price']-$data['youhuiquan_je'];
            //秒杀商品转链接
            $quan = urlencode($data['youhuiquan']);
            $itemid=trim($data['num_iid'],' ');
            $url = "http://api.olivecloud.cn/Web/taobao_tbk_privilege_get?youhuiquan=$quan&item_id=$itemid";
            $res = curl_get($url);
            $click_url = $res['coupon_click_url'];
            if($click_url){
                $data['url']=$click_url;
                if($res['coupon_total_count']){
                    $coupon_num = $res['coupon_total_count'];
                }else{
                    $coupon_num = 10000;
                }
                $data['youhuiquan_num']=$coupon_num;
                $tbkurl=urlencode($click_url);
                $url = str_replace('http://','https://',$click_url);
                //获取短连接
                $url = "http://dwz.olivecloud.cn/tkbGetDWZ?url=".urlencode($url)."&itemid=$itemid";
                $shorturl_arr = curl_get($url);
                $shorturl = $shorturl_arr['msg'];
                $taokouling  = $shorturl_arr['kouling'];
                $tkl = urlencode($taokouling);
                $url ="http://api.olivecloud.cn/Web/taobao_tbk_data_report?tbkurl=$click_url&itemid=$itemid&kouling=$tkl";
                curl_get($url);
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'高佣链接转换失败'
                );
                $this->ajaxReturn($arr);
            }
            $r = M('a_items_miaosha')->add($data);
            if($r){
                $arr = array(
                    'code'=>1,
                    'msg'=>'添加秒杀商品成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加秒杀商品失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $this->display();
        }
    }
    //编辑秒杀商品
    public function edit_miaosha_item(){
        if(IS_POST){
            $data = I('post.');
            $data['time']=time();
            $data['pic']=rtrim($data['pic'],',');
            $data['youhuiquan']=str_replace('amp;','',$data['youhuiquan']);
            $data['coupon_price']=$data['price']-$data['youhuiquan_je'];
            //秒杀商品转链接
            $quan = urlencode($data['youhuiquan']);
            $itemid=trim($data['num_iid'],' ');
            $url = "http://api.olivecloud.cn/Web/taobao_tbk_privilege_get?youhuiquan=$quan&item_id=$itemid";
            $res = curl_get($url);
            $click_url = $res['coupon_click_url'];
            if($click_url){
                $data['url']=$click_url;
                if($res['coupon_total_count']){
                    $coupon_num = $res['coupon_total_count'];
                }else{
                    $coupon_num = 10000;
                }
                $data['youhuiquan_num']=$coupon_num;
                $tbkurl=urlencode($click_url);
                $url = str_replace('http://','https://',$click_url);
                //获取短连接
                $url = "http://dwz.olivecloud.cn/tkbGetDWZ?url=".urlencode($url)."&itemid=$itemid";
                $shorturl_arr = curl_get($url);
                $shorturl = $shorturl_arr['msg'];
                $taokouling  = $shorturl_arr['kouling'];
                
                $tkl = urlencode($taokouling);
                $url ="http://api.olivecloud.cn/Web/taobao_tbk_data_report?tbkurl=$click_url&itemid=$itemid&kouling=$tkl";
                curl_get($url);
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'高佣链接转换失败'
                );
                $this->ajaxReturn($arr);
            }
            $r = M('a_items_miaosha')->save($data);
            if($r){
                $arr = array(
                    'code'=>1,
                    'msg'=>'编辑秒杀商品成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'编辑秒杀商品失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $id = I('id');
            $item = M('a_items_miaosha')->where(array('id'=>$id))->find();
            $this->assign('item',$item);
            $this->display();
        }
    }
    public function find_item(){
        $num_iid = I('num_iid');
        $res = M('a_items')->where(array('num_iid'=>$num_iid))->find();
        if($res){
            $arr = array(
                'code'=>0,
                'msg'=>'商品库存在该商品，直接根据商品ID搜索往前排序即可'
            );
            $this->ajaxReturn($arr);
        }
    }
    //添加商品
    public function add_item(){
        if(IS_POST){
            $data = I('post.');
            $data['youhuiquan']=str_replace('amp;','',$data['youhuiquan']);
            $data['pic_url']=rtrim($data['pic_url'],',');
            $data['ordid']=1;
            $data['uname']='后台添加';
            $com = $data['commission'];
            $data['commission']=($com/100)*($data['price']-$data['youhuiquan_je']);
            $data['commission_rate']=$com*10000;
            $data['coupon_price']=$data['price']-$data['youhuiquan_je'];
            if($data['shop_type']==1){
                $data['shop_type']='B';
            }else{
                $data['shop_type']="C";
            }
            $data['item_url']="https://item.taobao.com/item.htm?id=".$data['num_iid'];
            $data['ems']=1;
            $data['add_time']=time();
            if($data['youhuiquan']){
                $data['has_youhuiquan']=1;
            }else{
                $data['has_youhuiquan']=0;
            }
            $data['coupon_update_time']=time();
            $youhuiquan=$data['youhuiquan'];
            $itemid = $data['num_iid'];
            $pattern ='/activity..?d=(\w+)/';
            preg_match($pattern , $youhuiquan , $matches);
            $activeid=$matches[1];
            $data['daili_url'] ="https://uland.taobao.com/coupon/edetail?activityId=$activeid&itemId=$itemid&pid=mm_116133360_35666802_126860353&src=YQT&dx=1";
            
            $res = M('a_items')->add($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'添加成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            //查询分类
            $cate = M('a_cate')->field('id,name')->select();
            $this->assign('cate',$cate);
            $this->display();
        }
    }
    //添加商品
    public function add_zhuanchang_item(){
        if(IS_POST){
            $data = I('post.');
            $data['youhuiquan']=str_replace('amp;','',$data['youhuiquan']);
            $data['pic_url']=rtrim($data['pic_url'],',');
            $data['ordid']=1;
            $data['uname']='后台添加';
            $com = $data['commission'];
            $data['commission']=($com/100)*($data['price']-$data['youhuiquan_je']);
            $data['commission_rate']=$com*10000;
            $data['coupon_price']=$data['price']-$data['youhuiquan_je'];
            if($data['shop_type']==1){
                $data['shop_type']='B';
            }else{
                $data['shop_type']="C";
            }
            $data['item_url']="https://item.taobao.com/item.htm?id=".$data['num_iid'];
            $data['ems']=1;
            $data['add_time']=time();
            if($data['youhuiquan']){
                $data['has_youhuiquan']=1;
            }else{
                $data['has_youhuiquan']=0;
            }
            $data['coupon_update_time']=time();
            $youhuiquan=$data['youhuiquan'];
            $itemid = $data['num_iid'];
            $pattern ='/activity..?d=(\w+)/';
            preg_match($pattern , $youhuiquan , $matches);
            $activeid=$matches[1];
            $data['daili_url'] ="https://uland.taobao.com/coupon/edetail?activityId=$activeid&itemId=$itemid&pid=mm_116133360_35666802_126860353&src=YQT&dx=1";
    
            $res = M('a_items')->add($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'添加成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $zhuanchang_id = I('zhuanchang_id');
            $weitao_id = I('weitao_id');
            $brand_id  = I('brand_id');
            //查询分类
            $cate = M('a_cate')->field('id,name')->select();
            $this->assign('cate',$cate);
            if($weitao_id){
                $this->assign('weitao_id',$weitao_id);
            }
            if($brand_id){
                $this->assign('brand_id',$brand_id);
            }
            if($zhuanchang_id){
                $this->assign('zhuanchang_id',$zhuanchang_id);
            }
            $this->display();
        }
    }

    //app首页活动专场图设置列表
    public function pic_list(){
        $list = M('a_shoptype_pic')->where(array('type'=>'版块'))->select();
        $this->assign('res',$list);
        $list = M('a_shoptype_pic')->where(array('type'=>'新版块'))->select();
        $this->assign('res_new',$list);
        $list = M('a_shoptype_pic')->where(array('type'=>'新版块1'))->select();
        $this->assign('res_new1',$list);
        $this->display();
    }

    //app首页活动专场图设置
    public function add_pic(){
        if(IS_POST){
            $title = I('title');
            $img = I('img');
            $sort = I('sort');
            $data = array(
                'name'=>$title,
                'shoptype_pic'=>$img,
                'sort'=>$sort,
            );
            $res = M('a_shoptype_pic')->add($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'添加成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $id = I('id');
            $this->assign('id',$id);
            $this->display();
        }
    }
    //直播商品列表页面
    public function zhibo_list(){
        $qudao = I('qudao');
        $this->assign('qudao',$qudao);
        $p = I('p',1);
        $num = 50;
        if($qudao){
            $str_where = " where a.token='$qudao'";
        }else{
            $search_str=$this->str_t;
            $str_where = " where a.token in ($search_str)";
        }
        $sql   = "select count(*) as count from daili_a_zhibo_items as a $str_where";
        
        $count = M('a_zhibo_items')->query($sql);
        $count = $count[0]['count'];
        $Page  = new \Think\Page($count,$num);
        $show  = $Page->show();
        $start = ($p-1)*$num;
        $end   = $num;
        $sql = "select a.*,b.qudao_name as b_qudao_name from daili_a_zhibo_items as a left join daili_a_media as b on a.token=b.token $str_where order by a.send_time desc,a.id desc limit $start,$end";
        //$list  = M('a_items')->where()->order('ordid asc,add_time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        
        $list = M('a_zhibo_items')->query($sql);
        
        $this->assign('list',$list);
        $this->assign('count',$count);
        $this->assign('page',$show);
        $this->assign('p',$p);
        $this->display();
    }
    //手工添加的直播商品列表页面
    public function zhibo_items(){
        $qudao = I('qudao');
        $this->assign('qudao',$qudao);
        $p = I('p',1);
        $num = 50;
        if($qudao){
            $str_where = " where a.token='$qudao'";
        }else{
            $search_str=$this->str_t;
            $str_where = " where a.token in ($search_str)";
        }
        $sql   = "select count(*) as count from daili_a_zhibo_items_copy as a $str_where";
        $count = M('a_zhibo_items_copy')->query($sql);
        $count = $count[0]['count'];
        $Page  = new \Think\Page($count,$num);
        $show  = $Page->show();
        $start = ($p-1)*$num;
        $end   = $num;
        $sql = "select a.*,b.qudao_name as b_qudao_name from daili_a_zhibo_items_copy as a left join daili_a_media as b on a.token=b.token $str_where order by a.add_time desc,a.id desc limit $start,$end";
        //$list  = M('a_items')->where()->order('ordid asc,add_time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
    
        $list = M('a_zhibo_items_copy')->query($sql);
    
        $this->assign('list',$list);
        $this->assign('count',$count);
        $this->assign('page',$show);
        $this->assign('p',$p);
        $this->display();
    }
    //直播商品添加
    public function zhibo_add_item(){
        if(IS_POST){
            $data = I('post.');
            $type=$data['type'];
            unset($data['type']);
            if($type){
                $obj_table=M('a_zhibo_items_copy');
            }else{
                $obj_table=M('a_zhibo_items');
            }
            $user = $this->user;
            $token = $user['token'];
            $data['item_url']="https://item.taobao.com/item.htm?id=".$data['num_iid'];
            $data['youhuiquan']=str_replace('amp;','',$data['youhuiquan']);
            $data['pic_url']=rtrim($data['pic_url'],',');
            $data['add_time']=time();
            $data['coupon_price']=$data['price']-$data['youhuiquan_je'];
            $data['send_time']=time();
            $data['uname']=$user['name'];
            if(!$token){
                $token='gh_90c6882faaf9';
                $data['token']=$token;
                $datalist=array($data);
            }else{
                $data['token']=$token;
            }
            //判断24小时内是否添加过
            if($data['id']){
                $res = M('a_zhibo_items')->save($data);
                if($res){
                    $arr = array(
                        'code'=>1,
                        'msg'=>'编辑成功'
                    );
                }else{
                    $arr = array(
                        'code'=>0,
                        'msg'=>'编辑失败'
                    );
                }
                $this->ajaxReturn($arr);
            }else{
                $w = array(
                    'num_iid'=>$data['num_iid'],
                    'add_time'=>array('gt',time()-24*3600)
                );
                $res = $obj_table->where($w)->find();
                if($res){
                    $arr=array(
                        'code'=>0,
                        'msg'=>'24小时之内添加过该商品'
                    );
                    $this->ajaxReturn($arr);
                }else{
                    $res = $obj_table->add($data);
                    if($res){
                        $arr = array(
                            'code'=>1,
                            'msg'=>'添加成功'
                        );
                    }else{
                        $arr = array(
                            'code'=>0,
                            'msg'=>'添加失败'
                        );
                    }
                    $this->ajaxReturn($arr);
                }
            }
        }ELSE{
            $id = I('id');
            $type=I('type');
            if($type){
                $obj_table=M('a_zhibo_items_copy');
            }else{
                $obj_table=M('a_zhibo_items');
            }
            $res = $obj_table->where(array('id'=>$id))->find();
            $this->assign('res',$res);
            $this->assign('type',$type);
            $this->display();
        }
    }
    //直播商品添加
    public function zhibo_add(){
        $id = I('id');
        $items=M('a_items')->where(array('id'=>$id))->find();
        $user = $this->user;
        $token = $user['token'];
        unset($items['id']);
        $data=$items;
        $data['add_time']=time();
        $data1=$data;
        $data2=$data;
        if(!$token){
            $token='gh_90c6882faaf9';
        }
        //查询最后一条数据
        $file = getcwd().'/Application/Home/Conf/'.$token.'_server_conf.php';
        $config = include($file);
        $space=$config['space_time'];
        $last_zhibo_item=M('a_zhibo_items')->where(array('token'=>$token))->order('send_time desc')->find();
        if($token=='gh_26c51afe50df' || $token=='gh_b676e24225c8' || $token=='chuankeyouhui2'){
            $data['token']='gh_26c51afe50df';
            $data['send_time']=$last_zhibo_item['send_time']+$space;
            $data1['token']='gh_b676e24225c8';
            $data1['send_time']=$last_zhibo_item['send_time']+$space;
            $data2['token']='chuankeyouhui2';
            $data2['send_time']=$last_zhibo_item['send_time']+$space;
            $datalist=array($data,$data1,$data2);
        }else{
            $data['token']=$token;
            $data['send_time']=$last_zhibo_item['send_time']+$space;
            $datalist=array($data);
        }
        $w = array(
            'num_iid'=>$items['num_iid'],
            'add_time'=>array('gt',time()-24*3600)
        );
        $res = M('a_zhibo_items')->where($w)->find();
        if($res){
            $arr=array(
                'code'=>0,
                'msg'=>'24小时之内添加过该商品'
            );
            $this->ajaxReturn($arr);
        }else{
            $res = M('a_zhibo_items')->addAll($datalist);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'添加成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加失败'
                );
            }
            $this->ajaxReturn($arr);
        }
    }
    //删除直播商品
    public function zhibo_del(){
        $id = I('id');
        //查询商品信息
        $item = M('a_zhibo_items')->field('id,token,send_time')->where(array('id'=>$id))->find();
        $token = $item['token'];
        $res = M('a_zhibo_items')->delete($id);
        if($res){
            $file = getcwd().'/Application/Home/Conf/'.$token.'_server_conf.php';
            $config = include($file);
            $start=$config['start_time'];
            $end  =$config['end_time'];
            $space=$config['space_time'];
            //查询此商品后面的商品发布时间往前推移
            $w = array(
                'token'=>$token,
                'send_time'=>array('gt',$item['send_time'])
            );
            $items = M('a_zhibo_items')->field('id,send_time')->where($w)->order('send_time asc')->select();
            foreach ($items as $key=>$val){
                $t = $val['send_time']-$space;
                $h = date('H',$t);
                if($h<$start){
                    if($start<$end){
                        $num = ((24-$end)+$start)*3600;
                    }else{
                        $num = ($start-$end)*3600;
                    }
                    $t = $t-$num;
                }
                $d = array(
                    'id'=>$val['id'],
                    'send_time'=>$t
                );
                M('a_zhibo_items')->save($d);
            }
            $arr = array(
                'code'=>1,
                'msg'=>'删除成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'删除失败'
            );
        }
        $this->ajaxReturn($arr);
    }
}