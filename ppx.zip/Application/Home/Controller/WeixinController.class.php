<?php
/*
 * 微信接入后调用接口控制器
 */
namespace Home\Controller;
use Think\Controller;
class WeixinController extends Controller {

    //公众号菜单列表
    public function menu_list(){
        $p = I('p',1);
        $gid = I('get.gid');
        $User = M('menu'); // 实例化User对象
        $count      = $User->where(array('statue'=>1,'gzh_id'=>$gid))->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = $User->where(array('statue'=>1,'gzh_id'=>$gid))->order('id desc')->limit($Page->firstRow.','.$Page->listRows)->select();

        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('gid',$gid);
        $this->assign('p',$p);
        $this->display();
    }



    //创建微信自定义菜单
    public function create_menu(){
        $user=session('user');
        if(!$user){echo '非法操作';}
        //查询公众号
        $gid = I('get.gid');
        if(empty($gid)){
            echo '缺少参数，非法操作';
        }

        $gzh = M('a_media')->where(array('id'=>$gid))->find();
        //先删除掉公众号菜单
        $url = 'https://api.weixin.qq.com/cgi-bin/menu/delete?access_token='.access_token($gzh['token']);

        //根据公众号ID查询一级菜单
        $w = array(
            'gzh_id'=>$gzh['id'],
            'level'=>1

        );
        $menu = M('menu')->where($w)->order('sort asc')->select();

        $url = 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token='.access_token($gzh['token']);

        foreach ($menu as $key_m=>$val_m){
            if($val_m['type']=='no'){
                $data[$key_m]['name']=$val_m['name'];
                //根据一级菜单查询二级菜单
                $w = array(
                    'pid'=>$val_m['id'],
                );
                $child_menu = M('menu')->where($w)->select();
                $child_data = array();
                foreach ($child_menu as $child_key=>$child_val){
                    $child_data[$child_key]['name']=$child_val['name'];
                    $child_data[$child_key]['type']=$child_val['type'];
                    if($child_val['type']=='view'){
                        if(strpos($child_val['url'],'?') !== false){
                            $child_val['url'] = $gzh['yuming'].$child_val['url'].'&token='.$gzh['token'];
                            
                        }else{
                            $child_val['url'] = $gzh['yuming'].$child_val['url'].'?token='.$gzh['token'];
                        }
                        
                        $child_data[$child_key]['url']=$child_val['url'];
                    }
                    if($child_val['type']=='click'){
                        $child_data[$child_key]['key']=$child_val['key'];
                    }

                }

                $data[$key_m]['sub_button']=$child_data;
            }else{
                $data[$key_m]['type']=$val_m['type'];
                $data[$key_m]['name']=$val_m['name'];
                if($val_m['type']=='click'){
                    $data[$key_m]['key']=$val_m['key'];
                }
                if($val_m['type']=='view'){
                    if(strops($val_m['url'],'http')==false){
                        $data[$key_m]['url']=$gzh['yuming'].$val_m['url'].'?token='.$gzh['token'];
                    }
                }
            }
        }
        $post_data = array(
            'button'=>$data
        );
        //echo '<pre>';
        //print_r($post_data);exit;
        $output = curl_post($post_data,$url);
        Addlog($output,$gzh['nick_name'].'创建菜单日志');
//        $arr_gzh = M('a_media')->select();
//        foreach ($arr_gzh as $key=>$gzh){
//
//
//        }
        if($output['errmsg']!='ok'){
            $arr = array(
                'code'=>0,
                'msg'=>'菜单发布失败'
            );
        }else{
            $arr = array(
                'code'=>1,
                'msg'=>'菜单发布成功'
            );
        }
        $this->ajaxReturn($arr);
    }
    //自定义菜单删除接口
    private function delete_menu($token){
        $url = 'https://api.weixin.qq.com/cgi-bin/menu/delete?access_token='.access_token($token);
        file_get_contents($url);
    }
    //生成带参数的二维码
    public function create_qrcode(){
        $equipment_id = I('equipment_id');
        if($equipment_id == 0 || strlen($equipment_id)>=32){
            $arr = array(
                'code'=>0,
                'msg'=>'必须是1到32位的非0整数'
            );
            $this->ajaxReturn($arr);
        }
        $url = 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.access_token($token);
        $post_data = array(
            'expire_seconds'=>'2592000',
            'action_name'=>'QR_SCENE',
            'action_info'=>array(
                'scene'=>array(
                    'scene_id'=>$equipment_id
                )
            )
        );
        $output = curl_post($post_data,$url);
        $url ='https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.UrlEncode($output['ticket']);
        $qrcode_img = file_get_contents($url);//得到post过来的二进制原始数据
        $filename="Zy_equipment_".$equipment_id.".jpg";//要生成的图片名字
		$time = date('Y-m-d');
		if(!is_dir(getcwd().'\Uploads\Qrcode_IMG\\')){
		    mkdir(getcwd().'\Uploads\Qrcode_IMG\\');
		}
		if(!is_dir(getcwd().'\Uploads\Qrcode_IMG\\'.$time.'\\')){
		    mkdir(getcwd().'\Uploads\Qrcode_IMG\\'.$time.'\\');
		}
		$url= getcwd().'\Uploads\Qrcode_IMG\\'.$time.'\\'.$filename;
		$url = str_replace('\\','/',$url);
		$http_url = 'http://'.$_SERVER['HTTP_HOST'].__ROOT__.'/Uploads/Qrcode_IMG/'.$time.'/'.$filename;
		$file = fopen($url,"w");//打开文件准备写入
		if($file){
		    fwrite($file,$qrcode_img);//写入
		    fclose($file);//关闭
		    $arr = array(
		        'code'=>1,
		        'result'=>array(
		            'msg'=>'success',
		            'qrcode_url'=>$http_url
		        )
		    );
		}else{
		    $arr = array(
		        'code'=>0,
		        'msg'=>'fail'
		    );
		}
		$this->ajaxReturn($arr);
    }
    //长链接转短连接
    public function long2short(){
        $url = I('url');
        $url = 'http://uland.taobao.com/coupon/edetail?activityId=2d7fdb3be451436abc728c3b856570d4&itemId=542201338634&pid=mm_119705378_18464776_65450205&src=YQT';
        $data = array(
            'action'=>'long2short',
            'long_url'=>$url
        );
        $url = 'https://api.weixin.qq.com/cgi-bin/shorturl?access_token='.access_token($token);
       
        $output = curl_post($data,$url);
        echo '<pre>';
        print_r($output);
    }
    //公众号列表
    public function gzh_list(){
        $p = I('p',1);
        $User = M('a_media'); // 实例化User对象
        $count      = $User->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = $User->order('add_time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->display();
    }
    /*
     * 用户关注后回复消息
     * */
    public function subscribe(){
        if(IS_POST){
            $db = M('wx_replay_text');
            $where ['gid'] = I('get.gid');
            if(empty($where ['gid'])){
                $this->ajaxReturn(array('statue'=>3));
            }
            $res = $db->where ( $where )->find ();
            $type = I('post.type',0,intval);
            if ($res == false) {
                $data['gid'] = I('get.gid');
                if ($type == 0) {
                    $data ['content'] = I('post.content');
                    if (empty ( $data ['content'] )) {
                        $this->ajaxReturn(array('statue'=>2));
                    }
                } else {
                    $data ['imageid'] = I('post.imageid');
                    $data ['home'] = 1;
                    if (empty ( $data ['imageid'] )) {
                        $this->ajaxReturn(array('statue'=>2));
                    }
                }
                $data ['createtime'] = time ();
                $id = $db->add ($data);
                if($id){
                    $this->ajaxReturn(array('statue'=>1));
                }

            } else {
                $where ['id'] = $res ['id'];

                $where ['updatetime'] = time ();
                if ($type == 0) {
                    $where ['content'] = I('post.content');
                    $where ['home'] = 0;
                    $where ['imageid']=0;
                    if (empty ( $where ['content'] )) {
                        $this->ajaxReturn(array('statue'=>2));
                    }
                } else {
                    $where ['imageid'] = I('post.imageid');
                    $where ['home'] = 1;
                    if (empty ( $where ['imageid'] )) {
                        $this->ajaxReturn(array('statue'=>2));
                    }
                }
                if ($db->where(array('id'=>$res ['id']))->save ( $where )) {
                    $this->ajaxReturn(array('statue'=>1));
                } else {
                    $this->ajaxReturn(array('statue'=>0));
                }
            }
        }else{
            $id = I('get.gid',0,intval);
            if($id == 0){
                $this->error('参数错误');
            }
            //查询文本消息
            $areply = M('wx_replay_text')->where(array('gid'=>$id))->find();
            if($areply['home']==1){
                $image=M("wx_img")->where(array('id'=>$areply['imageid']))->find();
                $image['child']=M("wx_img")->where(array('parentid'=>$image['id']))->select();
                $this->assign('img',$image);
            }
            $this->assign('areply',$areply);
            $this->assign('gid',$id);
            $this->display();
        }
    }

    /**
     * 获取图文库消息
     */
    public function img_list() {
        if (IS_POST) {
            $gid = I('get.gid');
            $db = M ( 'wx_img' );
            $totalRows = $db->order ( 'id desc' )->where ( array ('gid' =>$gid,'parentid' => 0 ) )->count ();
            $listRows = 2;
            $totalPages = ceil ( $totalRows / $listRows ); // 总页数
            $nowPage = ! empty ( $_POST ['p'] ) ? intval ( $_POST ['p'] ) : 1;
            if ($nowPage < 1) {
                $nowPage = 1;
            } elseif (! empty ( $totalPages ) && $nowPage > $totalPages) {
                $nowPage = $totalPages;
            }
            $firstRow = $listRows * ($nowPage - 1);
            $info = $db->field ( 'id,title,text,pic,createtime' )->where ( array ('gid' =>$gid,'parentid' => 0 ) )->order('createtime desc')->limit ( $firstRow . ',' . $listRows )->select ();
            $info_list = array ();
            if ($info !== false) {
                foreach ( $info as $key => $v ) {
                    $info_list [$key] ['id'] = $v ['id'];
                    $info_list [$key] ['title'] = $v ['title'];
                    $info_list [$key] ['text'] = (empty ( $v ['text'] )) ? '' : substr ( $v ['text'], 0, 30 );
                    $info_list [$key] ['pic'] = $v ['pic'];
                    $info_list [$key] ['createtime'] = date ( 'Y-m-d', $v ['createtime'] );
                    $info_list [$key] ['child'] = $db->field ( 'id,title,text,pic,createtime' )->where ( array ('gid' =>$gid,'parentid' => $v ['id'] ) )->select ();
                    if ($info_list [$key] ['child']) {
                        foreach ( $info_list [$key] ['child'] as $m => $n ) {
                            $info_list [$key] ['child'] [$m] ['createtime'] = date ( 'Y-m-d', $n ['createtime'] );
                        }
                    } else {
                        $info_list [$key] ['child'] = array ();
                    }
                }
            }
            unset ( $info );
            echo json_encode ( array ('list' => $info_list,'count' => $totalPages,'firstRow' => $nowPage ) );
        } else {
            echo json_encode ( array () );
        }
        ;
    }


    /*
     * 自定义回复管理
     * */
    public function replay(){
        $db = M ( 'wx_rule' );
        $where ['gid'] = I('get.gid');
        if(empty($where ['gid'])){
            $this->error('参数错误，请刷新页面重试');
        }
        $count = $db->where ( $where )->count ();
        $page       = new \Think\Page($count,5);       // 实例化分页类 传入总记录数和每页显示的记录数(25)
        $info = $db->where ( $where )->limit ( $page->firstRow . ',' . $page->listRows )->order ( array ('createtime' => 'desc' ) )->select ();
        $img = M ( 'wx_img' );
        foreach ( $info as $k => $v ) {
            if ($v ['type'] == 2) {
                $images = $img->where ( array ('id' => $v ['imageid'] ) )->find ();
                $images ['child'] = $img->where ( array ('parentid' => $v ['imageid'] ) )->select ();
                $images ['child'] = empty ( $images ['child'] ) ? array () : $images ['child'];
                $info [$k] ['content'] = $images ['title'];
                $info [$k] ['images'] = $images;
            }
        }
        $this->assign('gid',I('get.gid'));
        $this->assign ( 'page', $page->show () );
        $this->assign ( 'list', $info );
        $this->display ();
    }

    public function keywordInsert() {
        $db = M ( "wx_rule" );
        $gid = I('get.gid');
        $id = I('post.id','','intval');
        if (! empty ( $id )) {
            $where ['id'] = $id;
            $where ['gid'] = $gid;
            $rule = I('post.rule');
            $keyword = I('post.keyword');
            $type = I('post.type','','intval');
            $data = array ('rule_name' => $rule,'keyword' => $keyword,'type' => $type,'updatetime' => time () );
            if ($data ['type'] == 1) {
                $contet = I('post.content');
                if (empty ( $contet )) {
                    $this->ajaxReturn ( 2 );
                } else {
                    $data ['content'] = $contet;
                }
            } else {
                $imageid = I('post.imageid','','intval');
                if ($imageid == 0) {
                    $this->ajaxReturn ( 2 );
                } else {
                    $data ['imageid'] = $imageid;
                }
            }
            if ($db->data ( $data )->where ( $where )->save () !== false) {
                $this->ajaxReturn ( 1 );
            } else {
                $this->ajaxReturn ( 3 );
            }
        } else {
            $rule = I('post.rule');
            $keyword = I('post.keyword');
            $type = I('post.type','','intval');
            $data = array ('rule_name' => $rule,'keyword' => $keyword,'type' => $type,'token' => session ( 'token' ),'createtime' => time () ,'gid'=>$gid);
            if ($data ['type'] == 1) {
                $contet = I('post.content');
                if (empty ( $contet )) {
                    $this->ajaxReturn ( 2 );
                } else {
                    $data ['content'] = $contet;
                }
            } else {
                $imageid = I('post.imageid','','intval');
                if ($imageid == 0) {
                    $this->ajaxReturn ( 2 );
                } else {
                    $data ['imageid'] = $imageid;
                }
            }
            if ($db->data ( $data )->add ()) {
                $this->ajaxReturn ( 1 );
            } else {
                $this->ajaxReturn ( 3 );
            }
        }
    }

    public function ruleDel() {
        if (! IS_AJAX) {
            exit ( 'access denied' );
        }
        $id = I('post.id','','intval');
        if (M ( 'wx_rule' )->where ( array ('id' => $id ) )->delete ()) {
            $this->ajaxReturn ( 1 );
        } else {
            $this->ajaxReturn ( 0 );
        }
    }
    public function ruleTypeEdit() {
        if (! IS_AJAX) {
            exit ( 'access denied' );
        }
        $id = I('post.id','','intval');
        $keyword = I('post.keyword');
        $keywordType = I('post.keywordType');
        $data = array ('keyword' => $keyword,'rule_type' => $keywordType );
        $where = array ('id' => $id );
        if (M ( 'wx_rule' )->data ( $data )->where ( $where )->save () !== false) {
            $this->ajaxReturn ( 1 );
        } else {
            $this->ajaxReturn ( 0 );
        }
    }

    /**
     * 设置自动回复图片
* */
    public function set_subscribe_img(){
        if(IS_POST){
            $id = I('post.id');
            $gid = I('post.gid');
            if(empty($gid)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'不存在该公众号'
                    )
                );
            }
            $info = M('wx_rule')->where(array('id'=>$id))->find();
            if(empty($info)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'不存在该数据'
                    )
                );
            }else{
                $infos = M('wx_replay_text')->where(array('gid'=>$gid))->find();
                if(empty($infos)){
                   $res =  M('wx_replay_text')->add(array('statue'=>1,'home'=>2,'imageid'=>$info['imageid'],'gid'=>$gid));
                }else{
                   $res =  M('wx_replay_text')->where(array('gid'=>$gid))->save(array('statue'=>1,'home'=>2,'imageid'=>$info['imageid']));
                }
                if($res){
                    $this->ajaxReturn(
                        array(
                            'statue'=>0,
                            'msg'=>'设置成功'
                        )
                    );
                }else{
                    $this->ajaxReturn(
                        array(
                            'statue'=>0,
                            'msg'=>'设置失败'
                        )
                    );
                }
            }
        }
    }



    /**
     * 关键字回复图片列表
     * */
    public function imagelist(){
        $p = I('p',1);
        $where ['daili_wx_rule.gid'] = I('get.gid');
        if(empty($where ['daili_wx_rule.gid'])){
            $this->error('参数错误，请刷新页面重试');
        }
        $where['daili_wx_rule.type'] = 3;
        $num = 20;
        $count = M ( 'wx_rule' )->where ( $where )->count ();
        $page       = new \Think\Page($count,$num);       // 实例化分页类 传入总记录数和每页显示的记录数
        $show       = $page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        $field = "daili_wx_rule.*,daili_wx_replay_img.img_url";
        $join = " left join daili_wx_replay_img on daili_wx_rule.imageid = daili_wx_replay_img.id";
        $info = M ( 'wx_rule' )->field($field)->where ( $where )->join($join)->limit ( $start . ',' . $num )->order ( array ('daili_wx_rule.createtime' => 'desc' ) )->select ();
        foreach($info as $k=>$v){
            $statue = M('wx_replay_text')->where(array('gid'=>$v['gid'],'home'=>2,'imageid'=>$v['imageid']))->find();
            if(empty($statue)){
                $info[$k]['set_statue'] = "否";
            }else{
                $info[$k]['set_statue'] = "是";
            }
        }
//        echo  M ( 'wx_rule' )->getLastSql();
        $this->assign('list',$info);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('gid',I('get.gid'));
        $this->display ();
    }

    /**
     * 关键字回复图片素材编辑
     * */
    public function edit_imagelist(){
        if(IS_POST){
            $gid = I('post.gid');
            if(empty($gid)){
                echo '缺少公众号参数，非法操作';
            }
            $id = I('post.id');
            $file = $_FILES['icon'];
            $datas['keyword'] = I('post.keyword');
            if($datas['keyword'] == ""){
                $this->error('请填写关键词');
            }
            if($_FILES['error'] != 0){
                $this->error('图片获取失败，请重新上传');
            }
            if(empty($id)){
                $keyword_info = M('wx_rule')->where(array('keyword'=> $datas['keyword'],'gid'=>$gid))->find();
                if(!empty($keyword_info)){
                    $this->error('已存在该关键词，请重新填写新关键词');
                }
            }
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     3145728 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->savePath  =      '/replay_img/'; // 设置附件上传目录    // 上传单个文件
            $info   =   $upload->uploadOne($file);
            if($info){
                $path = '/Uploads'.$info['savepath'].$info['savename'];
                $data['img_url']=$path;
                $data['img_local_url'] = dirname(dirname(dirname(dirname(__FILE__)))). '/Uploads'.$info['savepath'].$info['savename'];
            }else{
                $this->error($info);
            }
            $gzh = M('a_media')->where(array('id'=>$gid))->find();
            $access_token = access_token($gzh['token']);
            if(empty($access_token)){
                $this->error('获取access_token失败');
            }
            $type = "image";
            $filedata = array("media"  => "@".$data['img_local_url']);
            $url = "http://file.api.weixin.qq.com/cgi-bin/media/upload?access_token=$access_token&type=$type";
            $result = https_request($url,$filedata);
            $result = json_decode($result,1);
            $data['code_media_id'] = $result['media_id'];
            $data['media_id_time'] = $result['created_at'];
            if(empty($result['media_id'])){
                $this->error('上传微信服务器失败');
            }

            if(!empty($id)){
                $infos = M('wx_rule')->where(array('id'=>$id))->find();
                if(empty($infos)){
                    $this->error('数据匹配失败');
                }else{
                    //修改表数据
                    M('wx_replay_img')->where(array('id'=>$infos['imageid']))->save($data);
                    $datas['updatetime'] = time();
                    M('wx_rule')->where(array('id'=>$id))->save($datas);
                    $this->success('添加成功');
                }
            }else{
                $res = M('wx_replay_img')->add($data);
                if($res){
                    $datas['imageid'] = $res;
                    $datas['type'] = 3;
                    $datas['gid'] = $gid;
                    $datas['createtime'] = time();
                    $infos = M('wx_rule')->add($datas);
                    if($infos){
                        $this->success('添加成功');
                    }else{
                        $this->error('添加关键词数据失败');
                    }
                }else{
                    $this->error('添加素材数据失败');
                }
            }
        }else{
            $id = I('get.id');
            $gid = I('get.gid');
            if(!empty($id)){
                $info = M('wx_rule')->where(array('id'=>$id))->find();
                $this->assign('info',$info);
            }
            $this->assign('gid',$gid);
            $this->display();
        }
    }

    /**
     * 关键字回复图片素材删除
     * */
    public function del_imageList(){
        if(IS_POST){
            $id = I('post.id');
            $info = M('wx_rule')->where(array('id'=>$id))->find();
            if(empty($info)){
                $this->ajaxReturn(
                    array(
                        'statue'=>0,
                        'msg'=>'不存在该数据'
                    )
                );
            }else{
                $res = M('wx_rule')->where(array('id'=>$id))->delete();
                M('wx_replay_img')->where(array('id'=>$info['imageid']))->delete();
                if($res){
                    $this->ajaxReturn(
                        array(
                            'statue'=>1,
                            'msg'=>'删除成功'
                        )
                    );
                }else{
                    $this->ajaxReturn(
                        array(
                            'statue'=>0,
                            'msg'=>'删除失败'
                        )
                    );
                }
            }
        }
    }



    //素材管理首页
    public function imagetextlibrary() {
        $db = D ( 'wx_img' );
        $gid = I('get.gid');
        $gzh_token = M('a_media')->where(array('id'=>$gid))->getField('token');
        $_SESSION['token'] = $gzh_token;
        $where ['parentid'] = 0;
        $where ['gid'] = $gid;
        $count = $db->where ( $where )->count ();
        $page       = new \Think\Page($count,25);       // 实例化分页类 传入总记录数和每页显示的记录数(25)
        $info = $db->where ( $where )->order ( 'createtime DESC' )->limit ( $page->firstRow . ',' . $page->listRows )->select ();
        if (! empty ( $info )) {
            foreach ( $info as $k => $v ) {
                $where ['parentid'] = $v ['id'];
                $info [$k] ['child'] = $db->where ( $where )->select ();
            }
        }
        $this->assign ( 'gid', $gid );
        $this->assign("Page", $page->show());
        $this->assign ( 'info', $info );
        $this->display ();
    }

    //单图文添加
    public function imageAdd() {
        $refer = I('get.refer');//优化添加
        $refer=empty($refer) ? 'save' : 'send';//优化添加
        $gid = I('get.gid');
        $this->assign ('gid',$gid);
        $this->assign ('refer',$refer);
        $this->display ();
    }

    //单图文修改
    public function imageEdit() {
//        $where ['token'] = session ( 'token' );
        //$where ['fid'] = 0; // 只选择一级分类
        $where ['id'] = I('get.id','','intval');
//        $where ['aid'] = session ( 'aid' );
        $where ['gid'] = I('get.gid');
        $res = D ( 'wx_img' )->where ( $where )->find ();
        $this->assign ( 'info', $res ); // 内容
        $this->assign ( 'gid', I('get.gid') );
        $this->display ();
    }

    //单图文保存
    public function imageSave() {
        $pat = "/<(\/?)(script|i?frame|style|html|body|title|font|strong|span|div|marquee|link|meta|\?|\%)([^>]*?)>/isU";
        $info = preg_replace ( $pat, "", I('post.info_intro'));
        $data = array ('gid' => I('get.gid'),
            //'uname' => $_SESSION ['uname'],
            'createtime' => time (),
//            'token' => $_SESSION ['token'],
            'title' => I('post.info_name') ,
            'text' => I('post.info_desc'),
            'pic' => I('post.info_pic'),
            'showpic' => I('post.show_pic','','intval'),
            'info' => $info,
            'url' => I('post.info_url','','trim'),
            'type' => 1  );
        //'keyword' => I('post.rule')
        $id = I('post.id','','intval');
        if (!empty($id)) {
            $status = M ( 'wx_img' )->data ( $data )->where ( array ('id' => $id ) )->save ();
            //M ( 'keyword' )->data ( array ('pid' => $id,'module' => 'Img','token' => session ( 'token' ),'keyword' => $data ['keyword'] ) )->where ( array ('pid' => $id ) )->save ();
        } else {
            $status = M ( 'wx_img' )->add ( $data );
            //M ( 'keyword' )->data ( array ('pid' => $status,'module' => 'Img','token' => session ( 'token' ),'keyword' => $data ['keyword'] ) )->add ();
        }
        if ($status) {
//            $this->ajaxReturn ( $status, 'success', 1 );//返回图文id
            $this->ajaxReturn ( array('info'=>'success'));//返回图文id
        } else {
//            $this->ajaxReturn ( '1', 'error', 'json' );
            $this->ajaxReturn ( array('info'=>'error'));
        }
    }

    //单图文删除
    public function imageDel() {
        if(IS_POST){
            $where ['gid'] =I('get.gid');
            $where ['id'] = I('post.id','','intval');
            $del = M ( 'wx_img' )->where ( $where )->delete ();
            if ($del) {
                M ( 'wx_img' )->where ( array ('parentid' => $where ['id'] ) )->delete ();
                //M ( 'keyword' )->where ( array ('pid' => $where ['id'] ) )->delete ();
                echo json_encode(array('status'=>1));
                //$this->success ( '操作成功' );
            } else {
                echo json_encode(array('status'=>0));
                //$this->error ( '操作失败' );
            }
        }
    }

    //多图文添加页面
    public function MultiImageAdd() {
        $refer = I('get.refer');//优化添加
        $refer=empty($refer) ? 'save' : 'send';//优化添加
        $gid = I('get.gid');
        $this->assign ('gid',$gid);
        $this->assign ('refer',$refer);
        $this->display ();
    }

    //多图文修改
    public function MessagePush_MultiEdit() {
        $id = I('get.id');
        $gid = I('get.gid');
        $db = M ( 'wx_img' );
        $info = $db->where ( array ('id' => $id ) )->find ();
        $info ['child'] = $db->where ( array ('parentid' => $id ) )->select ();
        $this->assign ( 'info', $info );
        $this->assign ( 'gid', $gid );
        $this->display ();
    }

    //多图文保存
    public function MessagePush_MultiSave() {
//        if (! IS_POST) {
//            $this->error ( '未知错误' );
//        }
        $MultiId = I('post.info_id');
        $rule = I('post.rule');
        $account_name = I('post.account_name');
        $ruleType = I('post.ruleType');
        $data = I('post.data');
        $data = htmlspecialchars_decode($data);
//        $data = json_decode(json_encode(simplexml_load_string($data, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
        try{
            $xmld = new \SimpleXMLElement($data);
        }catch(Exception $e){
            die($data);
        }

        foreach ( $xmld as $key => $value ) {
            if (is_object ( $value ) && ! empty ( $value )) {
                foreach ( $value as $k => $v ) {
                    $xml [$key] [$k] = urldecode ( strval ( $v ) );
                }
            } else {
                $xml [$key] = urldecode ( strval ( $value ) );
            }
        }
        $db = M ( 'wx_img' );
        $time = time ();
        if ($MultiId) {
            foreach ( $xml as $v ) {
                $datas ['url'] = $v ['info_url'];
                $datas ['title'] = $v ['info_name'];
                $datas ['info'] = $v ['info_intro'];
                $datas ['pic'] = $v ['info_pic'];
                $datas ['keyword'] = $rule;
                $datas ['type'] = 2;
                $datas ['updatetime'] = $time;
                if (! empty ( $v ['id'] )) {
                    $where = array ('id' => $v ['id'],'gid' =>I('get.gid'));
                    $db->where ( $where )->data ( $datas )->save ();
                } else {
                    $datas ['gid'] = I('get.gid');
                    $datas ['token'] = session ( 'token' );
                    $datas ['createtime'] = $time;
                    $datas ['parentid'] = $MultiId;
                    $db->data ( $datas )->add ();
                }
            }
            //$this->ajaxReturn ( '1', 'success', 'json' );
            $this->ajaxReturn(array('info'=>'success'));
        } else {
            $data1 = array_shift ( $xml );
            $datas ['url'] = $data1 ['info_url'];
            $datas ['title'] = $data1 ['info_name'];
            $datas ['info'] = $data1 ['info_intro'];
            $datas ['pic'] = $data1 ['info_pic'];
            $datas ['gid'] = I('get.gid');
//            $datas ['uname'] = session ( 'uname' );
            $datas ['keyword'] = $rule;
//            $datas ['token'] = session ( 'token' );
            $datas ['type'] = 2;
            $datas ['createtime'] = $time;
            $id = $db->data ( $datas )->add ();
            foreach ( $xml as $v ) {
                $datas ['url'] = $v ['info_url'];
                $datas ['title'] = $v ['info_name'];
                $datas ['info'] = $v ['info_intro'];
                $datas ['pic'] = $v ['info_pic'];
                $datas ['parentid'] = $id;
                $datas ['keyword'] = $rule;
                $datas ['type'] = 2;
                $db->data ( $datas )->add ();
            }
            //M ( 'keyword' )->data ( array ('pid' => $id,'module' => 'Img','token' => session ( 'token' ),'keyword' => $rule ) )->add ();
            if ($id) {
                //$this->ajaxReturn ( $id, 'success', 'json' );
                $this->ajaxReturn(array('info'=>'success'));
            } else {
                //$this->ajaxReturn ( '1', 'error', 'json' );
                $this->ajaxReturn(array('info'=>'error','messages'=>'添加失败'));
            }
        }
    }

    /**
     * 删除数据
     * */
    public function del(){
        $table = I('get.table');
        $id = I('get.id');
        $res = M($table)->delete($id);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'删除成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'删除失败'
            );
        }
        $this->ajaxReturn($arr);
    }

}