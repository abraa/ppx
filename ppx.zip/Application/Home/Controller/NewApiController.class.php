<?php
/**
 * 切换阿里妈妈账号控制器
 * */
namespace Home\Controller;
use Think\Controller;
class NewApiController extends Controller {
    //查询没有新建推广位的用户
    public function user(){
        //查询已经是代理的用户
        $w = array(
            'Statue'=>1,
            'TgwID'=>array('exp','is not null'),
            'new_tgwid'=>array('exp','is null'),
            'new_mediaid'=>array('exp','is null'),
            'new_adid'=>array('exp','is null')
        );
        $user = M('wx_user')->field('ID,MediaName,AdName')->where($w)->order('ID desc')->limit(0,50)->select();
        $this->ajaxReturn($user);
    }
    //用户新建推广位和媒体位成功后修改数据库
    public function update_user(){
        $id      = I('id');
        $mediaid = I('mediaid');
        $adid    = I('adid');
        if(!$id){$this->ajaxReturn(array('code'=>0,'msg'=>'用户ID必填'));}
        if(!$mediaid){$this->ajaxReturn(array('code'=>0,'msg'=>'媒体ID必填'));}
        if(!$adid){$this->ajaxReturn(array('code'=>0,'msg'=>'推广位ID必填'));}
        $d = array(
            'ID'=>$id,
            'MediaID'=>$mediaid,
            'AdID'=>$adid
        );
        $res = M('wx_user')->save($d);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'修改成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }
}