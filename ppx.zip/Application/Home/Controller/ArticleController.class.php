<?php
namespace Home\Controller;
use Think\Controller;
class ArticleController extends BaseController {
    //系统文档管理
    public function article(){
        $res = M('article')->field('id,add_time,title')->select();
        $http='http://'.$_SERVER['HTTP_HOST'].'/Index/view/id/';
        $this->assign('res',$res);
        $this->assign('http',$http);
        $this->display();
    }
    //添加文档
    public function add_article(){
        $id = I('id');
        if($id){
            $res = M('article')->where(array('id'=>$id))->find();
            $this->assign('res',$res);
        }
        $this->display();
    }
    //添加文档
    public function ajax_add_article(){
        $data = I('post.');
        $id = $data['id'];
        $data = M('article')->create($data);
        $text = html_entity_decode(html_entity_decode($data['text']));
        $data['text']=$text;
        $data['add_time']=time();
        if($id){
            $res = M('article')->save($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg' =>'编辑文档成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'编辑文档失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $res = M('article')->add($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg' =>'添加文档成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加文档失败'
                );
            }
            $this->ajaxReturn($arr);
        }
    }
    //APP启动图
    public function pic(){
        $qd = I('qudao');
        if($qd){
            $search_token="'".$qd."'";
        }else{
            $search_token=$this->str_t;
        }
        $sql ="select a.*,b.qudao_name as b_name from daili_pic as a left join daili_a_media as b on a.token =b.token where a.token in ($search_token) order by a.time desc";
        $res = M('pic')->query($sql);
        $this->assign('lunbotu',$lunbotu);
        
        $this->assign('qudao',$qd);
        $this->assign('res',$res);
        $this->display();
    }
    //添加APP启动图
    public function add_pic(){
        $id = I('id');
        $user = $this->user;
        if($id){
            $res = M('pic')->where(array('id'=>$id))->find();
            $this->assign('res',$res);
        }
        $this->display();
    }
    //post数据添加图片
    public function ajax_add_pic(){
        $user = $this->user;
        $data = I('post.');
        $id = $data['id'];
        $data['token']=$user['token'];
        if(!$data['token']){
            $data['token']='gh_90c6882faaf9';
        }
        $data = M('pic')->create($data);
        $data['time']=time();
        $data['type']='app启动图';
        if($id){
            $res = M('pic')->save($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg' =>'编辑成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'编辑失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $res = M('pic')->add($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg' =>'添加成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加失败'
                );
            }
            $this->ajaxReturn($arr);
        }
    }
    //微淘专题
    public function weitao(){
        $p = I('p',1);
        $isshow= I('isshow');
        if($isshow != null){
            $w = " isshow = $isshow and ";
            $this->assign('isshow',$isshow);
        }
        $num = 10;
        $start = ($p-1)*$num;
        $qd = I('qudao');
        if($qd){
            $search_token="'".$qd."'";
        }else{
            $search_token=$this->str_t;
        }
        $sql ="select count(a.id) as count from daili_a_weitao as a where $w a.token in ($search_token)";
        
        $res = M('a_weitao','daili_','DB_DAILI_READ')->query($sql);
        $count = $res[0]['count'];
        $page = new \Think\Page($count,$num);
        $show       = $page->show();
        $this->assign('page',$show);
        $this->assign('count',$count);
        $this->assign('p',$p);
        $sql ="select a.*,b.qudao_name as qudao from daili_a_weitao as a left join daili_a_media as b on a.token=b.token where $w a.token in ($search_token) order by a.ordid asc,add_time desc limit $start,$num";
        $lunbotu = M('a_weitao','daili_','DB_DAILI_READ')->query($sql);
        $this->assign('lunbotu',$lunbotu);
        $this->assign('qudao',$qd);
        $this->assign('user',$this->user);
        $this->display();
    }
    //添加微淘
    public function add_weitao(){
        if(IS_POST){
            $data = I('post.');
            $id = $data['id'];
            $add_items=$data['add_items'];
            
            $data = M('a_weitao')->create($data);
            $text = html_entity_decode(html_entity_decode($data['text']));
            $data['text']=$text;
            $data['update_time']=time();
            $data['isshow']='-1';
            $title = $data['title'];
            if($id){
                $res = M('a_weitao')->save($data);
                if($res){
                    if($add_items==1){
                        $a = array(
                            'id'=>$id,
                            'url'=>'http://'.$_SERVER['HTTP_HOST'].'/Index/page/id/'.$id
                        );
                        M('a_weitao')->save($a);
                    }
                    $arr = array(
                        'code'=>1,
                        'msg' =>'编辑成功'
                    );
                }else{
                    $arr = array(
                        'code'=>0,
                        'msg'=>'编辑失败'
                    );
                }
                $this->ajaxReturn($arr);
            }else{
                $data['add_time']=time();
                $zhuanchang = M('a_weitao')->where('title="'.$title.'"')->find();
                if($zhuanchang){
                    $arr = array(
                        'code'=>0,
                        'msg'=>'已经添加了同名文章了'
                    );
                    $this->ajaxReturn($arr);
                }
                $res = M('a_weitao')->add($data);
                if($res){
                    if($add_items==1){
                        $a = array(
                            'id'=>$res,
                            'url'=>'http://'.$_SERVER['HTTP_HOST'].'/Index/page/id/'.$res
                        );
                        M('a_weitao')->save($a);
                    }
                    $arr = array(
                        'code'=>1,
                        'msg' =>'添加成功'
                    );
                }else{
                    $arr = array(
                        'code'=>0,
                        'msg'=>'添加专场失败'
                    );
                }
                $this->ajaxReturn($arr);
            }
        }else{
            $id = I('id');
            if($id){
                $res = M('a_weitao')->where(array('id'=>$id))->find();
                $this->assign('res',$res);
            }
            $this->display();
        }
    }
    //设置微淘文章通过
    public function tongguo(){
        $id = I('id');
        $isshow=I('isshow');
        if($isshow==1){
            //表示通过
            $d = array(
                'id'=>$id,
                'isshow'=>1
            );
            $r = M('a_weitao')->save($d);
        }else{
            //表示不通过
            $d = array(
                'id'=>$id,
                'isshow'=>0
            );
            $r = M('a_weitao')->save($d);
        }
        if($r){
            $arr = array(
                'code'=>1,
                'msg'=>'操作成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'操作失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //会员页面
    public function huiyuan(){
        $qd = I('qudao');
        if($qd){
            $search_token="'".$qd."'";
        }else{
            $search_token=$this->str_t;
        }
        $this->assign('qudao',$qd);
        $w['_string']="token in($search_token)";
        $res = M('wx_huiyuan_page')->where($w)->select();
        foreach ($res as $key=>$val){
            $media = M('a_media')->where(array('token'=>$val['token']))->find();
            $res[$key]['qudao_name']=$media['qudao_name'];
        }
        $this->assign('res',$res);
        $this->display();
    }
    
}