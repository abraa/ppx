<?php
namespace Home\Controller;
use Think\Controller;
class BaseController extends Controller {
    public $user;
    public $str_t;
    public function _initialize(){
        $user = session('user');
        if(!$user){
            $this->error('请先登录',U('Index/index'));
        }else{
            $this->user=$user;
            //$this->success('已经登录',U('Public/main'));
        }
        $uid = $user['id'];
        //根据用户id查询有权限的媒体
        $sql = "select b.* from daili_b_group_media as a left join daili_a_media as b on a.MediaId=b.ID where a.UID = $uid";
        $q = M('b_group_media')->query($sql);
        foreach ($q as $key=>$val){
            $str_t .= "'".$val['token']."',";
        }
        $str_t = rtrim($str_t,"',");
        if(!$str_t){
            $this->error('还没设置渠道权限');
        }
        $this->str_t=$str_t."'";
        $this->assign('q',$q);
    }
}