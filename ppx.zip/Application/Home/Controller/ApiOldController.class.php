<?php
/**
 * 数据处理控制器
 * */
namespace Home\Controller;
use Think\Controller;
class ApiController extends Controller {
    //private $redis;
    public function _initialize(){
        
        //查询数据库配置项
        $config =   M('a_config')->getField('key,value');
        C($config);
        //连接本地的 Redis 服务
        //$redis = new \Redis();
        //$redis->connect('127.0.0.1', 6379);
        //$this->redis = $redis;
    }
    /*
     * 读取阿里妈妈账号接口
     * @param 
     * 传入参数                 无
     * 输出参数
     * [id] =>      数据ID
     * [name] =>    账号
     * [password] =>密码
     * */
    public function GetAlimama(){
        $res = M('a_alimama')->where(array('Statue'=>1))->select();
        $this->ajaxReturn($res);
    }
    /*
     * 上传Execl表格处理订单数据(第三方推广订单)
     * @param
     * 传入参数
     * id      阿里妈妈账号ID
     * 输出参数
     * count        总订单数
     * success      导入成功数据
     * fail         导入失败数据
     * */
    public function UploadExcel_Third(){
        G('begin');
        $order_obj = M('a_order');
        $shouyi_obj =M('a_shouyi');
        set_time_limit(0);
        $f=file_get_contents("php://input");
        $estr=explode("|\n|",$f);//使用|\n|划分
        $taobao = $estr[3];
        //$taobao = 2;
        if(!$taobao){$arr = array('code'=>0,'msg'=>'请传入ID');$this->ajaxReturn($arr);}
        //$file_name = getcwd().'/Uploads/EXECL/dingdan/sanfang2.xlsx';
        $file_name = getcwd().'/Uploads/EXECL/dingdan/order_all_third_'.$taobao.'.xls';
        $file_name = str_replace('\\','/',$file_name);
        $fp=fopen($file_name,"w+");
        fwrite($fp,$estr[2]);
        $file_size = filesize($file_name);
        $file_size = $estr[1];
        if($file_size>10485760){$res = array('code'=>0,'msg'=>'文件太大');$this->ajaxReturn($res);}
        vendor("PHPExcel");
        $objReader = \PHPExcel_IOFactory::createReader('Excel5');
        $objPHPExcel = $objReader->load($file_name,$encode='utf-8');
    
        $sheet = $objPHPExcel->getSheet(0);
    
        $highestRow = $sheet->getHighestRow(); // 取得总行数
        $highestColumn = $sheet->getHighestColumn(); // 取得总列数
        if($objPHPExcel->getActiveSheet()->getCell('A1')->getValue() != '创建时间'){$res = array( 'code'=>0,'msg'=>'导入失败,导入的EXECL数据不正确' );$this->ajaxReturn($res);}
        for($i=65;$i<91;$i++){
            $arr_A[] = strtoupper(chr($i));
        }
         
        foreach ($arr_A as $val){
            if($highestColumn == 'A'.$val){
                $arr_A[]='A'.$val;
                break;
            }else{
                $arr_A[]='A'.$val;
            }
        }
        //查询数据库中的字段
        $sql = 'SHOW COLUMNS FROM daili_a_order';
        $res = $order_obj->query($sql);
        unset($res[0]);
        foreach ($res as $key=>$val){
            if($arr_A[$key-1]){
                $fields[$arr_A[$key-1]]=$val['field'];
            }
        }
    
        $all_order=array();
        for($i=2;$i<=$highestRow;$i++){
            $data = array();
            foreach($arr_A as $val){
                $value = $objPHPExcel->getActiveSheet()->getCell($val.$i)->getValue();
                if($fields[$val]=='CreateTime' || $fields[$val]=='ClickTime' || $fields[$val]=='CompleteTime'){
                    $value=strtotime($value);
                }
                $data[$fields[$val]] = $value;
            }
            $data['ShouYiStatue']=0;
            $data['AliMaMaID']=$taobao;
            $all_order[]=$data;
            //$this->redis->lpush('all_order_list'.$taobao,serialize($data));
        }
        //$this->redis->set('order_list'.$taobao,serialize($orders));
        //上传成功执行数据插入到数据库
        foreach ($all_order as $key=>$val){
            //$val = unserialize($val);
            $m[$val['OrderNum']][]=$val;
        }
        $success=0;
        foreach ($m as $o=>$p){
            foreach ($p as $i=>$val){
                $num = $i+1;
                $val['Num']=$num;
                //先查询order表中是否有这个订单
                $w = array(
                    //'CreateTime'=>$val['CreateTime'],
                    'Num'=>$val['Num'],
                    'OrderNum'=>$val['OrderNum'],
                    'Pay'=>$val['Pay']
                );
                $res = $order_obj->where($w)->find();
                if($res){
                    if($res['orderstatue'] != '订单结算' && $val['OrderStatue']=='订单结算'){
                        $d = $val;
                        $d['ID']=$res['id'];
                        $order_obj->save($d);//修改订单状态
                        //给用户增加收益
                        //订单修改为结算之后增加用户余额
                        $time = 1505370625;//下单时间大于这个时间的订单结算后余额才会增加
                        if($val['CreateTime']>$time){
                            $orderid = $res['id'];
                            $shouyi = $shouyi_obj->where(array('OrderID'=>$orderid))->find();
                            if($shouyi['uid']){
                                M('wx_user')->where(array('ID'=>$shouyi['uid']))->setInc('YuE',$shouyi['shouyi']);
                            }
                            if($shouyi['shangjiuid']){
                                M('wx_user')->where(array('ID'=>$shouyi['shangjiuid']))->setInc('YuE',$shouyi['shangjishouyi']);
                            }
                            if($shouyi['shangshanguid']){
                                M('wx_user')->where(array('ID'=>$shouyi['shangshangjiuid']))->setInc('YuE',$shouyi['shangshangjishouyi']);
                            }
                            $log = array(
                                'orderid'=>$orderid,
                                'shouyi'=>$shouyi['shouyi'],
                                'shangjishouyi'=>$shouyi['shangjishouyi'],
                                'shangshangjishouyi'=>$shouyi['shangshangjishouyi']
                            );
                            add_file_log('user_add_third',$log);
                        }
                    }
                    if($res['orderstatue'] != '订单失效' && $val['OrderStatue']=='订单失效'){
                        //将原来添加过收益的订单全部变为-1，然后减去用户的收益
                        $data = array(
                            'ID'=>$res['id'],
                            'OrderStatue' => $val['OrderStatue'],
                            'Pay' => $val['Pay'],
                            'XiaoGuoYuGu' => $val['XiaoGuoYuGu'],
                            'JieSuanJinE' => $val['JieSuanJinE'],
                            'YuGuShouRu' => $val['YuGuShouRu'],
                            'YongJinBi' => $val['YongJinBi'],
                            'YongJinJinE' => $val['YongJinJinE'],
                            'BuTieBi' => $val['BuTieBi'],
                            'BuTieJinE' => $val['BuTieJinE'],
                        );
                        $r = $order_obj->save($data);
                        if($r){
                            //根据订单ID查询添加过的收益数据
                            $order_id = $res['id'];
                            $d = array(
                                'ShouYi'=>0,
                                'ShangJiShouYi'=>0,
                                'ShangShangJiShouYi'=>0,
                                'OrderStatue'=>0,
                                'UpdateTime'=>time()
                            );
                            $shouyi_obj->where(array('OrderID'=>$order_id))->save($d);
                        }
                    }
                    add_file_log('all_order_third',$w);
                    continue;
                }else{
                    $orderID = $order_obj->add($val);
                    if($val['OrderStatue']=='订单失效'){
                        $orderstatue=0;
                    }else{
                        $orderstatue=1;
                    }
                    $mediaid = $val['MediaID'];
                    $adid = $val['AdID'];
                    //订单加成功后加收益
                    //根据媒体ID查询媒体配置
                    //$sql = "select b.* from daili_a_media as a left join daili_a_config_copy as b on a.ID=b.MediaID where a.new_media_id = '$mediaid'";
                    //$config = M('a_media')->query($sql);
                    //查询用户信息
                    $sql = "select ID,Pid from daili_wx_user where MediaID ='$mediaid' and AdID='$adid'";
                    $user = M('wx_user')->query($sql);
                    $user = $user[0];
                    if($user['id']){
                        $user_level=get_level($user['id']);
                        $w = array(
                            'UID'=>$user['id'],
                            'OrderID'=>$orderID
                        );
                        $res = $shouyi_obj->where($w)->find();
                        if(!$res){
                            $UID = 0;
                            $shouyi=0;
                            $shangjiUID=0;
                            $shangjishouyi=0;
                            $shangshangjiUID=0;
                            $shangshangjishouyi=0;
                            $shangji_user=array();
                            $shangshangji_user=array();
                            //统计用户收益数据表加收益
                            $UID = $user['id'];
                            //$shouyi = $val['XiaoGuoYuGu']*0.9*($config[0]['shouyibi']/100);
                            $shouyi = $val['XiaoGuoYuGu']*0.9*($user_level['b_level1']/100);
                            
                            if($user['pid']){
                                //查询上级代理用户给上级数据表加收益
                                $shangji_user = M('wx_user')->field('ID,Pid')->where(array('ID'=>$user['pid']))->find();
                                $shangjishouyi=$val['XiaoGuoYuGu']*0.9*($user_level['b_level2']/100);
                                $shangjiUID = $shangji_user['id'];
                                //M('wx_user')->where(array('ID'=>$shangji_user['id']))->setInc('YuE',$shangjishouyi);
                            }
                            if($shangji_user['pid']){
                                //查询上上级代理用户
                                $shangshangji_user = M('wx_user')->field('ID,Pid')->where(array('ID'=>$shangji_user['pid']))->find();
                                $shangshangjishouyi=$val['XiaoGuoYuGu']*0.9*($user_level['b_level3']/100);
                                $shangshangjiUID=$shangshangji_user['id'];
                                //M('wx_user')->where(array('ID'=>$shangshangji_user['id']))->setInc('YuE',$shangshangjishouyi);
                            }
                            $shouyidata = array(
                                'UID'=>$UID,
                                'ShouYi'=>$shouyi,
                                'ShangJiUID'=>$shangjiUID,
                                'ShangJiShouYi'=>$shangjishouyi,
                                'ShangShangJiUID'=>$shangshangjiUID,
                                'ShangShangJiShouYi'=>$shangshangjishouyi,
                                'OrderStatue'=>$orderstatue,
                                'OrderID'=>$orderID,
                                'CreateTime'=>$val['CreateTime']
                            );
                            //添加收益
                            $re = $shouyi_obj->add($shouyidata);
                            if($re){
                                //收益添加成功后修改订单状态
                                $d = array(
                                    'ID'=>$orderID,
                                    'ShouYiStatue'=>1
                                );
                                $order_obj->save($d);
                            }
                            $log = array(
                                'orderid'=>$orderID,
                                'shouyiid'=>$re,
                            );
                            add_file_log('all_order_success',$log);
                        }
                        //计划任务执行的方法不需要输出
                    }
                    $success += 1;
                }
            }
        }
        G('end');
        $arr = array(
            'count'=>$highestRow-1,//总订单数据
            'success'=>$success,    //添加成功
            'time'=>'用时间'.G('begin','end').'秒'         //添加失败
        );
        $this->ajaxReturn($arr);
    }
    /*
     * 上传Execl表格处理订单数据
     * @param
     * 传入参数
     * id      阿里妈妈账号ID
     * 输出参数
     * count        总订单数
     * success      导入成功数据
     * fail         导入失败数据
     * */
    public function UploadExcel(){
        G('begin');
        $order_obj = M('a_order');
        $shouyi_obj =M('a_shouyi');
        set_time_limit(0);
        $f=file_get_contents("php://input");
        $estr=explode("|\n|",$f);//使用|\n|划分
        $taobao = $estr[3];
        if(!$taobao){$arr = array('code'=>0,'msg'=>'请传入ID');$this->ajaxReturn($arr);}
        //$file_name = getcwd().'/Uploads/EXECL/dingdan/TaokeDetail-2017-12-22.xls';
        $file_name = getcwd().'/Uploads/EXECL/dingdan/order_all_'.$taobao.'.xls';
        $file_name = str_replace('\\','/',$file_name);
        $fp=fopen($file_name,"w+");
        fwrite($fp,$estr[2]);
        $file_size = filesize($file_name);
        $file_size = $estr[1];
        if($file_size>10485760){$res = array('code'=>0,'msg'=>'文件太大');$this->ajaxReturn($res);}
        vendor("PHPExcel");
        $objReader = \PHPExcel_IOFactory::createReader('Excel5');
        $objPHPExcel = $objReader->load($file_name,$encode='utf-8');
    
        $sheet = $objPHPExcel->getSheet(0);
    
        $highestRow = $sheet->getHighestRow(); // 取得总行数
        $highestColumn = $sheet->getHighestColumn(); // 取得总列数
        if($objPHPExcel->getActiveSheet()->getCell('A1')->getValue() != '创建时间'){$res = array( 'code'=>0,'msg'=>'导入失败,导入的EXECL数据不正确' );$this->ajaxReturn($res);}
        for($i=65;$i<91;$i++){
            $arr_A[] = strtoupper(chr($i));
        }
         
        foreach ($arr_A as $val){
            if($highestColumn == 'A'.$val){
                $arr_A[]='A'.$val;
                break;
            }else{
                $arr_A[]='A'.$val;
            }
        }
        //查询数据库中的字段
        $sql = 'SHOW COLUMNS FROM daili_a_order';
        $res = $order_obj->query($sql);
        unset($res[0]);
        foreach ($res as $key=>$val){
            if($arr_A[$key-1]){
                $fields[$arr_A[$key-1]]=$val['field'];
            }
        }
        
        $all_order=array();
        for($i=2;$i<=$highestRow;$i++){
            $data = array();
            foreach($arr_A as $val){
                $value = $objPHPExcel->getActiveSheet()->getCell($val.$i)->getValue();
                if($fields[$val]=='CreateTime' || $fields[$val]=='ClickTime' || $fields[$val]=='CompleteTime'){
                    $value=strtotime($value);
                }
                $data[$fields[$val]] = $value;
            }
            $data['ShouYiStatue']=0;
            $data['AliMaMaID']=$taobao;
            $all_order[]=$data;
            //$this->redis->lpush('all_order_list'.$taobao,serialize($data));
        } 
        //$this->redis->set('order_list'.$taobao,serialize($orders));
        //上传成功执行数据插入到数据库
        foreach ($all_order as $key=>$val){
            //$val = unserialize($val);
            $m[$val['OrderNum']][]=$val;
        }
        $success=0;
        foreach ($m as $o=>$p){
            foreach ($p as $i=>$val){
                $num = $i+1;
                $val['Num']=$num;
                //先查询order表中是否有这个订单
                $w = array(
                    'CreateTime'=>$val['CreateTime'],
                    'Num'=>$val['Num'],
                    'OrderNum'=>$val['OrderNum'],
                    'Pay'=>$val['Pay']
                );
                $res = $order_obj->where($w)->count();
                if($res){
                    add_file_log('all_order',$w);
                    continue;
                }else{
                    $orderID = $order_obj->add($val);
                    
                    $mediaid = $val['MediaID'];
                    $adid = $val['AdID'];
                    //订单加成功后加收益
                    //根据媒体ID查询媒体配置
                    //$sql = "select b.* from daili_a_media as a left join daili_a_config_copy as b on a.ID=b.MediaID where a.new_media_id = '$mediaid'";
                    //$config = M('a_media')->query($sql);
                    //查询用户信息
                    $sql = "select ID,Pid from daili_wx_user where MediaID ='$mediaid' and AdID='$adid'";
                    $user = M('wx_user')->query($sql);
                    $user = $user[0];
                    if($val['OrderStatue']=='订单失效'){
                        $orderstatue=0;
                    }else{
                        //订单不失效查询优惠券金额添加的用户省钱字段中
                        
                        $item_info = get_item_infos($val['ItemID'],1);
                        $q_je = $item_info['zk_final_price']*$val['ItemNum']-$val['Pay'];
                        $q_w = array(
                            'ID'=>$user['id']
                        );
                        if($q_je<0){
                            $q_je=0;
                        }
                        M('wx_user')->where($q_w)->setInc('save_money',$q_je);
                        
                        $orderstatue=1;
                    }
                    if($user['id']){
                        $user_level=get_level($user['id']);
                        $w = array(
                            'UID'=>$user['id'],
                            'OrderID'=>$orderID
                        );
                        $res = $shouyi_obj->where($w)->find();
                        if(!$res){
                            $UID = 0;
                            $shouyi=0;
                            $shangjiUID=0;
                            $shangjishouyi=0;
                            $shangshangjiUID=0;
                            $shangshangjishouyi=0;
                            $shangji_user=array();
                            $shangshangji_user=array();
                            //统计用户收益数据表加收益
                            $UID = $user['id'];
                            $shouyi = $val['XiaoGuoYuGu']*0.9*($user_level['b_level1']/100);
                            //M('wx_user')->where(array('ID'=>$user['id']))->setInc('YuE',$shouyi);
                            if($user['pid']){
                                //查询上级代理用户给上级数据表加收益
                                $shangji_user = M('wx_user')->field('ID,Pid')->where(array('ID'=>$user['pid']))->find();
                                $shangjishouyi=$val['XiaoGuoYuGu']*0.9*($user_level['b_level2']/100);
                                $shangjiUID = $shangji_user['id'];
                                //M('wx_user')->where(array('ID'=>$shangji_user['id']))->setInc('YuE',$shangjishouyi);
                            }
                            if($shangji_user['pid']){
                                //查询上上级代理用户
                                $shangshangji_user = M('wx_user')->field('ID,Pid')->where(array('ID'=>$shangji_user['pid']))->find();
                                $shangshangjishouyi=$val['XiaoGuoYuGu']*0.9*($user_level['b_level3']/100);
                                $shangshangjiUID=$shangshangji_user['id'];
                                //M('wx_user')->where(array('ID'=>$shangshangji_user['id']))->setInc('YuE',$shangshangjishouyi);
                            }
                            $shouyidata = array(
                                'UID'=>$UID,
                                'ShouYi'=>$shouyi,
                                'ShangJiUID'=>$shangjiUID,
                                'ShangJiShouYi'=>$shangjishouyi,
                                'ShangShangJiUID'=>$shangshangjiUID,
                                'ShangShangJiShouYi'=>$shangshangjishouyi,
                                'OrderStatue'=>$orderstatue,
                                'OrderID'=>$orderID,
                                'CreateTime'=>$val['CreateTime']
                            );
                            //添加收益
                            $re = $shouyi_obj->add($shouyidata);
                            if($re){
                                //添加收益成功设置用户更改等级
                                set_level($UID);
                                //收益添加成功后修改订单状态
                                $d = array(
                                    'ID'=>$orderID,
                                    'ShouYiStatue'=>1
                                );
                                $order_obj->save($d);
                            }
                            $log = array(
                                'orderid'=>$orderID,
                                'shouyiid'=>$re,
                            );
                            add_file_log('all_order_success',$log);
                        }
                        //计划任务执行的方法不需要输出
                    }
                    $success += 1;
                }
            }
        }
        G('end');
        $arr = array(
            'count'=>$highestRow-1,//总订单数据
            'success'=>$success,    //添加成功
            'time'=>'用时间'.G('begin','end').'秒'         //添加失败
        );
        $this->ajaxReturn($arr);
    }
    /*
     * 上传Execl表格处理订单数据（失效订单数据）
     * @param
     * 传入参数
     * id      阿里妈妈账号ID
     * 输出参数
     * count        总订单数
     * success      导入成功数据
     * fail         导入失败数据
     * */
    
    public function UploadExcelShiXiao(){
        G('begin');
        $order_obj = M('a_order');
        $shouyi_obj =M('a_shouyi');
        set_time_limit(0);
        $f=file_get_contents("php://input");
        $estr=explode("|\n|",$f);//使用|\n|划分
        $taobao = $estr[3];
        //$taobao = 2;
        if(!$taobao){$arr = array('code'=>0,'msg'=>'请传入ID');$this->ajaxReturn($arr);}
        //$file_name = getcwd().'/Uploads/EXECL/dingdan/TaokeDetail-2017-12-25(3).xls';
        $file_name = getcwd().'/Uploads/EXECL/dingdan/order_all_shixiao'.$taobao.'.xls';
        $file_name = str_replace('\\','/',$file_name);
        $fp=fopen($file_name,"w+");
        fwrite($fp,$estr[2]);
        $file_size = filesize($file_name);
        $file_size = $estr[1];
        if($file_size>10485760){$res = array('code'=>0,'msg'=>'文件太大');$this->ajaxReturn($res);}
        vendor("PHPExcel");
        $objReader = \PHPExcel_IOFactory::createReader('Excel5');
        $objPHPExcel = $objReader->load($file_name,$encode='utf-8');
        
        $sheet = $objPHPExcel->getSheet(0);
        
        $highestRow = $sheet->getHighestRow(); // 取得总行数
        $highestColumn = $sheet->getHighestColumn(); // 取得总列数
        if($objPHPExcel->getActiveSheet()->getCell('A1')->getValue() != '创建时间'){$res = array( 'code'=>0,'msg'=>'导入失败,导入的EXECL数据不正确' );$this->ajaxReturn($res);}
        for($i=65;$i<91;$i++){
            $arr_A[] = strtoupper(chr($i));
        }
         
        foreach ($arr_A as $val){
            if($highestColumn == 'A'.$val){
                $arr_A[]='A'.$val;
                break;
            }else{
                $arr_A[]='A'.$val;
            }
        }
        //查询数据库中的字段
        $sql = 'SHOW COLUMNS FROM daili_a_order';
        $res = $order_obj->query($sql);
        unset($res[0]);
        foreach ($res as $key=>$val){
            if($arr_A[$key-1]){
                $fields[$arr_A[$key-1]]=$val['field'];
            }
        }
        
        $all_order=array();
        for($i=2;$i<=$highestRow;$i++){
            $data = array();
            foreach($arr_A as $val){
                $value = $objPHPExcel->getActiveSheet()->getCell($val.$i)->getValue();
                if($fields[$val]=='CreateTime' || $fields[$val]=='ClickTime' || $fields[$val]=='CompleteTime'){
                    $value=strtotime($value);
                }
                $data[$fields[$val]] = $value;
            }
            $data['ShouYiStatue']=0;
            $data['AliMaMaID']=$taobao;
            $all_order[]=$data;
            //$this->redis->lpush('all_order_list'.$taobao,serialize($data));
        }
        //$this->redis->set('order_list'.$taobao,serialize($orders));
        //上传成功执行数据插入到数据库
        foreach ($all_order as $key=>$val){
            //$val = unserialize($val);
            $m[$val['OrderNum']][]=$val;
        }
        $success=0;
        foreach ($m as $o=>$p){
            foreach ($p as $i=>$val){
                $num = $i+1;
                $val['Num']=$num;
                //先查询order表中是否有这个订单
                $w = array(
                    'CreateTime'=>$val['CreateTime'],
                    'Num'=>$val['Num'],
                    'OrderNum'=>$val['OrderNum'],
                    'Pay'=>$val['Pay']
                );
                $a = $order_obj->where($w)->find();
                //判断原来订单是否有效
                //AddwxLog($a,'上传的失效订单到数据库查询对应的订单');
                if($a && $a['orderstatue'] != '订单失效'){
                    $mediaid = $val['MediaID'];
                    $adid = $val['AdID'];
                    //查询用户信息
                    $sql = "select ID,Pid from daili_wx_user where MediaID ='$mediaid' and AdID='$adid'";
                    $user = M('wx_user')->query($sql);
                    $user = $user[0];
                    //订单失效查询优惠券金额减去添加的用户省钱字段中
                    $item_info = get_item_infos($val['ItemID'],1);
                    $q_je = $item_info['zk_final_price']*$val['ItemNum']-$val['Pay'];
                    if($q_je<0){
                        $q_je=0;
                    }
                    $q_w = array(
                        'ID'=>$user['id']
                    );
                    M('wx_user')->where($q_w)->setDec('save_money',$q_je);
                    
                    //将原来添加过收益的订单全部变为-1，然后减去用户的收益
                    $data = array(
                        'ID'=>$a['id'],
                        'OrderStatue' => $val['OrderStatue'],
                        'Pay' => $val['Pay'],
                        'XiaoGuoYuGu' => $val['XiaoGuoYuGu'],
                        'JieSuanJinE' => $val['JieSuanJinE'],
                        'YuGuShouRu' => $val['YuGuShouRu'],
                        'YongJinBi' => $val['YongJinBi'],
                        'YongJinJinE' => $val['YongJinJinE'],
                        'BuTieBi' => $val['BuTieBi'],
                        'BuTieJinE' => $val['BuTieJinE'],
                    );
                    $res = $order_obj->save($data);
                    if($res){
                        //根据订单ID查询添加过的收益数据
                        $order_id = $a['id'];
                        $d = array(
                            'ShouYi'=>0,
                            'ShangJiShouYi'=>0,
                            'ShangShangJiShouYi'=>0,
                            'OrderStatue'=>0,
                            'UpdateTime'=>time()
                        );
                        $shouyi_obj->where(array('OrderID'=>$order_id))->save($d);
                        $success +=1;
                    }
                    add_file_log('shixiao_order',$a);
                }
            }
        }
        G('end');
        $arr = array(
            'count'=>$highestRow-1,
            'success'=>$success,
            'time'=>'用时间'.G('begin','end').'秒',
        );
        $this->ajaxReturn($arr);
    }
    /**
     * 上传结算订单
     * */
    
    public function UploadExcelJieSuan(){
        G('begin');
        $order_obj = M('a_order');
        $shouyi_obj =M('a_shouyi');
        set_time_limit(0);
        $f=file_get_contents("php://input");
        $estr=explode("|\n|",$f);//使用|\n|划分
        $taobao = $estr[3];
        //$taobao = 2;
        if(!$taobao){$arr = array('code'=>0,'msg'=>'请传入ID');$this->ajaxReturn($arr);}
        //$file_name = getcwd().'/Uploads/EXECL/dingdan/TaokeDetail-2017-12-25(3).xls';
        $file_name = getcwd().'/Uploads/EXECL/dingdan/order_all_jiesuan'.$taobao.'.xls';
        $file_name = str_replace('\\','/',$file_name);
        $fp=fopen($file_name,"w+");
        fwrite($fp,$estr[2]);
        $file_size = filesize($file_name);
        $file_size = $estr[1];
        if($file_size>10485760){$res = array('code'=>0,'msg'=>'文件太大');$this->ajaxReturn($res);}
        vendor("PHPExcel");
        $objReader = \PHPExcel_IOFactory::createReader('Excel5');
        $objPHPExcel = $objReader->load($file_name,$encode='utf-8');
        
        $sheet = $objPHPExcel->getSheet(0);
        
        $highestRow = $sheet->getHighestRow(); // 取得总行数
        $highestColumn = $sheet->getHighestColumn(); // 取得总列数
        if($objPHPExcel->getActiveSheet()->getCell('A1')->getValue() != '创建时间'){$res = array( 'code'=>0,'msg'=>'导入失败,导入的EXECL数据不正确' );$this->ajaxReturn($res);}
        for($i=65;$i<91;$i++){
            $arr_A[] = strtoupper(chr($i));
        }
         
        foreach ($arr_A as $val){
            if($highestColumn == 'A'.$val){
                $arr_A[]='A'.$val;
                break;
            }else{
                $arr_A[]='A'.$val;
            }
        }
        //查询数据库中的字段
        $sql = 'SHOW COLUMNS FROM daili_a_order';
        $res = $order_obj->query($sql);
        unset($res[0]);
        foreach ($res as $key=>$val){
            if($arr_A[$key-1]){
                $fields[$arr_A[$key-1]]=$val['field'];
            }
        }
        
        $all_order=array();
        for($i=2;$i<=$highestRow;$i++){
            $data = array();
            foreach($arr_A as $val){
                $value = $objPHPExcel->getActiveSheet()->getCell($val.$i)->getValue();
                if($fields[$val]=='CreateTime' || $fields[$val]=='ClickTime' || $fields[$val]=='CompleteTime'){
                    $value=strtotime($value);
                }
                $data[$fields[$val]] = $value;
            }
            $data['ShouYiStatue']=0;
            $data['AliMaMaID']=$taobao;
            $all_order[]=$data;
            //$this->redis->lpush('all_order_list'.$taobao,serialize($data));
        }
        //$this->redis->set('order_list'.$taobao,serialize($orders));
        //上传成功执行数据插入到数据库
        foreach ($all_order as $key=>$val){
            //$val = unserialize($val);
            $m[$val['OrderNum']][]=$val;
        }
        $success=0;
        foreach ($m as $o=>$p){
            foreach ($p as $i=>$val){
                $num = $i+1;
                $val['Num']=$num;
                //先查询order表中是否有这个订单
                $w = array(
                    'CreateTime'=>$val['CreateTime'],
                    'Num'=>$val['Num'],
                    'OrderNum'=>$val['OrderNum'],
                    'Pay'=>$val['Pay']
                );
                $a = $order_obj->where($w)->find();
                //判断原来订单是否有效
                //AddwxLog($a,'上传的失效订单到数据库查询对应的订单');
                if($a && $a['orderstatue'] != '订单结算'){
                    //修改订单状态为结算
                    $res = $order_obj->where(array('ID'=>$a['id']))->save($val);
                    if($res){
                        //订单修改为结算之后增加用户余额
                        $time = 1505370625;//下单时间大于这个时间的订单结算后余额才会增加
                        if($val['CreateTime']>$time){
                            $orderid = $a['id'];
                            $shouyi = $shouyi_obj->where(array('OrderID'=>$orderid))->find();
                            if($shouyi['uid']){
                                M('wx_user')->where(array('ID'=>$shouyi['uid']))->setInc('YuE',$shouyi['shouyi']);
                            }
                            if($shouyi['shangjiuid']){
                                M('wx_user')->where(array('ID'=>$shouyi['shangjiuid']))->setInc('YuE',$shouyi['shangjishouyi']);
                            }
                            if($shouyi['shangshanguid']){
                                M('wx_user')->where(array('ID'=>$shouyi['shangshangjiuid']))->setInc('YuE',$shouyi['shangshangjishouyi']);
                            }
                            $log = array(
                                'orderid'=>$a['id'],
                                'shouyi'=>$shouyi['shouyi'],
                                'shangjishouyi'=>$shouyi['shangjishouyi'],
                                'shangshangjishouyi'=>$shouyi['shangshangjishouyi']
                            );
                            add_file_log('user_add',$log);
                        }
                        $success +=1;
                    } 
                    add_file_log('jiesuan_order',$a);
                }
            }
        }
        G('end');
        $arr = array(
            'count'=>$highestRow-1,
            'success'=>$success,
            'time'=>'用时间'.G('begin','end').'秒',
        );
        $this->ajaxReturn($arr);
    }
    /**
     * 新的获取需要创建推广位的用户和媒体位
     * **/
    public function GetTuiGuanWei(){
        //查询阿里妈妈账号
        $alimama = M('a_alimama')->where(array('Statue'=>1))->select();
        foreach ($alimama as $key=>$val){
            $a['name']=$val['name'];
            $a['pass']=$val['password'];
            $w = array('new_alimama_id'=>$val['id']);
            $media = M('a_media')->where($w)->select();
            $b=array();
            foreach ($media as $key_media=>$val_media){
                $b[$key_media]['id']=$val_media['id'];
                $b[$key_media]['name']=$val_media['nick_name'];
                $b[$key_media]['zhanghao']=$val_media['name'];
                $b[$key_media]['MediaID']=$val_media['new_media_id'];
                //查询这个媒体下面还没有创建推广位的用户
                $w = array(
                    'Statue'=>array('in','-1'),
                    'TgwID'=>array('exp', 'is null'),
                    'GzhToken'=>$val_media['token'],
                );
                $res = M('wx_user')->field('id,name,phone')->where($w)->select();
                $table = 'wx_user_'.$val['id'];
                $user = array();
                foreach ($res as $k=>$v){
                    //查询需要创建推广位的用户
                    $r = M($table)->where(array('uid'=>$v['id']))->find();
                    if(!$r){
                        $user[$k]=$v;
                    }
                }
                $b[$key_media]['user']=array_values($user);
            }
            $a['media']=$b;
            $data[$key]=$a;
        }
        $this->ajaxReturn($data);
    }
    public function UpdateMediaStatue(){
        $id = I('id');
        $mediaid=I('mediaid');
        $data = array(
            'id'=>$id,
            'new_media_id'=>$mediaid,
        );
        $res = M('a_media')->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'修改成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    
    /**
     * 生成推广位成功修改用户推广位ID
     * @param
     * id       用户ID（GetTuiGuanWei接口返回的推广位数据库ID）
     * tgwid    阿里妈妈后台生成的推广位ID例如mm_116133360_21496586_72144353
     * medianame阿里妈妈后台生成的媒体位名称
     * tgwname  阿里妈妈后台生成的推广位名称
     * */
    public function UpdateTuiGuanWei(){
        $id = I('id');
        $user =M('wx_user')->field('ID,Pid,Phone,OpenID,GzhToken,MediaID,Statue,username,password')->where(array('ID'=>$id))->find();
        $statue = $user['statue'];
        $token = $user['gzhtoken'];
        $tgwid=I('tgwid');
        $arr = explode('_',$tgwid);
        $medianame=urldecode(I('medianame'));
        $tgwname  =urldecode(I('tgwname'));
        $username = $user['username'];
        $password = $user['password'];
        //根据公众号token查询媒体信息
        $media=M('a_media')->field('id,short_name')->where(array('token'=>$token))->find();
        $f=$media['short_name'];
        
        if($statue==-1){
            if($username && $password){
                $data = array(
                    'ID'=>$id,
                    'TgwID'=>$tgwid,
                    'MediaID'=>$arr[2],
                    'MediaName'=>$medianame,
                    'AdID'=>$arr[3],
                    'AdName'=>$tgwname,
                    'Statue'=>1,
                    'invitation_code'=>set_invitation_code(),
                );
            }else{
                $data = array(
                    'ID'=>$id,
                    'TgwID'=>$tgwid,
                    'MediaID'=>$arr[2],
                    'MediaName'=>$medianame,
                    'AdID'=>$arr[3],
                    'AdName'=>$tgwname,
                    'Statue'=>1,
                    'invitation_code'=>set_invitation_code(),
                    'username'=>$f.$user['phone'],
                    'password'=>$arr[2]
                );
            }
            $res=M('wx_user')->save($data);
            if($res){
                //申请成功给用户发模板消息
                //根据用户id查询token
                $sql = "select b.*,a.yuming from daili_a_media as a left join daili_a_config_copy as b on a.ID=b.MediaID where a.token='".$token."'";
                $config = M('a_media')->query($sql);
                //用户通过代理审核查询用户是否有上级代理有就加奖励
                if($user['pid']){
                    $yaoqingmax = $config[0]['yaoqingmax'];//最大邀请值
                    //查询用户已经邀请的用户数量
                    $yaoqingcount = M('b_jiangli')->where(array('UID'=>$user['pid']))->count();
                    if($yaoqingcount<$yaoqingmax){
                        $jiangli=array(
                            'UID'=>$user['pid'],
                            'XiaJiUID'=>$user['id'],
                            'Money'=>$config[0]['yaoqingjiangli'],
                            'Time'=>time()
                        );
                        M('wx_user')->where(array('ID'=>$user['pid']))->setInc('YuE',$config[0]['yaoqingjiangli']);
                        M('b_jiangli')->add($jiangli);
                    }
                }
                $arr = array(
                    'code'=>1,
                    'msg'=>'修改成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'修改失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $arr = array(
                'code'=>1,
                'msg'=>'已经是代理了'
            );
            $this->ajaxReturn($arr);
        }
    }
   
    /*
     * 查询最后更新优惠券的商品500条
     * */
    public function get_yhq_items(){
        $items = M('a_items')->field('id,youhuiquan,num_iid')->order('coupon_update_time asc,id asc')->limit(0,500)->select();
        $this->ajaxReturn($items);
    }
    /**
     * 转链接并获取佣金比和计算分成金额
     * */
    public function GetItems(){
        //查询所有阿里妈妈账号
        $res = M('a_alimama')->field('ID')->where(array('Statue'=>1))->order('id asc')->select();
        $str_id = '';
        foreach ($res as $key=>$val){
            $str_id .= $val['id'].',';
        }
        $str_id = rtrim($str_id,',');
        //查询未转链接的数据
        
        $map['daili_url_statue'] = array(
            array('neq',$str_id),
            array('EXP','is null'),
            'or'
        );
        $res = M('a_items')->field('id,num_iid,youhuiquan,daili_url_statue')->where($map)->order('id desc')->limit(0,500)->select();
        
        $result['login_user']='余晚桥 ';
        $result['login_password']='qiao@li131';
        $result['media']='DailiSystem代理系统媒体位';
        $result['zhanghao']='yu_wanqiao';
        $result['tgw']='admin';
        foreach ($res as $key=>$val){
            $res[$key]['num_iid']=str_replace(' ','',$val['num_iid']);
        }
        $result['res']=$res;
        $this->ajaxReturn($result);
    }
    /**
     * 修改商品转换后的链接
     * @apram
     * id   数据库id
     * daili_url 转完链接后的URL
     * */
    public function UpdateUrl(){
        $id = I('id');
        $statue = I('statue');
        if($statue==9){
            $res = M('a_items')->delete($id);
            $arr = array(
                'code'=>1,
                'msg'=>'商品下架成功'
            );
            $this->ajaxReturn($arr);
        }
        $commission_rate=I('commission_rate');
        $daili_url = urldecode(I('daili_url'));
        $daili_url_statue = urldecode(I('alimama_id'));
      
        if(!$id || !$daili_url || !$daili_url_statue){
            $arr = array('code'=>0,'msg'=>'参数错误');
            $this->ajaxReturn($arr);
        }
        
        //先查询商品的daili_url_statue
        $res = M('a_items')->field('id,daili_url_statue,coupon_price')->where(array('id'=>$id))->find();
        
        $statue = $res['daili_url_statue'];
        $str =trim($statue.','.$daili_url_statue,',');
        $arr = explode(',',$str);
        sort($arr);
        $str = implode(',',$arr);
        $data = array(
            'id'=>$id,
            'daili_url'=>str_replace('amp;','',$daili_url),
            'daili_url_statue'=>trim($str,','),
            'commission_rate'=>$commission_rate*10000,
            'daili_shouru'=>floor($res['coupon_price']*$commission_rate*0.9*(C('five')/100))/100
        );
        $res = M('a_items')->save($data);
        if($res){
            $arr=array(
                'code'=>1,
                'msg'=>'转链接修改成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'转链接修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }

    public function update_pic_url(){
        $page_num = M('a_items_copy')->count();
        $page_nums  = ceil($page_num/100);
        for($i=1;$i<=$page_nums;$i++){
            $info = M('a_items_copy')->page($i,100)->order('id desc')->select();
            foreach($info as $k=>$v){
                $res = explode('http',$v['pic_url']);
                if(!empty($res[2])){
                    M('a_items_copy')->where(array('id'=>$v['id']))->save(array(
                        'pic_url'=>'http'.$res[2]
                    ));
                }
            }
            sleep(1);
        }

        echo   "执行完毕";
        exit;
    }
    //根据商品ID获取商品信息
    public function get_item_info(){
        $id = I('num_iid');
        $res = get_item_infos($id,1);
        $pic = $res['small_images']['string'];
        if(!is_array($pic)){
            $res['small_images']['string']=array($pic);
        }
        $this->ajaxReturn($res);
    }
    public function img_upload(){
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize   =     3145728 ;// 设置附件上传大小
        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->savePath  =      '/ITEM_IMG/'; // 设置附件上传目录
        // 上传文件
        $info   =   $upload->uploadOne($_FILES['image']);
        if(!$info){
            $res = array(
                'code'=>0,
                'msg'=>'上传失败'
            );
            $this->ajaxReturn($res);
        }else{
            //$data = $info['savename'];
            //$local_path = getcwd()."/Uploads".$info['savepath'].$info['savename'];
            //$local_path = str_replace('\\','/',$local_path);
            //$image = new \Think\Image();
            //$image->open($local_path);// 生成一个固定大小为150*150的缩略图并保存为thumb.jpg
            //$name_arr = explode('.',$info['savename']);
            //$name_str = $name_arr[0].'_thumb'.'.'.$name_arr[1];
            //$image->thumb(400, 400)->save(getcwd().'/Uploads'.$info['savepath'].$name_str);
            //$local_path = getcwd().'/Uploads'.$info['savepath'].$name_str;
            //$local_path = str_replace('\\','/',$local_path);
            //$success = $this->ftp_upload($info['savepath'],$name_str,$local_path);
            //$file_path = 'http://img.baicaibuy.cn/Uploads'.$info['savepath'].$name_str;
            $file_path = 'http://home.taokehelp.cn/Uploads'.$info['savepath'].$info['savename'];
    
            //if($success['code']){
            $res = array(
                'code'=>1,
                'msg'=>'上传成功',
                'img_url'=>$file_path,
            );
            //}else{
            //    $res = array(
            //        'code'=>0,
            //       'msg'=>'上传失败'.$success['msg'],
            //    );
            //}
            $this->ajaxReturn($res);
        }
    }
    //统计app的激活量
    public function tongji_jihuo(){
        $platform = I('platform');
        $sys_version = I('sys_version');
        $equipment_id    = I('equipment_id');
        $phone_models    = I('phone_models');
        $app_version     = I('app_version');
        $application_name= I('application_name');
        $app_channel     = I('app_channel');
        $is_wifi         = I('is_wifi');
        $package_name    = I('package_name');
        $ip_address = get_client_ip();
        import('Org.Net.IpLocation');// 导入IpLocation类
        $Ip = new \IpLocation('UTFWry.dat'); // 实例化类 参数表示IP地址库文件
        $area = $Ip->getlocation($ip_address); // 获取某个IP地址所在的位置
        //echo '<pre>';
        //print_r($area);exit;
        $ip_city = $area['country'];
        $data = array(
            'platform'=>$platform,
            'sys_version'=>$sys_version,
            'equipment_id'   =>$equipment_id,
            'phone_models'   =>$phone_models,
            'app_version'    =>$app_version,
            'application_name'=>$application_name,
            'app_channel'    =>$app_channel,
            'is_wifi'        =>$is_wifi,
            'ip_address'     =>$ip_address,
            'ip_city'        =>$ip_city,
            'package_name'   =>$package_name,
            'add_time'       =>time()
        );
        $where = array(
            'platform'=>$platform,
            'equipment_id'=>$equipment_id,
            'package_name'=>$package_name
        );
        $res = M('app_tongji_jihuo')->where($where)->find();
        if(!$res){
            $res = M('app_tongji_jihuo')->add($data);
        }
        $data1 = array(
            'platform'=>$platform,
            'equipment_id'=>$equipment_id,
            'package_name'=>$package_name,
            'is_wifi'=>$is_wifi,
            'start_time'=>time(),
        );
        $res1 =M('app_tongji_zaixian')->add($data1);
        if($res && $res1){
            $arr = array(
                'code'=>1,
                'msg'=>'添加成功',
                'id'=>$res1
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg' =>'添加失败'
            );
        }
        echo json_encode($arr);
    }
    //统计在线的时常
    public function tongji_zaixian(){
        
        $equipment_id    = I('equipment_id');
        $package_name    = I('package_name');
        $id              = I('id');
        $is_wifi         = I('is_wifi');
        $data = array(
            'equipment_id'=>$equipment_id,
            'pachage_name'=>$package_name,
            'end_time'=>time()
        );
        $res = M('app_tongji_zaixian')->where('id='.$id)->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'调用成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg' =>'调用失败'
            );
        }
        echo json_encode($arr);
    }
    //APP调用的发圈商品列表
    public function faquan_items(){
        $p    = I('page',1);
        $code = I('code');
        $res = S('faquan_item'.$code.$p);
        if(!$res){
            //根据code查询用户信息
            $user = M('wx_user')->field('GzhToken,TgwID,username')->where(array('invitation_code'=>$code))->find();
            if($user['gzhtoken']=='gh_26c51afe50df' || $user['gzhtoken']=='chuankeyouhui2' || $user['gzhtoken']=='gh_b676e24225c8'){
                //根据token查询用户ID
                $u = M('user')->field('id')->where(array('token'=>'gh_26c51afe50df'))->select();
            }else{
                $u = M('user')->field('id')->where(array('token'=>'gh_90c6882faaf9'))->select();
            }
            foreach ($u as $key=>$val){
                $uid .= $val['id'].',';
            }
            //查询渠道配置信息
            $token = $user['gzhtoken'];
            $sql = "select a.* from daili_a_config_copy as a left join daili_a_media as b on a.MediaID=b.id where b.token='$token'";
            $media = M('a_config_copy')->query($sql);
            $shouyibi = $media[0]['shouyibi'];
            $uid = rtrim($uid,',');
            $num = 5;
            $start = ($p-1)*$num;
            $time = 12*3600;
            $sql = "select * from daili_wx_faquan where uid in ($uid) order by add_time desc limit $start,$num";
            $res = M('wx_faquan')->query($sql);
            foreach ($res as $key=>$val){
                //判断有没有口令
                if(empty($val['tj_reson'])){
                    $text = $val['title'];
                }else{
                    $text = $val['tj_reson'];
                }
                $res[$key]['title']=json_decode($val['title']);
                $replay = json_decode($val['replay']);
                //查询淘口令
                $k = M('wx_faquan_kouling')->where(array('table_id'=>$val['id'],'item_id'=>$val['num_iid'],'pid'=>$user['tgwid']))->order('add_time desc')->find();
                if(!$k['kouling'] || ($k['kouling'] && (time()-$k['add_time']>$time))){
                    $r = $this->app_zhuanlian($val['id'],$val['num_iid'],$val['youhuiquan'],$user['tgwid'],$user['token'],$text,$user['username'],$val['title'],$val['pic']);
                    $res[$key]['b_kouling']=$r['kouling'];
                    $res[$key]['b_ehy_url']=$r['ehy_url'];
                    $res[$key]['b_short_url']=$r['short_url'];
                    $res[$key]['b_pid']=$val['b_pid'];
                    $res[$key]['b_add_time']=time();
                    $commission_rate=$r['commission_rate'];
                    $kouling = $r['kouling'];
                }else{
                    $res[$key]['b_kouling']=$k['kouling'];
                    $res[$key]['b_ehy_url']=$k['ehy_url'];
                    $res[$key]['b_short_url']=$k['short_url'];
                    $res[$key]['b_pid']=$k['pid'];
                    $res[$key]['b_add_time']=$k['add_time'];
                    $commission_rate=$k['commission_rate'];
                    $kouling = $k['kouling'];
                }
                $qudao_shouyi=($shouyibi/100)*0.9*$val['price']*($commission_rate/100);
                if(strpos($replay,'【淘口令】')){
                    $replay = str_replace('【淘口令】',$kouling,$replay);
                }else{
                    $replay .= $kouling;
                }
                $res[$key]['pic']=explode(',',rtrim($val['pic'],','));
                
                $a=array(
                    $replay,$val['tj_reson']
                );
                $res[$key]['replay']=array_filter($a);
                $qudao = M('user')->where(array('id'=>$val['uid']))->find();
                $res[$key]['qudao_name']=$qudao['name'];
                $res[$key]['qudao_pic']=$qudao['pic'];
                $res[$key]['qudao_shouyi']=round($qudao_shouyi,2);
            }
        }
        $this->ajaxReturn($res);
    }
    //内部调用转链接口
    /**
     * $num_iid     商品ID
     * $quan        商品优惠券
     * $pid         推广位id
     * $token       公众号token
     * $text        推荐理由
     * $account     账号
     * taobao_tbk_privilege_get_daili   转高佣链接接口
     * taobao_tbk_data_report           上行日志接口
     * */
    private function app_zhuanlian($id,$itemid,$quan,$pid,$token,$text,$account,$title,$pic){
        $arr_pid = explode('_',$pid);
        $adzone_id = $arr_pid[3];
        $site_id   = $arr_pid[2];
        $quan=urlencode($quan);
        $url = "http://api.olivecloud.cn/index/taobao_tbk_privilege_get_daili?youhuiquan=$quan&item_id=$itemid&adzone_id=$adzone_id&site_id=$site_id";
        $res = curl_get($url);
        $click_url = $res['coupon_click_url'];
        $commission_rate = $res['max_commission_rate'];
        if($click_url){
            $tbkurl=urlencode($click_url);
            $url = str_replace('http://','https://',$click_url);
            //获取短连接
            $url = "http://dwz.olivecloud.cn/tkbGetDWZ?url=".urlencode($url)."&itemid=$itemid";
            $shorturl_arr = curl_get($url);
            $shorturl = $shorturl_arr['msg'];
            $taokouling  = $shorturl_arr['kouling'];
            $tkl = urlencode($taokouling);
            if(!$shorturl){
                $arr = array('code'=>0,'msg'=>'生成短网址失败');
                return $arr;
            }
            $commission = $res['max_commission_rate'];
            //调用上行日志接口
            $report_api ="http://api.olivecloud.cn/index/taobao_tbk_data_report?";
            $report_api .="tbkurl=$tbkurl&";
            $report_api .="token=$token&";
            $report_api .="itemid=$itemid&";
            //$report_api .="text=&";
            $report_api .="kouling=$tkl&";
            $report_api .="account=$account&";
            $report_api .="pid=$pid";
            //echo $report_api;exit;
            curl_get($report_api);
            $d = array(
                'item_id'=>$itemid,
                'pid'=>$pid,
                'kouling'=>$taokouling,
                'ehy_url'=>$click_url,
                'add_time'=>time(),
                'short_url'=>$shorturl,
                'table_id'=>$id,
                'commission_rate'=>$commission_rate
            );
            M('wx_faquan_kouling')->add($d);
            return $d;
        }else{
            $d = array(
                'code'=>0,
                'msg'=>'转链接失败'
            );
            return $d;
        }
    }
    //查询僵尸代理
    public function del_daili_list(){
        $url ="https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQGV8TwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyYkZQb05UbDFmNmgxMDAwMGcwM3cAAgSQsxtaAwQAAAAA";
        $res = file_get_contents($url);
        $imgDir = str_replace('\\','/',getcwd()).'/Uploads/haibao_qrcode/qrcode/';
        //要生成的图片名字
        $filename = time().".png"; //新图片名称
        $newFilePath = $imgDir.$filename;
        $data = $res;
        $newFile = fopen($newFilePath,"w"); //打开文件准备写入
        fwrite($newFile,$data); //写入二进制流到文件
        fclose($newFile); //关闭文件
        $qrcode_url=$newFilePath;
        $qrcode_url="http://home.taokehelp.cn/Uploads/haibao_qrcode/qrcode/".$filename;
        $url ="http://wx.qlogo.cn/mmopen/avicdpaNXLJs5gTj77mEh27F4TrffjbGE4lEe6ywniacRCB1Gc2Vyv2drSWKA2ed4McC5K4930lp3y7FGQSR0swWrAzEcxfwsa/0";
        $res = file_get_contents($url);
        $imgDir = str_replace('\\','/',getcwd()).'/Uploads/haibao_qrcode/headpic/';
        //要生成的图片名字
        $filename = time().".png"; //新图片名称
        $newFilePath = $imgDir.$filename;
        $data = $res;
        $newFile = fopen($newFilePath,"w"); //打开文件准备写入
        fwrite($newFile,$data); //写入二进制流到文件
        fclose($newFile); //关闭文件
        $pic = "http://wx.qlogo.cn/mmopen/avicdpaNXLJs5gTj77mEh2z3ebf2Vl86iaE8mA1X28DW9cedjQAvV9aAUN6bTiaRSt9oILgCjP4r8K69IgwIBCNmNJPNr6UiaD7u/0";
        //$pic = $newFilePath;
        $pic="http://home.taokehelp.cn/Uploads/haibao_qrcode/headpic/".$filename;
        $nickname="测试";
        $uid=2;
        //$qrcode_url="https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQGV8TwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyYkZQb05UbDFmNmgxMDAwMGcwM3cAAgSQsxtaAwQAAAAA";
        set_pic_src($pic,$nickname,$qrcode_url,$uid);
        exit;
        $w = array(
            'Statue'=>1,
            'Time'=>array('between',array(1483200000,time()-3600*240))
        ); 
    }
    //同步微博商品到直播商品中
    public function zhibo_sync_items(){
        //查询所有的媒体渠道
        $qudao = M('a_media')->field('id,qudao_name,token')->select();
        foreach ($qudao as $key=>$val){
            $token = $val['token'];
            $file = getcwd().'/Application/Home/Conf/'.$token.'_server_conf.php';
            $config = include($file);
            $start=$config['start_time'];
            $end  =$config['end_time'];
            $space=$config['space_time'];
    
            //计算两个小时需要商品数量
            $num = ceil(7200/$space);
            //查询商品
            $qudao_str = '('.$val['qudao_name'].')';
            $w=array(
                //'coupon_price'=>array('gt',50),
                'shop_type'=>'B',
                'to_zhibo'=>array('notlike','%'.$qudao_str.'%')
            );
            $field="id,num_iid,title,pic_url,price,volume,coupon_price,item_url,add_time,youhuiquan,youhuiquan_je,recommend_reason,movie_url,to_zhibo";
            $obj_table=M('a_zhibo_items_copy');
            $res = $obj_table->field($field)->where($w)->order('add_time desc,volume desc')->limit(0,$num)->select();
            if(!$res){
                $w=array(
                    //'coupon_price'=>array('gt',50),
                    //'shop_type'=>'B',
                    'to_zhibo'=>array('notlike','%'.$qudao_str.'%')
                );
                $obj_table=M('a_items');
                $res = $obj_table->field($field)->where($w)->order('add_time desc,volume desc')->limit(0,$num)->select();
            }
            foreach ($res as $k=>$v){
                //查找直播商品最后一条数据发布时间
                $w = array(
                    'token'=>$val['token']
                );
                $i = M('a_zhibo_items')->where($w)->order('send_time desc')->find();
                if($i){
                    $send_time=$i['send_time']+$space;
                }else{
                    $send_time=time()+$space;
                }
                $h = date('H',$send_time);
                if($end>$start){
                    if($h<$start){
                        $send_time=strtotime(date('Y-m-d',$send_time))+$start*3600;
                    }
                    if($h>$end){
                        $send_time=strtotime(date('Y-m-d',$send_time))+($start+24)*3600;
                    }
                }else{
                    if($h>$end && $h<$start){
                        $send_time=strtotime(date('Y-m-d',$send_time))+$start*3600;
                    }
                }
                if($send_time>=time()+7200){
                    break;
                }
                $id = $v['id'];
                unset($v['id']);
                $v['token']=$val['token'];
                $v['send_time']=$send_time;
                //添加到直播数据表
                $r=M('a_zhibo_items')->data($v)->add();
                if($r){
                    $str_tozhibo = trim($val['to_zhibo'].','.$qudao_str,',');
                    $d = array(
                        'id'=>$id,
                        'to_zhibo'=>$str_tozhibo,
                    );
                    $obj_table->save($d);
                }
            }
        }
    }
    //APP端上传用户头像
    public function uploadimg(){
        $code=I('code');
        $photo=I('photo');
        $user=M('wx_user');
        $exist=$user->where(array('invitation_code'=>$code))->find();
        if(empty($exist)){
            $arr = array(
                'code'=>0,
                'msg'=>'code参数错误'
            );
            $this->ajaxReturn($arr);
        }
        $time=time();
        $file=getcwd()."/Uploads/user_imgs/$code"."_"."$time.jpg";
        $url = 'http://'.$_SERVER['HTTP_HOST']."/Uploads/user_imgs/$code"."_"."$time.jpg";
        $img=base64_decode($photo);
        $a=file_put_contents($file, $img);
        if($a){
            $d=array(
                'ID'=>$exist['id'],
                'HeaderPic'=>$url,
            );
            $res = M('wx_user')->save($d);
            if($res){
                $arr = array(
                    'code'=>1,
                    'img_path'=>$url,
                    'msg'=>'上传成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'上传失败'
                );
            }
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'图片上传失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    public function test(){
        $data = array(
            'url'=>'https://mos.m.taobao.com/activity_newer?from=tool&sight=yhly&pid=mm_121956448_23084993_76582704',
            'title'=>'超级好货0元购',
            'logo'=>'https://gw.alicdn.com/tfs/TB1fHQlXDtYBeNjy1XdXXXXyVXa-750-351.png'
        );
        $res = taokouling_new($data);
        echo '<pre>';
        print_r($res);exit;
        $item_id=I('id');
        Vendor(C('Vendor_file_new'));
        $c = new \TopClient;
        $c->appkey = C('TB_appid_new');//优惠乐园3294401375@qq.com账号的淘宝开放平台
        $c->secretKey = C('TB_appsecret_new');
      
        $req = new \TbkItemInfoGetRequest;
        if($type){
            $req->setFields("num_iid,title,pict_url,small_images,reserve_price,zk_final_price,user_type,provcity,item_url,seller_id,volume,nick");
        }else{
            $req->setFields("num_iid,title,pict_url,small_images,item_url");
        }
        $req->setPlatform("1");
        $req->setNumIids($item_id);
        $resp = $c->execute($req);
        $resp = obj_to_arr($resp);
        //$resp = $resp['results'];
        echo '<pre>';
        print_r($resp);
    }
}