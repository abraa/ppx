<?php
namespace Home\Controller;
use Think\Controller;
class PublicController extends Controller {
    private $user;
    public function _initialize(){
        //判断用户是否登录
        $user = $_SESSION['user'];
        if(!$user){
            $this->error('请先登录',U('Index/index'));
        }else{
            $this->user = $user;
        }
    }
    public function top(){
        $user = $this->user;
        $this->assign('user',$user);
        $this->display();
    }
    public function left(){
        $user = $this->user;
        $uid = $user['id'];
        //查询一级菜单
        $sql = "select b.* from daili_b_group_caidan as a left join daili_b_menu as b on a.MenuID=b.id where a.UID=$uid and a.MenuPID=0 order by b.id asc";
        $caidan = M()->query($sql);
        $res_caidan = array(
            'name' => '首页',
            'second' => Array(
                '-1' => Array(
                    'name' => '系统首页',
                    'url' => U('Project/index')
                ),
                '0' =>  Array(
                    'name'=>'修改密码',
                    'url' => U('Project/update_pass')    
                ),
            )
        );
        foreach ($caidan as $key=>$val){
            //查询二级菜单
            $pid = $val['id'];
            $sql = "select b.* from daili_b_group_caidan as a left join daili_b_menu as b on a.MenuID=b.id where a.UID=$uid and a.MenuPID=$pid order by b.id asc";
            $res = M('b_group_caidan')->query($sql);
            foreach ($res as $key_1=>$val_1){
                $res[$key_1]['url']=U($val_1['controller'].'/'.$val_1['action']);
            }
            $caidan[$key]['second']=$res;
        }
        $this->assign('shouye',$res_caidan);
        $this->assign('menu',$caidan);
        $this->display();
    }
    public function main(){
        $url = U('Project/index');
        $this->assign('url',$url);
        $this->display();
    }
}