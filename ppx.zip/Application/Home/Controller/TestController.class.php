<?php
/**
 * 数据处理控制器
 * */
namespace Home\Controller;
use Think\Controller;
class TestController extends Controller {
    private $api_url="http://api.olivecloud.cn";
    //获取订单列表
    public function order(){
        //查询9月份订单
        $sql = "select sum(XiaoGuoYuGu) from daili_a_order where CreateTime between 1504195200 and 1506787199";
        $res = M('a_order')->query($sql);
        echo '<pre>';
        print_r($res);
        echo '<hr>';
        $w['CreateTime']=array('between',array(1504195200,1506787199));
        $res = M('a_order')->field('ID,OrderNum')->where($w)->select();
        foreach ($res as $key=>$val){
            $arr[$val['ordernum']][]=$val;
        }
        echo '<pre>';
        print_r($arr);
    }
    //测试搜索
    public function search(){
        //用于关键词搜索
        $key = str_replace("\n","",I('key'));
        $search = A('Home/UseXs');
        $sorts=1;
        $page = 1;
        $ress  = $search->search_items($key,$sorts,$page);
        echo '<pre>';
        print_r($ress);exit;
        $api_url = $this->api_url."/Index/search_test.html?page=%s&sort=%s&key=%s";
        /* $api_url = $this->api_url."/Index/taobao_tbk_sc_material_optional.html?key=$key";
        $res = file_get_contents($api_url);
        $res = json_decode($res,true);
        echo '<pre>';
        print_r($res); */
        switch ($sorts){
            case 1:
                $sorts_="price_asc";
                break;
            case 2:
                $sorts_="total_sales_desc";
                break;
            case 3:
                $sorts_="tk_total_sales_desc";
                break;
        }
        $res = vget(sprintf($api_url,$page,$sorts_,$key));
        $res = json_decode($res,true);
        //$ress['items']=$res;
        echo '<pre>';
        print_r($res);
    }
    //
    public function code(){
        echo set_invitation_code();
    }
}