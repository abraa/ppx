<?php
namespace Home\Controller;
use Think\Controller;
class KefuController extends Controller {
    private $user;
    public function _initialize(){
        $user = session('user');
        if(!$user){
            $this->error('请先登录',U('Index/index'));
        }else{
            //查询数据库配置项
            $config =   M('a_config')->getField('key,value');
            C($config);
            $this->user = $user;
        }
    }
    //阿里妈妈账号列表
    public function alimama_list(){
        $user = $this->user;
        $uid = $user['id'];
        //根据用ID查询有权限的阿里妈妈
        
        $p = I('p',1);
        $num = 20;
        $start = ($p-1)*$num;
        $User = M('z_kefu_alimama_new'); // 实例化User对象
        //$count      = $User->count();// 查询满足要求的总记录数
        $sql = "select count(*) as count from daili_z_kefu_alimama_new as a left join daili_z_kefu_group as b on a.id=b.alimamaid where b.uid=$uid";
        $count = $User->query($sql);
        $count = $count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        //$list = $User->order('addtime desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        $sql        = "select a.* from daili_z_kefu_alimama_new as a left join daili_z_kefu_group as b on a.id=b.alimamaid where b.uid=$uid order by id desc limit $start,$num";
        $list=$User->query($sql);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('uid',$uid);
        $this->display();
    }
    /**
     * 添加阿里妈妈账号
     * */
    public function add_alimama(){
        if(IS_POST){
            $data = I('post.');
            $id = $data['id'];
            if($id){
                $res = M('z_kefu_alimama_new')->save($data);
                if($res){
                    //修改公众号内的对应的阿里妈妈账号
                    $gzh = M('z_kefu_gzh')->where(array('alimama_id'=>$id))->select();
                    foreach ($gzh as $key=>$val){
                        $d = array(
                            'id'=>$val['id'],
                            'alimama_name'=>$data['name']
                        );
                        M('z_kefu_gzh')->save($d);
                    }
                    $this->success('编辑成功');
                }else{
                    $this->error('编辑失败');
                }
            }else{
                unset($data['id']);
                $data['addtime']=time();
                $res = M('z_kefu_alimama_new')->add($data);
                if($res){
                    $this->success('添加成功');
                }else{
                    $this->error('添加失败');
                }
            }
        }else{
            $id = I('id');
            if($id){
                $res = M('z_kefu_alimama_new')->where(array('id'=>$id))->find();
                $this->assign('res',$res);
            }
            $this->display();
        }
    }
    /*
     * 媒体位管理
     * */
    public function gzh_list(){
        $user = $this->user;
        $uid = $user['id'];
        $p = I('p',1);
        $num = 20;
        $User = M('z_kefu_gzh'); // 实例化User对象
        //$count      = $User->count();// 查询满足要求的总记录数
        $sql = "select count(*) as count from daili_z_kefu_gzh as a left join daili_z_kefu_group as b on a.id = b.gzhid where b.uid=$uid";
        $count = $User->query($sql);
        $count = $count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        $sql = "select a.* from daili_z_kefu_gzh as a left join daili_z_kefu_group as b on a.id=b.gzhid where b.uid=$uid order by a.id desc limit $start,$num";
        $list = $User->query($sql);
        foreach ($list as $key=>$val){
            $alimam = M('z_kefu_alimama_new')->where(array('id'=>$val['alimama_id']))->find();
            $list[$key]['b_name']=$alimam['name'];
        }
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('uid',$uid);
        $this->display();
    }
    /*
     * 用户列表
     * */
    public function user_list(){
        $user = $this->user;
        $uid = $user['id'];
        //根据用户ID查询用户的公众号ID
        $group = M('z_kefu_group')->where(array('uid'=>$uid))->select();
        foreach($group as $key=>$val){
            $gzhid .= $val['gzhid'].',';
            //根据公众号id查询公众号token
            $gzh = M('z_kefu_gzh')->where(array('id'=>$val['gzhid']))->find();
            $token .= '"'.$gzh['token'].'",';
        }
        $gzhid = rtrim($gzhid,',');
        $token = rtrim($token,',');
        //查询公众号
        $gzh = M('z_kefu_gzh')->where(array('id'=>array('in',$gzhid)))->order('id desc')->select();
        $this->assign('gzh',$gzh);
        $id = I('id');
        if($id){
            $this->assign('id',$id);
            $w[0] = "a.id=$id";
            $h[0] = "id=$id";
        }
        $iskefu = I('iskefu');
        if($iskefu != ''){
            $this->assign('iskefu',$iskefu);
            $w[1] = "a.iskefu=$iskefu";
            $h[1] = "iskefu=$iskefu";
        }
        $gzh = I('gzh');
        if($gzh){
            $this->assign('gzh_token',$gzh);
            $w[2] = "a.gzhtoken='$gzh'";
            $h[2] = "gzhtoken='$gzh'";
        }
        $nickname = I('nickname');
        if($nickname){
            $this->assign('nickname',$nickname);
            $w[3] = "a.nickname like '%$nickname%'";
            $h[3] = "nickname like '%$nickname%'";
        }
        $pid = I('pid');
        if($pid){
            $w[4] ="a.pid =".$pid;
            $h[4] ="pid=".$pid;
        }
        foreach ($w as $key=>$val){
            $where .=$val.' and ';
        }
        foreach ($h as $key=>$val){
            $wh .=$val.' and ';
        }
        
        $where = " where gzhtoken in ($token) and ".$where;
        $wh = " where gzhtoken in ($token) and ".$wh;
        $where = rtrim($where,' and ');
        $wh = rtrim($wh,' and ');
        
        
        
        $num = 20;
        $p = I('p',1);
        $User = M('z_kefu_user');
        //$count      = $User->count();// 查询满足要求的总记录数
        $sql = "select count(*) as count from daili_z_kefu_user $wh";
        $count = $User->query($sql);
        $count = $count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        $sql = "select a.*,b.nick_name as b_name from daili_z_kefu_user as a left join daili_z_kefu_gzh as b on a.gzhtoken=b.token $where order by a.id desc limit $start,$num";
        $list = $User->query($sql);
        foreach ($list as $key=>$val){
            $kefu = M('z_kefu_user')->where(array('id'=>$val['pid']))->find();
            $list[$key]['kefu']=$kefu['nickname'];
        }
        $this->assign('page',$show);
        $this->assign('list',$list);
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->display();
    }
    /*
     * 用户列表
     * */
    public function fensi_list(){
        
        $pid = I('pid');
        $w ="a.pid =".$pid;
        $h ="pid=".$pid;
        
        $where = " where ".$w;
        $wh = " where ".$h;
    
        $num = 20;
        $p = I('p',1);
        $User = M('z_kefu_user');
        //$count      = $User->count();// 查询满足要求的总记录数
        $sql = "select count(*) as count from daili_z_kefu_user $wh";
        $count = $User->query($sql);
        $count = $count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        $sql = "select a.*,b.nick_name as b_name from daili_z_kefu_user as a left join daili_z_kefu_gzh as b on a.gzhtoken=b.token $where order by a.id desc limit $start,$num";
        $list = $User->query($sql);
        $this->assign('page',$show);
        $this->assign('list',$list);
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->display();
    }
    //添加公众号页面
    public function add_gzh(){
        if(IS_POST){
            $data = I('post.');
            $alimama = $data['alimama_id'];
            $arr_alimama=explode('-',$alimama);
            $data['alimama_id']=$arr_alimama[0];
            $data['alimama_name']=$arr_alimama[1];
            $data['add_time']=time();
            $file = $_FILES['icon'];
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     3145728 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->savePath  =      '/gzh_icon/'; // 设置附件上传目录    // 上传单个文件
            $info   =   $upload->uploadOne($file);
            if($info){
                $path = '/Uploads'.$info['savepath'].$info['savename'];
                $data['icon']=$path;
            }
            $r = M('z_kefu_gzh')->add($data);
            if($r){
                //添加成功后添加默认用户
                $u = array(
                    'issubscribe'=>1,
                    'subscribetime'=>time(),
                    'nickname'=>'admin',
                    'address'=>'--',
                    'gzhtoken'=>$data['token'],
                    'iskefu'=>2
                );
                M('z_kefu_user')->add($u);
                $this->success('添加成功');
            }else{
                $this->error('添加失败');
            }
        }else{
            //查询阿里妈妈账号
            $alimama = M('z_kefu_alimama_new')->order('id desc')->select();
            $this->assign('alimama',$alimama);
            $this->display();
        }
    }

    //公众号菜单列表
    public function menu_list(){
        $p = I('p',1);
        $gid = I('get.gid');
        $User = M('z_kefu_menu'); // 实例化User对象
        $count      = $User->where(array('gzh_id'=>$gid))->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = $User->where(array('statue'=>1,'gzh_id'=>$gid))->order('id desc')->limit($Page->firstRow.','.$Page->listRows)->select();
    
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('gid',$gid);
        $this->assign('p',$p);
        $this->display();
    }
    
    //添加公众号菜单
    public function add_menu(){
        if(IS_POST){
            $data = I('post.');
            $gzh_id = $data['gzh_id'];
            $level  = $data['level'];
            //根据公众号ID查询已经添加了几个一级菜单最多只能加三，二级菜单最多5个
            if($level==1){
                $count = M('menu')->where(array('gzh_id'=>$gzh_id,'level'=>$level))->count();
                if($count>=3){$this->error('一级菜单最多3个');}
            }
            if($level==2){
                $count = M('menu')->where(array('gzh_id'=>$gzh_id,'level'=>$level,'pid'=>$data['pid']))->count();
                if($count>=5){$this->error('二级菜单最多5个');}
            }
            if($data['type']=='click'){
                //                $data['key']='key_'.$data['key'];
                $data['key']=$data['key'];
            }
            $r = M('z_kefu_menu')->add($data);
            if($r){
                $this->success('添加成功');
            }else{
                $this->error('添加失败');
            }
        }else{
            $gid = I('get.gid');
            if(empty($gid)){
                $this->error('参数丢失');
            }
            //查询公众号
            //$gzh = M('a_media')->field('id,nick_name')->where(array('statue'=>1))->select();
            //$this->assign('gzh',$gzh);
            //查询当前公众号一级菜单
            $w = array(
                'gzh_id'=>$gid,
                'level'=>1,
            );
            $menu = M('z_kefu_menu')->where($w)->select();
            $this->assign('gid',$gid);
            $this->assign('menu',$menu);
            $this->display();
        }
    }
    //编辑公众号菜单
    public function edit_menu(){
        $save = I('save');
        if($save){
            $data = I('post.');
            unset($data['save']);
            //            $gzh_id = $data['gzh_id'];
            //            $level  = $data['level'];
             
            $r = M('z_kefu_menu')->where(array('id'=>I('post.id'),'gzh_id'=>I('post.gid')))->save($data);
            if($r){
                $this->success('编辑成功');
            }else{
                $this->error('编辑失败');
            }
        }else{
            $id = I('id');
            $gid = I('get.gid');
            $res = M('z_kefu_menu')->where(array('id'=>$id))->find();
            //查询公众号
            //$gzh = M('a_media')->field('id,nick_name')->where(array('statue'=>1))->select();
            //$this->assign('gzh',$gzh);
            //查询当前公众号一级菜单
            $w = array(
                //'gzh_id'=>$gzh[0]['id'],
                'level'=>1,
            );
            $menu = M('z_kefu_menu')->where($w)->select();
            $this->assign('menu',$menu);
            $this->assign('res',$res);
            $this->assign('gid',$gid);
            $this->display();
        }
    }
    
    //创建微信自定义菜单
    public function create_menu(){
        $user=session('user');
        if(!$user){echo '非法操作';}
        //查询公众号
        $gid = I('get.gid');
        
        if(empty($gid)){
            echo '缺少参数，非法操作';
        }
        $gzh = M('z_kefu_gzh')->where(array('id'=>$gid))->find();
        $token = $gzh['token'];
        $access_token = S("kf_".$token);
        if(!$access_token){
            //先删除掉公众号菜单
            $appid = $gzh['appid'];
            $appsecret=$gzh['appsecret'];
            $url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$appsecret;
            $res = file_get_contents($url);
            $obj=json_decode($res);
            $access_token=$obj->access_token;
            S("kf_".$token,$access_token,7000);
        }
        $url = 'https://api.weixin.qq.com/cgi-bin/menu/delete?access_token='.$access_token;
        //根据公众号ID查询一级菜单
        $w = array(
            'gzh_id'=>$gzh['id'],
            'level'=>1
    
        );
        $menu = M('z_kefu_menu')->where($w)->order('sort asc')->select();
    
        $url = 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token='.$access_token;
        
        foreach ($menu as $key_m=>$val_m){
            if($val_m['type']=='no'){
                $data[$key_m]['name']=$val_m['name'];
                //根据一级菜单查询二级菜单
                $w = array(
                    'pid'=>$val_m['id'],
                );
                $child_menu = M('z_kefu_menu')->where($w)->select();
                $child_data = array();
                foreach ($child_menu as $child_key=>$child_val){
                    $child_data[$child_key]['name']=$child_val['name'];
                    $child_data[$child_key]['type']=$child_val['type'];
                    if($child_val['type']=='view'){
                        if(strpos($child_val['url'],'?') !== false){
                            $child_val['url'] = $gzh['yuming'].$child_val['url'].'&token='.$gzh['token'];
                        }else{
                            $child_val['url'] = $gzh['yuming'].$child_val['url'].'?token='.$gzh['token'];
                        }
                        $child_data[$child_key]['url']=$child_val['url'];
                    }
                    if($child_val['type']=='click'){
                        $child_data[$child_key]['key']=$child_val['key'];
                    }
    
                }
    
                $data[$key_m]['sub_button']=$child_data;
            }else{
                $data[$key_m]['type']=$val_m['type'];
                $data[$key_m]['name']=$val_m['name'];
                if($val_m['type']=='click'){
                    $data[$key_m]['key']=$val_m['key'];
                }
                if($val_m['type']=='view'){
                    $data[$key_m]['url']=$gzh['yuming'].$val_m['key'];
                }
            }
        }
        $post_data = array(
            'button'=>$data
        );
        //echo '<pre>';
        //print_r($post_data);exit;
        $output = curl_post($post_data,$url);
        Addlog($output,$gzh['nick_name'].'客服公众号创建菜单日志');
        //        $arr_gzh = M('a_media')->select();
        //        foreach ($arr_gzh as $key=>$gzh){
        //
        //
        //        }
        if($output['errmsg']!='ok'){
            $arr = array(
                'code'=>0,
                'msg'=>'菜单发布失败'
            );
        }else{
            $arr = array(
                'code'=>1,
                'msg'=>'菜单发布成功'
            );
        }
        $this->ajaxReturn($arr);
    }
    /**
     * 修改用户信息
     * */
    public function update_user_info(){
        $id = I('id');
        $pid=I('pid');
        //根据ID查询用户类型
        $user = M('z_kefu_user')->where(array('id'=>$id))->find();
        if($pid){
            if($user['iskefu']==2){
                $iskefu=2;
            }else{
                $iskefu=1;
            }
        }else{
            $iskefu=0;
        }
        $data = array(
            'id'=>$id,
            'tgwid'=>$pid,
            'iskefu'=>$iskefu
        );
        $ress = M('z_kefu_user')->save($data);
        if($ress){
            $arr = array(
                'code'=>1,
                'msg'=>'修改成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //取消客服
    public function quxiao_kefu(){
        $id = I('id');
        $d = array(
            'id'=>$id,
            'tgwid'=>null,
            'iskefu'=>0
        );
        $user = M('z_kefu_user')->save($d);
        if($user){
            $arr = array(
                'code'=>1,
                'msg'=>'操作成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'操作失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //设置pid
    public function set_pid(){
        $id = I('id');
        $pid = str_replace(' ','',I('pid'));
        $data = array(
            'id'=>$id,
            'tgwid'=>$pid
        );
        $user = M('z_kefu_user')->save($data);
        if($user){
            $arr = array(
                'code'=>1,
                'msg'=>'操作成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'操作失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //获取微信关注二维码
    public function get_qrcode(){
        $id = I('id');
        $openid=I('openid');
        $token = I('token');
        $gzh = M('z_kefu_gzh')->where(array('token'=>$token))->find();
        $access_token = S("kf_".$token);
        if(!$access_token){
            $appid = $gzh['appid'];
            $appsecret=$gzh['appsecret'];
            $url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$appsecret;
            $res = file_get_contents($url);
            $obj=json_decode($res);
            $access_token=$obj->access_token;
            S("kf_".$token,$access_token,7000);
        }
        $url = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=".$access_token;
        //{"action_name": "QR_LIMIT_STR_SCENE", "action_info": {"scene": {"scene_str": "test"}}}
        $data = array(
            'action_name'=>'QR_LIMIT_SCENE',
            'action_info'=>array(
                'scene'=>array(
                    'scene_id'=>$id,
                )
            )
        );
        $res = curl_post($data,$url);
        $ticket=$res['ticket'];
        $url = 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.UrlEncode($ticket);
        $img_str = file_get_contents($url);
        $path = './Uploads/KefuQrcode/'.$id.'.jpg';
        $res = file_put_contents($path, $img_str);
        if($res){
            //获取关注的推广链接
            $url = $gzh['yuming'].'index/guanzhu?token='.$token.'&id='.$id;
            $get_dwz_url = 'http://dwz.olivecloud.cn/getDWZ?url='.urlencode($url).'&qudao=kefu_system';
            $res = curl_get($get_dwz_url);
            //获取首页的推广链接
            $index_url = $gzh['yuming'].'index/index?token='.$token.'&openid='.$openid.'&tz=true';
            $get_dwz_url = 'http://dwz.olivecloud.cn/getDWZ?url='.urlencode($index_url).'&qudao=kefu_system';
            $res_index = curl_get($get_dwz_url);
            //获取搜索页的推广链接
            $search_url = $gzh['yuming'].'index/find_shop?token='.$token.'&openid='.$openid.'&tz=true';
            $get_dwz_url = 'http://dwz.olivecloud.cn/getDWZ?url='.urlencode($search_url).'&qudao=kefu_system';
            $res_search = curl_get($get_dwz_url);
            if($res['msg']){
                $userinfo = array(
                    'id'=>$id,
                    'qrcode'=>'http://'.$_SERVER['HTTP_HOST'].ltrim($path,'.'),
                    'tuiguan_url'=>$res['msg'],
                    'index_url'=>$res_index['msg'],
                    'search_url'=>$res_search['msg']
                );
                $res = M('z_kefu_user')->save($userinfo);
                if($res){
                    $arr = array(
                        'code'=>1,
                        'msg'=>'生成二维码成功'
                    );
                }else{
                    $arr = array(
                        'code'=>0,
                        'msg'=>'生成二维码失败'
                    );
                }
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'生成推广链接失败'
                );
            }
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'生成二维码失败'
            );
        }
        $this->ajaxReturn($arr);
    }


    /**
     * APP客服列表
     * */
    public function app_kefu_list(){
        $user = $this->user;
        $uid = $user['id'];
        $res = M('a_app_kefu')->select();
        $this->assign('list',$res);
        $this->assign('uid',$uid);
        $this->display();
    }

    public function add_app_kefu(){
        if(IS_POST){
            $data = I('post.');
            $id = $data['id'];
            if($id){
                $data['edittime'] = time();
                $res = M('a_app_kefu')->where(array('id'=>$id))->save($data);
                if($res){
                    $this->success("编辑成功",U('app_kefu_list'));
                }else{
                    $this->error("编辑失败",U('app_kefu_list'));
                }
            }else{
                $data['addtime'] = time();
                $res = M('a_app_kefu')->add($data);
                if($res){
                    $this->success("添加成功",U('app_kefu_list'));
                }else{
                    $this->error("添加失败",U('app_kefu_list'));
                }
            }
        }else{
            $id = I('id');
            if($id){
                $res = M('a_app_kefu')->where(array('id'=>$id))->find();
                $this->assign('res',$res);
            }
            $this->display();
        }
    }

    public function edit_app_statue(){
        $id = I('id');
        $statue = M('a_app_kefu')->where(array('id'=>$id))->getField('statue');
        $status = $statue==1?0:1;
        $res = M('a_app_kefu')->where(array('id'=>$id))->save(array('statue'=>$status));
        header("Location:".U('app_kefu_list'));
    }

    public function del_app_kefu(){
        $id = I('id');
        $res = M('a_app_kefu')->where(array('id'=>$id))->delete();
        header("Location:".U('app_kefu_list'));
    }


    /**
     * 安卓APP版本
     * */
    public function app_version_list(){
        $data = M('a_app_version')->where(array('app_type'=>1))->order('id desc')->select();
        foreach($data as $k=>$v){
            $data[$k]['status'] = $data[$k]['statue']==0?"否":"是";
        }

        $this->assign('data',$data);
        $this->display();
    }

    /**
     * 安卓APP修改
     * */
    public function app_version_edit(){
        header("Content-type: text/html; charset=utf-8");
        if(IS_POST){
            $id = I('post.ver_id','',intval);
            $data = array(
                'version'        => trim(I('post.version')),
                'version_name'       => trim(I('post.version_name')),
                'describe' => trim(I('post.describe')),
                'app_type'      => 1,
                'add_time'      =>time(),
                'statue'       => I('post.statue','',intval)
            );
            if($id){
                if(!empty($_FILES['file']['name']) && $_FILES['file']['error']==0){
                    $res = $this->rj_upload($_FILES['file']);
                    $data['download_url'] = $res['file_path'];
                }
                $ress = M('a_app_version')->where(array('id'=>$id))->save($data);
            }else{
                $res = $this->rj_upload($_FILES['file']);
                $data['add_time'] = time();
                $data['download_url'] = $res['file_path'];
                $ress = M('a_app_version')->add($data);
            }
            if($ress){
                $this->success('编辑成功','app_version_list');
            }else{
                $this->error('编辑失败');
            }
        }else{
            $id = I('id');
            if(!empty($id)){
                $data = M('a_app_version')->where(array('id'=>$id))->find();
                $this->assign('info',$data);
                $this->assign('id',$id);
            }
            $this->display();
        }
    }

    /**
     * 安卓APP删除
     * */
    public function app_version_del(){
        $id = I('id');
        M('a_app_version')->where(array('id'=>$id))->delete();
        header("Location:".U('app_version_list'));
    }


    /**
     * ios版本
     * */
    public function ios_version_list(){
        $data = M('a_app_version')->where(array('app_type'=>2))->order('id desc')->select();
        foreach($data as $k=>$v){
            $data[$k]['status'] = $data[$k]['statue']==0?"否":"是";
        }

        $this->assign('data',$data);
        $this->display();
    }

    /**
     * ios修改
     * */
    public function ios_version_edit(){
        header("Content-type: text/html; charset=utf-8");
        if(IS_POST){
            $id = I('post.ver_id','',intval);
            $data = array(
                'version'       => trim(I('post.version')),
                'version_name'  => trim(I('post.version_name')),
                'describe'      => trim(I('post.describe')),
                'statue'        => I('post.statue','',intval),
                'app_type'      => 2,
                'add_time'      =>time(),
                'download_url'  => I('post.download_url')
            );
            if($id){
                $ress = M('a_app_version')->where(array('id'=>$id))->save($data);
            }else{
                $data['add_time'] = time();
                $ress = M('a_app_version')->add($data);
            }
            if($ress){
                $this->success('编辑成功','ios_version_list');
            }else{
                $this->error('编辑失败');
            }
        }else{
            $id = I('id');
            if(!empty($id)){
                $data = M('a_app_version')->where(array('id'=>$id))->find();
                $this->assign('info',$data);
                $this->assign('id',$id);
            }
            $this->display();
        }
    }

    /**
     * ios删除
     * */
    public function ios_version_del(){
        $id = I('id');
        M('a_app_version')->where(array('id'=>$id))->delete();
        header("Location:".U('ios_version_list'));
    }

    /**
     * 软件新版本上传
     * 2017/10/18
     * */
    public  function rj_upload($files_info){
        header('Content-type: application/json');
        //检测是否存在指定文件夹
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize   =     3145728000 ;// 设置附件上传大小
        $upload->exts      =     array('apk','jpg', 'gif','png', 'jpeg', 'exe','cpk','she','dll','txt','bmp','ini','edb','js','html');// 设置附件上传类型
        $upload->savePath  =     '/RJ_VERSION/'; // 设置附件上传目录
        // 上传文件
        $info   =   $upload->uploadOne($files_info);
        if(!$info){
            $msg = '上传失败';
            return $msg;
        }else{
//            $local_path = getcwd()."/Uploads".$info['savepath'].$info['savename'];
//            $local_path = str_replace('\\','/',$local_path);
//            $success = $this->ftp_upload($info['savepath'],$info['savename'],$local_path);
            $infos['file_path'] = 'http://img.yunbace.cn/Uploads'.$info['savepath'].$info['savename'];
            $infos['md5'] = $info['md5'];
            $infos['size'] = $info['size'];
            return $infos;
        }
    }
}
