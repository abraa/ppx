<?php
/**
 * 活动控制器
 * */
namespace Home\Controller;
use Think\Controller;
class ActiveController extends BaseController {
    //活动列表页
    public function index(){
        $qudao=I('qudao');
        $obj = M('a_active');
        $p = I('p',1);
        $num  = 20;
        $start = ($p-1)*$num;
        
        $count = $obj->count();
        $page = new \Think\Page($count,$num);
        $show = $page->show();
        //查询活动列表
        //$list = $obj->where($w)->limit($page->firstRow.','.$page->listRows)->select();
        $sql = "select * from daili_a_active limit $start,$num";
       
        $list=$obj->query($sql);
        $this->assign('page',$show);
        $this->assign('list',$list);
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->display();
    }
    //添加活动页面
    public function add_active(){
        if(IS_POST){
            $data = I('post.');
            $reward  = str_replace(' ','',str_replace('，',',',$data['reward']));
            $complete= str_replace(' ','',str_replace('，',',',$data['complete']));
            $data['reward']=$reward;
            $data['complete']=$complete;
            $id = $data['id'];
            $data['token']=$data['qudao'];
            $data['start_time']=strtotime($data['start_time']);
            $data['end_time']=strtotime($data['end_time']);
            if($id){
                $res = M('a_active_qudao')->save($data);
                if($res){
                    $this->ajaxReturn(array('code'=>1,'msg'=>'编辑成功'));
                }else{
                    $this->ajaxReturn(array('code'=>0,'msg'=>'编辑失败'));
                }
            }else{
                $res = M('a_active_qudao')->add($data);
                if($res){
                    $this->ajaxReturn(array('code'=>1,'msg'=>'添加成功'));
                }else{
                    $this->ajaxReturn(array('code'=>0,'msg'=>'添加失败'));
                }
            }
        }
        $id = I('id');
        if($id){
            $res = M('a_active_qudao')->where(array('id'=>$id))->find();
            $this->assign('res',$res);
        }
        $active_id = I('active_id');
        $active = M('a_active')->where(array('id'=>$active_id))->find();
        $this->assign('active',$active);
        $html = 'add_active'.$active_id;
        $this->display($html);
    }
    //渠道活动列表页面
    public function qudao_active(){
        $qudao=I('qudao');
        $obj = M('a_active_qudao');
        $p = I('p',1);
        $num  = 20;
        $start = ($p-1)*$num;
        if($qudao){
            $where =" where a.token = '$qudao'";
            $this->assign('qudao',$qudao);
            
        }else{
            $search_token = $this->str_t;
            $where=" where a.token in ($search_token)";
            
        }
        $sql = "select count(*) as count from daili_a_active_qudao as a $where";
        $count = $obj->query($sql);
        $count = $count[0]['count'];
        $page = new \Think\Page($count,$num);
        $show = $page->show();
        //查询活动列表
        //$list = $obj->where($w)->limit($page->firstRow.','.$page->listRows)->select();
        $sql = "select a.*,b.title as b_title,b.content as b_content,c.qudao_name as c_qudao_name from daili_a_active_qudao as a left join daili_a_active as b on a.active_id=b.id left join daili_a_media as c on a.token = c.token $where order by a.id desc limit $start,$num";
         
        $list=$obj->query($sql);
        $this->assign('page',$show);
        $this->assign('list',$list);
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->display();
    }
    //删除活动
    public function del_active(){
        $id = I('id');
        $res = M('a_active_qudao')->delete($id);
        if($res){
            $this->ajaxReturn(array('code'=>1,'msg'=>'删除成功'));
        }else{
            $this->ajaxReturn(array('code'=>0,'msg'=>'删除失败'));
        }
    }
    //用户添加奖励
    public function add_jiangli(){
        $user = $this->user;
        $uid = I('id');
        $active_id=I('active_id');
        $reward=I('reward');
        $data=array(
            'uid'=>$uid,
            'time'=>time(),
            'reward'=>$reward,
            'action_user'=>$user['name'],
            'active_id'=>$active_id
        );
        $session_str = md5('data_uid='.$uid.'active_id='.$active_id);
        $s = session($session_str);
        if(!$s){
            session($session_str,$data);
            $res = M('a_active_complete')->add($data);
            if($res){
                //给用户添加余额
                /* $res = M('wx_user')->where(array('ID'=>$uid))->setInc('YuE',$reward);
                if($res){
                    $log=array(
                        'active_id'=>$active_id,
                        'uid'=>$uid,
                        'reward'=>$reward,
                        'time'=>time(),
                        'date_time'=>date('Y-m-d H:i:s',time()),
                        'action_user'=>$user['name']
                    );
                    M('a_active_log')->add($log);
                } */
                $arr = array(
                    'code'=>1,
                    'msg'=>'操作成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'操作失败'
                );
            }
        }else{
            $arr = array(
                'code'=>1,
                'msg'=>'操作成功'
            );
        }
        $this->ajaxreturn($arr);
    
    }
    //活动详情页面
    public function details(){
        $id = I('id');
        //根据ID查询所属活动
        $active = M('a_active_qudao')->where(array('id'=>$id))->find();
        $function_name='active'.$active['active_id'];
        $data = array(
            'id'=>$id,
            'p'=>I('p',1),
        );
        $this->$function_name($data);
    }
    //详细信息页面
    public function active1($data){
        $id = $data['id'];
        $p  = $data['p'];
        $num = 20;
        $start=($p-1)*$num;
        //查询活动信息
        $sql = "select a.*,b.qudao_name as b_qudao_name,c.ShouYiBi as c_shouyibi,d.title as d_title from daili_a_active_qudao as a left join daili_a_media as b on a.token=b.token left join daili_a_config_copy as c on b.id=c.MediaID left join daili_a_active as d on a.active_id=d.id where a.id=$id";
        $active = M('a_active_qudao')->query($sql);
        $active=$active[0];
        $shouyibi = $active['c_shouyibi']/100;
        $token      = $active['token'];
        $start_time = $active['start_time'];
        $end_time   = $active['end_time'];
        $complete   = $active['complete'];
        $reward     = $active['reward']/100;
        $qudao_name = $active['b_qudao_name']; 
        if($start_time>time()){
            $this->error('活动暂未开始');
        }
        //查询总数
        $sql="select count(a.ID) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID
            where a.MediaName='$qudao_name' 
            and a.OrderStatue<>'订单失效' 
            and (a.CreateTime between $start_time and $end_time)
            group by a.AdID
            having count(a.ID) >= $complete  
        ";
        $res = M('a_order')->query($sql);
        $count = count($res);
        $page = new \Think\Page($count,$num);
        $show = $page->show();
        $sql = "select 
        count(a.ID) as a_count,a.AdID,b.ShouYi as b_shouyi
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID
        where a.MediaName='$qudao_name' 
        and a.OrderStatue<>'订单失效' 
        and (a.CreateTime between $start_time and $end_time)
        group by a.AdID having a_count>=$complete order by a_count desc limit $start,$num";
        $list = M('a_order')->query($sql);
        foreach ($list as $key=>$val){
            //查询用户信息
            $v_adid=$val['adid'];
            $sql = "select a.ID,a.Name,a.Phone,a.MediaName,b.Name as b_name from daili_wx_user as a left join daili_wx_user as b on a.kefu_id=b.ID where a.AdID = $v_adid";
            $user = M('wx_user')->query($sql);
            $user = $user[0];
            //$user = M('wx_user')->field('ID,Name,Phone,MediaName')->where(array('AdID'=>$val['adid']))->find();
            $list[$key]['id']=$user['id'];
            $list[$key]['name']=$user['name'];
            $list[$key]['phone']=$user['phone'];
            $list[$key]['medianame']=$user['medianame'];
            $list[$key]['b_name']=$user['b_name'];
            //根据用户adid查询完成任务的订单的收益总和
            $adid = $val['adid'];
            $sql = "select sum(ShouYi) as sum from ( select b.ShouYi from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.AdID='$adid' and a.OrderStatue<>'订单失效' and (a.CreateTime between $start_time and $end_time) order by a.CreateTime asc limit 0,$complete) t";
            $res = M('a_order')->query($sql);
            $list[$key]['sum']=round($res[0]['sum']*$reward,2);
            $w=array(
                'active_id'=>$id,
                'uid'=>$user['id'],
            );
            $res = M('a_active_complete')->where($w)->find();
            if($res){
                $list[$key]['statue']=1;
            }else{
                $list[$key]['statue']=0;
            }
        }
        if(time()>$start_time){
            $this->assign('start',1);//活动开始
        }else{
            $this->assign('start',0);//活动未开始
        }
        if(time()<$end_time){
            $this->assign('end',1);//活动进行中
        }else{
            $this->assign('end',0);//活动结束
        }
        $this->assign('qudao',$qudao);
        $this->assign('count',$count);
        $this->assign('active',$active);
        $this->assign('p',$p);
        $this->assign('page',$show);
        $this->assign('complete',$complete);
        $this->assign('list',$list);
        $this->assign('id',$id);
        $this->display('active1');
    }
    
    public function active5($data){
        $id = $data['id'];
        $p  = $data['p'];
        $num = 20;
        $start=($p-1)*$num;
        //查询活动信息
        $sql = "select a.*,b.qudao_name as b_qudao_name,c.ShouYiBi as c_shouyibi,d.title as d_title from daili_a_active_qudao as a left join daili_a_media as b on a.token=b.token left join daili_a_config_copy as c on b.id=c.MediaID left join daili_a_active as d on a.active_id=d.id where a.id=$id order by a.id desc";
        $active = M('a_active_qudao')->query($sql);
        $active=$active[0];
        $shouyibi = $active['c_shouyibi']/100;
        $qudao_name = $active['b_qudao_name'];
        $token      = $active['token'];
        $start_time = $active['start_time'];
        $end_time   = $active['end_time'];
        $complete   = explode(',',$active['complete']);
        sort($complete);
        $reward     = explode(',',$active['reward']);
        sort($reward);
        foreach ($complete as $key=>$val){
            $arr[$val]=$reward[$key];
        }
        $min_complete = $complete[0];
        //查询总数
        $sql = "select a.*,sum(b.ShouYi) as sum
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID
        where a.MediaName='$qudao_name' 
        and a.OrderStatue<>'订单失效' 
        and (a.CreateTime between $start_time and $end_time)
        group by a.AdID
        having sum>=$min_complete
        order by sum desc
        ";
        $res = M('a_order')->query($sql);
        $count=count($res);
        $page = new \Think\Page($count,$num);
        $show = $page->show();
        $sql = "select 
        sum(b.ShouYi) as a_count,a.AdID
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID
        where a.MediaName='$qudao_name' 
        and a.OrderStatue<>'订单失效' 
        and (a.CreateTime between $start_time and $end_time)
        group by a.AdID having a_count>=$min_complete order by a_count desc limit $start,$num";
        $list = M('a_order')->query($sql);
        foreach ($list as $key=>$val){
            $a_count = round($val['a_count'],2);
            $list[$key]['a_count']=$a_count;
            foreach ($arr as $k=>$v){
                if($a_count>=$k){
                    $list[$key]['reward']=$v;
                }
            }
            $v_adid=$val['adid'];
            //查询用户信息
            $sql = "select a.ID,a.Name,a.Phone,a.MediaName,b.Name as b_name from daili_wx_user as a left join daili_wx_user as b on a.kefu_id=b.ID where a.AdID = $v_adid";
            $user = M('wx_user')->query($sql);
            $user = $user[0];
            //$user = M('wx_user')->field('ID,Name,Phone,MediaName')->where(array('AdID'=>$val['adid']))->find();
            $list[$key]['id']=$user['id'];
            $list[$key]['name']=$user['name'];
            $list[$key]['phone']=$user['phone'];
            $list[$key]['b_name']=$user['b_name'];
            $list[$key]['medianame']=$user['medianame'];
            //根据用户adid查询完成任务的订单的收益总和
            $w=array(
                'active_id'=>$id,
                'uid'=>$user['id'],
            );
            $res = M('a_active_complete')->where($w)->find();
            if($res){
                $list[$key]['statue']=1;
            }else{
                $list[$key]['statue']=0;
            }
        }
        if(time()>$start_time){
            $this->assign('start',1);//活动开始
        }else{
            $this->assign('start',0);//活动未开始
        }
        if(time()<$end_time){
            $this->assign('end',1);//活动进行中
        }else{
            $this->assign('end',0);//活动结束
        }
        $this->assign('qudao',$qudao);
        $this->assign('arr',$arr);
        $this->assign('count',$count);
        $this->assign('active',$active);
        $this->assign('p',$p);
        $this->assign('page',$show);
        $this->assign('complete',$complete);
        $this->assign('list',$list);
        $this->assign('id',$id);
        $this->display('active5');
    }
    //导出execl
    public function export_execl1(){
        $id = I('id');
        //查询活动信息
        $sql = "select a.*,b.qudao_name as b_qudao_name,c.ShouYiBi as c_shouyibi,d.title as d_title from daili_a_active_qudao as a left join daili_a_media as b on a.token=b.token left join daili_a_config_copy as c on b.id=c.MediaID left join daili_a_active as d on a.active_id=d.id where a.id=$id";
        $active = M('a_active_qudao')->query($sql);
        $active=$active[0];
        $shouyibi = $active['c_shouyibi']/100;
        $token      = $active['token'];
        $start_time = $active['start_time'];
        $end_time   = $active['end_time'];
        $complete   = $active['complete'];
        $reward     = $active['reward']/100;
        $qudao_name = $active['b_qudao_name']; 
        if($start_time>time()){
            $this->error('活动暂未开始');
        }
        $sql = "select 
        count(a.ID) as a_count,a.AdID
        from daili_a_order as a
        where a.MediaName='$qudao_name' 
        and a.OrderStatue<>'订单失效' 
        and (a.CreateTime between $start_time and $end_time)
        group by a.AdID having a_count>=$complete order by a_count desc";
        $list = M('a_order')->query($sql);
        foreach ($list as $key=>$val){
            //查询用户信息
            $v_adid=$val['adid'];
            $sql = "select a.ID,a.Name,a.Phone,a.MediaName,b.Name as b_name from daili_wx_user as a left join daili_wx_user as b on a.kefu_id=b.ID where a.AdID = $v_adid";
            $user = M('wx_user')->query($sql);
            $user = $user[0];
            //$user = M('wx_user')->field('ID,Name,Phone,MediaName')->where(array('AdID'=>$val['adid']))->find();
            $list[$key]['id']=$user['id'];
            $list[$key]['name']=$user['name'];
            $list[$key]['phone']=' '.$user['phone'];
            $list[$key]['medianame']=$user['medianame'];
            $list[$key]['b_name']=$user['b_name'];
            //根据用户adid查询完成任务的订单的收益总和
            $adid = $val['adid'];
            $sql = "select sum(ShouYi) as sum from ( select b.ShouYi from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.AdID='$adid' and a.OrderStatue<>'订单失效' and (a.CreateTime between $start_time and $end_time) order by a.CreateTime asc limit 0,$complete) t";
            $res = M('a_order')->query($sql);
            $list[$key]['sum']=round($res[0]['sum']*0.9*$shouyibi*$reward,2);
        }
        $expTitle=date('Y-m-d/H/i/s',time()).'活动奖励明细';//文件名
        $expCellName=array(
            array('id','编号'),
            array('medianame','渠道名称'),
            array('name','代理姓名'),
            array('b_name','客服姓名'),
            array('phone','代理手机'),
            array('a_count','完成订单数'),
            array('sum','奖励金额'),
        );//每列的字段名称
        $expTableData=$list;//需要导出的数据
        exportExcel($expTitle,$expCellName,$expTableData);
    }
    //导出execl
    public function export_execl5(){
        $id = I('id');
        //查询活动信息
        $sql = "select a.*,b.qudao_name as b_qudao_name,c.ShouYiBi as c_shouyibi,d.title as d_title from daili_a_active_qudao as a left join daili_a_media as b on a.token=b.token left join daili_a_config_copy as c on b.id=c.MediaID left join daili_a_active as d on a.active_id=d.id where a.id=$id order by a.id desc";
        $active = M('a_active_qudao')->query($sql);
        $active=$active[0];
        $shouyibi = $active['c_shouyibi']/100;
        $qudao_name = $active['b_qudao_name'];
        $token      = $active['token'];
        $start_time = $active['start_time'];
        $end_time   = $active['end_time'];
        $complete   = explode(',',$active['complete']);
        sort($complete);
        $reward     = explode(',',$active['reward']);
        sort($reward);
        foreach ($complete as $key=>$val){
            $arr[$val]=$reward[$key];
        }
        $min_complete = $complete[0];
        
        $sql = "select 
        sum(b.ShouYi) as a_count,a.AdID
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID
        where a.MediaName='$qudao_name' 
        and a.OrderStatue<>'订单失效' 
        and (a.CreateTime between $start_time and $end_time)
        group by a.AdID having a_count>=$min_complete order by a_count desc";
        $list = M('a_order')->query($sql);
        foreach ($list as $key=>$val){
            $a_count = round($val['a_count'],2);
            $list[$key]['a_count']=$a_count;
            foreach ($arr as $k=>$v){
                if($a_count>=$k){
                    $list[$key]['reward']=$v;
                }
            }
            $v_adid=$val['adid'];
            //查询用户信息
            $sql = "select a.ID,a.Name,a.Phone,a.MediaName,b.Name as b_name from daili_wx_user as a left join daili_wx_user as b on a.kefu_id=b.ID where a.AdID = $v_adid";
            $user = M('wx_user')->query($sql);
            $user = $user[0];
            //$user = M('wx_user')->field('ID,Name,Phone,MediaName')->where(array('AdID'=>$val['adid']))->find();
            $list[$key]['id']=$user['id'];
            $list[$key]['name']=$user['name'];
            $list[$key]['phone']=' '.$user['phone'];
            $list[$key]['b_name']=$user['b_name'];
            $list[$key]['medianame']=$user['medianame'];
            
        }
        $expTitle=date('Y-m-d/H/i/s',time()).'活动奖励明细';//文件名
        $expCellName=array(
            array('id','编号'),
            array('medianame','渠道名称'),
            array('name','代理姓名'),
            array('b_name','客服姓名'),
            array('phone','代理手机'),
            array('a_count','总佣金金额'),
            array('reward','奖励金额'),
        );//每列的字段名称
        $expTableData=$list;//需要导出的数据
        exportExcel($expTitle,$expCellName,$expTableData);
    }
    //批量操作1
    public function jiangli_piliang(){
        $user = $this->user;
        $uid = I('ids');
        $active_id=I('active_id');
        $reward=I('reward');
        $session_str = md5('data_uid='.$uid.'active_id='.$active_id);
        $s = session($session_str);
        if(!$s){
            session($session_str,$data);
            $user=$user['name'];
            foreach ($uid as $key=>$val){
                $time = time();
                $r=$reward[$key];
                $str .="($val, $time, $r, '$user',$active_id),";
            }
            $str = rtrim($str,',');
            $sql ="INSERT INTO `daili_a_active_complete` (`uid`, `time`, `reward`, `action_user`,`active_id`) VALUES $str";
            $res = M('a_active_complete')->execute($sql);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'操作成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'操作失败'
                );
            }
        }else{
            $arr = array(
                'code'=>1,
                'msg'=>'操作成功'
            );
        }
        $this->ajaxreturn($arr);
        
    }
}