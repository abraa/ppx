<?php
namespace Home\Controller;
use Think\Controller;
class ProjectController extends BaseController {
    private $api_url="http://api.olivecloud.cn";
    //后台首页
    public function index(){
        $userinfo = session('user');
        $hour = intval(date('H',time()));
        if($hour>12){
            $welcome_msg = "下午好";
        }else{
            $welcome_msg = '上午好';
        }
        $this->assign('userinfo',$userinfo);
        $this->assign('welcome_msg',$welcome_msg);
        $this->display();
    }
  
    //后台修改密码页面
    public function update_pass(){
        $user = $this->user;
        $user = M('user')->where(array('id'=>$user['id']))->find();
        $this->assign('user',$user);
        $this->display();
    }

    /*
     * 阿里妈妈账号列表
     * */
    public function alimama_list(){
        $user = $this->user;
        $uid = $user['id'];
        $p = I('p',1);
        $num = 20;
        $start = ($p-1)*$num;
        $User = M('a_alimama'); // 实例化User对象
        $count      = $User->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = $User->order('AddTime desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        //$list=$User->query($sql);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('uid',$uid);
        $this->display();
    }
    
    
    /*
     * 媒体位管理
     * */
    public function media_list(){
        $user = $this->user;
        //根据用户ID查询，有权限的媒体
        $q = M('b_group_media')->where(array('UID'=>$user['id']))->select();
        if($q){
            foreach ($q as $val){
                $str_mediaID .= $val['mediaid'].',';
            }
            $str_mediaID = rtrim($str_mediaID,',');
        }
        if(!rtrim($str_mediaID,',')){
            $this->error('还没设置渠道权限');
        }
        $p = I('p',1);
        $num = 20;
        $User = M('a_media'); // 实例化User对象
        $count      = $User->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        //$sql = "select a.*,b.Name as b_name,b.ID as b_id from daili_a_media as a left join daili_a_alimama as b on a.alimama_id=b.ID where a.ID in ($str_mediaID) order by a.ID desc limit $start,$num";
        $sql = "select a.*,b.Name as b_name from daili_a_media as a left join daili_a_alimama as b on a.new_alimama_id=b.ID where a.ID in ($str_mediaID) order by a.ID desc limit $start,$num";
        $list = $User->query($sql);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('uid',$user['id']);
        $this->display();
    }
    /*
     * 用户列表
     * */
    public function daili_list(){
        $id = I('id');
        $qudao_id = I('qudao_id');
        $statue = I('statue');
        $text1  = str_replace(' ','',I('text1'));
        $text2  = str_replace(' ','',I('text2'));
        $start = I('start');
        $end   = I('end');
        $start_sy = I('start_sy');
        $end_sy   = I('end_sy');
        $paixu = I('paixu');
        $shangjiid=I('shangjiid');
        $shouyi_paixu = I('shouyi_paixu');
        $str_t = "";
        $where = "";
        $where_sy = "";

        if($paixu==1){
            $order_str = " order by a.YiTiXian desc";
        }elseif($paixu==2){
            $order_str =" order by a.YuE desc";
        }else{
            if($shouyi_paixu==1){
                $order_str = " order by d_shouyi desc";
            }else{
                $order_str =" order by a.ID desc";
            }
        }

        $user = $this->user;
        $uid = $user['id'];
        //根据用户id查询有权限的媒体
        $sql = "select b.* from daili_b_group_media as a left join daili_a_media as b on a.MediaId=b.ID where a.UID = $uid";
        $q = M('b_group_media')->query($sql);
        foreach ($q as $key=>$val){
            $str_t .= $val['token'].',';
        }
        if(!rtrim($str_t,',')){
            $this->error('还没设置渠道权限');
        }
        if($qudao_id){
            //根据媒体ID查询token得到where条件
            $media = M('a_media')->where(array('id'=>$qudao_id))->find();
            $where = 'a.GzhToken="'.$media['token'].'"';
            
        }else{
            if($q){
                //得到媒体下面公众号的token
                foreach ($q as $val){
                    $where .= 'a.GzhToken="'.$val['token'].'" or ';
                }
                $where = '('.rtrim($where,' or ').')';
            }
        }
        if($id){
            $where .=" and a.ID=$id";
        }
        if($shangjiid){
            $where .=" and a.Pid=$shangjiid";
            $this->assign('shangjiid',$shangjiid);
        }
        
        if($statue != ''){
            if($statue==2){
                $where .=' and a.kefu_id=a.ID';
            }else{
                $where .=' and a.Statue='.$statue;
            }
        }
        if($text1){
            $where .=" and (a.Phone like '%".$text1."%' or a.Name like '%".$text1."%')";
        }
        if($text2){
            $where .=" and (b.Phone like '%".$text2."%' or b.Name like '%".$text2."%')";
        }
        if($start && empty($end)){
            $start_time = strtotime($start);
            $where .=" and (a.SubscribeTime >=$start_time or a.reg_app_time>=$start_time)";
        }
        if(empty($start) && $end){
            $end_time = strtotime($end)+3600*24;
            $where .=" and (a.SubscribeTime <$end_time and a.reg_app_time<$end_time)";
        }
        if($start && $end){
            $start_time = strtotime($start);
            $end_time   = strtotime($end)+3600*24;
            $where .=" and (a.SubscribeTime between $start_time and $end_time or a.reg_app_time between $start_time and $end_time)";
        }

        // AND c.CreateTime BETWEEN $now_start and $now_last
        if($start_sy && empty($end_sy)){
            $start_time_sy = strtotime($start_sy);
            $where_sy .=" and c.CreateTime >=$start_time_sy";
        }
        if(empty($start_sy) && $end_sy){
            $end_time_sy = strtotime($end_sy)+3600*24;
            $where_sy .=" and c.CreateTime <$end_time_sy";
        }
        if($start_sy && $end_sy){
            $start_time_sy = strtotime($start_sy);
            $end_time_sy   = strtotime($end_sy)+3600*24;
            $where_sy .=" and c.CreateTime between $start_time_sy and $end_time_sy";
        }

        //echo $where;exit;
        $search_data = array(
            'start'=>$start,
            'end'=>$end,
            'start_sy'=>$start_sy,
            'end_sy'=>$end_sy
        );
        $this->assign('search',$search_data);
        S('where',$where);
        $p = I('p',1);
        $num = 20;
        $User = M('wx_user'); // 实例化User对象
        $sql = "select count(*) as count from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID where $where";
        //echo $sql;exit;
        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count=$count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        $now_start = mktime(0,0,0,date('m'),date('d'),date('Y'));
        $now_last  = mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
        $sql = "select a.*, b.ID            as b_ID,
                            b.Pid           as b_Pid,
                            b.IsSubscribe   as b_IsSubscribe,
                            b.OpenID        as b_OpenID,
                            b.HeaderPic     as b_HeaderPic,
                            b.NickName      as b_NickName,
                            b.Address       as b_Address,
                            b.WxNum         as b_WxNum,
                            b.Alipay        as b_Alipay,
                            b.Name          as b_Name,
                            b.Phone         as b_Phone,
                            b.TgwId         as b_TgwId,
                            b.MediaID       as b_MediaID,
                            b.MediaName     as b_MediaName,
                            b.AdID          as b_AdID,
                            b.AdName        as b_AdName,
                            b.YiTiXian      as b_YiTiXian,
                            b.Statue        as b_Statue,
                            b.IsUseSoftware as b_IsUseSoftware,
                            b.kefu_id       as b_kefu_id,
                            (
                                SELECT
                                    sum(d.ShouYi)
                                FROM
                                    daili_a_order AS c
                                LEFT JOIN daili_a_shouyi AS d ON c.ID = d.OrderID
                                WHERE
                                    d.UID = a.ID
                                   $where_sy
                            ) AS d_shouyi
         from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID where $where $order_str limit $start,$num";
        $list = $User->query($sql);
        foreach ($list as $key=>$val){
//            $list[$key]['now_first_yg'] = $val['d_shouyi']>0?sprintf("%.2f",$now_first_yg):0;
            $list[$key]['now_first_yg'] = $val['d_shouyi']>0?$val['d_shouyi']:0;
            switch ($val['member_level']){
                case -1:
                    $list[$key]['member_level_str']='普通粉丝';
                    break;
                case 0:
                    $list[$key]['member_level_str']='会员';
                    break;
                case 1:
                    $list[$key]['member_level_str']='超级会员';
                    break;
                case 2:
                    $list[$key]['member_level_str']='运营商';
                    break;
                case 3:
                    $list[$key]['member_level_str']='区域合伙人';
                    break;
            }
        }
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('q',$q);
        $this->assign('qudaoid',$qudao_id);
        $this->assign('paixu',$paixu);
        $this->assign('shouyi_paixu',$shouyi_paixu);
        $this->assign('statue',$statue);
        $this->assign('text1',$text1);
        $this->assign('text2',$text2);
        $this->assign('id',$id);
        $this->assign('uid',$uid);
        $this->display();
    }
    /*
     * 查询用户收入明细
     */
    public function daili_mingxi(){
        $uid = I('id');
        //查询用户邀请的奖励
        $count_yaoqing = M('b_jiangli')->where(array('UID'=>$uid))->sum('Money');
        if(!$count_yaoqing){
            $count_yaoqing=0;
        }
        $this->assign('count_yaoqing',$count_yaoqing);
        $startTime = I('start');
        $endTime   = I('end');
        if(!$startTime){
            $startTime = "2017-08-01";
        }
        $start = strtotime($startTime);
        if(!$endTime){
            $endTime = date('Y-m-d',time());
        }
        $end   = strtotime($endTime)+24*3600;
        $p = I('p',1);
        $num = 20;
        $startnum = ($p-1)*$num;
        $User = M('a_order'); // 实例化User对象
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where (a.CreateTime between $start and $end) and (b.UID=$uid or b.ShangJiUID=$uid or b.ShangShangJiUID=$uid) and a.OrderStatue='订单失效'";
       
        $count_shixiao      = $User->query($sql);// 查询满足要求的总记录数
        $this->assign('count_shixiao',$count_shixiao[0]['count']);
        //查询失效订单
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where (a.CreateTime between $start and $end) and (b.UID=$uid or b.ShangJiUID=$uid or b.ShangShangJiUID=$uid)";
         
        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count = $count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        
        $sql = "select a.*,
        a.XiaoGuoYuGu*0.9 as a_xiaoguoyugu,
        b.ID as b_id,
        b.UID as b_uid,
        b.OrderID as b_orderid,
        b.CreateTime as b_createtime,
        b.ShouYi as b_shouyi,
        b.ShangJiUID as b_shangjiuid,
        b.ShangJiShouYi as b_shangjishouyi,
        b.ShangShangJiUID as b_shangshangjiuid,
        b.ShangShangJiShouYi as b_shangshangjishouyi,
        b.OrderStatue as b_orderstatue,
        b.agent_id as b_agent_id,
        b.agent_shouyi as b_agent_shouyi,
        b.shangji_agent_id as b_shangji_agent_id,
        b.shangji_agent_shouyi as b_shangji_agent_shouyi,
        b.area_id as b_area_id,
        b.area_shouyi as b_area_shouyi
        from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where (a.CreateTime between $start and $end) and (b.UID=$uid or b.ShangJiUID=$uid or b.ShangShangJiUID=$uid) order by a.CreateTime desc limit $startnum,$num";
        //echo $sql;exit;
        $list=$User->query($sql);
        //总预估收入
        $count_yugushouru = 0;
        //代理总收入
        $count_dailishouru=0;
        foreach ($list as $key=>$val){
            $daili_uid = $val['b_uid'];
            $shangji_uid = $val['b_shangjiuid'];
            $shangshangji_uid = $val['b_shangshangjiuid'];
            $agent_id = $val['b_agent_id'];
            $shangji_agent_id=$val['b_shangji_agent_id'];
            $area_id = $val['b_area_id'];
            if($daili_uid){
                $user = M('wx_user')->where(array('ID'=>$daili_uid))->find();
                $list[$key]['b_user']=$user['name'];
                $list[$key]['b_user_phone']=$user['phone'];
            }
            if($shangji_uid){
                $shangjiuser = M('wx_user')->where(array('ID'=>$shangji_uid))->find();
                $list[$key]['b_shangjiuser']=$shangjiuser['name'];
                $list[$key]['b_shangjiuser_phone']=$shangjiuser['phone'];
            }
            if($shangshangji_uid){
                $shangshangjiuser = M('wx_user')->where(array('ID'=>$shangshangji_uid))->find();
                $list[$key]['b_shangshangjiuser']=$shangshangjiuser['name'];
                $list[$key]['b_shangshangjiuser_phone']=$shangshangjiuser['phone'];
            }
            if($agent_id){
                $agentuser = M('wx_user')->where(array('ID'=>$agent_id))->find();
                $list[$key]['b_agentuser']=$agentuser['name'];
                $list[$key]['b_agentuser_phone']=$agentuser['phone'];
            }
            if($shangji_agent_id){
                $shangjiagentuser = M('wx_user')->where(array('ID'=>$shangji_agent_id))->find();
                $list[$key]['b_shangjiagentuser']=$shangjiagentuser['name'];
                $list[$key]['b_shangjiagentuser_phone']=$shangjiagentuser['phone'];
            }
            if($area_id){
                $areauser = M('wx_user')->where(array('ID'=>$area_id))->find();
                $list[$key]['b_areauser']=$areauser['name'];
                $list[$key]['b_areauser_phone']=$areauser['phone'];
            }
            $pingtaishouyi = $val['xiaoguoyugu']*0.9-$val['b_shouyi']-$val['b_shangjishouyi']-$val['b_shangshangjishouyi']-$val['b_agent_shouyi']-$val['b_shanji_agent_shouyi']-$val['b_area_shouyi'];
            $list[$key]['pingtaishouyi']=$pingtaishouyi;
        }
        //总的佣金收入
        $sql = "select 
            sum(a.XiaoGuoYuGu) as count ,
            sum(b.ShouYi)+sum(b.ShangJiShouYi)+sum(b.ShangShangJiShouYi) as count_daili,
            sum(b.agent_shouyi)+sum(b.shangji_agent_shouyi) as count_agent,
            sum(b.area_shouyi) as count_area
            from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where (a.CreateTime between $start and $end) and (b.UID=$uid or b.ShangJiUID=$uid or b.ShangShangJiUID=$uid)";
        
        $count_countshouru_all = $User->query($sql);
        $count_countshouru = $count_countshouru_all[0]['count'];
        if(!$count_countshouru){$count_countshouru=0;}
        //总的代理收入
        $count_dailishouru=$count_countshouru_all[0]['count_daili'];
        if(!$count_dailishouru){$count_dailishouru=0;}
        
        //总的运营商收入
        $count_agentshouru=$count_countshouru_all[0]['count_agent'];
        if(!$count_agentshouru){$count_agentshouru=0;}
        //总的运营商收入
        $count_areashouru= $count_countshouru_all[0]['count_area'];
        if(!$count_areashouru){$count_areashouru=0;}
        //平台总收入
        $count_pingtai=$count_countshouru*0.9-$count_dailishouru-$count_agentshouru-$count_areashouru;
        if(!$count_pingtai){$count_pingtai=0;}
        //单个代理的收入
        $sql1 = "select sum(b.ShouYi) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where (a.CreateTime between $start and $end) and b.UID=$uid";
        $sql2 = "select sum(b.ShangJiShouYi) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where (a.CreateTime between $start and $end) and b.ShangJiUID=$uid";
        $sql3 = "select sum(b.ShangShangJiShouYi) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where (a.CreateTime between $start and $end) and b.ShangShangJiUID=$uid";
        
        $count_user1=$User->query($sql1);
        $count_user2=$User->query($sql2);
        $count_user3=$User->query($sql3);
        $count_user= $count_user1[0]['count']+$count_user2[0]['count']+$count_user3[0]['count'];
        if(!$count_user){$count_user=0;}
        $search = array(
            'start'=>$startTime,
            'end'=>$endTime
        );
        $countshouru = array(
            //'count_yugushouru'=>round($count_yugushouru,2),//总预估收入
            'count_dailishouru'=>$count_dailishouru,//代理总收入
            'count_pingtai'=>$count_pingtai, //平台总收入
            'count_countshouru'=>$count_countshouru,
            'count_fuwufei' => $count_countshouru*0.1,
            'count_agentshouru'=>$count_agentshouru,
            'count_areashouru'=>$count_areashouru,
            //单个代理的收入
            'count_user'=>$count_user
        );
        $this->assign('search',$search);
        $this->assign('countshouru',$countshouru);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $user = M('wx_user')->where(array('ID'=>$uid))->find();
        $this->assign('user',$user);
        $this->display();
    }
    /*
     * 查询下级有奖励的用户
     * */
    public function xiaji_list(){
        $uid = I('uid');
        $p = I('p',1);
        $num = 20;
        $User = M('wx_user'); // 实例化User对象
        $sql = "select count(*) as count from daili_b_jiangli as a left join daili_wx_user as b on a.XiaJiUID=b.ID where a.UID=$uid";
        //echo $sql;exit;
        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count=$count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        $sql = "select b.*, 
        a.Money as b_money,
        a.Time as b_time
        from daili_b_jiangli as a left join daili_wx_user as b on a.XiaJiUId=b.ID where a.UID=$uid order by a.ID desc limit $start,$num";
        //echo $sql;exit;
        $list = $User->query($sql);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->display();
    }
    /*
     * 代理用户订单列表
     * */
    public function order_list(){
        $ordernum = I('ordernum','','trim');
        $user = $this->user;
        $uid = $user['id'];
        $qd = I('qudao');
        $start_time = I('start');
        $end_time   = I('end');
        $numid = I('numid');
        if($start_time && !$end_time){
            $start_str = strtotime($start_time);
            $where = " and a.CreateTime>=$start_str";
        }
        if($end_time && !$start_time){
            $end_str = strtotime($end_time)+3600*24;
            $where .= " and a.CreateTime<=$end_str";
        }
        if($start_time && $end_time){
            $start_str = strtotime($start_time);
            $end_str=strtotime($end_time)+3600*24;
            $where .= " and a.CreateTime between $start_str and $end_str";
        }
        if($qd){
            $search_token = '"'.$qd.'"';
        }else{
            $search_token=$this->str_t;
        }
        if(!empty($ordernum)){
            $where .= " and a.OrderNum=".$ordernum;
        }

        if(!empty($numid)){
            $where .= " and a.ItemID=".$numid;
        }

        $p = I('p',1);
        $num = 20;
        $start = ($p-1)*$num;
        $User = M('a_order');
        $sql = "select count(*) as count from daili_a_order as a 
        left join daili_a_shouyi as b on a.ID = b.OrderID left join daili_wx_user as c on c.ID = b.UID 
         where c.GzhToken in ($search_token)".$where;
        S('where_order_list_token',$search_token);
        S('where_order_list_where',$where);
        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count=$count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $sql = "select a.*,
            a.MediaName as b_name from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID left join daili_wx_user as c on c.ID = b.UID where  c.GzhToken in ($search_token) $where order by a.CreateTime desc limit $start,$num
            ";
        $list=$User->query($sql);
        foreach ($list as $key=>$val){
            $iteminfo=get_item_infos($val['itemid']);
            $list[$key]['pic']=$iteminfo['pict_url'];
        }
        $search = array(
            'qudao'=>$qd,
            'ordernum'=>$ordernum,
            'start'=>$start_time,
            'end'=>$end_time,
            'numid'=>$numid,
        );
        $this->assign('search',$search);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->display();
    }

    /*
     * 添加代理用户订单
     * */
    public function add_order(){
        if(IS_POST){
            $user = $this->user;
            $data = array();
            //验证传递过来的参数是否为空
            $data += array(
                'CreateTime'=>strtotime(I('post.createtime','','trim')),
                'ClickTime'=>strtotime(I('post.clicktime','','trim')),
                'Title'=>I('post.title','','trim'),
                'ItemID'=>I('post.itemid','','trim'),
                'ShopUser'=>I('post.shopuser','','trim'),
                'ShopName'=>I('post.shopname','','trim'),
                'ItemNum'=>I('post.itemnum','0','trim'),
                'Price'=>I('post.price','0.00','floatval'),
                'OrderStatue'=>I('post.orderstatue','','trim'),
                'OrderType'=>I('post.ordertype','','trim'),
                'ShouRuBi'=>I('post.shourubi','','floatval'),
                'FenChengBi'=>I('post.fenchengbi','','floatval'),
                'Pay'=>I('post.pay','0.00','floatval'),
                'XiaoGuoYuGu'=>I('post.xiaoguoyugu','0.00','floatval'),
                'JieSuanJinE'=>I('post.jiesuanjine','0.00','floatval'),
                'YuGuShouRu'=>I('post.yugushouru','0.00','floatval'),
                'CompleteTime'=>strtotime(I('post.completetime','','trim')),
                'YongJinBi'=>I('post.yongjinbi','0.00','floatval'),
                'YongJinJinE'=>I('post.yongjinjine','0.00','floatval'),
                'BuTieBi'=>I('post.butiebi','0.00','floatval'),
                'BuTieJinE'=>I('post.butiejine','0.00','floatval'),
                'BuTieType'=>I('post.butietype','','trim'),
                'ChengJiaoPingTai'=>I('post.chengjiaopingtai','','trim'),
                'ThirdFuWu'=>I('post.thirdfuwu','','trim'),
                'OrderNum'=>I('post.ordernum','','trim'),
                'Cate'=>I('post.cate','','trim'),
                'MediaID'=>I('post.mediaid','','trim'),
                'MediaName'=>I('post.medianame','','trim'),
                'AdID'=>I('post.adid','','trim'),
                'AdName'=>I('post.adname','','trim')
            );
            //验证当前订单号是否已经存在数据库（用于添加相同订单号的多笔订单）
            $order_info = M('a_order')->where(array('OrderNum'=>$data['OrderNum']))->order('Num desc')->select();
            $num = $order_info[0]['num']==""?1:($order_info[0]['num']+1);
            //查询当前订单所属渠道
            $qd_id = M('a_media')->where(array('nick_name'=>$data['MediaName']))->getField('id');
            if(empty($qd_id)){
                $this->ajaxReturn(
                    array(
                        'code'=>0,
                        'msg'=>'匹配不到渠道，请检查媒体名称是否正确'
                    )
                );exit;
            }
            //验证当前订单的状态
            if($data['OrderStatue']=='订单付款'){
                $shouyistatue = 1;
            }elseif($data['OrderStatue']=='订单结算'){
                $shouyistatue = 1;
            }elseif($data['OrderStatue']=='订单失效'){
                $shouyistatue = -1;
            }else{
                $this->ajaxReturn(
                    array(
                        'code'=>0,
                        'msg'=>'订单状态异常，请检查'
                    )
                );exit;
            }

            //获取当前订单的用户所属渠道的配置项
            $field = "daili_a_config_copy.ShouYiBi,daili_a_config_copy.ShangJiShouYiBi,daili_wx_user.ID,daili_wx_user.Pid";
            $join = " left join daili_a_media on daili_wx_user.GzhToken=daili_a_media.token left join daili_a_config_copy on daili_a_media.id=daili_a_config_copy.MediaID";
            $where = array('daili_wx_user.Phone'=>$data['AdName'],'daili_wx_user.MediaName'=>$data['MediaName']);
            $config = M('wx_user')->field($field)->where($where)->join($join)->find();
            if(empty($config)){
                $this->ajaxReturn(array('code'=>0,'msg'=>'匹配不到配置表信息，请检查广告位名称与来源媒体名称'));
            }
            $data+=array(
                'ShouYiStatue'=>$shouyistatue,
                'IMG'=>'',
                'Num'=>$num
            );

            //查询收益相关信息
            $infos = get_shouyi_info($data['XiaoGuoYuGu'],$data['MediaID'],$data['AdID']);
            if(empty($infos)){
                $this->ajaxReturn(
                    array(
                        'code'=>0,
                        'msg'=>'获取各个收益数据失败，请重试！'
                    )
                );
            }

            $order = M('a_order');
            $shouyi = M('a_shouyi');
            $wx_user = M('wx_user');
            //添加订单到订单表
            $res = $order->add($data);
            if($res){
                //检测是否是失效订单，如果不是，更新用户表用户的节省金额字段
                if($data['OrderStatue']!='订单失效'){
                    $item_info = get_item_infos($data['ItemID'],1);
                    $q_je = $item_info['zk_final_price']*$data['ItemNum']-$data['Pay'];
                    $q_w = array(
                        'ID'=>$config['id']
                    );
                    if($q_je<0){
                        $q_je=0;
                    }
                    M('wx_user')->where($q_w)->setInc('save_money',$q_je);
                }

                M('a_order_log')->add(
                    array(
                        'edit_time'=>time(),
                        'edit_userid'=>$user['id'],
                        'data'=>'添加订单号'.$data['OrderNum'].'成功，订单编号：'.$res.'数据：'.json_encode($data)
                    ));
                //添加数据到收益表
                $shouyi->add(
                    array(
                        'OrderID'=>$res,
                        'CreateTime'=>($data['CreateTime']),
//                        'UID'=>$config['id'],
//                        'ShouYi'=>0.9*$config['shouyibi']*$data['XiaoGuoYuGu']/100,
//                        'ShangJiUID'=>$config['pid'],
//                        'ShangJiShouYi'=>0.9*$config['shangjishouyibi']*$data['XiaoGuoYuGu']/100,
                        'UID'=>$infos['uid'],
                        'ShouYi'=>$infos['shouyi'],
                        'ShangJiUID'=>$infos['shangjiuid'],
                        'ShangJiShouYi'=>$infos['shangjishouyi'],
                        'ShangShangJiUID'=>$infos['shangshangjiuid'],
                        'ShangShangJiShouYi'=>$infos['shangshangjishouyi'],
                        'agent_id'=>$infos['agent_id'],
                        'agent_shouyi'=>$infos['agent_shouyi'],
                        'shangji_agent_id'=>$infos['shangji_agent_id'],
                        'shangji_agent_shouyi'=>$infos['shangji_agent_shouyi'],
                        'area_id'=>$infos['area_id'],
                        'area_shouyi'=>$infos['area_shouyi'],
                        'OrderStatue'=>1
                    )
                );
                M('a_order_log')->add(
                    array(
                        'edit_time'=>time(),
                        'edit_userid'=>$user['id'],
                        'data'=>'添加收益数据成功，订单编号：'.$res.'数据：'.json_encode( array(
                                'OrderID'=>$res,
                                'CreateTime'=>($data['CreateTime']),
                                'UID'=>$infos['uid'],
                                'ShouYi'=>$infos['shouyi'],
                                'ShangJiUID'=>$infos['shangjiuid'],
                                'ShangJiShouYi'=>$infos['shangjishouyi'],
                                'ShangShangJiUID'=>$infos['shangshangjiuid'],
                                'ShangShangJiShouYi'=>$infos['shangshangjishouyi'],
                                'agent_id'=>$infos['agent_id'],
                                'agent_shouyi'=>$infos['agent_shouyi'],
                                'shangji_agent_id'=>$infos['shangji_agent_id'],
                                'shangji_agent_shouyi'=>$infos['shangji_agent_shouyi'],
                                'area_id'=>$infos['area_id'],
                                'area_shouyi'=>$infos['area_shouyi'],
                                'OrderStatue'=>1
                            ))
                    ));
                if($data['OrderStatue']=='订单结算'){
                    //查询当前订单所属用户的信息，以及上级、上上级、运营商、区域合伙人的用户的信息，同步更新这些用户的余额
                    $yu_e = $wx_user->where(array('ID'=>$infos['uid']))->getField('YuE');
                    $shangji_yu_e = $wx_user->where(array('ID'=>$infos['shangjiuid']))->getField('YuE');
                    $shangshangji_yue = $wx_user->where(array('ID'=>$infos['shangshangjiuid']))->getField('YuE');
                    $agent_yue = $wx_user->where(array('ID'=>$infos['agent_id']))->getField('YuE');
                    $shangji_agent_yue = $wx_user->where(array('ID'=>$infos['shangji_agent_id']))->getField('YuE');
                    $area_yue = $wx_user->where(array('ID'=>$infos['area_id']))->getField('YuE');

                    $wx_user->where(array('ID'=>$infos['uid']))->save(array('YuE'=>($yu_e+$infos['shouyi'])));
                    $wx_user->where(array('ID'=>$infos['shangjiuid']))->save(array('YuE'=>($shangji_yu_e+$infos['shangjishouyi'])));
                    $wx_user->where(array('ID'=>$infos['shangshangjiuid']))->save(array('YuE'=>($shangshangji_yue+$infos['shangshangjishouyi'])));
                    $wx_user->where(array('ID'=>$infos['agent_id']))->save(array('YuE'=>($agent_yue+$infos['agent_shouyi'])));
                    $wx_user->where(array('ID'=>$infos['shangji_agent_id']))->save(array('YuE'=>($shangji_agent_yue+$infos['shangji_agent_shouyi'])));
                    $wx_user->where(array('ID'=>$infos['area_id']))->save(array('YuE'=>($area_yue+$infos['area_shouyi'])));

                    M('a_order_log')->add(
                        array(
                            'edit_time'=>time(),
                            'edit_userid'=>$user['id'],
                            'data'=>'添加结算订单收益数据成功，订单编号：'.$res.'数据：'.json_encode( array(
                                    'uid'=>$infos['uid'],
                                    'shangjiuid'=>$infos['shangjiuid'],
                                    'uid_old_yue'=>$yu_e,
                                    'uid_yue'=>($yu_e+$infos['shouyi']),
                                    'shangjiuid_old_yue'=>$shangji_yu_e,
                                    'shangjiuid_yue'=>($shangji_yu_e+$infos['shangjishouyi']),
                                    'shangshangji_old_yue'=>$shangshangji_yue,
                                    'shangshangji_yue'=>($shangshangji_yue+$infos['shangshangjishouyi']),
                                    'agent_old_yue'=>$agent_yue,
                                    'agent_yue'=>($agent_yue+$infos['agent_shouyi']),
                                    'shangji_agent_old_yue'=>$shangji_agent_yue,
                                    'shangji_agent_yue'=>($shangji_agent_yue+$infos['shangji_agent_shouyi']),
                                    'area_old_yue'=>$area_yue,
                                    'area_yue'=>($area_yue+$infos['area_shouyi']),
                                    'ordernum'=>$data['OrderNum'],
                                    'orderid'=>$res,
                                ))
                        ));
                    $this->ajaxReturn(array(
                        'msg'=>"订单添加完成，同步收益成功，余额更新成功",
                        'code'=>1
                    ));
                }else{
                    $this->ajaxReturn(array(
                        'msg'=>"订单添加完成，添加收益表数据成功",
                        'code'=>1
                    ));
                }
            }else{
                $this->ajaxReturn(
                    array(
                        'code'=>0,
                        'msg'=>'订单添加失败，请重试！'
                    )
                );
            }
        }else{
            $this->display();
        }
    }



    //更新订单操作日志
    public function add_order_log($data){
        M('a_order_log')->add(
            array(
                'edit_time'=>time(),
                'edit_userid'=>$data['edit_userid'],
                'data'=>json_encode(array(
                    'uid'=>$data['uid'],
                    'shangjiuid'=>$data['shangjiuid'],
                    'uid_old_yue'=>$data['uid_old_yue'],
                    'shangjiuid_old_yue'=>$data['shangjiuid_old_yue'],
                    'uid_yue'=>$data['uid_yue'],
                    'shangjiuid_yue'=>$data['shangjiuid_yue'],
                    'ordernum'=>$data['ordernum'],
                    'orderid'=>$data['orderid']
                ))
            )
        );
    }

    /**
     * 系统收入情况显示页面
     * */
    public function shouru1(){
        $user = $this->user;
        $uid = $user['id'];
        //根据用户ID查询，有权限的媒体
        //根据用户id查询有权限的媒体
        $qd = I('qudao');
        $sql = "select b.* from daili_b_group_media as a left join daili_a_media as b on a.MediaId=b.ID where a.UID = $uid";
        $q = M('b_group_media')->query($sql);
        $this->assign('qudao',$q);
        if($qd){
            $sql = M('a_media')->where(array('id'=>$qd))->find();
            $str_mediaID=$sql['media_id'];
        }else{
            if($q){
                foreach ($q as $val){
                    $str_mediaID .= $val['media_id'].',';
                }
                $str_mediaID = rtrim($str_mediaID,',');
            }
        }
        $order_num = str_replace(' ','',I('order_num'));
        if($order_num){
            $where = "a.OrderNum like '%".$order_num."%' and ";
            $this->assign('order_num',$order_num);
        }
        $startTime = I('start');
        $endTime   = I('end');

        $js_startTime = I('js_start');
        $js_endTime   = I('js_end');
        
        if(!$js_startTime && !$js_endTime){
            if(!$startTime){
                $startTime = date('Y-m-d',time());
            }
            if(!$endTime){
                $endTime = date('Y-m-d',time());
            } 
        }
        if($startTime && empty($endTime)){
            $str_starttime = strtotime($startTime);
            $where_t0 = " a.CreateTime>=$str_starttime";
        }
        if($endTime && empty($startTime)){
            $str_endtime = strtotime($endTime)+3600*24-1;
            $where_t0 = " a.CreateTime<=$str_endtime";
        }
        if($startTime && $endTime){
            $str_starttime = strtotime($startTime);
            $str_endtime = strtotime($endTime)+3600*24-1;
            $where_t0=" a.CreateTime between $str_starttime and $str_endtime";;
        }
        //$end   = strtotime($endTime)+24*3600;
        //S('shouru_start',$start);
        //S('shouru_end',$end);
        if($where_t0){
            $where .=$where.$where_t0.' and';
        }
        if($js_startTime && empty($js_endTime)){
            $str_js_starttime = strtotime($js_startTime);
            $where_t1 = " a.CompleteTime>=$str_js_starttime";
        }
        if($js_endTime && empty($js_startTime)){
            $str_js_endtime = strtotime($js_endTime)+3600*24-1;
            $where_t1 = " a.CompleteTime between 1493913600 and $str_js_endtime";
        }
        if($js_startTime && $js_endTime){
            $str_js_starttime = strtotime($js_startTime);
            $str_js_endtime = strtotime($js_endTime)+3600*24-1;
            $where_t1=" a.CompleteTime between $str_js_starttime and $str_js_endtime";;
        }
        
        if($where_t1){
            $where .=$where.$where_t1.' and ';
        }
        if($where){
            S('shouru_where',$where);
        }else{
            S('shouru_where',null);
        }
        $p = I('p',1);
        $num = 20;
        $startnum = ($p-1)*$num;
        $User = M('a_order'); // 实例化User对象
        //查询失效订单数据
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where $where a.OrderStatue='订单失效' and a.MediaId in($str_mediaID)";
        $count_shixiao      = $User->query($sql);// 查询满足要求的总记录数
        $count_shixiao      = $count_shixiao[0]['count'];
        $this->assign('count_shixiao',$count_shixiao);
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where $where a.MediaId in($str_mediaID)";
        
        $count      = $User->query($sql);// 查询满足要求的总记录数
        
        $count = $count[0]['count'];
        $this->assign('count_youxiao',$count-$count_shixiao);
        
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        
        $sql = "select a.*,
        a.XiaoGuoYuGu*0.9 as a_xiaoguoyugu,
        b.ID as b_id,
        b.UID as b_uid,
        b.OrderID as b_orderid,
        b.CreateTime as b_createtime,
        b.ShouYi as b_shouyi,
        b.ShangJiUID as b_shangjiuid,
        b.ShangJiShouYi as b_shangjishouyi,
        b.ShangShangJiUID as b_shangshangjiuid,
        b.ShangShangJiShouYi as b_shangshangjishouyi,
        b.OrderStatue as b_orderstatue
        from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where $where a.MediaId in($str_mediaID) order by a.CreateTime desc limit $startnum,$num";
        //echo $sql;exit;
        $list=$User->query($sql);
        //总预估收入
        $count_yugushouru = 0;
        //代理总收入
        $count_dailishouru=0;
        foreach ($list as $key=>$val){
            $uid = $val['b_uid'];
            $shangji_uid = $val['b_shangjiuid'];
            $shangshangji_uid = $val['b_shangshangjiuid'];
            if($uid){
                $user = M('wx_user')->where(array('ID'=>$uid))->find();
                $list[$key]['b_user']=$user['name'];
                $list[$key]['b_user_phone']=$user['phone'];
            }
            if($shangji_uid){
                $shangjiuser = M('wx_user')->where(array('ID'=>$shangji_uid))->find();
                $list[$key]['b_shangjiuser']=$shangjiuser['name'];
                $list[$key]['b_shangjiuser_phone']=$shangjiuser['phone'];
            }
            if($shangshangji_uid){
                $shangshangjiuser = M('wx_user')->where(array('ID'=>$shangshangji_uid))->find();
                $list[$key]['b_shangshangjiuser']=$shangshangjiuser['name'];
                $list[$key]['b_shangshangjiuser_phone']=$shangshangjiuser['phone'];
            }
            $pingtaishouyi = $val['a_xiaoguoyugu']-$val['b_shouyi']-$val['b_shangjishouyi']-$val['b_shangshangjishouyi'];
            $list[$key]['pingtaishouyi']=$pingtaishouyi;
        }
        
        //总的佣金收入
        $sql = "select sum(XiaoGuoYuGu) as count from daili_a_order as a where $where a.MediaId in($str_mediaID)";
        
        $count_countshouru = $User->query($sql);
        $count_countshouru = $count_countshouru[0]['count'];
        if(!$count_countshouru){$count_countshouru=0;}
        //总的代理收入
        $sql = "select sum(b.ShouYi)+sum(b.ShangJiShouYi)+sum(b.ShangShangJiShouYi) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where a.MediaId in($str_mediaID)";
       
        $count_dailishouru=$User->query($sql);
        $count_dailishouru= $count_dailishouru[0]['count'];
        if(!$count_dailishouru){$count_dailishouru=0;}
        //平台总收入
        $count_pingtai=$count_countshouru*0.9-$count_dailishouru;
        if(!$count_pingtai){$count_pingtai=0;}
        $search = array(
            'start'=>$startTime,
            'end'=>$endTime,
            'qudao'=>$qd,
            'js_start'=>$js_startTime,
            'js_end'=>$js_endTime
        );
        $countshouru = array(
            //'count_yugushouru'=>round($count_yugushouru,2),//总预估收入
            'count_dailishouru'=>$count_dailishouru,//代理总收入
            'count_pingtai'=>$count_pingtai, //平台总收入
            'count_countshouru'=>$count_countshouru,
            'count_fuwufei' => $count_countshouru*0.1
        );
        $this->assign('search',$search);
        $this->assign('countshouru',$countshouru);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->display();
    }
    /**
     * 系统收入情况显示页面
     * */
    public function shouru(){
        $user = $this->user;
        $uid = $user['id'];
        $qd = I('qudao');
        
        /* $token = $user['token'];
        if($token){
            $media = M('a_media')->where(array('token'=>$token))->select();
        }else{
            $media = M('a_media')->order('id desc')->select();
        }
        $this->assign('qudao',$media); */
        /* if($qd){
            $sql = M('a_media')->where(array('id'=>$qd))->find();
            $search_token="'".$sql['token']."'";
        }else{
            foreach ($q as $val){
                $search_token .= "'".$val['token']."',";
            }
            $search_token = rtrim($search_token,',');
        } */
        if($qd){
            $search_token = "'".$qd."'";
        }else{
            $search_token = $this->str_t;
        }
       
        $order_num = str_replace(' ','',I('order_num'));
        if($order_num){
            $where = "a.OrderNum like '%".$order_num."%' and ";
            $this->assign('order_num',$order_num);
        }
        $startTime = I('start');
        $endTime   = I('end');
    
        $js_startTime = I('js_start');
        $js_endTime   = I('js_end');
    
        if(!$js_startTime && !$js_endTime){
            if(!$startTime){
                $startTime = date('Y-m-d',time());
            }
            if(!$endTime){
                $endTime = date('Y-m-d',time());
            }
        }
        if($startTime && empty($endTime)){
            $str_starttime = strtotime($startTime);
            $where_t0 = " a.CreateTime>$str_starttime";
        }
        if($endTime && empty($startTime)){
            $str_endtime = strtotime($endTime)+3600*24-1;
            $where_t0 = " a.CreateTime<$str_endtime";
        }
        if($startTime && $endTime){
            $str_starttime = strtotime($startTime);
            $str_endtime = strtotime($endTime)+3600*24;
            $where_t0=" a.CreateTime between $str_starttime and $str_endtime";;
        }
        //$end   = strtotime($endTime)+24*3600;
        //S('shouru_start',$start);
        //S('shouru_end',$end);
        if($where_t0){
            $where .=$where.$where_t0.' and';
        }
        if($js_startTime && empty($js_endTime)){
            $str_js_starttime = strtotime($js_startTime);
            $where_t1 = " a.CompleteTime>=$str_js_starttime";
        }
        if($js_endTime && empty($js_startTime)){
            $str_js_endtime = strtotime($js_endTime)+3600*24-1;
            $where_t1 = " a.CompleteTime between 1493913600 and $str_js_endtime";
        }
        if($js_startTime && $js_endTime){
            $str_js_starttime = strtotime($js_startTime);
            $str_js_endtime = strtotime($js_endTime)+3600*24-1;
            $where_t1=" a.CompleteTime between $str_js_starttime and $str_js_endtime";;
        }
    
        if($where_t1){
            $where .=$where.$where_t1.' and ';
        }
        if($where){
            S('shouru_where',$where);
        }else{
            S('shouru_where',null);
        }
        S('search_token',$search_token);
        $p = I('p',1);
        $num = 20;
        $startnum = ($p-1)*$num;
        $User = M('a_order'); // 实例化User对象
        //查询失效订单数据
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on b.OrderID = a.ID left join daili_wx_user as c on c.ID=b.UID where $where a.OrderStatue='订单失效' and c.GzhToken in ($search_token)";
        $count_shixiao      = $User->query($sql);// 查询满足要求的总记录数
        $count_shixiao      = $count_shixiao[0]['count'];
        $this->assign('count_shixiao',$count_shixiao);
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on b.OrderID = a.ID left join daili_wx_user as c on c.ID=b.UID where $where c.GzhToken in ($search_token)";
    
        $count      = $User->query($sql);// 查询满足要求的总记录数
    
        $count = $count[0]['count'];
        $this->assign('count_youxiao',$count-$count_shixiao);
    
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        
        $sql = "select a.*,
        a.XiaoGuoYuGu*0.9 as a_xiaoguoyugu,
        b.ID as b_id,
        b.UID as b_uid,
        b.OrderID as b_orderid,
        b.CreateTime as b_createtime,
        b.ShouYi as b_shouyi,
        b.ShangJiUID as b_shangjiuid,
        b.ShangJiShouYi as b_shangjishouyi,
        b.ShangShangJiUID as b_shangshangjiuid,
        b.ShangShangJiShouYi as b_shangshangjishouyi,
        b.OrderStatue as b_orderstatue,
        b.agent_id as b_agent_id,
        b.agent_shouyi as b_agent_shouyi,
        b.shangji_agent_id as b_shangji_agent_id,
        b.shangji_agent_shouyi as b_shangji_agent_shouyi,
        b.area_id as b_area_id,
        b.area_shouyi as b_area_shouyi,
        c.kefu_id as c_kefu_id
        from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID left join daili_wx_user as c on c.ID=b.UID where $where c.GzhToken in($search_token) order by a.CreateTime desc limit $startnum,$num";
        //echo $sql;exit;
        $list=$User->query($sql);
        //echo '<pre>';
        //print_r($list);exit;
        //总预估收入
        $count_yugushouru = 0;
        //代理总收入
        $count_dailishouru=0;
        foreach ($list as $key=>$val){
            $uid = $val['b_uid'];
            $shangji_uid = $val['b_shangjiuid'];
            $shangshangji_uid = $val['b_shangshangjiuid'];
            $agent_id = $val['b_agent_id'];
            $shangji_agent_id = $val['b_shangji_agent_id'];
            $area_id = $val['b_area_id'];
            if($uid){
                $user = M('wx_user')->where(array('ID'=>$uid))->find();
                $list[$key]['b_user']=$user['name'];
                $list[$key]['b_user_phone']=$user['phone'];
            }
            if($shangji_uid){
                $shangjiuser = M('wx_user')->where(array('ID'=>$shangji_uid))->find();
                $list[$key]['b_shangjiuser']=$shangjiuser['name'];
                $list[$key]['b_shangjiuser_phone']=$shangjiuser['phone'];
            }
            if($shangshangji_uid){
                $shangshangjiuser = M('wx_user')->where(array('ID'=>$shangshangji_uid))->find();
                $list[$key]['b_shangshangjiuser']=$shangshangjiuser['name'];
                $list[$key]['b_shangshangjiuser_phone']=$shangshangjiuser['phone'];
            }
            if($agent_id){
                $agentuser = M('wx_user')->where(array('ID'=>$agent_id))->find();
                $list[$key]['b_agentuser']=$agentuser['name'];
                $list[$key]['b_agentuser_phone']=$agentuser['phone'];
            }
            if($shangji_agent_id){
                $shangjiagentuser = M('wx_user')->where(array('ID'=>$shangji_agent_id))->find();
                $list[$key]['b_shangjiagentuser']=$shangjiagentuser['name'];
                $list[$key]['b_shangjiagentuser_phone']=$shangjiagentuser['phone'];
            }
            if($area_id){
                $areauser = M('wx_user')->where(array('ID'=>$area_id))->find();
                $list[$key]['b_areauser']=$areauser['name'];
                $list[$key]['b_areauser_phone']=$areauser['phone'];
            }
            $pingtaishouyi = $val['a_xiaoguoyugu']-$val['b_shouyi']-$val['b_shangjishouyi']-$val['b_shangshangjishouyi']-$val['b_agent_shouyi']-$val['b_shangjiagent_shouyi']-$val['b_area_shouyi'];
            $list[$key]['pingtaishouyi']=$pingtaishouyi;
        }
    
        //总的佣金收入
        $sql = "select sum(a.XiaoGuoYuGu) as count from daili_a_order as a left join daili_a_shouyi as b on b.OrderID=a.ID left join daili_wx_user as c on c.ID=b.UID where $where c.GzhToken in($search_token)";
        
        $count_countshouru = M('a_shouyi')->query($sql);
        
        $count_countshouru = $count_countshouru[0]['count'];
        if(!$count_countshouru){$count_countshouru=0;}
        //查询客服的总收入
        $sql_a = "select sum(b.ShouYi) as count_a from daili_a_order as a left join daili_a_shouyi as b on b.OrderId=a.ID left join daili_wx_user as c on c.ID=b.UID where $where c.GzhToken in($search_token) and c.ID=c.kefu_id";
        $sql_b = "select sum(b.ShangJiShouYi) as count_b from daili_a_order as a left join daili_a_shouyi as b on b.OrderId=a.ID left join daili_wx_user as c on c.ID=b.ShangJiUID where $where c.GzhToken in($search_token) and c.ID=c.kefu_id";
        $sql_c = "select sum(b.ShangShangJiShouYi) as count_c from daili_a_order as a left join daili_a_shouyi as b on b.OrderId=a.ID left join daili_wx_user as c on c.ID=b.ShangShangJiUID where $where c.GzhToken in($search_token) and c.ID=c.kefu_id";
        $count_a = M('a_order')->query($sql_a);
        $count_b = M('a_order')->query($sql_b);
        $count_c = M('a_order')->query($sql_c);
      
        $count_kefu = $count_a[0]['count_a']+$count_b[0]['count_b']+$count_c[0]['count_c'];
        
        //总的代理收入
        $sql_a = "select sum(b.ShouYi) as count_a from daili_a_order as a left join daili_a_shouyi as b on b.OrderID=a.ID left join daili_wx_user as c on c.ID=b.UID where $where c.GzhToken in($search_token)";
        $sql_b = "select sum(b.ShangJiShouYi) as count_b from daili_a_order as a left join daili_a_shouyi as b on b.OrderID=a.ID left join daili_wx_user as c on c.ID=b.ShangJiUID where $where c.GzhToken in($search_token)";
        $sql_c = "select sum(b.ShangShangJiShouYi) as count_c from daili_a_order as a left join daili_a_shouyi as b on b.OrderID=a.ID left join daili_wx_user as c on c.ID=b.ShangShangJiUID where $where c.GzhToken in($search_token)";
        $count_dailishouru_a=$User->query($sql_a);
        $count_dailishouru_b=$User->query($sql_b);
        $count_dailishouru_c=$User->query($sql_c);
        $count_dailishouru= $count_dailishouru_a[0]['count_a']+$count_dailishouru_b[0]['count_b']+$count_dailishouru_c[0]['count_c'];
        
        //总的运营商收入
        $sql_a = "select sum(b.agent_shouyi) as count_a from daili_a_order as a left join daili_a_shouyi as b on b.OrderID=a.ID left join daili_wx_user as c on c.ID=b.agent_id where $where c.GzhToken in($search_token)";
        $sql_b = "select sum(b.shangji_agent_shouyi) as count_b from daili_a_order as a left join daili_a_shouyi as b on b.OrderID=a.ID left join daili_wx_user as c on c.ID=b.shangji_agent_id where $where c.GzhToken in($search_token)";
        $count_agentshouru_a=$User->query($sql_a);
        $count_agentshouru_b=$User->query($sql_b);
        $count_agentshouru= $count_agentshouru_a[0]['count_a']+$count_agentshouru_b[0]['count_b'];
        
        //总的区域代理收入
        $sql_a = "select sum(b.area_shouyi) as count_a from daili_a_order as a left join daili_a_shouyi as b on b.OrderID=a.ID left join daili_wx_user as c on c.ID=b.area_id where $where c.GzhToken in($search_token)";
        $count_areashouru_a=$User->query($sql_a);
        $count_areashouru= $count_areashouru_a[0]['count_a'];
        if(!$count_areashouru){
            $count_areashouru=0;
        }
        if(!$count_dailishouru){$count_dailishouru=0;}
        //平台总收入
        $count_pingtai=$count_countshouru*0.9-$count_dailishouru-$count_agentshouru-$count_areashouru;
        if(!$count_pingtai){$count_pingtai=0;}
        $search = array(
            'start'=>$startTime,
            'end'=>$endTime,
            'qudao'=>$qd,
            'js_start'=>$js_startTime,
            'js_end'=>$js_endTime
        );
        $countshouru = array(
            //'count_yugushouru'=>round($count_yugushouru,2),//总预估收入
            'count_dailishouru'=>$count_dailishouru-$count_kefu,//代理总收入
            'count_pingtai'=>$count_pingtai+$count_kefu, //平台总收入
            'count_countshouru'=>$count_countshouru,
            'count_fuwufei' => $count_countshouru*0.1,
            'count_kefu'=>$count_kefu,
            'count_agentshouru'=>$count_agentshouru,
            'count_areashouru'=>$count_areashouru
        );
        $this->assign('search',$search);
        $this->assign('countshouru',$countshouru);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->display();
    }
    /**
     * 用户提现显示页面
     * */
    public function tixian(){
        $user = $this->user;
        $uid = $user['id'];
        $qd = I('qudao');
        if($qd){
            $search_token="'".$qd."'";
        }else{
            $search_token = $this->str_t;
        }
        
        $phone = str_replace(' ','',I('phone'));
        $start_time = I('start');
        $end_time   = I('end');
        $cz_start = I('cz_start');
        $cz_end   = I('cz_end');
        $statue   = I('statue');
        $p = I('p',1);
        $num = 50;
        $start = ($p-1)*$num;
        $where = "where b.GzhToken in ($search_token)";
        
        if($phone){
           $where .=" and b.Phone='$phone'";
        }
        if($start_time && !$end_time){
            $str_start_time = strtotime($start_time);
            $where .=" and a.Time>=$str_start_time";
        }
        if($end_time && !$start_time){
            $str_end_time = strtotime($end_time)+3600*24;
            $where .=" and a.Time<=$str_end_time";
         }
        if($start_time && $end_time){
            $str_start_time = strtotime($start_time);
            $str_end_time   = strtotime($end_time)+3600*24;
            $where .=" and (a.Time between $str_start_time and $str_end_time)";
        }
        if($cz_start && !$cz_end){
            $str_cz_start = strtotime($cz_start);
            $where .=" and a.operation_time>=$str_cz_start";
         }
        if($cz_end && !$cz_start){
            $str_cz_end = strtotime($cz_end)+3600*24;
            $where .=" and a.operation_time<=$str_cz_end";
        }
        if($cz_start && $cz_end){
            $str_cz_start = strtotime($cz_start);
            $str_cz_end   = strtotime($cz_end)+3600*24;
            $where .=" and a.operation_time between $str_cz_start and $str_cz_end";
        }
        if($statue==1){
            $where .=" and a.Statue=1";
        }elseif($statue==2){
            $where .=" and a.Statue=0";
        }elseif($statue==3){
            $where .=" and a.Statue=-1";
        }
        S('tixian_where',$where);
        $sql = "select count(*) as count from daili_a_tixian as a left join daili_wx_user as b on a.UID = b.ID $where";
        $count = M('a_tixian')->query($sql);
        $count = $count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        
        $sql = "select
        a.*,
        b.Name as b_name,
        b.MediaName as b_qudao,
        b.Alipay as b_alipay,
        b.Phone as b_phone
        from daili_a_tixian as a left join daili_wx_user as b on a.UID=b.ID $where order by id desc limit $start,$num";
        $list = M('a_tixian')->query($sql);
        $search = array(
            'start'=>$start_time,
            'end'=>$end_time,
            'qudao'=>$qd,
            'cz_start'=>$cz_start,
            'cz_end'=>$cz_end,
            'phone'=>$phone,
            'statue'=>$statue
        );
        //查询提现成功金额
        if($where){
            $w1 = $where.' and a.Statue=1';
            $w2 = $where.' and a.Statue=0';
        }else{
            $w1 = 'where a.Statue=1';
            $w2 = 'where a.Statue=0';
        }
        $sql = "select sum(a.JinE) as count from daili_a_tixian as a left join daili_wx_user as b on a.UID = b.ID $w1";
        //echo $sql;exit;
        $r = M('a_tixian')->query($sql);
        if($r[0]['count']){
            $r1 = $r[0]['count'];
        }else{
            $r1 = 0;
        }
        $this->assign('count_jine',$r1);
        //查询提现中金额
        $sql = "select sum(a.JinE) as count from daili_a_tixian as a left join daili_wx_user as b on a.UID = b.ID $w2";
        $r = M('a_tixian')->query($sql);
        if($r[0]['count']){
            $r2=$r[0]['count'];
        }else{
            $r2=0;
        }
        $this->assign('count_jine1',$r2);
        $this->assign('search',$search);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->display();
    }
    /**
     * 申请提现后
     * */
    public function tixian_order(){
        $id = I('id');
        //根据ID查询UId
        $res_tixian = M('a_tixian')->where(array('ID'=>$id))->find();
        $uid = $res_tixian['uid'];
        //查询上一次提现成功的时间
        $sql = "SELECT * FROM daili_a_tixian AS n WHERE n.ID < $id and n.UID=$uid and n.Statue=1 ORDER BY n.ID DESC  LIMIT 0,1";
        $res_last_tixian = M('a_tixian')->query($sql);
        if($res_last_tixian){
            $last_time = $res_last_tixian[0]['time'];
        }else{
            $last_time = 0;
        }
        //根据两次提现的时间查询这期间创建的订单在提现后失效了的
        $this_time = $res_tixian['time'];
        $sql = "select b.* from daili_a_shouyi as a left join daili_a_order as b on a.OrderID=b.ID where (a.UID = $uid or a.ShangJiUID = $uid or a.ShangShangJiUid = $uid) and a.OrderStatue=-1 and a.UpdateTime <= $this_time and b.CreateTime between $last_time and $this_time order by b.ID desc";
        $res = M('a_shouyi')->query($sql);
        $this->assign('res',$res);
        $this->display();
    }
    /**
     * 后台用户管理页面
     * */
    public function user(){
        $p = I('p',1);
        $num = 20;
        $user = $this->user;
        $token = $user['token'];
        if($token){
            $w['_string']="token='$token'";
            $where ="where token='$token'";
        }else{
            $w='';
            $where='';
        }
        $User = M('user'); // 实例化User对象
        $count      = $User->where($w)->count();// 查询满足要求的总记录数
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        $sql = "select * from daili_user $where order by id asc limit $start,$num";
        $list = $User->query($sql);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->display();
    }
    /**
     * 后台系统配置
     * */
    public function config(){
        $str_t = $this->str_t;
        $sql = "select a.*,b.qudao_name,b.token from daili_a_config_copy as a left join daili_a_media as b on a.MediaID=b.id where b.token in ($str_t) order by a.ID asc";
        $res = M('a_config_copy')->query($sql);
        $this->assign('q',$res);
        $this->display();
    }
    //更多配置页面
    public function more_config(){
        if(IS_POST){
            $date = I('post.');
            $token = $date['token'];
            $path = getcwd().'/Application/Home/Conf/'.$token.'_conf.php';
            $file = fopen($path,'w');
            if($file){
                $save_arr = "<?php return ".var_export($date,true).";";
                $res = file_put_contents($path,$save_arr);
            }
            fclose($file);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'保存成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'保存失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $token = I('token');
            $file = getcwd().'/Application/Home/Conf/'.$token.'_conf.php';
            if(is_file($file)){
                $config = include($file);
                $this->assign('config',$config);
            }
            $this->assign('token',$token);
            $this->display();
        }
    }
    //服务端配置页面
    public function server_config(){
        if(IS_POST){
            $date = I('post.');
            $token = $date['token'];
            $path = getcwd().'/Application/Home/Conf/'.$token.'_server_conf.php';
            $file = fopen($path,'w');
            if($file){
                $save_arr = "<?php return ".var_export($date,true).";";
                $res = file_put_contents($path,$save_arr);
            }
            fclose($file);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'保存成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'保存失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $token = I('token');
            $file = getcwd().'/Application/Home/Conf/'.$token.'_server_conf.php';
            if(is_file($file)){
                $config = include($file);
                $this->assign('config',$config);
            }
            $this->assign('token',$token);
            $this->display();
        }
    }
    /**
     * 修改配置
     * */
    public function update_config(){
        if(IS_POST){
            $data = I('post.');
            $res = M('a_config_copy')->save($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'编辑成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'编辑失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $id = I('id');
            $res = M('a_config_copy')->where(array('ID'=>$id))->find();
            
            $this->assign('res',$res);
            $this->display();
        }
    }
    /**
     * 修改配置
     * */
    public function update_config_level(){
        if(IS_POST){
            $data = I('post.');
            $level = $data['level'];
            switch ($level){
                case 1:
                    $d=array(
                        'id'=>$data['id'],
                        'level1'=>$data['one'],
                        'level2'=>$data['two'],
                        'level3'=>$data['three'],
                        'yaoqingjiangli'=>$data['four'],
                        'zuiditixian'=>$data['five'],
                        'yaoqingmax'=>$data['six']
                    );
                    break;
                case 2:
                    $d=array(
                        'id'=>$data['id'],
                        'level1'=>$data['one'],
                        'level2'=>$data['two'],
                        'level3'=>$data['three'],
                        'yaoqingjiangli'=>$data['four'],
                        'zuiditixian'=>$data['five'],
                        'yaoqingmax'=>$data['six'],
                        'complete'=>$data['seven'],
                        'reward'=>$data['eight']
                    );
                    break;
                case 3:
                    $d=array(
                        'id'=>$data['id'],
                        'level1'=>$data['one'],
                        'level2'=>$data['two'],
                        'level3'=>$data['three'],
                        'yaoqingjiangli'=>$data['four'],
                        'zuiditixian'=>$data['five'],
                        'yaoqingmax'=>$data['six'],
                        'complete'=>$data['seven'],
                        'reward'=>$data['eight'],
                        'jianglibi'=>$data['nine']
                    );
                    break;
            }
            $res = M('wx_user_level')->save($d);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'编辑成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'编辑失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $id = I('id');
            $res = M('wx_user_level')->where(array('id'=>$id))->find();
    
            $this->assign('res',$res);
            $this->display();
        }
    }
    /**
     * 其他会员配置 
     */
    public function config_level(){
            $str_t = $this->str_t;
            $level=I('level');
            $str_t = $this->str_t;
            $sql = "select a.*,b.qudao_name from daili_wx_user_level as a left join daili_a_media as b on a.token=b.token where a.token in ($str_t) and a.member_level=$level order by a.id asc";
            $res = M('a_config_copy')->query($sql);
            $this->assign('q',$res);
            $this->assign('level',$level);
            $this->display();
    }
    /**
     * 后台转链接
     * */
    public function zhuanlian(){
        $user = $this->user;
        $uid = $user['id'];
        //根据用户id查询有权限的媒体
        $sql = "select b.* from daili_b_group_media as a left join daili_a_media as b on a.MediaId=b.ID where a.UID = $uid";
        $q = M('b_group_media')->query($sql);
        if($qudao_id){
            //根据媒体ID查询token得到where条件
            $media = M('a_media')->where(array('id'=>$qudao_id))->find();
            $where = 'GzhToken="'.$media['token'].'"';
        
        }else{
            if($q){
                //得到媒体下面公众号的token
                foreach ($q as $val){
                    $where .= 'GzhToken="'.$val['token'].'" or ';
                }
                $where = rtrim($where,' or ');
            }
        }
        $User = M('wx_user'); // 实例化User对象
        //$sql = "select * from daili_wx_user where ($where) and Statue=1";
        //$res      = $User->query($sql);// 查询满足要求的总记录数
       
        //$this->assign('user',$res);
        $this->display();
    }
    


    public function use_software(){
        $id = I('get.id');
        $info = M('wx_user')->where(array('ID'=>$id))->getField('IsUseSoftware');
        if($info == 0){
            M('wx_user')->where(array('ID'=>$id))->save(array('IsUseSoftware'=>1));
        }else{
            M('wx_user')->where(array('ID'=>$id))->save(array('IsUseSoftware'=>0));
        }
    }
    /**
     *设置用户为客服 
     */
    public function set_kefu(){
        $id = I('get.id');
        $is_kefu = I('is_kefu');
        $data = array(
            'ID'=>$id,
            'kefu_id'=>$id,
        );
        if($is_kefu==2){
            $info = M('wx_user')->where(array('ID'=>$id))->find();
            if($info['statue'] != 1){
                $arr = array(
                    'code'=>0,
                    'msg'=>'成为代理后才可设置为客服'
                );
                $this->ajaxReturn($arr);
            }
            $r = M('wx_user')->save($data);
        }else{
           
            $data = array(
                'ID'=>$id,
                'kefu_id'=>null
            );
            $r = M('wx_user')->save($data);
        }
        if($r){
            $this->update_kefu_id($id,$id);
            $arr = array(
                'code'=>1,
                'msg'=>'设置成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'设置失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //设置客服后将这个客服邀请的所有下级kefu_id设置为这个客服
    public function update_kefu_id($id,$kefu_id){
        //这个$id 为被设置的用户的ID，也是下级的kefu_id;
        $user = M('wx_user')->field('ID')->where(array('Pid'=>$id))->select();
        if($user){
            foreach($user as $key=>$val){
                $d = array(
                    'ID'=>$val['id'],
                    'kefu_id'=>$kefu_id
                );
                M('wx_user')->save($d);
                $this->update_kefu_id($val['id'],$kefu_id);
            }
        }
    }
    //后台管理员添加代理页面
    public function add_daili(){
        if(IS_POST){
            $wx_num = str_replace(' ','',I('wx_num'));
            $alipay = str_replace(' ','',I('alipay'));
            $name   = str_replace(' ','',I('name'));
            /* if(!$name){
                $arr = array('code'=>0,'msg'=>'代理姓名必填');
                $this->ajaxReturn($arr);
            } */
            
            $phone  = str_replace(' ','',I('phone'));
            if(!$phone){
                $arr = array('code'=>0,'msg'=>'代理手机号必填');
                $this->ajaxReturn($arr);
            }
            //判断手机号是否存在
            $r = M('wx_user')->where(array('Phone'=>$phone))->find();
            if($r){
                $arr = array('code'=>0,'msg'=>'手机号已经存在');
                $this->ajaxReturn($arr);
            }
            $invation_code=str_replace(' ','',I('invation_code'));
            if(!$invation_code){
                $arr = array('code'=>0,'msg'=>'邀请码必填');
                $this->ajaxReturn($arr);
            }
            $login_name=str_replace(' ','',I('login_name'));
            if(!$login_name){
                $arr = array('code'=>0,'msg'=>'用户登录账号必填');
                $this->ajaxReturn($arr);
            }
            $login_pass=str_replace(' ','',I('login_pass'));
            if(!$login_pass){
                $arr = array('code'=>0,'msg'=>'用户登录密码必填');
                $this->ajaxReturn($arr);
            }
            //判断登录名是否存在
            $a = M('wx_user')->where(array('username'=>$login_name))->find();
            if($a){
                $arr = array('code'=>0,'msg'=>'登录名已经存在');
                $this->ajaxReturn($arr);
            }
            //根据用户邀请码查询客服信息
            $i = M('wx_user')->where(array('invitation_code'=>$invation_code))->find();
            if(!$i){
                $arr = array('code'=>0,'msg'=>'邀请码不存在');
                $this->ajaxReturn($arr);
            }
            $member_level=$i['member_level'];
            if($member_level==2){
                $member_agent=$i['id'];
                $member_area = $i['member_area'];
            }elseif($member_level==3){
                $member_area=$i['id'];
                $member_agent=$i['member_agent'];
            }else{
                $member_agent=$i['member_agent'];
                $member_area=$i['member_area'];
            }
            $url = C('GXZL_API_URL')."/index/taobao_tbk_adzone_create?&siteid=%s&adzone=%s";
            $site_id = $i['mediaid'];
            $qudao = M('a_media')->where(array('token'=>$i['gzhtoken']))->find();
            $site_id = $info['mediaid'];
            $adzone_id=$qudao['qudao_name'].$phone;
            $res = vget(sprintf($url,trim($site_id),trim($adzone_id)));
            $ress = json_decode($res,true);
            $tgwid = $ress['pid'];
            if(empty($tgwid)){
                $this->error('创建推广位失败');
            }
            $arr_tgwid = explode('_',$tgwid);
            $mediaid = $arr_tgwid[2];
            $adid    = $arr_tgwid[3];
            $d = array(
                'WxNum'=>$wx_num,
                'Alipay'=>$alipay,
                'Phone'=>$phone,
                //'Name'=>$name,
                'HeaderPic'=>C('LOCAL_IMG_URL').'/Public/home/images/getheadimg.png',
                'username'=>$login_name,
                'password'=>$login_pass,
                'kefu_id'=>$i['kefu_id'],
                'Pid'=>$i['id'],
                //'Time'=>time(),
                'TgwID'=>$tgwid,
                'GzhToken'=>$i['gzhtoken'],
                'MediaTableID'=>$i['mediatalbeid'],
                'MediaID'=>$mediaid,
                'AdID'=>$adid,
                'AdName'=>$phone,
                'Statue'=>1,
                'MediaName'=>$i['medianame'],
                'is_app'=>3,
                'reg_app_time'=>time(),
                'member_agent'=>$member_agent,
                'member_area'=>$member_area,
                'invitation_code'=>set_invitation_code(),
            );
            
            $j = M('wx_user')->add($d);
            if($j){
                $arr = array(
                    'code'=>1,
                    'msg'=>'添加代理成功'
                );
                //后台代理添加成功，记录注册用户数量
                //查询统计表数据是否存在
                $r = M('a_app_statistics')->where(array('uid'=>$i['id']))->find();
                if($r){
                    M('a_app_statistics')->setInc('reg_count');
                }else{
                    M('a_app_statistics')->add(array('uid'=>$i['id'],'download_count'=>1,'activation_count'=>1,'reg_count'=>1));
                }
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加代理失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $this->display();
        }
    }
    //客服的下级用户
    public function sub_user(){
        $user = $this->user;
        $uid = $user['id'];
        $start_time = I('start');
        $end_time   = I('end');
        $sort = I('sort');
        $order = '';
        if($sort==1){
            $order = ' order by YiTiXian desc';
        }
        if($sort == 2){
            $order = ' order by YuE desc';
        }
        $search = array(
            'start'=>$start_time,
            'end'=>$end_time
        );
        $this->assign('search',$search);
        $pre_id = I('pre_id');
        //根据ID查询客服信息
        $kefu = M('wx_user')->where(array('ID'=>$pre_id))->find();
        $this->assign('kefu',$kefu);
        //查询客服的下级用户 包括用户自己
        $where = "where kefu_id=$pre_id or Pid=$pre_id";
        $p = I('p',1);
        $num = 20;
        $start = ($p-1)*$num;
        $sql = "select count(*) as count from daili_wx_user $where";
        $res = M('wx_user')->query($sql);
        $count = $res[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $sql = "select * from daili_wx_user $where $order limit $start,$num";
        $res = M('wx_user')->query($sql);
        foreach ($res as $key=>$val){
            $b = M('wx_user')->field('ID,Name,Phone,WxNum,NickName,Address')->where(array('ID'=>$val['pid']))->find();
            $res[$key]['b_name']=$b['name'];
            $res[$key]['b_phone']=$b['phone'];
            $res[$key]['b_id']=$b['id'];
            $res[$key]['b_wxnum']=$b['wxnum'];
            $res[$key]['b_nickname']=$b['nickname'];
            $res[$key]['b_address']=$b['address'];
            $res[$key]['p_count'] = M('wx_user')->where(array('Pid'=>$val['id']))->count();
        }
        //查询所有客服导入的用户的ID
       /*  $sql = "select ID,AdID from daili_wx_user where kefu_id=$pre_id and ID <> $pre_id";
        $all_user_id = M('wx_user')->query($sql);
        foreach ($all_user_id as $key=>$val){
            $str_user_id .= $val['id'].',';
            $str_user_adid.=$val['adid'].',';
        }
        $str_user_id = rtrim($str_user_id,',');
        $str_user_adid=rtrim($str_user_adid,',');
        if(!$str_user_adid){
            $str_user_adid=1;
        } */
        if($start_time && !$end_time){
        
            $start_time = strtotime($start_time);
            $w1 = " and a.CreateTime >= $start_time";
         }
        if(!$start_time && $end_time){
            $end_time = strtotime($end_time)+3600*24;
            $w1 = " and a.CreateTime<=$end_time";
        }
        if($start_time && $end_time){
            $start_time=strtotime($start_time);
            $end_time  =strtotime($end_time)+3600*24;
            $w1 = " and a.CreateTime between $start_time and $end_time";
        }
        //查询客服导入的用户所有收入情况
        $sql = "select ID from daili_wx_user $where";
        $r = M('wx_user')->query($sql);
        foreach ($r as $val){
            $str_uid .= $val['id'].',';
        }
        $str_uid = rtrim($str_uid,',');
        $sql = "select 
            count(a.id) as count_order,
            sum(a.XiaoGuoYuGu) as c_shouyi,
            sum(b.ShouYi) as b_shouyi,
            sum(b.ShangJiShouYi) as b_shangjishouyi,
            sum(b.ShangShangJiShouYi) as b_shangshangjishouyi
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID in ($str_uid) $w1";
        $res_tongji = M('a_order')->query($sql);
        //查询有效订单
        $sql = "select
        count(a.id) as count_order 
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID in ($str_uid) and a.OrderStatue='订单失效' $w1";
        $count_shixiao = M('a_order')->query($sql);
        $this->assign('count_shixiao',$count_shixiao[0]['count_order']);
        /* $sql = "select
        count(a.id) as count_order,
        sum(a.XiaoGuoYuGu) as c_shouyi,
        sum(b.ShouYi) as b_shouyi,
        sum(b.ShangJiShouYi) as b_shangjishouyi,
        sum(b.ShangShangJiShouYi) as b_shangshangjishouyi
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID left join daili_wx_user as c on c.ID=b.ShangJiUId where c.kefu_id=$pre_id $w1";
        $res_tongji_shangji = M('a_order')->query($sql);
        $sql = "select
        count(a.id) as count_order,
        sum(a.XiaoGuoYuGu) as c_shouyi,
        sum(b.ShouYi) as b_shouyi,
        sum(b.ShangJiShouYi) as b_shangjishouyi,
        sum(b.ShangShangJiShouYi) as b_shangshangjishouyi
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID left join daili_wx_user as c on c.ID=b.ShangShangJiUID where c.kefu_id=$pre_id $w1";
        $res_tongji_shangshangji = M('a_order')->query($sql);
         */
        $tongji = $res_tongji[0]['count_order'];
        
        $count_daili_shouyi = 
            $res_tongji[0]['b_shouyi']+$res_tongji[0]['b_shangjishouyi']+$res_tongji[0]['b_shangshangjishouyi'];
            
        $this->assign('count_daili_shouyi',$count_daili_shouyi);
        $this->assign('tongji',$tongji);
        $c = $res_tongji[0]['c_shouyi'];
        $this->assign('count_ali',$c*0.1);
        $this->assign('count_pt',$c-$c*0.1-$count_daili_shouyi);
        $this->assign('count_shouyi',$c);
        $this->assign('p',$p);
        $this->assign('count',$count);
        $this->assign('list',$res);
        $this->assign('page',$show);
        $this->assign('pre_id',$pre_id);
        $this->assign('uid',$uid);
        $this->display();
    }

    public function qrcode_download(){
        $id = I('id');
        $info = M('wx_user')->where(array('ID'=>$id))->find();
        //验证是否存在当前公众号token文件夹
        if (!file_exists('./Uploads/RJ_VERSION/AppVersion')){
            mkdir ('./Uploads/RJ_VERSION/AppVersion',0777,true);
            mkdir ('./Uploads/RJ_VERSION/AppVersion/qrcode',0777,true);
            mkdir ('./Uploads/RJ_VERSION/AppVersion/version',0777,true);
        }
        copy("./Uploads/RJ_VERSION/kf_code_bg.png","./Uploads/RJ_VERSION/AppVersion/version/user_".$id.".jpg");
        import('Org.Images.Images');
        $img = new \Images();

        //通过百度二维码接口生成二维码
        file_put_contents('./Uploads/RJ_VERSION/AppVersion/qrcode/user_'.$id.'.jpg',
            http_get_data("http://pan.baidu.com/share/qrcode?w=150&h=150&url=".C('APP_API_URL')."/Index/download?code=".$info['invitation_code']));

        //上图与二维码合成
        $img-> imageWaterMark("./Uploads/RJ_VERSION/AppVersion/version/user_".$id.".jpg",
            10,'./Uploads/RJ_VERSION/AppVersion/qrcode/user_'.$id.'.jpg',
            "","","",400,248);
       
        $file =C('LOCAL_IMG_URL')."/Uploads/RJ_VERSION/AppVersion/version/user_".$id.".jpg";
        
        header("Location:".$file);
//        header("Content-type: octet/stream");
//        header("Content-disposition:attachment;filename=".$file.";");
//        header("Content-Length:".filesize($file));
//        readfile($file);
//        exit;
    }
    //ios激活统计
    public function tongji_jihuo(){
        $start_time=I('start');
        $end_time = I('end');
        $search = array(
            'start'=>$start_time,
            'end'=>$end_time
        );
        $this->assign('search',$search);
        $where = array(
            'platform'=>'ios'
        );
        if($start_time && !$end_time){
            $start_time = strtotime($start_time);
            $where['add_time']=array('gt',$start_time);
        }
        if($end_time && !$start_time){
            $end_time=strtotime($end_time)+3600*24;
            $where['add_time']=array('lt',$end_time);
        }
        if($start_time && $end_time){
            $start_time=strtotime($start_time);
            $end_time=strtotime($end_time)+3600*24;
            $where['add_time']=array('between',array($start_time,$end_time));
        }
        $count= M('app_tongji_jihuo')->field('id')->where($where)->count();// 查询满足要求的总记录数
        $page_num = 50;
        $Page       = new \Think\Page($count,$page_num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = M('app_tongji_jihuo')->where($where)->order('id desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        //foreach($search_data as $key=>$val) {
        //    $Page->parameter[$key] = $val;
        //}
        $show       = $Page->show();// 分页显示输出
        if(!I('p')){
            $p = 1;
        }else{
            $p = I('p');
        }
        $this->assign('p',$p);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->display();
    }
    //android激活统计
    public function android_tongji(){
        $start_time=I('start');
        $end_time = I('end');
        $search = array(
            'start'=>$start_time,
            'end'=>$end_time
        );
        $this->assign('search',$search);
        $where = array(
            'platform'=>'android'
        );
        if($start_time && !$end_time){
            $start_time = strtotime($start_time);
            $where['add_time']=array('gt',$start_time);
        }
        if($end_time && !$start_time){
            $end_time=strtotime($end_time)+3600*24;
            $where['add_time']=array('lt',$end_time);
        }
        if($start_time && $end_time){
            $start_time=strtotime($start_time);
            $end_time=strtotime($end_time)+3600*24;
            $where['add_time']=array('between',array($start_time,$end_time));
        }
        $count= M('app_tongji_jihuo')->field('id')->where($where)->count();// 查询满足要求的总记录数
        $page_num = 50;
        $Page       = new \Think\Page($count,$page_num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = M('app_tongji_jihuo')->where($where)->order('id desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        //foreach($search_data as $key=>$val) {
        //    $Page->parameter[$key] = $val;
        //}
        $show       = $Page->show();// 分页显示输出
        if(!I('p')){
            $p = 1;
        }else{
            $p = I('p');
        }
        $this->assign('p',$p);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->display();
    }
    //统计注册代理的用户数量
    public function reg_tongji(){
        $id = I('id');
        $statue = I('statue');
        $qudao_id = I('qudao_id');
        $text = I('text1');
        
        $user = $this->user;
        $uid = $user['id'];
        //根据用户id查询有权限的媒体
        $sql = "select b.* from daili_b_group_media as a left join daili_a_media as b on a.MediaId=b.ID where a.UID = $uid";
        $q = M('b_group_media')->query($sql);
        $this->assign('q',$q);
        if($qudao_id){
            $sql = M('a_media')->where(array('token'=>$qudao_id))->find();
            $search_token="'".$sql['token']."'";
        }else{
            foreach ($q as $val){
                $search_token .= "'".$val['token']."',";
            }
            $search_token = rtrim($search_token,',');
        }
        if(!$search_token){
            $this->error('请先配置渠道权限');exit;
        }
        $where = "where a.GzhToken in ($search_token)";
        if($id){
            $where .= " and a.ID = $id";
        }
        if($statue){
           if($statue == 2){
               $where .= " and a.ID=a.kefu_id";
           }else{
               $where .= " and a.Statue=$statue";
           }
        }
        if($text){
           $where .=" and a.Name='".$text."' or a.Phone='".$text."'";
        }
        $this->assign('id',$id);
        $this->assign('statue',$statue);
        $this->assign('qudaoid',$qudao_id);
        $this->assign('text1',$text);
        
        $p = I('p',1);
        $num = 20;
        $start = ($p-1)*$num;
        $page_count = M('wx_user')->query("select count(b.uid) as count from daili_wx_user as a right join daili_a_app_statistics as b on a.ID=b.uid $where");
        $page_count = $page_count[0]['count'];
        $Page       = new \Think\Page($page_count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        
        $sql = "select a.*,b.uid as b_uid,b.download_count as b_download_count,b.activation_count as b_activation_count,b.reg_count as b_reg_count from daili_wx_user as a right join daili_a_app_statistics as b on a.ID = b.uid $where order by a.ID desc limit $start,$num";
        $res = M('wx_user')->query($sql);
        foreach ($res as $key=>$val){
            $token = $val['gzhtoken'];
            $r = M('a_media')->where(array('token'=>$token))->find();
            $res[$key]['qudao']=$r['qudao_name'];
        }
        $this->assign('p',$p);
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$page_count);
        $this->assign('res',$res);
        $this->display();
    }
    //统计当前用户下的所有数据
    public function view_tongji(){
        $id = I('id');
        $user = session('user');
        $token = $user['token'];
        if($token){
            $media[] = M('a_media')->where(array('token'=>$token))->find();
        }else{
            $media = M('a_media')->select();
        }
        $this->assign('q',$media);
        //查询客服ID等于用户ID的下级用户
        
        $this->display('reg_tongji');
    }
    //查询客服列表
    public function kefu(){
        $user = $this->user;
        $uid = $user['id'];
        $id = I('id');
        $qudaoid = I('qudao_id');
        $phone   = I('text1');
        $start_time=I('start');
        $end_time = I('end');
        
        $sql = "select b.* from daili_b_group_media as a left join daili_a_media as b on a.MediaId=b.ID where a.UID = $uid";
        $q = M('b_group_media')->query($sql);
        $this->assign('q',$q);
        if($qudaoid){
            $this->assign('qudaoid',$qudaoid);
            $sql = M('a_media')->where(array('id'=>$qudaoid))->find();
            $search_token="'".$sql['token']."'";
        }else{
            foreach ($q as $val){
                $search_token .= "'".$val['token']."',";
            }
            $search_token = rtrim($search_token,',');
        }
        
        $p = I('p',1);
        $num = 20;
        $start = ($p-1)*$num;
        
        $w = array(
            'GzhToken'=>array('in',$search_token),
            '_string'=>'a.ID=a.kefu_id'
        );
        $where = "where a.GzhToken in ($search_token) and a.ID=a.kefu_id";
        $w_a = " and b.GzhToken in ($search_token)";
        $w_b = " and GzhToken in ($search_token)";
        
        if($id){
            $where = $where.' and a.ID='.$id;
            $w['ID']=$id;
            $this->assign('id',$id);
        }
        if($phone){
            $where = $where." and (a.Phone='".$phone."' or a.Name like '%$phone%')";
            $w['_query'] = " a.Phone='$phone'&a.Name like '%$phone%'&_logic=or";
            $this->assign('text1',$phone);
        }
        $count_sql = 'select count(*) as count from daili_wx_user as a '.$where;
        $count_res = M('wx_user')->query($count_sql);
        $count = $count_res[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $sql = "select a.* from daili_wx_user as a $where order by a.ID desc limit $start,$num";
        $res = M('wx_user')->query($sql);
        $w1 ='';
        $w2 ='';
        $search = array(
            'start'=>$start_time,
            'end'=>$end_time
        );
        $this->assign('search',$search);
        if($start_time && !$end_time){
            $start_time = strtotime($start_time);
            $w1 = " and add_time >= $start_time";
            $w2 = " and (reg_app_time >= $start_time or SubscribeTime >= $start_time)";
            $w3 = " and a.CreateTime >= $start_time";
            $w4 = " and a.add_time>=$start_time";
        }
        if(!$start_time && $end_time){
            $end_time = strtotime($end_time)+3600*24;
            $w1 = " and add_time<=$end_time";
            $w2 = " and (reg_app_time<=$end_time and SubscribeTime <= $end_time)";
            $w3 = " and a.CreateTime<=$end_time";
            $w4 = " and a.add_time<=$end_time";
        }
        if($start_time && $end_time){
            $start_time=strtotime($start_time);
            $end_time  =strtotime($end_time)+3600*24;
            $w1 = " and add_time between $start_time and $end_time";
            $w2 = " and (reg_app_time between $start_time and $end_time or SubscribeTime between $start_time and $end_time)";
            $w3 = " and a.CreateTime between $start_time and $end_time";
            $w4 = " and a.add_time between $start_time and $end_time";
        }
        foreach ($res as $key=>$val){
            //根据时间段查询激活数量和注册数量
            //查询激活
            $uid = $val['id'];
            $sql = "select count(*) as count from daili_a_app_statistics_new where uid = $uid $w1";
            
            $a = M('a_app_statistics_new')->query($sql);
            $res[$key]['b_activation_count']=$a[0]['count'];
            //查找注册数量
            $sql = "select count(*) as count from daili_wx_user where kefu_id = $uid $w2";
            $a = M('wx_user')->query($sql);
            $res[$key]['b_reg_count']=$a[0]['count'];
            //查找直属下级用户数量
            $sql = "select count(*) as count from daili_wx_user where Pid=$uid";
            $a = M('wx_user')->query($sql);
            $res[$key]['zhishu_xiaji']=$a[0]['count'];
            //查询所有下级数量
            $a = M('wx_user')->query("select count(*) as count from daili_wx_user where (kefu_id=$uid or Pid=$uid) and ID <> kefu_id");
            $res[$key]['all_xiaji']=$a[0]['count'];
        }
       
        $sql = "select count(*) as count from daili_a_app_statistics_new as a left join daili_wx_user as b on a.uid=b.ID where b.ID=b.kefu_id $w_a $w4";
        $a = M('a_app_statistics_new')->query($sql);
        $this->assign('jihuo',$a[0]['count']);
        //查询注册总数
        $sql = "select count(*) as count from daili_wx_user where kefu_id>0 $w_b $w2";
        $a = M('wx_user')->query($sql);
        $this->assign('zhuce',$a[0]['count']);
        $this->assign('list',$res);
        $this->assign('p',$p);
        $this->assign('page',$show);
        $this->assign('count',$count);
        $this->display();
    }
    //各渠道分成统计
    public function fencheng(){
        $start=I('start');
        if(!$start){
            $start = date("Y-m",mktime(0, 0 , 0,date("m")-1,1,date("Y")));
        }
        $user = $this->user;
        $token = $user['token'];
        if($token){
            $media = M('a_media')->where(array('token'=>$token))->select();
        }else{
            $media = M('a_media')->order('id asc')->select();   
        }
        $start_time = strtotime($start);
        $firstday = $start.'-01';
        $end_time = $lastday = strtotime("$firstday +1 month -1 day")+3600*24;
        //查询时间的阿里妈妈结算数据
        $r = M('a_ali_jiesuan')->where(array('time'=>strtotime($start),'remark'=>'李东林账号'))->find();
        if(!$r){
            $r = array(
                'id'=>0,
                'str_time'=>0,
                'yugushouru'=>0,
                'weiquanfankuan'=>0,
                'weiquanjine'=>0,
                'dongjiejine'=>0,
                'bukoujine'=>0,
                'yuejiefaqian'=>0,
                'koushui'=>0,
                'fuwufei'=>0,
                'tixian'=>0,
            );
        }else{
            $r['tixian']=$r['weiquanfankuan']+$r['yugushouru']-$r['weiquanjine']-$r['dongjiejine']-$r['bukoujine']-$r['koushui']-$r['fuwufei'];
        }
        $k_w = $r['weiquanjine']+$r['dongjiejine']+$r['bukoujine']+$r['koushui'];
        $this->assign('ali_jiesuan',$r);
        //查询时间的阿里妈妈结算数据
        $r1 = M('a_ali_jiesuan')->where(array('time'=>strtotime($start),'remark'=>'樱桃17766（汪瑛那边账号）'))->find();
        $r1['tixian']=$r1['weiquanfankuan']+$r1['yugushouru']-$r1['weiquanjine']-$r1['dongjiejine']-$r1['bukoujine']-$r1['koushui']-$r1['fuwufei'];
        $this->assign('ali_jiesuan1',$r1);
        $result = array();
        $a=$b=$c=$d=$e=$f=0;
        foreach ($media as $key=>$val){
            $result[$key]['id']=$val['id'];
            $result[$key]['qudao_name']=$val['qudao_name'];
            //查询渠道总订单数
            $gzhtoken = $val['token'];
            $str = " from daili_a_shouyi as a left join daili_wx_user as b on a.UID=b.ID left join daili_a_order as c on c.ID=a.OrderID where c.OrderStatue='订单结算' and b.GzhToken='$gzhtoken' and c.CompleteTime between $start_time and $end_time";
            $sql = "select count(a.id) as count ".$str;
            $r = M('a_shouyi')->query($sql);
            $result[$key]['count_order_num']=$r[0]['count'];
            $a += $r[0]['count'];
            //查询总佣金收入
            $sql ="select sum(c.XiaoGuoYuGu) as count ".$str;
            $r = M('a_shouyi')->query($sql);
            $result[$key]['count_shouyi']=$r[0]['count'];
            $b += $r[0]['count'];
            //查询客服收入
            $sql ="select sum(a.ShouYi) as sum_a  from daili_a_shouyi as a left join daili_wx_user as b on a.UID=b.ID left join daili_a_order as c on c.ID=a.OrderID where c.OrderStatue='订单结算' and b.GzhToken='$gzhtoken' and c.CompleteTime between $start_time and $end_time and b.ID=b.kefu_id";
            $sum_a=M('a_shouyi')->query($sql);
            $sql ="select sum(a.ShangJiShouYi) as sum_b  from daili_a_shouyi as a left join daili_wx_user as b on a.ShangJiUID=b.ID left join daili_a_order as c on c.ID=a.OrderID where c.OrderStatue='订单结算' and b.GzhToken='$gzhtoken' and c.CompleteTime between $start_time and $end_time and b.ID=b.kefu_id";
            $sum_b=M('a_shouyi')->query($sql);
            $sql ="select sum(a.ShangShangJiShouYi) as sum_c  from daili_a_shouyi as a left join daili_wx_user as b on a.ShangShangJiUID=b.ID left join daili_a_order as c on c.ID=a.OrderID where c.OrderStatue='订单结算' and b.GzhToken='$gzhtoken' and c.CompleteTime between $start_time and $end_time and b.ID=b.kefu_id";
            $sum_c=M('a_shouyi')->query($sql);
            $result[$key]['kefu_shouyi']=$sum_a[0]['sum_a']+$sum_b[0]['sum_b']+$sum_c[0]['sum_c'];
            $c += $sum_a[0]['sum_a']+$sum_b[0]['sum_b']+$sum_c[0]['sum_c'];
            
            //阿里服务费
            $result[$key]['ali_fuwufei']=$r[0]['count']*0.1;
            $d += $r[0]['count']*0.1;
            //代理总收入
            $sql ="select sum(a.ShouYi)+sum(a.ShangJiShouYi)+sum(ShangShangJiShouYi) as count from daili_a_shouyi as a left join daili_wx_user as b on a.UID=b.ID left join daili_a_order as c on c.ID=a.OrderID  where c.OrderStatue='订单结算' and b.GzhToken='$gzhtoken' and c.CompleteTime between $start_time and $end_time";
            $res =M('a_shouyi')->query($sql);
            $result[$key]['count_daili']=$res[0]['count'];
            $e += $res[0]['count'];
            //可分成金额
            $result[$key]['shengyu']=$r[0]['count']-$res[0]['count']-$r[0]['count']*0.1+$sum_a[0]['sum_a']+$sum_b[0]['sum_b']+$sum_c[0]['sum_c'];
            $f += $r[0]['count']-$res[0]['count']-$r[0]['count']*0.1+$sum_a[0]['sum_a']+$sum_b[0]['sum_b']+$sum_c[0]['sum_c'];
        }
        foreach ($result as $key=>$val){
            //计算分成比率和扣税金额
            $wk=round(($val['count_daili']/$e)*$k_w,4);
            $result[$key]['w_k']=$wk;
            $result[$key]['shengyu']=$val['shengyu']-$wk;
        }
        
        $search=array(
            'start'=>$start,
        );
        $this->assign('search',$search);
        $this->assign('res',$result);
        $this->assign('a',$a);
        $this->assign('b',$b);
        $this->assign('c',$c);
        $this->assign('d',$d);
        $this->assign('e',$e);
        $this->assign('w_k',$k_w);
        $this->assign('f',$f);
        $this->display();
    }
    //阿里妈妈结算
    public function ali_jiesuan(){
        $res = M('a_ali_jiesuan')->order('time desc')->select();
        foreach ($res as $key=>$val){
            $res[$key]['tixian']=$val['weiquanfankuan']+$val['yugushouru']-$val['weiquanjine']-$val['dongjiejine']-$val['bukoujine']-$val['koushui']-$val['fuwufei']; 
        }
        $this->assign('res',$res);
        $this->display();
    }
    //代理价值分析
    public function jiazhi_fenxi(){
        $qudao = I('qudao');
        $user = $this->user;
        $str_t= $this->str_t;
        if($qudao){
            $search_token = "GzhToken='$qudao'";
            //根据token查询mediaid
            $media = M('a_media')->where(array('token'=>$qudao))->find();
            $mediaid=$media['new_media_id'];
            $search_media = "MediaID='$mediaid'";
            $str_token="'".$qudao."'";
        }else{
            $search_token = "GzhToken in ($str_t)";
            $media = M('a_media')->where("token in ($str_t)")->select();
            foreach ($media as $val){
                $search_media.="'".$val['new_media_id']."',";
            }
            $search_media = rtrim($search_media,',');
            $search_media = "MediaID in ($search_media)";
            $str_token = $str_t;
        }
        $start = I('js_start');
        $end   = I('js_end');
        if(!$start && !$end){
            $end = date('Y-m-d',time());
            $start=date('Y-m-d',strtotime($end)-6*86400);
        }
        $days = (strtotime($end) - strtotime($start)) / 86400;
        $days = $days+1;
        for($i=1;$i<=$days;$i++){
            $days_time = $i*86400;
            $now_day_time = strtotime($start)+$days_time;
            //查询渠道人数
            $sql = "select count(ID) as count from daili_wx_user where $search_token and (SubscribeTime<$now_day_time and reg_app_time<$now_day_time)";
            //echo $sql;exit;
            $qudao_all_num = M('wx_user')->query($sql);
            $qudao_all_num = $qudao_all_num[0]['count'];
            //查询代理人数
            $sql = "select count(ID) as count from daili_wx_user where $search_token and (SubscribeTime<$now_day_time and reg_app_time<$now_day_time) and Statue = 1";
            $daili_all_num = M('wx_user')->query($sql);
            $daili_all_num = $daili_all_num[0]['count'];
            //查询总佣金收入
            $start_now_day = $now_day_time-86400;
            $end_now_day   = $now_day_time;
            $sql = "select sum(XiaoGuoYuGu) as sum from daili_a_order where $search_media and (CreateTime between $start_now_day and $end_now_day)";
            $sum_xiaoguoyugu = M('wx_user')->query($sql);
            $sum_xiaoguoyugu = $sum_xiaoguoyugu[0]['sum'];
            //阿里服务费
            $ali_fuwufei    = $sum_xiaoguoyugu*0.1;
            //查询客服的总收入
            $sql_a = "select sum(b.ShouYi) as count_a from daili_a_order as a left join daili_a_shouyi as b on b.OrderId=a.ID left join daili_wx_user as c on c.ID=b.UID where (a.CreateTime between $start_now_day and $end_now_day ) and c.GzhToken in($str_token) and c.ID=c.kefu_id";
            $sql_b = "select sum(b.ShangJiShouYi) as count_b from daili_a_order as a left join daili_a_shouyi as b on b.OrderId=a.ID left join daili_wx_user as c on c.ID=b.ShangJiUID where (a.CreateTime between $start_now_day and $end_now_day ) and c.GzhToken in($str_token) and c.ID=c.kefu_id";
            $sql_c = "select sum(b.ShangShangJiShouYi) as count_c from daili_a_order as a left join daili_a_shouyi as b on b.OrderId=a.ID left join daili_wx_user as c on c.ID=b.ShangShangJiUID where (a.CreateTime between $start_now_day and $end_now_day ) and c.GzhToken in($str_token) and c.ID=c.kefu_id";
            $count_a = M('a_order')->query($sql_a);
            $count_b = M('a_order')->query($sql_b);
            $count_c = M('a_order')->query($sql_c);
            $count_kefu = $count_a[0]['count_a']+$count_b[0]['count_b']+$count_c[0]['count_c'];
            //总的代理收入
            $sql_a = "select sum(b.ShouYi) as count_a from daili_a_order as a left join daili_a_shouyi as b on b.OrderID=a.ID left join daili_wx_user as c on c.ID=b.UID where (a.CreateTime between $start_now_day and $end_now_day ) and c.GzhToken in($str_token)";
            $sql_b = "select sum(b.ShangJiShouYi) as count_b from daili_a_order as a left join daili_a_shouyi as b on b.OrderID=a.ID left join daili_wx_user as c on c.ID=b.ShangJiUID where (a.CreateTime between $start_now_day and $end_now_day ) and c.GzhToken in($str_token)";
            $sql_c = "select sum(b.ShangShangJiShouYi) as count_c from daili_a_order as a left join daili_a_shouyi as b on b.OrderID=a.ID left join daili_wx_user as c on c.ID=b.ShangShangJiUID where (a.CreateTime between $start_now_day and $end_now_day ) and c.GzhToken in($str_token)";
            $count_dailishouru_a=M('a_order')->query($sql_a);
            $count_dailishouru_b=M('a_order')->query($sql_b);
            $count_dailishouru_c=M('a_order')->query($sql_c);
            $count_dailishouru= $count_dailishouru_a[0]['count_a']+$count_dailishouru_b[0]['count_b']+$count_dailishouru_c[0]['count_c'];
            //平台总收入
            $count_pingtai=$sum_xiaoguoyugu*0.9-$count_dailishouru;
            //单代理价值
            $jiazhi = round($sum_xiaoguoyugu/$daili_all_num,4);
            $data[$i]=array(
                'time'=>$now_day_time-86400,
                'qudao_all_num'=>$qudao_all_num,
                'daili_all_num'=>$daili_all_num,
                'sum_xiaoguoyugu'=>$sum_xiaoguoyugu,
                'ali_fuwufei'=>$ali_fuwufei,
                'count_dailishouru'=>$count_dailishouru-$count_kefu,
                'count_kefu'=>$count_kefu,
                'count_pingtai'=>$count_pingtai+$count_kefu,
                'jiazhi'=>$jiazhi
            );
        }
        krsort($data);
        $search=array(
            'qudao'=>$qudao,
            'js_start'=>$start,
            'js_end'=>$end
        );
        $this->assign('search',$search);
        $this->assign('res',$data);
        $this->display();
    }
    //活跃统计
    public function active_statistics(){
        $start = I('js_start');
        $end   = I('js_end');
        if(!$start && !$end){
            $end = date('Y-m-d',time());
            $start=date('Y-m-d',strtotime($end)-6*86400);
        }
        $days = (strtotime($end) - strtotime($start)) / 86400;
        $days = $days+1;
        //查询所有渠道
        $qudao = M('a_media')->field('id,qudao_name,token')->order('id desc')->select();
        $this->assign('qudao',$qudao);
        for($i=0;$i<$days;$i++){
            $days_time = $i*86400;
            $now_day_start = strtotime($start)+$days_time;
            $now_day_end   = $now_day_start+86400;
            foreach ($qudao as $k=>$val){
                //查询各渠道数量
                $w=array(
                    'token'=>$val['token'],
                    'add_time'=>array('between',array($now_day_start,$now_day_end))
                );
                $num=M('a_app_index_log')->where($w)->count();
                $qudao[$k]['num']=$num;
                
            }
            
            $w=array(
                'token'=>array('exp','is not null'),
                'add_time'=>array('between',array($now_day_start,$now_day_end))
            );
            $all=M('a_app_index_log')->where($w)->count();
            $data[$i]=array(
                'time'=>$now_day_start,
                'qudao'=>$qudao,
                'other'=>$other,
                'all'=>$all
            );
        }
        krsort($data);
        $search=array(
            'js_start'=>$start,
            'js_end'=>$end
        );
        $this->assign('search',$search);
        $this->assign('res',$data);
        $this->display();
    }
    //留存用户统计
    public function keep_w(){
        $qudao = I('qudao');
        $user = $this->user;
        $str_t= $this->str_t;
        if($qudao){
            $search_token = "GzhToken='$qudao'";
            //根据token查询mediaid
            $media = M('a_media')->where(array('token'=>$qudao))->find();
            $mediaid=$media['new_media_id'];
            $search_media = "MediaID='$mediaid'";
            $str_token="'".$qudao."'";
        }else{
            $search_token = "GzhToken in ($str_t)";
            $media = M('a_media')->where("token in ($str_t)")->select();
            foreach ($media as $val){
                $search_media.="'".$val['new_media_id']."',";
            }
            $search_media = rtrim($search_media,',');
            $search_media = "MediaID in ($search_media)";
            $str_token = $str_t;
        }
        $w = date('w')==0 ? $w=7 : $w=date('w');//当前星期几
        //8表示前8个星期
        for($i=1;$i<=8;$i++){
            //前一个星期
            $now_end = strtotime(date('Y-m-d',time()))-($w-1)*86400-($i-1)*7*86400;
            $now_start   = $now_end-86400*7;
            $strID='';
            //查询新增代理人数
            $sql = "select ID,invitation_code from daili_wx_user where $search_token and Statue=1 and ((SubscribeTime between $now_start and $now_end) or (reg_app_time between $now_start and $now_end))";
            $inc_res = M('wx_user')->query($sql);
            $inc_num = count($inc_res);
            $data[$i]['inc_num']=$inc_num;
            $data[$i]['day']=date('Y-m-d',$now_start).'  --  '.date('Y-m-d',$now_end).'('.$i.'周前)';
            //查询当周增加的用户在未来8周的登录情况
            foreach ($inc_res as $key=>$val){
                $strID .= "'".$val['invitation_code']."',";
            }
            $strID = rtrim($strID,',');
            if($strID){
                $keep_start=$now_end;
                $keep_end  =$now_end+86400*7;
                $sql="select count(t.counts) as count from (select id,count(*) as counts from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code) t";
                //$sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep1']=$keep_num;
                $data[$i]['percent1']=(round($keep_num/$inc_num,4)*100).'%';
                
                $keep_start=$now_end+86400*7;
                $keep_end  =$now_end+86400*7*2;
                $sql="select count(t.counts) as count from (select id,count(*) as counts from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code) t";
                //$sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep2']=$keep_num;
                $data[$i]['percent2']=(round($keep_num/$inc_num,4)*100).'%';
                
                $keep_start=$now_end+86400*7*2;
                $keep_end  =$now_end+86400*7*3;
                $sql="select count(t.counts) as count from (select id,count(*) as counts from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code) t";
                //$sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep3']=$keep_num;
                $data[$i]['percent3']=(round($keep_num/$inc_num,4)*100).'%';
                
                $keep_start=$now_end+86400*7*3;
                $keep_end  =$now_end+86400*7*4;
                $sql="select count(t.counts) as count from (select id,count(*) as counts from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code) t";
                //$sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep4']=$keep_num;
                $data[$i]['percent4']=(round($keep_num/$inc_num,4)*100).'%';
                
                $keep_start=$now_end+86400*7*4;
                $keep_end  =$now_end+86400*7*5;
                $sql="select count(t.counts) as count from (select id,count(*) as counts from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code) t";
                //$sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep5']=$keep_num;
                $data[$i]['percent5']=(round($keep_num/$inc_num,4)*100).'%';
                
                $keep_start=$now_end+86400*7*5;
                $keep_end  =$now_end+86400*7*6;
                $sql="select count(t.counts) as count from (select id,count(*) as counts from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code) t";
                //$sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep6']=$keep_num;
                $data[$i]['percent6']=(round($keep_num/$inc_num,4)*100).'%';
                
                $keep_start=$now_end+86400*7*6;
                $keep_end  =$now_end+86400*7*7;
                $sql="select count(t.counts) as count from (select id,count(*) as counts from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code) t";
                //$sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep7']=$keep_num;
                $data[$i]['percent7']=(round($keep_num/$inc_num,4)*100).'%';
                
                $keep_start=$now_end+86400*7*7;
                $keep_end  =$now_end+86400*7*8;
                $sql="select count(t.counts) as count from (select id,count(*) as counts from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code) t";
                //$sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep8']=$keep_num;
                $data[$i]['percent8']=(round($keep_num/$inc_num,4)*100).'%';
            }else{
                $data[$i]['keep1']=0;
                $data[$i]['percent1']='0%';
                $data[$i]['keep2']=0;
                $data[$i]['percent2']='0%';
                $data[$i]['keep3']=0;
                $data[$i]['percent3']='0%';
                $data[$i]['keep4']=0;
                $data[$i]['percent4']='0%';
                $data[$i]['keep5']=0;
                $data[$i]['percent5']='0%';
                $data[$i]['keep6']=0;
                $data[$i]['percent6']='0%';
                $data[$i]['keep7']=0;
                $data[$i]['percent7']='0%';
                $data[$i]['keep8']=0;
                $data[$i]['percent8']='0%';
            } 
        }
        $search=array(
            'qudao'=>$qudao,
            //'js_start'=>$start,
            //'js_end'=>$end
        );
        $this->assign('search',$search);
        $this->assign('res',$data);
        $this->display();
    }
    //留存用户统计
    public function keep_m(){
        $qudao = I('qudao');
        $user = $this->user;
        $str_t= $this->str_t;
        if($qudao){
            $search_token = "GzhToken='$qudao'";
            //根据token查询mediaid
            $media = M('a_media')->where(array('token'=>$qudao))->find();
            $mediaid=$media['new_media_id'];
            $search_media = "MediaID='$mediaid'";
            $str_token="'".$qudao."'";
        }else{
            $search_token = "GzhToken in ($str_t)";
            $media = M('a_media')->where("token in ($str_t)")->select();
            foreach ($media as $val){
                $search_media.="'".$val['new_media_id']."',";
            }
            $search_media = rtrim($search_media,',');
            $search_media = "MediaID in ($search_media)";
            $str_token = $str_t;
        }
        
        for($i=1;$i<=6;$i++){
            if(date('m')-$i<=0){
                $y = date('Y')-1;
                $m = date('m')-$i+12;
            }else{
                $y = date('Y');
                $m = date('m')-$i;
            }
            //获取当前月数
            $now_start = strtotime($y.'-'.$m);
            $t = date('t',$now_start);
            $now_end= $now_start+$t*86400;
            $strID='';
            //查询新增代理人数
            $sql = "select ID,invitation_code from daili_wx_user where $search_token and Statue=1 and ((SubscribeTime between $now_start and $now_end) or (reg_app_time between $now_start and $now_end))";
            $inc_res = M('wx_user')->query($sql);
            $inc_num = count($inc_res);
            $data[$i]['inc_num']=$inc_num;
            $data[$i]['day']=date('Y-m-d',$now_start).' -- '.date('Y-m-d',$now_end).'('.$i.'个月前)';
            //查询当月增加的用户在未来6个月的登录情况
            foreach ($inc_res as $key=>$val){
                $strID .= "'".$val['invitation_code']."',";
            }
            $strID = rtrim($strID,',');
            if($strID){
                $m = $m+1;
                if($m>12){
                    $y=$y+1;
                    $t1 = date('t',strtotime($y.'-'.$m));
                }else{
                    $t1 = date('t',strtotime($y.'-'.$m));
                }
                $keep_start=$now_end;
                $keep_end  =$now_end+86400*$t1;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = count($keep_num);
                $data[$i]['keep1']=$keep_num;
                $data[$i]['percent1']=(round($keep_num/$inc_num,4)*100).'%';
                
                $m = $m+1;
                if($m>12){
                    $y=$y+1;
                    $t2 = date('t',strtotime($y.'-'.$m))+$t1;
                }else{
                    $t2 = date('t',strtotime($y.'-'.$m))+$t1;
                }
                $keep_start=$now_end+86400*$t1;
                $keep_end  =$now_end+86400*$t2;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = count($keep_num);
                $data[$i]['keep2']=$keep_num;
                $data[$i]['percent2']=(round($keep_num/$inc_num,4)*100).'%';
                
                $m = $m+1;
                if($m>12){
                    $y=$y+1;
                    $t3 = date('t',strtotime($y.'-'.$m))+$t2;
                }else{
                    $t3 = date('t',strtotime($y.'-'.$m))+$t2;
                }
                $keep_start=$now_end+86400*$t2;
                $keep_end  =$now_end+86400*$t3;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = count($keep_num);
                $data[$i]['keep3']=$keep_num;
                $data[$i]['percent3']=(round($keep_num/$inc_num,4)*100).'%';
        
                $m = $m+1;
                if($m>12){
                    $y=$y+1;
                    $t4 = date('t',strtotime($y.'-'.$m))+$t3;
                }else{
                    $t4 = date('t',strtotime($y.'-'.$m))+$t3;
                }
                $keep_start=$now_end+86400*$t3;
                $keep_end  =$now_end+86400*$t4;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = count($keep_num);
                $data[$i]['keep4']=$keep_num;
                $data[$i]['percent4']=(round($keep_num/$inc_num,4)*100).'%';
        
                $m = $m+1;
                if($m>12){
                    $y=$y+1;
                    $t5 = date('t',strtotime($y.'-'.$m))+$t4;
                }else{
                    $t5 = date('t',strtotime($y.'-'.$m))+$t4;
                }
                $keep_start=$now_end+86400*$t4;
                $keep_end  =$now_end+86400*$t5;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = count($keep_num);
                $data[$i]['keep5']=$keep_num;
                $data[$i]['percent5']=(round($keep_num/$inc_num,4)*100).'%';
        
                $m = $m+1;
                if($m>12){
                    $y=$y+1;
                    $t6 = date('t',strtotime($y.'-'.$m))+$t5;
                }else{
                    $t6 = date('t',strtotime($y.'-'.$m))+$t5;
                }
                $keep_start=$now_end+86400*$t5;
                $keep_end  =$now_end+86400*$t6;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end) group by code";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = count($keep_num);
                $data[$i]['keep6']=$keep_num;
                $data[$i]['percent6']=(round($keep_num/$inc_num,4)*100).'%';
        
            }else{
                $data[$i]['keep1']=0;
                $data[$i]['percent1']='0%';
                $data[$i]['keep2']=0;
                $data[$i]['percent2']='0%';
                $data[$i]['keep3']=0;
                $data[$i]['percent3']='0%';
                $data[$i]['keep4']=0;
                $data[$i]['percent4']='0%';
                $data[$i]['keep5']=0;
                $data[$i]['percent5']='0%';
                $data[$i]['keep6']=0;
                $data[$i]['percent6']='0%';
            }
        }
        //krsort($data);
        $search=array(
            'qudao'=>$qudao,
            //'js_start'=>$start,
            //'js_end'=>$end
        );
        $this->assign('search',$search);
        $this->assign('res',$data);
        $this->display();
    }
    //留存用户统计
    public function keep_d(){
        $qudao = I('qudao');
        $user = $this->user;
        $str_t= $this->str_t;
        if($qudao){
            $search_token = "GzhToken='$qudao'";
            //根据token查询mediaid
            $media = M('a_media')->where(array('token'=>$qudao))->find();
            $mediaid=$media['new_media_id'];
            $search_media = "MediaID='$mediaid'";
            $str_token="'".$qudao."'";
        }else{
            $search_token = "GzhToken in ($str_t)";
            $media = M('a_media')->where("token in ($str_t)")->select();
            foreach ($media as $val){
                $search_media.="'".$val['new_media_id']."',";
            }
            $search_media = rtrim($search_media,',');
            $search_media = "MediaID in ($search_media)";
            $str_token = $str_t;
        }
        $start = I('js_start');
        $end   = I('js_end');
        if(!$start && !$end){
            $end = date('Y-m-d',time()-86400);
            $start=date('Y-m-d',strtotime($end)-6*86400);
        }
        $days = (strtotime($end) - strtotime($start)) / 86400;
        $days = $days+1;
        for($i=1;$i<=$days;$i++){
            $strID='';
            $days_time = $i*86400;
            $now_end = strtotime($start)+$days_time;
            $now_start   = strtotime($start)+$days_time-86400;
            //查询新增代理人数
            $sql = "select ID,invitation_code from daili_wx_user where $search_token and Statue=1 and ((SubscribeTime between $now_start and $now_end) or (reg_app_time between $now_start and $now_end))";
            $inc_res = M('wx_user')->query($sql);
            $inc_num = count($inc_res);
            $data[$i]['inc_num']=$inc_num;
            $data[$i]['day']=date('Y-m-d',$now_start);
            //查询当天增加的用户在未来7天的登录情况
            foreach ($inc_res as $key=>$val){
                $strID .= "'".$val['invitation_code']."',";
            }
            $strID = rtrim($strID,',');
            if($strID){
                $keep_start=$now_end;
                $keep_end  =$now_end+86400;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep1']=$keep_num;
                $data[$i]['percent1']=(round($keep_num/$inc_num,4)*100).'%';
        
                $keep_start=$now_end+86400;
                $keep_end  =$now_end+86400*2;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep2']=$keep_num;
                $data[$i]['percent2']=(round($keep_num/$inc_num,4)*100).'%';
        
                $keep_start=$now_end+86400*2;
                $keep_end  =$now_end+86400*3;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep3']=$keep_num;
                $data[$i]['percent3']=(round($keep_num/$inc_num,4)*100).'%';
        
                $keep_start=$now_end+86400*3;
                $keep_end  =$now_end+86400*4;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep4']=$keep_num;
                $data[$i]['percent4']=(round($keep_num/$inc_num,4)*100).'%';
        
                $keep_start=$now_end+86400*4;
                $keep_end  =$now_end+86400*5;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep5']=$keep_num;
                $data[$i]['percent5']=(round($keep_num/$inc_num,4)*100).'%';
        
                $keep_start=$now_end+86400*5;
                $keep_end  =$now_end+86400*6;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep6']=$keep_num;
                $data[$i]['percent6']=(round($keep_num/$inc_num,4)*100).'%';
        
                $keep_start=$now_end+86400*6;
                $keep_end  =$now_end+86400*7;
                $sql = "select count(id) as count from daili_a_app_index_log where code in($strID) and (add_time between $keep_start and $keep_end)";
                $keep_num = M('a_app_index_log')->query($sql);
                $keep_num = $keep_num[0]['count'];
                $data[$i]['keep7']=$keep_num;
                $data[$i]['percent7']=(round($keep_num/$inc_num,4)*100).'%';
            }else{
                $data[$i]['keep1']=0;
                $data[$i]['percent1']='0%';
                $data[$i]['keep2']=0;
                $data[$i]['percent2']='0%';
                $data[$i]['keep3']=0;
                $data[$i]['percent3']='0%';
                $data[$i]['keep4']=0;
                $data[$i]['percent4']='0%';
                $data[$i]['keep5']=0;
                $data[$i]['percent5']='0%';
                $data[$i]['keep6']=0;
                $data[$i]['percent6']='0%';
                $data[$i]['keep7']=0;
                $data[$i]['percent7']='0%';
            }
        }
        krsort($data);
        $search=array(
            'qudao'=>$qudao,
            'js_start'=>$start,
            'js_end'=>$end
        );
        $this->assign('search',$search);
        $this->assign('res',$data);
        $this->display();
    }
    //留存用户统计
    public function order_analysis(){
        $qudao = I('qudao');
        $user = $this->user;
        $str_t= $this->str_t;
        if($qudao){
            $search_token = "GzhToken='$qudao'";
            //根据token查询mediaid
            $media = M('a_media')->where(array('token'=>$qudao))->find();
            $mediaid=$media['new_media_id'];
            $search_media = "MediaID='$mediaid'";
            $str_token="'".$qudao."'";
        }else{
            $search_token = "GzhToken in ($str_t)";
            $media = M('a_media')->where("token in ($str_t)")->select();
            foreach ($media as $val){
                $search_media.="'".$val['new_media_id']."',";
            }
            $search_media = rtrim($search_media,',');
            $search_media = "MediaID in ($search_media)";
            $str_token = $str_t;
        }
        $start = I('js_start');
        $end   = I('js_end');
        if(!$start && !$end){
            $end = date('Y-m-d',time());
            $start=date('Y-m-d',strtotime($end)-6*86400);
        }
        $days = (strtotime($end) - strtotime($start)) / 86400;
        $days = $days+1;
        for($i=1;$i<=$days;$i++){
            $w=array();
            $w['_string']=$search_media;
            $days_time = $i*86400;
            $now_start   = strtotime($start)+$days_time-86400;
            $now_end     = $now_start+86400;
            //$data[$i]['start']=date('Y-m-d H:i:s',$now_start);
            //$data[$i]['end']=date('Y-m-d H:i:s',$now_end);
            $data[$i]['day']=date('Y-m-d',$now_start);
            $w['CreateTime']= array('between',array($now_start,$now_end));
            //查询时间段总数
            $count=M('a_order')->where($w)->count();
            $data[$i]['count']=$count;
            //查询收入比小于等于10%
            $w['_string']='ShouRuBi <= 10 and '.$search_media;
            $count1=M('a_order')->where($w)->count();
            $data[$i]['count1']=$count1;
            $data[$i]['percent1']=round($count1/$count,4)*100 .'%';
            //查询收入比大于10%小于等于20%
            $w['_string']='ShouRuBi > 10 and ShouRuBi <= 20 and '.$search_media;
            $count2=M('a_order')->where($w)->count();
            $data[$i]['count2']=$count2;
            $data[$i]['percent2']=round($count2/$count,4)*100 .'%';
            //查询收入比大于20%小于等于30%
            $w['_string']='ShouRuBi > 20 and ShouRuBi <= 30 and '.$search_media;
            $count3=M('a_order')->where($w)->count();
            $data[$i]['count3']=$count3;
            $data[$i]['percent3']=round($count3/$count,4)*100 .'%';
            //查询收入比大于30%小于等于40%
            $w['_string']='ShouRuBi > 30 and ShouRuBi <= 40 and '.$search_media;
            $count4=M('a_order')->where($w)->count();
            $data[$i]['count4']=$count4;
            $data[$i]['percent4']=round($count4/$count,4)*100 .'%';
            //查询收入比大于40%小于等于50%
            $w['_string']='ShouRuBi > 40 and ShouRuBi <= 50 and '.$search_media;
            $count5=M('a_order')->where($w)->count();
            $data[$i]['count5']=$count5;
            $data[$i]['percent5']=round($count5/$count,4)*100 .'%';
            //查询收入比大于50%
            $w['_string']='ShouRuBi > 50 and '.$search_media;
            $count6=M('a_order')->where($w)->count();
            $data[$i]['count6']=$count6;
            $data[$i]['percent6']=round($count6/$count,4)*100 .'%';
            
        }
        krsort($data);
        $search=array(
            'qudao'=>$qudao,
            'js_start'=>$start,
            'js_end'=>$end
        );
        $this->assign('search',$search);
        $this->assign('res',$data);
        $this->display();
    }
    //新增用户收益统计分析
    public function new_user(){
        //获取当前时间
        $js_month = I('js_start');
        $month = I('start');
        if(!$js_month){
            $js_month = date('Y-m',time());
        }
        if(!$month){
            $month=date('Y-m',time());
        }
        $start=$js_month.'-01';
        $end = date('Y-m-d', strtotime("$start +1 month -1 day"));
        $start = strtotime($start);
        $end   = strtotime($end)+24*3600-1;
        
        $start_=$month.'-01';
        $end_ = date('Y-m-d', strtotime("$start_ +1 month -1 day"));
        $start_ = strtotime($start_);
        $end_   = strtotime($end_)+24*3600-1;
        //查询所有渠道
        $media = M('a_media')->field('id,token,qudao_name')->order('id desc')->select();
        $arr = array();
        foreach ($media as $key=>$val){
            $arr[$key]['qudao']=$val['qudao_name'];
            //查询一级代理数量
            $token = $val['token'];
            $sql = "select ID from daili_wx_user where Statue=1 and (Pid=0 or Pid = kefu_id) and GzhToken = '$token' and ((reg_app_time between $start and $end) or (SubscribeTime between $start and $end))";
            $res = M('wx_user')->query($sql);
            $count = count($res);
            if($count>0){
                $arr[$key]['first']=$count;
                $id_str = '';
                foreach ($res as $k=>$v){
                    $id_str .= $v['id'].",";
                }
                $id_str = rtrim($id_str,',');
                //查询一级预估收入
                $sql = "select sum(a.XiaoGuoYuGu) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID in($id_str) and a.CreateTime between $start_ and $end_";
               
                $sum = M('a_order')->query($sql);
                $sum = $sum[0]['sum'];
                if($sum>0){
                    $arr[$key]['first_shouyi']=$sum;
                }else{
                    $arr[$key]['first_shouyi']=0;
                }
            }else{
                $arr[$key]['first']=0;
                $arr[$key]['first_shouyi']=0;
            }
            
            if($id_str){
                //查询二级代理
                $sql = "select ID from daili_wx_user where Statue=1 and  ID<>kefu_id and Pid <> kefu_id and GzhToken = '$token' and ((reg_app_time between $start and $end) or (SubscribeTime between $start and $end)) and PID in($id_str)";
                $res = M('wx_user')->query($sql);
                $count = count($res);
                if($count>0){
                    
                    $arr[$key]['second']=$count;
                    $id_str = '';
                    foreach ($res as $k=>$v){
                        $id_str .= $v['id'].',';
                    }
                    $id_str = rtrim($id_str,',');
                    //查询二级级预估收入
                    $sql = "select sum(a.XiaoGuoYuGu) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID in ($id_str) and a.CreateTime between $start_ and $end_";
                    $sum = M('a_order')->query($sql);
                    $sum = $sum[0]['sum'];
                    if($sum>0){
                        $arr[$key]['second_shouyi']=$sum;
                    }else{
                        $arr[$key]['second_shouyi']=0;
                    }
                }else{
                    $arr[$key]['second']=0;
                    $arr[$key]['second_shouyi']=0;
                }
            }else{
                $arr[$key]['second']=0;
                $arr[$key]['second_shouyi']=0;
            }
            
        }
        $this->assign('res',$arr);
        $this->assign('month',$month);
        $this->assign('js_month',$js_month);
        $this->display();
    }



    /*
     * 升级店主订单查询
     * */
    public function upgrade_order_list(){
        $user = $this->user;
        $qudao = I('qudao');
        if($qudao){
            $str_token = "'".$qudao."'";
        }else{
            $str_token = $this->str_t;
        }
        $search = array(
            'qudao'=>$qudao,
        );
        $this->assign('search',$search);
        $ordernum = I('out_trade_no','','trim');
        $trade_no = I('trade_no','','trim');
        $pay_channel = I('pay_channel','','intval');
        $wx_trade_no = I('wx_trade_no','','trim');
        $where = "a.uid is not null";
        if(!empty($ordernum)){
            $where .= " and a.out_trade_no='".$ordernum."'";
        }
        if(!empty($trade_no)){
            $where .= " and a.trade_no=".$trade_no;
        }
        if(!empty($wx_trade_no)){
            $where .= " and a.wx_trade_no=".$wx_trade_no;
        }
        if(!empty($pay_channel)){
            $where .= " and a.pay_channel=".$pay_channel;
        }
        $p = I('p',1);
        $num = 20;
        $start = ($p-1)*$num;
        $User = M('a_order');
        $sql = "select count(*) as count from daili_a_upgrade_order as a left join daili_wx_user as b on a.uid=b.ID where b.GzhToken in ($str_token) and ".$where;
        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count=$count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $sql = "select a.* from daili_a_upgrade_order as a left join daili_wx_user as b on a.uid=b.ID  where b.GzhToken in ($str_token) and $where order by a.pay_time desc limit $start,$num";
        $list=$User->query($sql);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('out_trade_no',$ordernum);
        $this->assign('trade_no',$trade_no);
        $this->assign('pay_channel',($pay_channel>0?($pay_channel+1):$pay_channel));
        $this->display();
    }
    //邀请奖励明细页面
    public function yaoqing_jiangli(){
        $user=$this->user;
        $str_t = $this->str_t;
        $qudao = I('qudao');
        if($qudao){
            $str_token = "'".$qudao."'";
        }else{
            $str_token = $this->str_t;
        }
        
        $num=20;
        $page = I('p',1);
        $start = ($page-1)*$num;
        $type = I('type');
        $uid  = I('uid');
        $search = array(
            'qudao'=>$qudao,
            'type'=>$type,
            'uid'=>$uid
        );
        if($uid){
            $w = " and b.ID=$uid";
        }
        $this->assign('search',$search);
        if($type){
            $w .= " and a.type=$type";
        }else{
            $w .= "";
        }
        $sql = "select count(*) as count from daili_b_jiangli as a left join daili_wx_user as b on a.UID=b.ID where b.GzhToken in ($str_t) $w";
        $count = M('b_jiangli')->query($sql);
        $count = $count[0]['count'];
        $count=$count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        
        $sql = "select a.*,b.ID as b_id,b.Phone as b_phone,b.member_level as b_member_level,c.ID as c_id,c.Phone as c_phone,c.member_level as c_member_level,d.qudao_name as b_qudao_name,e.qudao_name as c_qudao_name from daili_b_jiangli as a left join daili_wx_user as b on a.UID=b.ID left join daili_wx_user as c on a.XiaJiUID=c.ID left join daili_a_media as d on b.GzhToken=d.token left join daili_a_media as e on c.GzhToken=e.token where b.GzhToken in ($str_t) $w order by a.time desc limit $start,$num";
        $res = M('b_jiangli')->query($sql);
        foreach ($res as $key=>$val){
            $res[$key]['b_phone']=substr($val['b_phone'],0,3).'****'.substr($val['b_phone'],7,4);
            $res[$key]['c_phone']=substr($val['c_phone'],0,3).'****'.substr($val['c_phone'],7,4);
            if($val['type']==1){//用户邀请注册用户
                //查询用户订单
                if($val['orderid']){//用户已经买了东西邀请奖励到账
                    $order = M('a_order')->where(array('ID'=>$val['orderid']))->find();
                    $res[$key]['order_info']=$order['orderstatue'];
                }else{
                    $res[$key]['order_info']='';
                    $res[$key]['remark']='被邀请用户未下单或下单金额不足';
                }
            }
            if($val['type']==2){
                //查询用户付款订单
                if($val['orderid']){//邀请店主的奖励
                    $order = M('a_upgrade_order')->where(array('id'=>$val['orderid']))->find();
                    if($order['order_statue']==1){
                        $order_statue = '已支付99升级店主';
                        if($val['b_member_level']==0){
                            $res[$key]['remark']='未支付99升级店主';
                        }
                    }else{
                        $order_statue = '订单失效';
                    }
                    $res[$key]['order_info']=$order_statue;
                }else{
                    $res[$key]['order_info']='';
                    $res[$key]['remark']='未支付99升级店主';
                }
            }
        }
        $this->assign('p',$page);
        $this->assign('count',$count);
        $this->assign('page',$show);
        $this->assign('res',$res);
        $this->display();
    }
}