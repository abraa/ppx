<?php
/**
 * 数据处理控制器
 * */
namespace Home\Controller;
use Think\Controller;
class ApiController extends Controller {
    public function _initialize(){
        //echo '停止访问';
        //exit;
    }
    //下载淘宝订单
    public function get_order_create($page){
        $time = urlencode(date('Y-m-d H:i:s',time()-800));
        //$time = urlencode('2018-04-17 15:10:00');
        $statue=1;
        $type='create_time';
        $url = C('GXZL_API_URL')."/Index/taobao_tbk_order_get?time=%s&statue=%s&type=%s&page=%s";
        $res = vget(sprintf($url,trim($time),trim($statue),trim($type),trim($page)));
        $ress = json_decode($res,true);
        if(!$ress[0]){
            $ress=array($ress);
        }
        foreach ($ress as $key=>$val){
            $create_time = strtotime($val['create_time']);
            $complate_time=strtotime($val['earning_time']);
            switch($val['tk_status']){
                case 3:
                    $tk_status="订单结算";
                    break;
                case 12:
                    $tk_status="订单付款";
                    break;
                case 13:
                    $tk_status="订单失效";
                    break;
                case 14:
                    $tk_status="订单成功";
                    break;
            }
            
            $d['CreateTime']=$create_time;
            $d['Title']=$val['item_title'];
            $d['ItemID']=$val['num_iid'];
            $d['ShopUser']=$val['seller_nick'];
            $d['ShopName']=$val['seller_shop_title'];
            $d['ItemNum']=$val['item_num'];
            $d['Price']=$val['price'];
            $d['OrderStatue']=$tk_status;//3：订单结算，12：订单付款， 13：订单失效，14：订单成功
            $d['OrderType']=$val['order_type'];//订单类型，如天猫，淘宝
            $d['ShouRuBi']=$val['income_rate'];
            $d['FenChengBi']=$val['commission_rate'];
            $d['Pay']=$val['alipay_total_price'];
            $d['XiaoGuoYuGu']=$val['pub_share_pre_fee'];
            //$d['JieSuanJinE']=
            $d['YuGuShouRu']=$val['commission'];
            $d['CompleteTime']=$complate_time;
            $d['YongJinBi']=$val['total_commission_rate'];
            $d['YongJinJinE']=$val['total_commission_fee'];
            $d['BuTieBi']=$val['subsidy_rate'];
            $d['BuTieJinE']=$val['subsidy_fee'];
            $d['BuTieType']=$val['subsidy_type'];//天猫:1，聚划算:2，航旅:3，阿里云:4
            $d['ChengJiaoPingTai']=$val['terminal_type'];//PC:1，无线:2
            $d['ThirdFuWu']=$val['tk3rd_type'];
            $d['tk3rd_pub_id']=$val['tk3rd_pub_id'];
            $d['OrderNum']=$val['trade_id'];
            $d['ParentOrderNum']=$val['trade_parent_id'];
            $d['Cate']=$val['auction_category'];
            $d['MediaID']=$val['site_id'];
            $d['MediaName']=$val['site_name'];
            $d['AdID']=$val['adzone_id'];
            $d['AdName']=$val['adzone_name'];
            $d['Num']=$num;
            if($val['site_id'] != C('MEDIA_ID')){
                continue;
            }else{
                
                $w = array(
                    'OrderNum'=>$val['trade_id'],
                    'ParentOrderNum'=>$val['trade_parent_id']
                );
                $res = M('a_order')->where($w)->find();
                if(!$res){
                    $orderid = M('a_order')->add($d);
                    //添加订单后计算收益
                    $xiaoguoyugu = $val['pub_share_pre_fee'];
                    $mediaid     = $val['site_id'];
                    $adid        = $val['adzone_id'];
                    $pay         = $val['alipay_total_price'];
                   
                    //根据媒体ID和广告位ID查询用户
                    $w = array(
                        'MediaID'=>$mediaid,
                        'AdID'=>$adid
                    );
                    $user = M('wx_user')->where($w)->find();
                    //查询会员邀请奖励
                    $config = M('a_config_copy')->where(array('token'=>$user['gzhtoken']))->find();
                    $yaoqingjiangli = $config['yaoqingjiangli'];
                    $yaoqingmax     = $config['yaoqingmax'];
                    if($pay>=C('PAY_MONEY')){
                        //查询上级用户
                        $shangjiuser = M('wx_user')->find($user['pid']);
                        if($shangjiuser['yaoqinghuiyuan_jiangli']<$yaoqingmax){
                            $jiangli_w = array(
                                'UID'=>$shangjiuser['id'],
                                'XiaJiUID'=>$user['id'],
                                'type'=>1
                            );
                            $jiangli = M('b_jiangli')->where($jiangli_w)->find();
                            if($jiangli['statue']==0){
                                $jiangli_statue=array(
                                    'statue'=>1,
                                    'orderid'=>$orderid,
                                    'operation_time'=>time(),
                                    'type'=>1,
                                );
                                M('b_jiangli')->where($jiangli_w)->save($jiangli_statue);
                                //给用户奖励
                                M('wx_user')->where(array('ID'=>$shangjiuser['id']))->setInc('yaoqinghuiyuan_jiangli',$yaoqingjiangli);
                                //M('wx_user')->where(array('ID'=>$shangjiuser['id']))->setInc('YuE',$yaoqingjiangli);
                                
                                $log = array(
                                    'orderid'=>$orderid,
                                    'time'=>time(),
                                    'uid'=>$shangjiuser['id'],
                                    'xiajiuid'=>$user['id'],
                                    'order_statue'=>$tk_status
                                );
                                M('yaoqingjiangli_order')->add($log);
                            }
                        }
                    }
                    $shouyi_info=get_shouyi_info($xiaoguoyugu,$user);
                    $w = array(
                        'UID'=>$shouyi_info['id'],
                        'OrderID'=>$orderid
                    );
                    $res = M('a_shouyi')->where($w)->find();
                    if(!$res){
                        $UID = $shouyi_info['uid'];
                        $shouyi=$shouyi_info['shouyi'];
                        $shangjiUID=$shouyi_info['shangjiuid'];
                        $shangjishouyi=$shouyi_info['shangjishouyi'];
                        $shangshangjiUID=$shouyi_info['shangshangjiuid'];
                        $shangshangjishouyi=$shouyi_info['shangshangjishouyi'];
                        $area_id = $shouyi_info['area_id'];
                        $area_shouyi=$shouyi_info['area_shouyi'];
                        //统计用户收益数据表加收益
                        $shouyidata = array(
                            'UID'=>$UID,
                            'ShouYi'=>$shouyi,
                            'ShangJiUID'=>$shangjiUID,
                            'ShangJiShouYi'=>$shangjishouyi,
                            'ShangShangJiUID'=>$shangshangjiUID,
                            'ShangShangJiShouYi'=>$shangshangjishouyi,
                            'OrderStatue'=>0,
                            'OrderID'=>$orderid,
                            'CreateTime'=>$create_time,
                            'area_id'=>$area_id,
                            'area_shouyi'=>$area_shouyi
                        );
                        M('a_shouyi')->add($shouyidata);
                        //添加收益
                        $l = array(
                            'content'=>json_encode($shouyidata),
                            'type'=>'收益分成'
                        );
                        M('z_logtest')->add($l);
                        
                    }
                }
            }
        }
        $num = count($ress);
        if($num>=20){
            $this->get_order_create($page+1);
        }
    }
    //下载淘宝订单结算的
    public function get_order_complate($page){
        $time = urlencode(date('Y-m-d H:i:s',time()-600));
        //$time = urlencode('2018-04-13 20:56:19');
        $statue=1;
        $type='settle_time';
        //$type="create_time";
        $url = C('GXZL_API_URL')."/Index/taobao_tbk_order_get?time=%s&statue=%s&type=%s&page=%s";
        $res = vget(sprintf($url,trim($time),trim($statue),trim($type),trim($page)));
        $ress = json_decode($res,true);
        if(!$ress[0]){
            $ress=array($ress);
        }
        foreach ($ress as $key=>$val){
            $create_time = strtotime($val['create_time']);
            $complate_time=strtotime($val['earning_time']);
            switch($val['tk_status']){
                case 3:
                    $tk_status="订单结算";
                    break;
                case 12:
                    $tk_status="订单付款";
                    break;
                case 13:
                    $tk_status="订单失效";
                    break;
                case 14:
                    $tk_status="订单成功";
                    break;
            }
            //$d['CreateTime']=$create_time;
            //$d['Title']=$val['item_title'];
            //$d['ItemID']=$val['num_iid'];
            //$d['ShopUser']=$val['seller_nick'];
            //$d['ShopName']=$val['seller_shop_title'];
            //$d['ItemNum']=$val['item_num'];
            $d['Price']=$val['price'];
            $d['OrderStatue']=$tk_status;//3：订单结算，12：订单付款， 13：订单失效，14：订单成功
            //$d['OrderType']=$val['order_type'];//订单类型，如天猫，淘宝
            $d['ShouRuBi']=$val['income_rate'];
            $d['FenChengBi']=$val['commission_rate'];
            $d['Pay']=$val['alipay_total_price'];
            $d['XiaoGuoYuGu']=$val['pub_share_pre_fee'];
            //$d['JieSuanJinE']=
            $d['YuGuShouRu']=$val['commission'];
            $d['CompleteTime']=$complate_time;
            $d['YongJinBi']=$val['total_commission_rate'];
            $d['YongJinJinE']=$val['total_commission_fee'];
            $d['BuTieBi']=$val['subsidy_rate'];
            $d['BuTieJinE']=$val['subsidy_fee'];
            //$d['BuTieType']=$val['subsidy_type'];//天猫:1，聚划算:2，航旅:3，阿里云:4
            //$d['ChengJiaoPingTai']=$val['terminal_type'];//PC:1，无线:2
            //$d['ThirdFuWu']=$val['tk3rd_type'];
            //$d['tk3rd_pub_id']=$val['tk3rd_pub_id'];
            //$d['OrderNum']=$val['trade_id'];
            //$d['ParentOrderNum']=$val['trade_parent_id'];
            //$d['Cate']=$val['auction_category'];
            //$d['MediaID']=$val['site_id'];
            //$d['MediaName']=$val['site_name'];
            //$d['AdID']=$val['adzone_id'];
            //$d['AdName']=$val['adzone_name'];
            //$d['Num']=$num;
            if($val['site_id'] != C('MEDIA_ID')){
                continue;
            }else{
                $w = array(
                    'OrderNum'=>$val['trade_id'],
                    'ParentOrderNum'=>$val['trade_parent_id']
                );
                $order = M('a_order')->where($w)->find();
                if($order && $tk_status=='订单结算'){
                    $res = M('a_order')->where(array('ID'=>$order['id']))->save($d);
                    if($res){
                        //查询收益
                        /* $shouyi_w = array(
                            'OrderID'=>$order['id']
                        );
                        $shouyi = M('a_shouyi')->where($shouyi_w)->find();
                        $uid = $shouyi['uid'];
                        $u_shouyi=$shouyi['shouyi']?$shouyi['shouyi']:0;
                        $shangjiuid=$shouyi['shangjiuid'];
                        $u_shangjishouyi=$shouyi['shangjishouyi']?$shouyi['shangjishouyi']:0;
                        $shangshangjiuid=$shouyi['shangshangjiuid'];
                        $u_shangshangjishouyi=$shouyi['shangshangjishouyi']?$shouyi['shangshangjishouyi']:0;
                        $areauid=$shouyi['area_id'];
                        $u_areashouyi=$shouyi['area_shouyi']?$shouyi['area_shouyi']:0;
                        //给用户添加收入
                        if($uid){
                            //M('wx_user')->where(array('ID'=>$uid))->setInc('YuE',$u_shouyi);
                        }
                        //给上级用户添加收入
                        if($shangjiuid){
                            //M('wx_user')->where(array('ID'=>$shangjiuid))->setInc('YuE',$u_shangjishouyi);
                        }
                        //给上上级用户添加收入
                        if($shangshangjiuid){
                            //M('wx_user')->where(array('ID'=>$shangshangjiuid))->setInc('YuE',$u_shangshangjishouyi);
                        }
                        //给区域合伙人添加收入
                        if($areauid){
                            //M('wx_user')->where(array('ID'=>$areauid))->setInc('YuE',$u_areashouyi);
                        } */
                    }
                    
                }
            }
        }
        $num = count($ress);
        if($num>=20){
            $this->get_order_complate($page+1);
        }
    }
    //下载订单判断失效
    public function get_order_shixiao($page,$num){
        if($num>=2160){
            $end = 1;
            $num=1;
        }else{
            $end = 0;
        }
        $times = $num*600;
        $time = urlencode(date('Y-m-d H:i:s',time()-$times));
        //$time = urlencode('2018-04-13 20:56:19');
        $statue=13;
        //$type='settle_time';
        $type="create_time";
        $url = C('GXZL_API_URL')."/Index/taobao_tbk_order_get?time=%s&statue=%s&type=%s&page=%s";
        $res = vget(sprintf($url,trim($time),trim($statue),trim($type),trim($page)));
        $ress = json_decode($res,true);
        if(!$ress[0]){
            $ress=array($ress);
        }
        foreach ($ress as $key=>$val){
            $create_time = strtotime($val['create_time']);
            $complate_time=strtotime($val['earning_time']);
            switch($val['tk_status']){
                case 3:
                    $tk_status="订单结算";
                    break;
                case 12:
                    $tk_status="订单付款";
                    break;
                case 13:
                    $tk_status="订单失效";
                    break;
                case 14:
                    $tk_status="订单成功";
                    break;
            }
            //$d['CreateTime']=$create_time;
            //$d['Title']=$val['item_title'];
            //$d['ItemID']=$val['num_iid'];
            //$d['ShopUser']=$val['seller_nick'];
            //$d['ShopName']=$val['seller_shop_title'];
            //$d['ItemNum']=$val['item_num'];
            $d['Price']=$val['price'];
            $d['OrderStatue']=$tk_status;//3：订单结算，12：订单付款， 13：订单失效，14：订单成功
            //$d['OrderType']=$val['order_type'];//订单类型，如天猫，淘宝
            $d['ShouRuBi']=$val['income_rate'];
            $d['FenChengBi']=$val['commission_rate'];
            $d['Pay']=$val['alipay_total_price'];
            $d['XiaoGuoYuGu']=$val['pub_share_pre_fee'];
            //$d['JieSuanJinE']=
            $d['YuGuShouRu']=$val['commission'];
            $d['CompleteTime']=$complate_time;
            $d['YongJinBi']=$val['total_commission_rate'];
            $d['YongJinJinE']=$val['total_commission_fee'];
            $d['BuTieBi']=$val['subsidy_rate'];
            $d['BuTieJinE']=$val['subsidy_fee'];
            //$d['BuTieType']=$val['subsidy_type'];//天猫:1，聚划算:2，航旅:3，阿里云:4
            //$d['ChengJiaoPingTai']=$val['terminal_type'];//PC:1，无线:2
            //$d['ThirdFuWu']=$val['tk3rd_type'];
            //$d['tk3rd_pub_id']=$val['tk3rd_pub_id'];
            //$d['OrderNum']=$val['trade_id'];
            //$d['ParentOrderNum']=$val['trade_parent_id'];
            //$d['Cate']=$val['auction_category'];
            //$d['MediaID']=$val['site_id'];
            //$d['MediaName']=$val['site_name'];
            //$d['AdID']=$val['adzone_id'];
            //$d['AdName']=$val['adzone_name'];
            //$d['Num']=$num;
            if($val['site_id'] != C('MEDIA_ID')){
                continue;
            }else{
                $w = array(
                    'OrderNum'=>$val['trade_id'],
                    'ParentOrderNum'=>$val['trade_parent_id']
                );
                $order = M('a_order')->where($w)->find();
                if($order && $order['orderstatue'] !='订单失效'){
                    M('a_order')->where(array('ID'=>$order['id']))->save($d);
                    $shouyi_data = array(
                        'ShouYi'=>0,
                        'ShangJiShouYi'=>0,
                        'ShangShangJiShouYi'=>0,
                        'area_shouyi'=>0,
                    );
                    M('a_shouyi')->where(array('OrderID'=>$order['id']))->save($shouyi_data);
                }
            }
        }
        $count = count($ress);
        if($count>=20){
            $this->get_order_shixiao($page+1,$num);
        }else{
            $arr = array(
                'num'=>$num+1,
                'end'=>1
            );
            //print_r($arr);
            $this->ajaxReturn($arr);
        }
    }
}