<?php
namespace Home\Controller;
use Think\Controller;
class BrandController extends BaseController {
    //品牌列表页面
    public function brandlist(){
        $p = I('p',1);
        $num = 10;
        $start = ($p-1)*$num;
        $qd = I('qudao');
        if($qd){
            $search_token="'".$qd."'";
        }else{
            $search_token=$this->str_t;
        }
        $sql ="select count(a.id) as count from daili_a_brand as a where a.token in ($search_token)";
        $res = M('a_brand','daili_','DB_DAILI_READ')->query($sql);
        $count = $res[0]['count'];
        $page = new \Think\Page($count,$num);
        $show       = $page->show();
        $this->assign('page',$show);
        $this->assign('count',$count);
        $this->assign('p',$p);
        $sql ="select a.*,b.qudao_name as qudao from daili_a_brand as a left join daili_a_media as b on a.token=b.token where a.token in ($search_token) order by a.ordid asc,add_time desc limit $start,$num";
        $lunbotu = M('a_brand','daili_','DB_DAILI_READ')->query($sql);
        $this->assign('lunbotu',$lunbotu);
        $this->assign('qudao',$qd);
        $this->display();
    }
    //添加品牌
    public function add_brand(){
        if(IS_POST){
            $data = I('post.');
            $id = $data['id'];
            $data = M('a_brand')->create($data);
            $data['add_time']=time();
            $title = $data['title'];
            if($id){
                $res = M('a_brand')->save($data);
                if($res){
                    $arr = array(
                        'code'=>1,
                        'msg' =>'编辑成功'
                    );
                }else{
                    $arr = array(
                        'code'=>0,
                        'msg'=>'编辑失败'
                    );
                }
                $this->ajaxReturn($arr);
            }else{
                $zhuanchang = M('a_brand')->where('title="'.$title.'"')->find();
                if($zhuanchang){
                    $arr = array(
                        'code'=>0,
                        'msg'=>'已经添加了同名品牌了'
                    );
                    $this->ajaxReturn($arr);
                }
                $res = M('a_brand')->add($data);
                if($res){
                    $arr = array(
                        'code'=>1,
                        'msg' =>'添加成功'
                    );
                }else{
                    $arr = array(
                        'code'=>0,
                        'msg'=>'添加失败'
                    );
                }
                $this->ajaxReturn($arr);
            }
        }else{
            $id = I('id');
            if($id){
                $res = M('a_brand')->where(array('id'=>$id))->find();
                $this->assign('res',$res);
            }
            $this->display();
        }
    }
}