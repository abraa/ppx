<?php
namespace Home\Controller;
use Think\Controller;
class UserController extends Controller {
    private $user;
    public function _initialize(){
        //判断用户是否登录
        $user = $_SESSION['user'];
        if(!$user){
            $this->error('请先登录',U('Index/index'));
        }else{
            $this->user = $user;
        }
    }
    //赚多多粉丝
    public function user(){
        $id = I('id');
        $qudao_id = I('qudao_id');
        $statue = I('statue');
        $text1  = str_replace(' ','',I('text1'));
        $text2  = str_replace(' ','',I('text2'));
        $start = I('start');
        $end   = I('end');
        
        $user = $this->user;
        $uid = $user['id'];
        //根据用户id查询有权限的媒体
        $sql = "select b.* from daili_b_group_media as a left join daili_a_media as b on a.MediaId=b.ID where a.UID = $uid";
        $q = M('b_group_media')->query($sql);
        foreach ($q as $key=>$val){
            $str_t .= $val['token'].',';
        }
        if(!rtrim($str_t,',')){
            $this->error('还没设置渠道权限');
        }
        if($qudao_id){
            //根据媒体ID查询token得到where条件
            $media = M('a_media')->where(array('id'=>$qudao_id))->find();
            $where = 'a.GzhToken="'.$media['token'].'"';
            
        }else{
            if($q){
                //得到媒体下面公众号的token
                foreach ($q as $val){
                    $where .= 'a.GzhToken="'.$val['token'].'" or ';
                }
                $where = '('.rtrim($where,' or ').')';
            }
        }
        if($id){
            $where .=" and a.ID=$id";
        }
        if($statue != ''){
            if($statue==2){
                $where .=' and a.kefu_id=a.ID';
            }else{
                $where .=' and a.Statue='.$statue;
            }
        }
        if($text1){
            $where .=" and (a.Phone like '%".$text1."%' or a.Name like '%".$text1."%')";
        }
        if($text2){
            $where .=" and (b.Phone like '%".$text2."%' or b.Name like '%".$text2."%')";
        }
        if($start && empty($end)){
            $start_time = strtotime($start);
            $where .=" and (a.SubscribeTime >=$start_time or a.reg_app_time>=$start_time)";
        }
        if(empty($start) && $end){
            $end_time = strtotime($end)+3600*24;
            $where .=" and (a.SubscribeTime <$end_time and a.reg_app_time<$end_time)";
        }
        if($start && $end){
            $start_time = strtotime($start);
            $end_time   = strtotime($end)+3600*24;
            $where .=" and (a.SubscribeTime between $start_time and $end_time or a.reg_app_time between $start_time and $end_time)";
        }
        //echo $where;exit;
        $search_data = array(
            'start'=>$start,
            'end'=>$end
        );
        $this->assign('search',$search_data);
        $where .= ' and a.member_level=-1';
        S('where',$where);
        $p = I('p',1);
        $num = 20;
        $User = M('wx_user'); // 实例化User对象
        $sql = "select count(*) as count from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID where $where";
        //echo $sql;exit;
        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count=$count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        $sql = "select a.*, b.ID            as b_ID,
                            b.Pid           as b_Pid,
                            b.IsSubscribe   as b_IsSubscribe,
                            b.OpenID        as b_OpenID,
                            b.HeaderPic     as b_HeaderPic,
                            b.NickName      as b_NickName,
                            b.Address       as b_Address,
                            b.WxNum         as b_WxNum,
                            b.Alipay        as b_Alipay,
                            b.Name          as b_Name,
                            b.Phone         as b_Phone,
                            b.TgwId         as b_TgwId,
                            b.MediaID       as b_MediaID,
                            b.MediaName     as b_MediaName,
                            b.AdID          as b_AdID,
                            b.AdName        as b_AdName,
                            b.YiTiXian      as b_YiTiXian,
                            b.Statue        as b_Statue,
                            b.IsUseSoftware as b_IsUseSoftware,
                            b.kefu_id       as b_kefu_id,
                            c.Phone         as c_phone,
                            c.Name          as c_name,
                            e.Phone         as e_phone,
                            e.Name          as e_name
         from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID left join daili_wx_user as c on a.member_agent=c.ID left join daili_wx_user as e on a.member_area=e.ID where $where order by a.ID desc limit $start,$num";
        //echo $sql;exit;
        $list = $User->query($sql);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('q',$q);
        $this->assign('qudaoid',$qudao_id);
        $this->assign('statue',$statue);
        $this->assign('text1',$text1);
        $this->assign('text2',$text2);
        $this->assign('id',$id);
        $this->assign('uid',$uid);
        $this->display();
    }
    //普通合伙人
    public function user_general(){
        $id = I('id');
        $qudao_id = I('qudao_id');
        $statue = I('statue');
        $text1  = str_replace(' ','',I('text1'));
        $text2  = str_replace(' ','',I('text2'));
        $start = I('start');
        $end   = I('end');
        
        $user = $this->user;
        $uid = $user['id'];
        //根据用户id查询有权限的媒体
        $sql = "select b.* from daili_b_group_media as a left join daili_a_media as b on a.MediaId=b.ID where a.UID = $uid";
        $q = M('b_group_media')->query($sql);
        foreach ($q as $key=>$val){
            $str_t .= $val['token'].',';
        }
        if(!rtrim($str_t,',')){
            $this->error('还没设置渠道权限');
        }
        if($qudao_id){
            //根据媒体ID查询token得到where条件
            $media = M('a_media')->where(array('id'=>$qudao_id))->find();
            $where = 'a.GzhToken="'.$media['token'].'"';
            
        }else{
            if($q){
                //得到媒体下面公众号的token
                foreach ($q as $val){
                    $where .= 'a.GzhToken="'.$val['token'].'" or ';
                }
                $where = '('.rtrim($where,' or ').')';
            }
        }
        if($id){
            $where .=" and a.ID=$id";
        }
        if($statue != ''){
            if($statue==2){
                $where .=' and a.kefu_id=a.ID';
            }else{
                $where .=' and a.Statue='.$statue;
            }
        }
        if($text1){
            $where .=" and (a.Phone like '%".$text1."%' or a.Name like '%".$text1."%')";
        }
        if($text2){
            $where .=" and (b.Phone like '%".$text2."%' or b.Name like '%".$text2."%')";
        }
        if($start && empty($end)){
            $start_time = strtotime($start);
            $where .=" and (a.SubscribeTime >=$start_time or a.reg_app_time>=$start_time)";
        }
        if(empty($start) && $end){
            $end_time = strtotime($end)+3600*24;
            $where .=" and (a.SubscribeTime <$end_time and a.reg_app_time<$end_time)";
        }
        if($start && $end){
            $start_time = strtotime($start);
            $end_time   = strtotime($end)+3600*24;
            $where .=" and (a.SubscribeTime between $start_time and $end_time or a.reg_app_time between $start_time and $end_time)";
        }
        //echo $where;exit;
        $search_data = array(
            'start'=>$start,
            'end'=>$end
        );
        $this->assign('search',$search_data);
        $where .= ' and a.member_level=0';
        S('where',$where);
        $p = I('p',1);
        $num = 20;
        $User = M('wx_user'); // 实例化User对象
        $sql = "select count(*) as count from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID where $where";
        //echo $sql;exit;
        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count=$count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        $sql = "select a.*, b.ID            as b_ID,
                            b.Pid           as b_Pid,
                            b.IsSubscribe   as b_IsSubscribe,
                            b.OpenID        as b_OpenID,
                            b.HeaderPic     as b_HeaderPic,
                            b.NickName      as b_NickName,
                            b.Address       as b_Address,
                            b.WxNum         as b_WxNum,
                            b.Alipay        as b_Alipay,
                            b.Name          as b_Name,
                            b.Phone         as b_Phone,
                            b.TgwId         as b_TgwId,
                            b.MediaID       as b_MediaID,
                            b.MediaName     as b_MediaName,
                            b.AdID          as b_AdID,
                            b.AdName        as b_AdName,
                            b.YiTiXian      as b_YiTiXian,
                            b.Statue        as b_Statue,
                            b.IsUseSoftware as b_IsUseSoftware,
                            b.kefu_id       as b_kefu_id,
                            c.Phone         as c_phone,
                            c.Name          as c_name,
                            e.Phone         as e_phone,
                            e.Name          as e_name
         from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID left join daili_wx_user as c on a.member_agent=c.ID left join daili_wx_user as e on a.member_area=e.ID where $where order by a.ID desc limit $start,$num";
        //echo $sql;exit;
        $list = $User->query($sql);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('q',$q);
        $this->assign('qudaoid',$qudao_id);
        $this->assign('statue',$statue);
        $this->assign('text1',$text1);
        $this->assign('text2',$text2);
        $this->assign('id',$id);
        $this->assign('uid',$uid);
        $this->display();
    }
    //超级会员
    public function user_gold(){
        $id = I('id');
        $qudao_id = I('qudao_id');
        $statue = I('statue');
        $text1  = str_replace(' ','',I('text1'));
        $text2  = str_replace(' ','',I('text2'));
        $start = I('start');
        $end   = I('end');
        
        $user = $this->user;
        $uid = $user['id'];
        //根据用户id查询有权限的媒体
        $sql = "select b.* from daili_b_group_media as a left join daili_a_media as b on a.MediaId=b.ID where a.UID = $uid";
        $q = M('b_group_media')->query($sql);
        foreach ($q as $key=>$val){
            $str_t .= $val['token'].',';
        }
        if(!rtrim($str_t,',')){
            $this->error('还没设置渠道权限');
        }
        if($qudao_id){
            //根据媒体ID查询token得到where条件
            $media = M('a_media')->where(array('id'=>$qudao_id))->find();
            $where = 'a.GzhToken="'.$media['token'].'"';
            
        }else{
            if($q){
                //得到媒体下面公众号的token
                foreach ($q as $val){
                    $where .= 'a.GzhToken="'.$val['token'].'" or ';
                }
                $where = '('.rtrim($where,' or ').')';
            }
        }
        if($id){
            $where .=" and a.ID=$id";
        }
        if($statue != ''){
            if($statue==2){
                $where .=' and a.kefu_id=a.ID';
            }else{
                $where .=' and a.Statue='.$statue;
            }
        }
        if($text1){
            $where .=" and (a.Phone like '%".$text1."%' or a.Name like '%".$text1."%')";
        }
        if($text2){
            $where .=" and (b.Phone like '%".$text2."%' or b.Name like '%".$text2."%')";
        }
        if($start && empty($end)){
            $start_time = strtotime($start);
            $where .=" and (a.SubscribeTime >=$start_time or a.reg_app_time>=$start_time)";
        }
        if(empty($start) && $end){
            $end_time = strtotime($end)+3600*24;
            $where .=" and (a.SubscribeTime <$end_time and a.reg_app_time<$end_time)";
        }
        if($start && $end){
            $start_time = strtotime($start);
            $end_time   = strtotime($end)+3600*24;
            $where .=" and (a.SubscribeTime between $start_time and $end_time or a.reg_app_time between $start_time and $end_time)";
        }
        //echo $where;exit;
        $search_data = array(
            'start'=>$start,
            'end'=>$end
        );
        $this->assign('search',$search_data);
        $where .= ' and a.member_level=1';
        S('where',$where);
        $p = I('p',1);
        $num = 20;
        $User = M('wx_user'); // 实例化User对象
        $sql = "select count(*) as count from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID where $where";
        //echo $sql;exit;
        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count=$count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        $sql = "select a.*, b.ID            as b_ID,
                            b.Pid           as b_Pid,
                            b.IsSubscribe   as b_IsSubscribe,
                            b.OpenID        as b_OpenID,
                            b.HeaderPic     as b_HeaderPic,
                            b.NickName      as b_NickName,
                            b.Address       as b_Address,
                            b.WxNum         as b_WxNum,
                            b.Alipay        as b_Alipay,
                            b.Name          as b_Name,
                            b.Phone         as b_Phone,
                            b.TgwId         as b_TgwId,
                            b.MediaID       as b_MediaID,
                            b.MediaName     as b_MediaName,
                            b.AdID          as b_AdID,
                            b.AdName        as b_AdName,
                            b.YiTiXian      as b_YiTiXian,
                            b.Statue        as b_Statue,
                            b.IsUseSoftware as b_IsUseSoftware,
                            b.kefu_id       as b_kefu_id,
                            c.Phone         as c_phone,
                            c.Name          as c_name,
                            e.Phone         as e_phone,
                            e.Name          as e_name
         from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID left join daili_wx_user as c on a.member_agent=c.ID left join daili_wx_user as e on a.member_area=e.ID where $where order by a.ID desc limit $start,$num";
        //echo $sql;exit;
        $list = $User->query($sql);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('q',$q);
        $this->assign('qudaoid',$qudao_id);
        $this->assign('statue',$statue);
        $this->assign('text1',$text1);
        $this->assign('text2',$text2);
        $this->assign('id',$id);
        $this->assign('uid',$uid);
        $this->display();
    }
    //运营商
    public function user_agent(){
        $id = I('id');
        $qudao_id = I('qudao_id');
        $statue = I('statue');
        $text1  = str_replace(' ','',I('text1'));
        $text2  = str_replace(' ','',I('text2'));
        $start = I('start');
        $end   = I('end');
        
        $user = $this->user;
        $uid = $user['id'];
        //根据用户id查询有权限的媒体
        $sql = "select b.* from daili_b_group_media as a left join daili_a_media as b on a.MediaId=b.ID where a.UID = $uid";
        $q = M('b_group_media')->query($sql);
        foreach ($q as $key=>$val){
            $str_t .= $val['token'].',';
        }
        if(!rtrim($str_t,',')){
            $this->error('还没设置渠道权限');
        }
        if($qudao_id){
            //根据媒体ID查询token得到where条件
            $media = M('a_media')->where(array('id'=>$qudao_id))->find();
            $where = 'a.GzhToken="'.$media['token'].'"';
            
        }else{
            if($q){
                //得到媒体下面公众号的token
                foreach ($q as $val){
                    $where .= 'a.GzhToken="'.$val['token'].'" or ';
                }
                $where = '('.rtrim($where,' or ').')';
            }
        }
        if($id){
            $where .=" and a.ID=$id";
        }
        if($statue != ''){
            if($statue==2){
                $where .=' and a.kefu_id=a.ID';
            }else{
                $where .=' and a.Statue='.$statue;
            }
        }
        if($text1){
            $where .=" and (a.Phone like '%".$text1."%' or a.Name like '%".$text1."%')";
        }
        if($text2){
            $where .=" and (b.Phone like '%".$text2."%' or b.Name like '%".$text2."%')";
        }
        if($start && empty($end)){
            $start_time = strtotime($start);
            $where .=" and (a.SubscribeTime >=$start_time or a.reg_app_time>=$start_time)";
        }
        if(empty($start) && $end){
            $end_time = strtotime($end)+3600*24;
            $where .=" and (a.SubscribeTime <$end_time and a.reg_app_time<$end_time)";
        }
        if($start && $end){
            $start_time = strtotime($start);
            $end_time   = strtotime($end)+3600*24;
            $where .=" and (a.SubscribeTime between $start_time and $end_time or a.reg_app_time between $start_time and $end_time)";
        }
        //echo $where;exit;
        $search_data = array(
            'start'=>$start,
            'end'=>$end
        );
        $this->assign('search',$search_data);
        $where .= ' and a.member_level=2';
        S('where',$where);
        $p = I('p',1);
        $num = 20;
        $User = M('wx_user'); // 实例化User对象
        $sql = "select count(*) as count from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID where $where";
        //echo $sql;exit;
        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count=$count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        $sql = "select a.*, b.ID            as b_ID,
                            b.Pid           as b_Pid,
                            b.IsSubscribe   as b_IsSubscribe,
                            b.OpenID        as b_OpenID,
                            b.HeaderPic     as b_HeaderPic,
                            b.NickName      as b_NickName,
                            b.Address       as b_Address,
                            b.WxNum         as b_WxNum,
                            b.Alipay        as b_Alipay,
                            b.Name          as b_Name,
                            b.Phone         as b_Phone,
                            b.TgwId         as b_TgwId,
                            b.MediaID       as b_MediaID,
                            b.MediaName     as b_MediaName,
                            b.AdID          as b_AdID,
                            b.AdName        as b_AdName,
                            b.YiTiXian      as b_YiTiXian,
                            b.Statue        as b_Statue,
                            b.IsUseSoftware as b_IsUseSoftware,
                            b.kefu_id       as b_kefu_id,
                            c.Phone         as c_phone,
                            c.Name          as c_name,
                            e.Phone         as e_phone,
                            e.Name          as e_name
         from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID left join daili_wx_user as c on a.member_agent=c.ID left join daili_wx_user as e on a.member_area=e.ID where $where order by a.ID desc limit $start,$num";
        //echo $sql;exit;
        $list = $User->query($sql);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('q',$q);
        $this->assign('qudaoid',$qudao_id);
        $this->assign('statue',$statue);
        $this->assign('text1',$text1);
        $this->assign('text2',$text2);
        $this->assign('id',$id);
        $this->assign('uid',$uid);
        $this->display();
    }
    //区域合伙人
    public function user_area(){
        $id = I('id');
        $qudao_id = I('qudao_id');
        $statue = I('statue');
        $text1  = str_replace(' ','',I('text1'));
        $text2  = str_replace(' ','',I('text2'));
        $start = I('start');
        $end   = I('end');
    
        $user = $this->user;
        $uid = $user['id'];
        //根据用户id查询有权限的媒体
        $sql = "select b.* from daili_b_group_media as a left join daili_a_media as b on a.MediaId=b.ID where a.UID = $uid";
        $q = M('b_group_media')->query($sql);
        foreach ($q as $key=>$val){
            $str_t .= $val['token'].',';
        }
        if(!rtrim($str_t,',')){
            $this->error('还没设置渠道权限');
        }
        if($qudao_id){
            //根据媒体ID查询token得到where条件
            $media = M('a_media')->where(array('id'=>$qudao_id))->find();
            $where = 'a.GzhToken="'.$media['token'].'"';
    
        }else{
            if($q){
                //得到媒体下面公众号的token
                foreach ($q as $val){
                    $where .= 'a.GzhToken="'.$val['token'].'" or ';
                }
                $where = '('.rtrim($where,' or ').')';
            }
        }
        if($id){
            $where .=" and a.ID=$id";
        }
        if($statue != ''){
            if($statue==2){
                $where .=' and a.kefu_id=a.ID';
            }else{
                $where .=' and a.Statue='.$statue;
            }
        }
        if($text1){
            $where .=" and (a.Phone like '%".$text1."%' or a.Name like '%".$text1."%')";
        }
        if($text2){
            $where .=" and (b.Phone like '%".$text2."%' or b.Name like '%".$text2."%')";
        }
        if($start && empty($end)){
            $start_time = strtotime($start);
            $where .=" and (a.SubscribeTime >=$start_time or a.reg_app_time>=$start_time)";
        }
        if(empty($start) && $end){
            $end_time = strtotime($end)+3600*24;
            $where .=" and (a.SubscribeTime <$end_time and a.reg_app_time<$end_time)";
        }
        if($start && $end){
            $start_time = strtotime($start);
            $end_time   = strtotime($end)+3600*24;
            $where .=" and (a.SubscribeTime between $start_time and $end_time or a.reg_app_time between $start_time and $end_time)";
        }
        //echo $where;exit;
        $search_data = array(
            'start'=>$start,
            'end'=>$end
        );
        $this->assign('search',$search_data);
        $where .= ' and a.member_level=3';
        S('where',$where);
        $p = I('p',1);
        $num = 20;
        $User = M('wx_user'); // 实例化User对象
        $sql = "select count(*) as count from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID where $where";
        //echo $sql;exit;
        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count=$count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $start = ($p-1)*$num;
        $sql = "select a.*, b.ID            as b_ID,
        b.Pid           as b_Pid,
        b.IsSubscribe   as b_IsSubscribe,
        b.OpenID        as b_OpenID,
        b.HeaderPic     as b_HeaderPic,
        b.NickName      as b_NickName,
        b.Address       as b_Address,
        b.WxNum         as b_WxNum,
        b.Alipay        as b_Alipay,
        b.Name          as b_Name,
        b.Phone         as b_Phone,
        b.TgwId         as b_TgwId,
        b.MediaID       as b_MediaID,
        b.MediaName     as b_MediaName,
        b.AdID          as b_AdID,
        b.AdName        as b_AdName,
        b.YiTiXian      as b_YiTiXian,
        b.Statue        as b_Statue,
        b.IsUseSoftware as b_IsUseSoftware,
        b.kefu_id       as b_kefu_id
        from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID where $where order by a.ID desc limit $start,$num";
        //echo $sql;exit;
        $list = $User->query($sql);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('q',$q);
        $this->assign('qudaoid',$qudao_id);
        $this->assign('statue',$statue);
        $this->assign('text1',$text1);
        $this->assign('text2',$text2);
        $this->assign('id',$id);
        $this->assign('uid',$uid);
        $this->display();
    }
    //每个月1号检测用户等级，判断条件是否满足，不满足就降级
    public function check_info(){
        $page=I('page',1);
        $num = 100;
        $start=($page-1)*100;
        $user = M('wx_user')->field('ID,member_level')->where(array('member_level'=>1))->limit($start,$num)->order('ID desc')->select();
        
        foreach ($user as $key=>$val){
            $y = date('Y',time());
            $m = date('m',time());
            if($m==1){
                $start=($y-1).'-12-01 00:00:00';
                $end  =($y-1).'-12-31 23:59:59';
            }else{
                $days = date('t', strtotime($y.'-'.($m-1).'-01'));
                $start=$y.'-'.($m-1).'-01 00:00:00';
                $end  =$y.'-'.($m-1).'-'.$days.' 23:59:59';
            }
            //查询用户结算金额
            $uid = $val['id'];
            $start_time = strtotime($start);
            $end_time   = strtotime($end);
            //判断普通合伙人上月订单数据(包括自己下单，下级下单，粉丝下单)
            if($val['member_level']==0){
                //查询用户的所有下级
                $xiaji = M('wx_user')->field('ID')->where(array('Pid'=>$uid,'Statue'=>1))->select();
                if($xiaji){
                    $xiaji_ids = '';
                    foreach ($xiaji as $key=>$val){
                        $xiaji_ids .= $val['id'].',';
                    }
                    $xiaji_ids = rtrim($xiaji_ids,',');
                    //查询下级代理的下单数量
                    $sql="select count(a.ID) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.CompleteTime between $start_time and $end_time and b.UID in ($xiaji_ids) and a.OrderStatue <> '订单失效'";
                    $count1 = M('a_order')->query($sql);
                }
                $sql="select count(a.ID) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.CompleteTime between $start_time and $end_time and b.UID=$uid and a.OrderStatue <> '订单失效'";
                $count2 = M('a_order')->query($sql);
                $count = $count1[0]['count']+$count2[0]['count'];
                if($count<3){
                    $d = array(
                        'ID'=>$uid,
                        'member_level'=>-1
                    );
                    M('wx_user')->save($d);
                }
            }
            //判断用户等级，如果是黄金合伙人判断上月订单结算金额和邀请代理数
            if($val['member_level']==1){
                $sql = "select sum(b.ShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.CompleteTime between $start_time and $end_time and b.UID=$uid";
                $res = M('a_order')->query($sql);
                $sum = $res[0]['sum'];
                //查询下级代理增加数
                $sql = "select count(ID) as count from daili_wx_user where (SubscribeTime between $start_time and $end_time) or (reg_app_time between $start_time and $end_time) and Pid=$uid and Statue=1";
                $res = M('wx_user')->query($sql);
                $count = $res[0]['count'];
                if($count<5 || $sum<50){
                    $d = array(
                        'ID'=>$uid,
                        'member_level'=>0
                    );
                    M('wx_user')->save($d);
                }
            }
        }
    }
    //用户升级为普通会员
    public function set_general(){
        $id = I('id');
        $user = M('wx_user')->field('ID,member_level')->where(array('ID'=>$id))->find();
        if($user['member_level']==2){
            $this->update_member_2($id);
        }elseif($user['member_level']==3){
            $this->update_member_2($id);
        }
        $data = array(
            'ID'=>$id,
            'member_level'=>0
        );
        $res = M('wx_user')->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'设置成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'设置失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //用户升级为超级会员
    public function set_gold(){
        $id = I('id');
        //查询用户信息
        $user = M('wx_user')->field('ID,member_level')->where(array('ID'=>$id))->find();
        if($user['member_level']==2){
            $this->update_member_2($id);
        }elseif($user['member_level']==3){
            $this->update_member_2($id);
        }
        $data = array(
            'ID'=>$id,
            'member_level'=>1
        );
        $res = M('wx_user')->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'设置成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'设置失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    public function update_member_2($id){
        $user = M('wx_user')->field('ID')->where(array('member_agent'=>$id))->select();
        if($user){
            foreach ($user as $key=>$val){
                $d = array(
                    'ID'=>$val['id'],
                    'member_agent'=>''
                );
                M('wx_user')->save($d);
            }
        }
    }
    public function update_member_3($id){
        $user = M('wx_user')->field('ID')->where(array('member_area'=>$id))->select();
        if($user){
            foreach ($user as $key=>$val){
                $d = array(
                    'ID'=>$val['id'],
                    'member_area'=>''
                );
                M('wx_user')->save($d);
            }
        }
    }
    //普通粉丝升级为运营商
    public function set_agent(){
        $id = I('id');
        //先将用户member_level设置为2表示运营商
        $d = array(
            'ID'=>$id,
            'member_level'=>2,
            'kefu_id'=>$id,
        );
        $r = M('wx_user')->save($d);
        if($r){
            $this->update_member_agent($id,$id);
            $arr = array(
                'code'=>1,
                'msg'=>'设置成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'设置失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //递归函数将用户升级为运营商后该用户的所有无限级下级的member_agent变成当前用户ID
    //参数$id 表示设置运营商用户的ID，$pid表示上级用户ID查询下级用户
    public function update_member_agent($id,$pid){
        //查询当前用户等级
        $u = M('wx_user')->field('ID,member_level')->where(array('ID'=>$id))->find();
        //如果用户是区域合伙人
        if($u['member_level']==3){
            //根据pid查询当前用户
            $user = M('wx_user')->field('ID')->where(array('Pid'=>$pid))->select();
            if($user){
                foreach ($user as $key=>$val){
                    $d = array(
                        'ID'=>$val['id'],
                        'member_agent'=>$id,
                        'member_area'=>''
                    );
                    M('wx_user')->save($d);
                    $this->update_member_agent($id,$val['id']);
                }
            }
        }else{
            //根据pid查询当前用户
            $user = M('wx_user')->field('ID')->where(array('Pid'=>$pid))->select();
            if($user){
                foreach ($user as $key=>$val){
                    $d = array(
                        'ID'=>$val['id'],
                        'member_agent'=>$id
                    );
                    M('wx_user')->save($d);
                    $this->update_member_agent($id,$val['id']);
                }
            }
        }
    }
    //普通粉丝升级为区域合伙人
    public function set_area(){
        $id = I('id');
        //先将用户member_level设置为3表示区域合伙人
        $d = array(
            'ID'=>$id,
            'member_level'=>3,
            'kefu_id'=>$id
        );
        $r = M('wx_user')->save($d);
        if($r){
            $this->update_member_area($id,$id);
            $arr = array(
                'code'=>1,
                'msg'=>'设置成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'设置失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //递归函数将用户升级为区域合伙人后该用户的所有无限级下级的member_area变成当前用户ID
    //参数$id 表示设置运营商用户的ID，$pid表示上级用户ID查询下级用户
    public function update_member_area($id,$pid){
        //根据pid查询当前用户
        $user = M('wx_user')->field('ID')->where(array('Pid'=>$pid))->select();
        if($user){
            foreach ($user as $key=>$val){
                if($val['member_agent']==$id){
                    $d = array(
                    'ID'=>$val['id'],
                    'member_agent'=>'',
                    'member_area'=>$id
                );
                }else{
                    $d = array(
                        'ID'=>$val['id'],
                        'member_area'=>$id
                    );
                }
                
                M('wx_user')->save($d);
                $this->update_member_area($id,$val['id']);
            }
        }
    }
    //将用户降级为普通粉丝不产生收益
    public function set_fans(){
        $id = I('id');
        $d = array(
            'ID'=>$id,
            'member_level'=>-1
        );
        $r = M('wx_user')->save($d);
        if($r){
            $arr = array(
                'code'=>1,
                'msg'=>'设置成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'设置失败'
            );
        }
        $this->ajaxReturn($arr);
        
    }
    //运营商或区域合伙人自己下单收益详细页面
    public function daili_mingxi(){
        $uid = I('id');
        //查询用户邀请的奖励
        $count_yaoqing = M('b_jiangli')->where(array('UID'=>$uid))->sum('Money');
        if(!$count_yaoqing){
            $count_yaoqing=0;
        }
        $this->assign('count_yaoqing',$count_yaoqing);
        $startTime = I('start');
        $endTime   = I('end');
        if(!$startTime){
            $startTime = "2017-08-01";
        }
        $start = strtotime($startTime);
        if(!$endTime){
            $endTime = date('Y-m-d',time());
        }
        $end   = strtotime($endTime)+24*3600;
        $p = I('p',1);
        $num = 20;
        $startnum = ($p-1)*$num;
        $User = M('a_order'); // 实例化User对象
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where (a.CreateTime between $start and $end) and (b.UID=$uid) and a.OrderStatue='订单失效'";
       
        $count_shixiao      = $User->query($sql);// 查询满足要求的总记录数
        $this->assign('count_shixiao',$count_shixiao[0]['count']);
        //查询失效订单
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where (a.CreateTime between $start and $end) and (b.UID=$uid)";
         
        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count = $count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        
        $sql = "select a.*,
        a.XiaoGuoYuGu*0.9 as a_xiaoguoyugu,
        b.ID as b_id,
        b.UID as b_uid,
        b.OrderID as b_orderid,
        b.CreateTime as b_createtime,
        b.ShouYi as b_shouyi,
        b.ShangJiUID as b_shangjiuid,
        b.ShangJiShouYi as b_shangjishouyi,
        b.ShangShangJiUID as b_shangshangjiuid,
        b.ShangShangJiShouYi as b_shangshangjishouyi,
        b.OrderStatue as b_orderstatue,
        b.agent_id as b_agent_id,
        b.agent_shouyi as b_agent_shouyi,
        b.shangji_agent_id as b_shangji_agent_id,
        b.shangji_agent_shouyi as b_shangji_agent_shouyi,
        b.area_id as b_area_id,
        b.area_shouyi as b_area_shouyi
        from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where (a.CreateTime between $start and $end) and b.UID=$uid order by a.CreateTime desc limit $startnum,$num";
        //echo $sql;exit;
        $list=$User->query($sql);
        //总预估收入
        $count_yugushouru = 0;
        //代理总收入
        $count_dailishouru=0;
        foreach ($list as $key=>$val){
            $daili_uid = $val['b_uid'];
            $shangji_uid = $val['b_shangjiuid'];
            $shangshangji_uid = $val['b_shangshangjiuid'];
            $agent_id = $val['b_agent_id'];
            $shangji_agent_id=$val['b_shangji_agent_id'];
            $area_id = $val['b_area_id'];
            if($daili_uid){
                $user = M('wx_user')->where(array('ID'=>$daili_uid))->find();
                $list[$key]['b_user']=$user['name'];
                $list[$key]['b_user_phone']=$user['phone'];
            }
            if($shangji_uid){
                $shangjiuser = M('wx_user')->where(array('ID'=>$shangji_uid))->find();
                $list[$key]['b_shangjiuser']=$shangjiuser['name'];
                $list[$key]['b_shangjiuser_phone']=$shangjiuser['phone'];
            }
            if($shangshangji_uid){
                $shangshangjiuser = M('wx_user')->where(array('ID'=>$shangshangji_uid))->find();
                $list[$key]['b_shangshangjiuser']=$shangshangjiuser['name'];
                $list[$key]['b_shangshangjiuser_phone']=$shangshangjiuser['phone'];
            }
            if($agent_id){
                $agentuser = M('wx_user')->where(array('ID'=>$agent_id))->find();
                $list[$key]['b_agentuser']=$agentuser['name'];
                $list[$key]['b_agentuser_phone']=$agentuser['phone'];
            }
            if($shangji_agent_id){
                $shangjiagentuser = M('wx_user')->where(array('ID'=>$shangji_agent_id))->find();
                $list[$key]['b_shangjiagentuser']=$shangjiagentuser['name'];
                $list[$key]['b_shangjiagentuser_phone']=$shangjiagentuser['phone'];
            }
            if($area_id){
                $areauser = M('wx_user')->where(array('ID'=>$area_id))->find();
                $list[$key]['b_areauser']=$areauser['name'];
                $list[$key]['b_areauser_phone']=$areauser['phone'];
            }
            $pingtaishouyi = $val['xiaoguoyugu']*0.9-$val['b_shouyi']-$val['b_shangjishouyi']-$val['b_shangshangjishouyi']-$val['b_agent_shouyi']-$val['b_shanji_agent_shouyi']-$val['b_area_shouyi'];
            $list[$key]['pingtaishouyi']=$pingtaishouyi;
        }
        //总的佣金收入
        $sql = "select 
            sum(a.XiaoGuoYuGu) as count ,
            sum(b.ShouYi)+sum(b.ShangJiShouYi)+sum(b.ShangShangJiShouYi) as count_daili,
            sum(b.agent_shouyi)+sum(b.shangji_agent_shouyi) as count_agent,
            sum(b.area_shouyi) as count_area
            from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where (a.CreateTime between $start and $end) and b.UID=$uid";
        
        $count_countshouru_all = $User->query($sql);
        $count_countshouru = $count_countshouru_all[0]['count'];
        if(!$count_countshouru){$count_countshouru=0;}
        //总的代理收入
        $count_dailishouru=$count_countshouru_all[0]['count_daili'];
        if(!$count_dailishouru){$count_dailishouru=0;}
        
        //总的运营商收入
        $count_agentshouru=$count_countshouru_all[0]['count_agent'];
        if(!$count_agentshouru){$count_agentshouru=0;}
        //总的运营商收入
        $count_areashouru= $count_countshouru_all[0]['count_area'];
        if(!$count_areashouru){$count_areashouru=0;}
        //平台总收入
        $count_pingtai=$count_countshouru*0.9-$count_dailishouru-$count_agentshouru-$count_areashouru;
        if(!$count_pingtai){$count_pingtai=0;}
        //单个代理的收入
        $sql1 = "select sum(b.ShouYi) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where (a.CreateTime between $start and $end) and b.UID=$uid";
       
        $count_user1=$User->query($sql1);
        $count_user= $count_user1[0]['count'];
        if(!$count_user){$count_user=0;}
        $search = array(
            'start'=>$startTime,
            'end'=>$endTime
        );
        $countshouru = array(
            //'count_yugushouru'=>round($count_yugushouru,2),//总预估收入
            'count_dailishouru'=>$count_dailishouru,//代理总收入
            'count_pingtai'=>$count_pingtai, //平台总收入
            'count_countshouru'=>$count_countshouru,
            'count_fuwufei' => $count_countshouru*0.1,
            'count_agentshouru'=>$count_agentshouru,
            'count_areashouru'=>$count_areashouru,
            //单个代理的收入
            'count_user'=>$count_user
        );
        $this->assign('search',$search);
        $this->assign('countshouru',$countshouru);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $user = M('wx_user')->where(array('ID'=>$uid))->find();
        $this->assign('user',$user);
        $this->display();
    }
    //查看运营商团队
    public function tuandui(){
        $user = $this->user;
        $uid = $user['id'];
        $start_time = I('start');
        $end_time   = I('end');
        $sort = I('sort');
        $order = '';
        if($sort==1){
            $order = ' order by YiTiXian desc';
        }
        if($sort == 2){
            $order = ' order by YuE desc';
        }
        $search = array(
            'start'=>$start_time,
            'end'=>$end_time
        );
        $this->assign('search',$search);
        $pre_id = I('id');
        //根据ID查询客服信息
        $kefu = M('wx_user')->where(array('ID'=>$pre_id))->find();
        $this->assign('kefu',$kefu);
        //查询客服的下级用户 包括用户自己
        $where = "where member_agent=$pre_id";
        $p = I('p',1);
        $num = 20;
        $start = ($p-1)*$num;
        $sql = "select count(*) as count from daili_wx_user $where";
        $res = M('wx_user')->query($sql);
        $count = $res[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $sql = "select * from daili_wx_user $where $order limit $start,$num";
        $res = M('wx_user')->query($sql);
        foreach ($res as $key=>$val){
            $b = M('wx_user')->field('ID,Name,Phone,WxNum,NickName,Address')->where(array('ID'=>$val['pid']))->find();
            $res[$key]['b_name']=$b['name'];
            $res[$key]['b_phone']=$b['phone'];
            $res[$key]['b_id']=$b['id'];
            $res[$key]['b_wxnum']=$b['wxnum'];
            $res[$key]['b_nickname']=$b['nickname'];
            $res[$key]['b_address']=$b['address'];
        }
        //查询所有客服导入的用户的ID
       /*  $sql = "select ID,AdID from daili_wx_user where kefu_id=$pre_id and ID <> $pre_id";
        $all_user_id = M('wx_user')->query($sql);
        foreach ($all_user_id as $key=>$val){
            $str_user_id .= $val['id'].',';
            $str_user_adid.=$val['adid'].',';
        }
        $str_user_id = rtrim($str_user_id,',');
        $str_user_adid=rtrim($str_user_adid,',');
        if(!$str_user_adid){
            $str_user_adid=1;
        } */
        if($start_time && !$end_time){
        
            $start_time = strtotime($start_time);
            $w1 = " and a.CreateTime >= $start_time";
         }
        if(!$start_time && $end_time){
            $end_time = strtotime($end_time)+3600*24;
            $w1 = " and a.CreateTime<=$end_time";
        }
        if($start_time && $end_time){
            $start_time=strtotime($start_time);
            $end_time  =strtotime($end_time)+3600*24;
            $w1 = " and a.CreateTime between $start_time and $end_time";
        }
        //查询客服导入的用户所有收入情况
        $sql = "select ID from daili_wx_user $where";
        $r = M('wx_user')->query($sql);
        foreach ($r as $val){
            $str_uid .= $val['id'].',';
        }
        $str_uid = rtrim($str_uid,',');
        if($str_uid){
            $sql = "select 
                count(a.id) as count_order,
                sum(a.XiaoGuoYuGu) as c_shouyi,
                sum(b.ShouYi) as b_shouyi,
                sum(b.ShangJiShouYi) as b_shangjishouyi,
                sum(b.ShangShangJiShouYi) as b_shangshangjishouyi
            from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID in ($str_uid) $w1";
            $res_tongji = M('a_order')->query($sql);
            //查询有效订单
            $sql = "select
            count(a.id) as count_order 
            from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID in ($str_uid) and a.OrderStatue='订单失效' $w1";
            $count_shixiao = M('a_order')->query($sql);
        }
        $this->assign('count_shixiao',$count_shixiao[0]['count_order']);
        /* $sql = "select
        count(a.id) as count_order,
        sum(a.XiaoGuoYuGu) as c_shouyi,
        sum(b.ShouYi) as b_shouyi,
        sum(b.ShangJiShouYi) as b_shangjishouyi,
        sum(b.ShangShangJiShouYi) as b_shangshangjishouyi
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID left join daili_wx_user as c on c.ID=b.ShangJiUId where c.kefu_id=$pre_id $w1";
        $res_tongji_shangji = M('a_order')->query($sql);
        $sql = "select
        count(a.id) as count_order,
        sum(a.XiaoGuoYuGu) as c_shouyi,
        sum(b.ShouYi) as b_shouyi,
        sum(b.ShangJiShouYi) as b_shangjishouyi,
        sum(b.ShangShangJiShouYi) as b_shangshangjishouyi
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID left join daili_wx_user as c on c.ID=b.ShangShangJiUID where c.kefu_id=$pre_id $w1";
        $res_tongji_shangshangji = M('a_order')->query($sql);
         */
        $tongji = $res_tongji[0]['count_order'];
        
        $count_daili_shouyi = 
            $res_tongji[0]['b_shouyi']+$res_tongji[0]['b_shangjishouyi']+$res_tongji[0]['b_shangshangjishouyi'];
            
        $this->assign('count_daili_shouyi',$count_daili_shouyi);
        $this->assign('tongji',$tongji);
        $c = $res_tongji[0]['c_shouyi'];
        $this->assign('count_ali',$c*0.1);
        $this->assign('count_pt',$c-$c*0.1-$count_daili_shouyi);
        $this->assign('count_shouyi',$c);
        $this->assign('p',$p);
        $this->assign('count',$count);
        $this->assign('list',$res);
        $this->assign('page',$show);
        $this->assign('pre_id',$pre_id);
        $this->assign('uid',$uid);
        $this->display();
    }
    //查看区域合伙人团队
    public function area_tuandui(){
        $user = $this->user;
        $uid = $user['id'];
        $start_time = I('start');
        $end_time   = I('end');
        $sort = I('sort');
        $order = '';
        if($sort==1){
            $order = ' order by YiTiXian desc';
        }
        if($sort == 2){
            $order = ' order by YuE desc';
        }
        $search = array(
            'start'=>$start_time,
            'end'=>$end_time
        );
        $this->assign('search',$search);
        $pre_id = I('id');
        //根据ID查询客服信息
        $kefu = M('wx_user')->where(array('ID'=>$pre_id))->find();
        $this->assign('kefu',$kefu);
        //查询客服的下级用户 包括用户自己
        $where = "where member_area=$pre_id";
        $p = I('p',1);
        $num = 20;
        $start = ($p-1)*$num;
        $sql = "select count(*) as count from daili_wx_user $where";
        $res = M('wx_user')->query($sql);
        $count = $res[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $sql = "select * from daili_wx_user $where $order limit $start,$num";
        $res = M('wx_user')->query($sql);
        foreach ($res as $key=>$val){
            $b = M('wx_user')->field('ID,Name,Phone,WxNum,NickName,Address')->where(array('ID'=>$val['pid']))->find();
            $res[$key]['b_name']=$b['name'];
            $res[$key]['b_phone']=$b['phone'];
            $res[$key]['b_id']=$b['id'];
            $res[$key]['b_wxnum']=$b['wxnum'];
            $res[$key]['b_nickname']=$b['nickname'];
            $res[$key]['b_address']=$b['address'];
        }
        //查询所有客服导入的用户的ID
        /*  $sql = "select ID,AdID from daili_wx_user where kefu_id=$pre_id and ID <> $pre_id";
         $all_user_id = M('wx_user')->query($sql);
         foreach ($all_user_id as $key=>$val){
         $str_user_id .= $val['id'].',';
         $str_user_adid.=$val['adid'].',';
         }
         $str_user_id = rtrim($str_user_id,',');
         $str_user_adid=rtrim($str_user_adid,',');
         if(!$str_user_adid){
         $str_user_adid=1;
         } */
        if($start_time && !$end_time){
    
            $start_time = strtotime($start_time);
            $w1 = " and a.CreateTime >= $start_time";
        }
        if(!$start_time && $end_time){
            $end_time = strtotime($end_time)+3600*24;
            $w1 = " and a.CreateTime<=$end_time";
        }
        if($start_time && $end_time){
            $start_time=strtotime($start_time);
            $end_time  =strtotime($end_time)+3600*24;
            $w1 = " and a.CreateTime between $start_time and $end_time";
        }
        //查询区域导入的用户所有收入情况
        $sql = "select ID from daili_wx_user $where";
        $r = M('wx_user')->query($sql);
        foreach ($r as $val){
            $str_uid .= $val['id'].',';
        }
        $str_uid = rtrim($str_uid,',');
        if($str_uid){
        $sql = "select
        count(a.id) as count_order,
        sum(a.XiaoGuoYuGu) as c_shouyi,
        sum(b.ShouYi) as b_shouyi,
        sum(b.ShangJiShouYi) as b_shangjishouyi,
        sum(b.ShangShangJiShouYi) as b_shangshangjishouyi
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID in ($str_uid) $w1";
        $res_tongji = M('a_order')->query($sql);
        //查询有效订单
        $sql = "select
        count(a.id) as count_order
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID in ($str_uid) and a.OrderStatue='订单失效' $w1";
        $count_shixiao = M('a_order')->query($sql);
        }
        $this->assign('count_shixiao',$count_shixiao[0]['count_order']);
        /* $sql = "select
        count(a.id) as count_order,
                sum(a.XiaoGuoYuGu) as c_shouyi,
                sum(b.ShouYi) as b_shouyi,
                sum(b.ShangJiShouYi) as b_shangjishouyi,
                sum(b.ShangShangJiShouYi) as b_shangshangjishouyi
                from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID left join daili_wx_user as c on c.ID=b.ShangJiUId where c.kefu_id=$pre_id $w1";
                $res_tongji_shangji = M('a_order')->query($sql);
                $sql = "select
                count(a.id) as count_order,
                sum(a.XiaoGuoYuGu) as c_shouyi,
                sum(b.ShouYi) as b_shouyi,
                sum(b.ShangJiShouYi) as b_shangjishouyi,
                sum(b.ShangShangJiShouYi) as b_shangshangjishouyi
                from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID left join daili_wx_user as c on c.ID=b.ShangShangJiUID where c.kefu_id=$pre_id $w1";
                $res_tongji_shangshangji = M('a_order')->query($sql);
                */
                $tongji = $res_tongji[0]['count_order'];
    
                    $count_daili_shouyi =
                    $res_tongji[0]['b_shouyi']+$res_tongji[0]['b_shangjishouyi']+$res_tongji[0]['b_shangshangjishouyi'];
    
                        $this->assign('count_daili_shouyi',$count_daili_shouyi);
                        $this->assign('tongji',$tongji);
                    $c = $res_tongji[0]['c_shouyi'];
        $this->assign('count_ali',$c*0.1);
        $this->assign('count_pt',$c-$c*0.1-$count_daili_shouyi);
        $this->assign('count_shouyi',$c);
        $this->assign('p',$p);
        $this->assign('count',$count);
        $this->assign('list',$res);
        $this->assign('page',$show);
        $this->assign('pre_id',$pre_id);
        $this->assign('uid',$uid);
        $this->display();
    }
    //各渠道用户升级
    public function set_user_level(){
        $p = I('p');
        //$token ='chuankeyouhui2';//创客优汇2
        //$token ="gh_26c51afe50df";//创客优汇
        //$token ="gh_90c6882faaf9";//分享宝联盟
        $token="gh_b676e24225c8";//白菜库
        $w = array(
            'GzhToken'=>$token,
            'member_level'=>1,
            //'Statue'=>1
        );
        $start = ($p-1)*1000;
        //$w['_string']='ID <> kefu_id';
        $user = M('wx_user')->field('ID,member_level')->where($w)->order('ID desc')->limit($start,1000)->select();
        //echo '<pre>';
        //echo M('wx_user')->getLastSql();exit;
        //echo '<pre>';
        //print_r($user);
        foreach($user as $key=>$val){
            //查询下级代理数量
            $where = array(
                'Pid'=>$val['id'],
                'Statue'=>1,
            );
            $u = M('wx_user')->where($where)->count();
            if($u<3){//先判断是否小于3，全部降级
                $d=array(
                    'ID'=>$val['id'],
                    'member_level'=>0,
                );
                $r = M('wx_user')->save($d);
                if($r){
                    $success += 1; 
                }else{
                    $fail += 1;
                }
            }else{
                $com += 1;
            }
        }
        echo "获取用户数量".count($user).",更新降级成功$success,失败$fail;没有降级$com";
    }
    //测试
    public function test(){
        $uid = I('id');
        $res = get_level($uid);
        echo '<pre>';
        print_r($res);
    }
}