<?php
/**
 * 数据处理控制器
 * */
namespace Home\Controller;
use Think\Controller;
class RedisController extends Controller {
    private $redis;
    public function _initialize(){
        //连接本地的 Redis 服务
        $redis = new \Redis();
        $redis->connect('127.0.0.1', 6379);
        $this->redis = $redis;
    }
    //调用发圈商品
    public function faquan_items(){
        $redis=$this->redis;
        $redis->set('key','value');
        $res = $redis->get('key');
        echo '<pre>';
        print_r($res);exit;
        $arList = $redis->keys("*");
        echo '<pre>';
        print_r($arList);exit;
        $p    = I('page',1);
        $code = I('code');
        $res = S('faquan_item'.$code.$p);
        if(!$res){
            //根据code查询用户信息
            $user = M('wx_user')->field('GzhToken,TgwID,username')->where(array('invitation_code'=>$code))->find();
            if($user['gzhtoken']=='gh_26c51afe50df' || $user['gzhtoken']=='chuankeyouhui2' || $user['gzhtoken']=='gh_b676e24225c8'){
                //根据token查询用户ID
                $u = M('user')->field('id')->where(array('token'=>'gh_26c51afe50df'))->select();
            }else{
                $u = M('user')->field('id')->where(array('token'=>'gh_90c6882faaf9'))->select();
            }
            foreach ($u as $key=>$val){
                $uid .= $val['id'].',';
            }
            //查询渠道配置信息
            $token = $user['gzhtoken'];
            $sql = "select a.* from daili_a_config_copy as a left join daili_a_media as b on a.MediaID=b.id where b.token='$token'";
            $media = M('a_config_copy')->query($sql);
            $shouyibi = $media[0]['shouyibi'];
            $uid = rtrim($uid,',');
            $num = 5;
            $start = ($p-1)*$num;
            $time = 12*3600;
            $sql = "select * from daili_wx_faquan where uid in ($uid) order by add_time desc limit $start,$num";
            $res = M('wx_faquan')->query($sql);
            foreach ($res as $key=>$val){
                if(empty($val['tj_reson'])){
                    $text = $val['title'];
                }else{
                    $text = $val['tj_reson'];
                }
                $res[$key]['title']=json_decode($val['title']);
                $replay = json_decode($val['replay']);
                //查询淘口令
                $k = M('wx_faquan_kouling')->where(array('table_id'=>$val['id'],'item_id'=>$val['num_iid'],'pid'=>$user['tgwid']))->order('add_time desc')->find();
                if(!$k['kouling'] || ($k['kouling'] && (time()-$k['add_time']>$time))){
                    $r = $this->app_zhuanlian($val['id'],$val['num_iid'],$val['youhuiquan'],$user['tgwid'],$user['token'],$text,$user['username'],$val['title'],$val['pic']);
                    $res[$key]['b_kouling']=$r['kouling'];
                    $res[$key]['b_ehy_url']=$r['ehy_url'];
                    $res[$key]['b_short_url']=$r['short_url'];
                    $res[$key]['b_pid']=$val['b_pid'];
                    $res[$key]['b_add_time']=time();
                    $commission_rate=$r['commission_rate'];
                    $kouling = $r['kouling'];
                }else{
                    $res[$key]['b_kouling']=$k['kouling'];
                    $res[$key]['b_ehy_url']=$k['ehy_url'];
                    $res[$key]['b_short_url']=$k['short_url'];
                    $res[$key]['b_pid']=$k['pid'];
                    $res[$key]['b_add_time']=$k['add_time'];
                    $commission_rate=$k['commission_rate'];
                    $kouling = $k['kouling'];
                }
                $qudao_shouyi=($shouyibi/100)*0.9*$val['price']*($commission_rate/100);
                if(strpos($replay,'【淘口令】')){
                    $replay = str_replace('【淘口令】',$kouling,$replay);
                }else{
                    $replay .= $kouling;
                }
                $res[$key]['pic']=explode(',',rtrim($val['pic'],','));
        
                $a=array(
                    $replay,$val['tj_reson']
                );
                $res[$key]['replay']=array_filter($a);
                $qudao = M('user')->where(array('id'=>$val['uid']))->find();
                $res[$key]['qudao_name']=$qudao['name'];
                $res[$key]['qudao_pic']=$qudao['pic'];
                $res[$key]['qudao_shouyi']=round($qudao_shouyi,2);
            }
        }
        $this->ajaxReturn($res);
    }
}