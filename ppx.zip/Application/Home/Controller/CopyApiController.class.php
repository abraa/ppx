<?php
/**
 * 数据处理控制器
 * */
namespace Home\Controller;
use Think\Controller;
class CopyApiController extends Controller {
    public function _initialize(){
        //查询数据库配置项
        
        $config =   M('a_config')->getField('key,value');
        C($config);
    }
    /*
     * 读取阿里妈妈账号接口
     * @param 
     * 传入参数                 无
     * 输出参数
     * [id] =>      数据ID
     * [name] =>    账号
     * [password] =>密码
     * */
    public function GetAlimama(){
        $res = M('a_alimama')->where(array('Statue'=>1))->select();
        $this->ajaxReturn($res);
    }
    /*
     * 上传Execl表格处理订单数据
     * @param
     * 传入参数
     * id      阿里妈妈账号ID
     * 输出参数
     * count        总订单数
     * success      导入成功数据
     * fail         导入失败数据
     * */
    public function UploadExcel(){
        $f=file_get_contents("php://input");
        $estr=explode("|\n|",$f);//使用|\n|划分
        $taobao = $estr[3];
        if(!$taobao){$arr = array('code'=>0,'msg'=>'请传入ID');$this->ajaxReturn($arr);}
    
        $file_name = getcwd().'/Uploads/EXECL/dingdan/order_all.xls';
        $file_name = str_replace('\\','/',$file_name);
        $fp=fopen($file_name,"w+");
        fwrite($fp,$estr[2]);
        $file_size = $estr[1];
        if($file_size>10485760){$res = array('code'=>0,'msg'=>'文件太大');$this->ajaxReturn($res);}
        vendor("PHPExcel");
        $objReader = \PHPExcel_IOFactory::createReader('Excel5');
        $objPHPExcel = $objReader->load($file_name,$encode='utf-8');
    
        $sheet = $objPHPExcel->getSheet(0);
    
        $highestRow = $sheet->getHighestRow(); // 取得总行数
        $highestColumn = $sheet->getHighestColumn(); // 取得总列数
    
        if($objPHPExcel->getActiveSheet()->getCell('A1')->getValue() != '创建时间'){$res = array( 'code'=>0,'msg'=>'导入失败,导入的EXECL数据不正确' );$this->ajaxReturn($res);}
        for($i=65;$i<91;$i++){
            $arr_A[] = strtoupper(chr($i));
        }
        foreach ($arr_A as $val){
            if($highestColumn == 'A'.$val){
                $arr_A[]='A'.$val;
                break;
            }else{
                $arr_A[]='A'.$val;
            }
        }
        //查询数据库中的字段
        $sql = 'SHOW COLUMNS FROM daili_a_order';
        $res = M('a_order')->query($sql);
        unset($res[0]);
        foreach ($res as $key=>$val){
            if($arr_A[$key-1]){
                $fields[$arr_A[$key-1]]=$val['field'];
            }
        }
        $success=0;
        $fail = 0;
        $error= 0;
        $update=0;
        for($i=2;$i<=$highestRow;$i++){
            $data = array();
            foreach($arr_A as $val){
                $value = $objPHPExcel->getActiveSheet()->getCell($val.$i)->getValue();
                if($fields[$val]=='CreateTime' || $fields[$val]=='ClickTime' || $fields[$val]=='CompleteTime'){
                    $value=strtotime($value);
                }
                $data[$fields[$val]] = $value;
            }
            if($data['OrderStatue']=='订单失效'){
                $data['ShouYiStatue']=-1;//
                $orderstatue=0;
            }else{
                $orderstatue=1;
            }
            $data['AliMaMaID']=$taobao;
            $w = array(
                'CreateTime'=>$data['CreateTime'],
                'ItemID'=>$data['ItemID'],
                'OrderNum'=>$data['OrderNum'],
                'Price'=>$data['Price'],
                'XiaoGuoYuGu'=>$data['XiaoGuoYuGu']
            );
            $res = M('a_order')->where($w)->find();
            if(!$res){
                //获取商品图片信息
                $iteminfo = get_item_infos($data['ItemID']);
                $data['IMG']=$iteminfo['pict_url'].'_200x200';
                $res_order = M('a_order')->add($data);
                if($res_order){
                    //订单加成功后加收益
                    //根据媒体ID查询媒体配置
                    $mediaid = $data['MediaID'];
                    $sql = "select b.* from daili_a_media as a left join daili_a_config_copy as b on a.ID=b.MediaID where a.media_id=$mediaid";
                    $config = M('a_media')->query($sql);
                    $ww = array(
                        'MediaID'=>$mediaid,
                        'AdID'=>$data['AdID'],
                    );
                    $user = M('wx_user')->field('ID,Pid')->where($ww)->find();
                    if($user['id']){
                        $UID = 0;
                        $shouyi=0;
                        $shangjiUID=0;
                        $shangjishouyi=0;
                        $shangshangjiUID=0;
                        $shangshangjishouyi=0;
                        //统计用户收益数据表加收益
                        $shouyi = $data['XiaoGuoYuGu']*0.9*($config[0]['shouyibi']/100);
                        if($user['pid']){
                            //查询上级代理用户给上级数据表加收益
                            $shangji_user = M('wx_user')->field('ID,Pid')->where(array('ID'=>$user['pid']))->find();
                            $shangjishouyi=$data['XiaoGuoYuGu']*0.9*($config[0]['shangjishouyibi']/100);
                        }
                        if($shangji_user['pid']){
                            //查询上上级代理用户
                            $shangshangji_user = M('wx_user')->field('ID,Pid')->where(array('ID'=>$shangji_user['pid']))->find();
                            $shangshangjishouyi=$data['XiaoGuoYuGu']*0.9*($config[0]['shangshangjishouyibi']/100);
                        }
                        $w = array(
                            'UID'=>$user['id'],
                            'OrderID'=>$res_order
                        );
                        $res = M('a_shouyi')->where($w)->find();
                        if(!$res){
                            $UID = $user['id'];
                            M('wx_user')->where(array('ID'=>$user['id']))->setInc('YuE',$shouyi);
                            if($shangji_user){
                                $shangjiUID = $shangji_user['id'];
                                M('wx_user')->where(array('ID'=>$shangji_user['id']))->setInc('YuE',$shangjishouyi);
                            }
                            if($shangshangji_user){
                                $shangshangjiUID=$shangshangji_user['id'];
                                M('wx_user')->where(array('ID'=>$shangshangji_user['id']))->setInc('YuE',$shangshangjishouyi);
                            }
                            $shouyidata = array(
                                'UID'=>$UID,
                                'ShouYi'=>$shouyi,
                                'ShangJiUID'=>$shangjiUID,
                                'ShangJiShouYi'=>$shangjishouyi,
                                'ShangShangJiUID'=>$shangshangjiUID,
                                'ShangShangJiShouYi'=>$shangshangjishouyi,
                                'OrderStatue'=>$orderstatue,
                                'OrderID'=>$res_order,
                                'CreateTime'=>$data['CreateTime']
                            );
                            //添加收益
                            M('a_shouyi')->add($shouyidata);
                            //收益添加成功后修改订单状态
                            $d = array(
                                'ID'=>$res_order,
                                'ShouYiStatue'=>1
                            );
                            M('a_order')->save($d);
                        }
                        //计划任务执行的方法不需要输出
                    }
                    $success += 1;
                }else{
                    $error += 1;
                    $error_order_msg .= $data['OrderNum'].'&'.$data['ItemID'].'&'.$data['CreateTime'].'添加失败;';
                }
            }else{
                $data['ID']=$res['id'];
                $res = M('a_order')->save($data);
                if($res){
                    $update += 1;
                    $update_order_msg .= $data['OrderNum'].'&'.$data['ItemID'].'&'.$data['CreateTime'].'修改订单成功;';
                }else{
                    $fail += 1;
                    $fail_order_msg .= $data['OrderNum'].'&'.$data['ItemID'].'&'.$data['CreateTime'].'修改订单失败';
                }
            }
        }
        $arr = array(
            'count'=>$highestRow-1,//总订单数据
            'success'=>$success,    //添加成功
            'fail'=>$fail,          //修改失败
            'update'=>$update,      //修改成功
            'error'=>$error         //添加失败
        );
        AddwxLog($arr,'上传订单成功失败数据');
        AddwxLog($error_order_msg,'上传订单失败数据');
        AddwxLog($fail_order_msg,'上传订单重复数据');
        AddwxLog($update_order_msg,'修改订单成功数据');
        $this->ajaxReturn($arr);
    }
    public function UploadExcel_new(){
        $f=file_get_contents("php://input");
        $estr=explode("|\n|",$f);//使用|\n|划分
        $taobao = $estr[3];
        if(!$taobao){$arr = array('code'=>0,'msg'=>'请传入ID');$this->ajaxReturn($arr);}
        
        $file_name = getcwd().'/Uploads/EXECL/dingdan/order_all.xls';
        $file_name = str_replace('\\','/',$file_name);
        $fp=fopen($file_name,"w+");
        fwrite($fp,$estr[2]);
        $file_size = $estr[1];
        if($file_size>10485760){$res = array('code'=>0,'msg'=>'文件太大');$this->ajaxReturn($res);}
        vendor("PHPExcel");
        $objReader = \PHPExcel_IOFactory::createReader('Excel5');
        $objPHPExcel = $objReader->load($file_name,$encode='utf-8');
        
        $sheet = $objPHPExcel->getSheet(0);
        
        $highestRow = $sheet->getHighestRow(); // 取得总行数
        $highestColumn = $sheet->getHighestColumn(); // 取得总列数
        
        if($objPHPExcel->getActiveSheet()->getCell('A1')->getValue() != '创建时间'){$res = array( 'code'=>0,'msg'=>'导入失败,导入的EXECL数据不正确' );$this->ajaxReturn($res);}
        for($i=65;$i<91;$i++){
            $arr_A[] = strtoupper(chr($i));
        }
         
        foreach ($arr_A as $val){
            if($highestColumn == 'A'.$val){
                $arr_A[]='A'.$val;
                break;
            }else{
                $arr_A[]='A'.$val;
            }
        }
        //清空数据表
        $sql = 'truncate `daili_a_order_copy_test_all`';
        M('a_order_copy_test_all')->execute($sql);
        //查询数据库中的字段
        $sql = 'SHOW COLUMNS FROM daili_a_order_copy_test_all';
        $res = M('a_order_copy_test_all')->query($sql);
        unset($res[0]);
        foreach ($res as $key=>$val){
            if($arr_A[$key-1]){
                $fields[$arr_A[$key-1]]=$val['field'];
            }
        }
        $success=0;
        $fail = 0;
        $error= 0;
        $update=0;
        for($i=2;$i<=$highestRow;$i++){
            $data = array();
            foreach($arr_A as $val){
                $value = $objPHPExcel->getActiveSheet()->getCell($val.$i)->getValue();
                if($fields[$val]=='CreateTime' || $fields[$val]=='ClickTime' || $fields[$val]=='CompleteTime'){
                    $value=strtotime($value);
                }
                $data[$fields[$val]] = $value;
            }
            if($data['OrderStatue']=='订单失效'){
                $data['ShouYiStatue']=-1;//
            }
            $data['AliMaMaID']=$taobao;
            $w = array(
                'CreateTime'=>$data['CreateTime'],
                'OrderNum'=>$data['OrderNum'],
            );
            $res = M('a_order_copy_test_all')->field('ID,OrderNum,Num')->where($w)->order('Num desc')->find();
            if($res){
                $num = $res['num']+1;
            }else{
                $num = 1;
            }
            $data['Num']=$num;
            //将订单全部加入到order_copy_test 数据表中
            //获取商品图片信息
            $iteminfo = get_item_infos($data['ItemID']);
            $data['IMG']=$iteminfo['pict_url'].'_200x200';
            M('a_order_copy_test_all')->add($data);
        }
        $orders = M('a_order_copy_test_all')->order('id desc')->select();
        
        foreach ($orders as $key=>$val){
            //先查询order表中是否有这个订单
            $w = array(
                'CreateTime'=>$val['createtime'],
                'Num'=>$val['num'],
                'OrderNum'=>$val['ordernum'],
            );
            $res = M('a_order_test')->field('ID,OrderNum,Num')->where($w)->find();
            if(!$res){
                $data = array(
                    'CreateTime' => $val['createtime'],
                    'ClickTime' => $val['clicktime'],
                    'Title' => $val['title'],
                    'ItemID' => $val['itemid'],
                    'ShopUser' => $val['shopuser'],
                    'ShopName' => $val['shopname'],
                    'ItemNum' => $val['itemnum'],
                    'Price' => $val['price'],
                    'OrderStatue' => $val['orderstatue'],
                    'OrderType' => $val['ordertype'],
                    'ShouruBi' => $val['shourubi'],
                    'FenChengBi' => $val['fenchengbi'],
                    'Bay' => $val['pay'],
                    'XiaoGuoYuGu' => $val['xiaoguoyugu'],
                    'JieSuanJinE' => $val['jiesuanjine'],
                    'YuGuShouRu' => $val['yugushouru'],
                    'CompleteTime' => $val['completetime'],
                    'YongJinBi' => $val['yongjinbi'],
                    'YongJinJinE' => $val['yongjinjine'],
                    'BuTieBi' => $val['butiebi'],
                    'BuTieJinE' => $val['butiejine'],
                    'BuTieType' => $val['butietype'],
                    'ChengJiaoPingTai' => $val['chengjiaopingtai'],
                    'ThirdFuWu' => $val['thirdfuwu'],
                    'OrderNum' => $val['ordernum'],
                    'Cate' => $val['cate'],
                    'MediaID' => $val['mediaid'],
                    'MediaName' => $val['medianame'],
                    'AdID' => $val['adid'],
                    'AdName' => $val['adname'],
                    'AliMaMaID' => $val['alimamaid'],
                    'ShouYiStatue' => $val['shouyistatue'],
                    'IMG' => $val['img'],
                    'Num' => $val['num'],
                );
                if($val['orderstatue']=='订单失效'){
                    $orderstatue=0;
                }else{
                    $orderstatue=1;
                }
                $res_order = M('a_order_test')->add($data);
                if($res_order){
                    //订单加成功后加收益
                    //根据媒体ID查询媒体配置
                    $mediaid = $val['mediaid'];
                    $sql = "select b.* from daili_a_media as a left join daili_a_config_copy as b on a.ID=b.MediaID where a.media_id=$mediaid";
                    $config = M('a_media')->query($sql);
                    $ww = array(
                        'MediaID'=>$mediaid,
                        'AdID'=>$val['adid'],
                    );
                    $user = M('wx_user_test')->field('ID,Pid')->where($ww)->find();
                    if($user['id']){
                        $w = array(
                            'UID'=>$user['id'],
                            'OrderID'=>$res_order
                        );
                        $res = M('a_shouyi_test')->where($w)->find();
                        if(!$res){
                            $UID = 0;
                            $shouyi=0;
                            $shangjiUID=0;
                            $shangjishouyi=0;
                            $shangshangjiUID=0;
                            $shangshangjishouyi=0;
                            $shangji_user=array();
                            $shangshangji_user=array();
                            //统计用户收益数据表加收益

                            $UID = $user['id'];
                            $shouyi = $val['xiaoguoyugu']*0.9*($config[0]['shouyibi']/100);
                            
                            M('wx_user_test')->where(array('ID'=>$user['id']))->setInc('YuE',$shouyi);
                            if($user['pid']){
                                //查询上级代理用户给上级数据表加收益
                                $shangji_user = M('wx_user_test')->field('ID,Pid')->where(array('ID'=>$user['pid']))->find();
                                $shangjishouyi=$val['xiaoguoyugu']*0.9*($config[0]['shangjishouyibi']/100);
                                $shangjiUID = $shangji_user['id'];
                                M('wx_user_test')->where(array('ID'=>$shangji_user['id']))->setInc('YuE',$shangjishouyi);
                            }
                            if($shangji_user['pid']){
                                //查询上上级代理用户
                                $shangshangji_user = M('wx_user_test')->field('ID,Pid')->where(array('ID'=>$shangji_user['pid']))->find();
                                $shangshangjishouyi=$val['xiaoguoyugu']*0.9*($config[0]['shangshangjishouyibi']/100);
                                $shangshangjiUID=$shangshangji_user['id'];
                                M('wx_user_test')->where(array('ID'=>$shangshangji_user['id']))->setInc('YuE',$shangshangjishouyi);
                            }
                            $shouyidata = array(
                                'UID'=>$UID,
                                'ShouYi'=>$shouyi,
                                'ShangJiUID'=>$shangjiUID,
                                'ShangJiShouYi'=>$shangjishouyi,
                                'ShangShangJiUID'=>$shangshangjiUID,
                                'ShangShangJiShouYi'=>$shangshangjishouyi,
                                'OrderStatue'=>$orderstatue,
                                'OrderID'=>$res_order,
                                'CreateTime'=>$val['createtime']
                            );
                            //添加收益
                            M('a_shouyi')->add($shouyidata);
                            //收益添加成功后修改订单状态
                            $d = array(
                                'ID'=>$res_order,
                                'ShouYiStatue'=>1
                            );
                            M('a_order_test')->save($d);
                        }
                        //计划任务执行的方法不需要输出
                    }
                    $success += 1;
                }else{
                    $error += 1;
                    $error_order_msg .= $data['ordernum'].'&'.$data['itemid'].'&'.date('Y-m-d H:i:s',$data['createtime']).'添加失败;';
                }
            }
        }
        
        $arr = array(
            'count'=>$highestRow-1,//总订单数据
            'success'=>$success,    //添加成功
            'error'=>$error         //添加失败
        );
        AddwxLog($arr,'上传订单成功失败数据');
        AddwxLog($error_order_msg,'上传失败的订单数据');
        $this->ajaxReturn($arr);
    }
    /*
     * 上传Execl表格处理订单数据（失效订单数据）
     * @param
     * 传入参数
     * id      阿里妈妈账号ID
     * 输出参数
     * count        总订单数
     * success      导入成功数据
     * fail         导入失败数据
     * */
    public function UploadExcelShiXiao(){
       
        $f=file_get_contents("php://input");
        $estr=explode("|\n|",$f);//使用|\n|划分
        //$taobao = I('id');
        $taobao = $estr[3];
        if(!$taobao){$arr = array('code'=>0,'msg'=>'请传入ID');$this->ajaxReturn($arr);}
        
        $file_name = getcwd().'/Uploads/EXECL/dingdan/order_shixiao.xls';
        $file_name = str_replace('\\','/',$file_name);
        $fp=fopen($file_name,"w+");
        
        fwrite($fp,$estr[2]);
        $file_size = $estr[1];
        if($file_size>10485760){$res = array('code'=>0,'msg'=>'文件太大');$this->ajaxReturn($res);}
        vendor("PHPExcel");
        $objReader = \PHPExcel_IOFactory::createReader('Excel5');
        $objPHPExcel = $objReader->load($file_name,$encode='utf-8');
        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow(); // 取得总行数
        
        $highestColumn = $sheet->getHighestColumn(); // 取得总列数
    
        if($objPHPExcel->getActiveSheet()->getCell('A1')->getValue() != '创建时间'){$res = array( 'code'=>0,'msg'=>'导入失败,导入的EXECL数据不正确' );$this->ajaxReturn($res);}
        for($i=65;$i<91;$i++){
            $arr_A[] = strtoupper(chr($i));
        }
        foreach ($arr_A as $val){
            if($highestColumn == 'A'.$val){
                $arr_A[]='A'.$val;
                break;
            }else{
                $arr_A[]='A'.$val;
            }
        }
        //查询数据库中的字段
        $sql = 'SHOW COLUMNS FROM daili_a_order';
        $res = M('a_order')->query($sql);
        unset($res[0]);
        foreach ($res as $key=>$val){
            $fields[$arr_A[$key-1]]=$val['field'];
        }
        $success=0;
        $fail = 0;
        $error=0;
        $other =0;
        for($i=2;$i<=$highestRow;$i++){
            $data = array();
            foreach($arr_A as $val){
                $value = $objPHPExcel->getActiveSheet()->getCell($val.$i)->getValue();
                if($fields[$val]=='CreateTime' || $fields[$val]=='ClickTime'){
                    $value=strtotime($value);
                }
                $data[$fields[$val]] = $value;
            }
            $data['AliMaMaID']=$taobao;
            $w = array(
                'CreateTime'=>$data['CreateTime'],
                'ItemID'=>$data['ItemID'],
                'OrderNum'=>$data['OrderNum'],
                'Price'=>$data['Price'],
                //'XiaoGuoYuGu'=>$data['XiaoGuoYuGu'],
                'AliMaMaID'=>$data['AliMaMaID']
            );
            $res_order = M('a_order')->where($w)->find();
            if($res_order){
                //判断原来订单是否有效
                if($res_order['orderstatue'] != '订单失效'){
                    //将原来添加过收益的订单全部变为0，然后减去用户的收益
                    $data['ShouYiStatue']=-1;//表示订单失效
                    $res = M('a_order')->where(array('ID'=>$res['id']))->save($data);
                    if($res){
                        //根据订单ID查询添加过的收益数据
                        $shouyi = M('a_shouyi')->where(array('OrderId'=>$res_order['id']))->find();
                        if($shouyi){
                            $uid = $shouyi['uid'];
                            $shouyi=$shouyi['shouyi'];
                            M('wx_user')->where(array('ID'=>$uid))->setDec('YuE',$shouyi);
                            $shangjiuid = $shouyi['shangjiuid'];
                            $shangjishouyi=$shouyi['shangjishouyi'];
                            M('wx_user')->where(array('ID'=>$uid))->setDec('YuE',$shangjishouyi);
                            $shangshangjiuid = $shouyi['shangshangjiuid'];
                            $shangshangjishouyi=$shouyi['shangshangjishouyi'];
                            M('wx_user')->where(array('ID'=>$uid))->setDec('YuE',$shangshangjishouyi);
                            $d = array(
                                'ID'=>$shouyi['id'],
                                'OrderStatue'=>0,
                                'UpdateTime'=>time()
                            );
                            M('a_shouyi')->save($d);
                        }
                        $success +=1;
                    }else{
                        $error += 1;
                        $error_order_msg .= $data['OrderNum'].'&'.$data['ItemID'].'&'.$data['CreateTime'].'修改订单失败;';
                    }
                }else{
                    $fail += 1;
                    $fail_order_msg .= $data['OrderNum'].'&'.$data['ItemID'].'&'.$data['CreateTime'].'不需要修改的订单;';
                    continue;
                }
            }else{
                $other += 1;
                $other_order_msg .= $data['OrderNum'].'&'.$data['ItemID'].'&'.$data['CreateTime'].'不存在的订单;';
                continue;
            }
        }
        $arr = array(
            'count'=>$highestRow-1,
            'success'=>$success,
            'fail'=>$fail,
            'error'=>$error,
            'other'=>$other
        );
        AddwxLog($arr,'上传失效订单,修改数据');
        AddwxLog($fail_order_msg,'上传失效订单，不需要修改的数据');
        AddwxLog($error_order_msg,'上传失效订单，修改失败的数据');
        $this->ajaxReturn($arr);
    }
    public function UploadExcelShiXiao_new(){
         
        $f=file_get_contents("php://input");
        $estr=explode("|\n|",$f);//使用|\n|划分
        //$taobao = I('id');
        $taobao = $estr[3];
        if(!$taobao){$arr = array('code'=>0,'msg'=>'请传入ID');$this->ajaxReturn($arr);}
    
        $file_name = getcwd().'/Uploads/EXECL/dingdan/order_shixiao.xls';
        $file_name = str_replace('\\','/',$file_name);
        $fp=fopen($file_name,"w+");
    
        fwrite($fp,$estr[2]);
        $file_size = $estr[1];
        if($file_size>10485760){$res = array('code'=>0,'msg'=>'文件太大');$this->ajaxReturn($res);}
        vendor("PHPExcel");
        $objReader = \PHPExcel_IOFactory::createReader('Excel5');
        $objPHPExcel = $objReader->load($file_name,$encode='utf-8');
        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow(); // 取得总行数
    
        $highestColumn = $sheet->getHighestColumn(); // 取得总列数
    
        if($objPHPExcel->getActiveSheet()->getCell('A1')->getValue() != '创建时间'){$res = array( 'code'=>0,'msg'=>'导入失败,导入的EXECL数据不正确' );$this->ajaxReturn($res);}
        for($i=65;$i<91;$i++){
            $arr_A[] = strtoupper(chr($i));
        }
        foreach ($arr_A as $val){
            if($highestColumn == 'A'.$val){
                $arr_A[]='A'.$val;
                break;
            }else{
                $arr_A[]='A'.$val;
            }
        }
        //清空数据表
        $sql = 'truncate daili_a_order_copy_test_shixiao';
        M('a_order_copy_test_shixiao')->execute($sql);
        //查询数据库中的字段
        $sql = 'SHOW COLUMNS FROM daili_a_order_copy_test_shixiao';
        $res = M('a_order_copy_test_shixiao')->query($sql);
        unset($res[0]);
        foreach ($res as $key=>$val){
            $fields[$arr_A[$key-1]]=$val['field'];
        }
        $success=0;
        $fail = 0;
        $error=0;
        $other =0;
        for($i=2;$i<=$highestRow;$i++){
            $data = array();
            foreach($arr_A as $val){
                $value = $objPHPExcel->getActiveSheet()->getCell($val.$i)->getValue();
                if($fields[$val]=='CreateTime' || $fields[$val]=='ClickTime'){
                    $value=strtotime($value);
                }
                $data[$fields[$val]] = $value;
            }
            $data['AliMaMaID']=$taobao;
            $w = array(
                'CreateTime'=>$data['CreateTime'],
                'OrderNum'=>$data['OrderNum'],
            );
            $res = M('a_order_copy_test_shixiao')->field('ID,OrderNum,Num')->where($w)->order('Num desc')->find();
            if($res){
                $num = $res['num']+1;
            }else{
                $num = 1;
            }
            $data['Num']=$num;
            //将订单全部加入到order_copy_test 数据表中
            //获取商品图片信息
            $iteminfo = get_item_infos($data['ItemID']);
            $data['IMG']=$iteminfo['pict_url'].'_200x200';
            M('a_order_copy_test_shixiao')->add($data);
        }
        $orders = M('a_order_copy_test_shixiao')->select();
        foreach ($orders as $key=>$val){
            
            $w = array(
                'CreateTime'=>$val['createtime'],
                'Num'=>$val['num'],
                'OrderNum'=>$val['ordernum'],
            );
            $a = M('a_order')->field('ID,OrderStatue')->where($w)->find();
            //判断原来订单是否有效
            if($a['orderstatue'] != '订单失效'){
                //将原来添加过收益的订单全部变为-1，然后减去用户的收益
                $data = array(
                    'ID'=>$val['id'],
                    'CreateTime' => $val['createtime'],
                    'ClickTime' => $val['clicktime'],
                    'Title' => $val['title'],
                    'ItemID' => $val['itemid'],
                    'ShopUser' => $val['shopuser'],
                    'ShopName' => $val['shopname'],
                    'ItemNum' => $val['itemnum'],
                    'Price' => $val['price'],
                    'OrderStatue' => $val['orderstatue'],
                    'OrderType' => $val['ordertype'],
                    'ShouruBi' => $val['shourubi'],
                    'FenChengBi' => $val['fenchengbi'],
                    'Bay' => $val['pay'],
                    'XiaoGuoYuGu' => $val['xiaoguoyugu'],
                    'JieSuanJinE' => $val['jiesuanjine'],
                    'YuGuShouRu' => $val['yugushouru'],
                    'CompleteTime' => $val['completetime'],
                    'YongJinBi' => $val['yongjinbi'],
                    'YongJinJinE' => $val['yongjinjine'],
                    'BuTieBi' => $val['butiebi'],
                    'BuTieJinE' => $val['butiejine'],
                    'BuTieType' => $val['butietype'],
                    'ChengJiaoPingTai' => $val['chengjiaopingtai'],
                    'ThirdFuWu' => $val['thirdfuwu'],
                    'OrderNum' => $val['ordernum'],
                    'Cate' => $val['cate'],
                    'MediaID' => $val['mediaid'],
                    'MediaName' => $val['medianame'],
                    'AdID' => $val['adid'],
                    'AdName' => $val['adname'],
                    'AliMaMaID' => $val['alimamaid'],
                    'ShouYiStatue' => -1,
                    'IMG' => $val['img'],
                    'Num' => $val['num'],
                );
                $res = M('a_order')->where(array('ID'=>$a['id']))->save($data);
                if($res){
                    //根据订单ID查询添加过的收益数据
                    $shouyi = M('a_shouyi')->where(array('OrderId'=>$a['id']))->find();
                    if($shouyi){
                        $uid = $shouyi['uid'];
                        $shouyi=$shouyi['shouyi'];
                        M('wx_user')->where(array('ID'=>$uid))->setDec('YuE',$shouyi);
                        $shangjiuid = $shouyi['shangjiuid'];
                        $shangjishouyi=$shouyi['shangjishouyi'];
                        if($shangjiuid){
                            M('wx_user')->where(array('ID'=>$shangjiuid))->setDec('YuE',$shangjishouyi);
                        }
                        $shangshangjiuid = $shouyi['shangshangjiuid'];
                        if($shangshangjiuid){
                            $shangshangjishouyi=$shouyi['shangshangjishouyi'];
                            M('wx_user')->where(array('ID'=>$shangshangjiuid))->setDec('YuE',$shangshangjishouyi);
                        }
                        $d = array(
                            'ID'=>$shouyi['id'],
                            'OrderStatue'=>0,
                            'UpdateTime'=>time()
                        );
                        M('a_shouyi')->save($d);
                    }
                    $success +=1;
                }else{
                    $error += 1;
                    $error_order_msg .= $val['ordernum'].'&'.$val['itemid'].'&'.$val['createtime'].'修改订单失败;';
                }
            }
        }
        $arr = array(
            'count'=>$highestRow-1,
            'success'=>$success,
            'error'=>$error,
        );
        AddwxLog($arr,'上传失效订单,修改数据');
        AddwxLog($error_order_msg,'上传失效订单，修改失败的数据');
        $this->ajaxReturn($arr);
    }
    /**
     * 上传结算订单
     * */
    public function UploadExcelJieSuan(){
         
        $f=file_get_contents("php://input");
        $estr=explode("|\n|",$f);//使用|\n|划分
        //$taobao = I('id');
        $taobao = $estr[3];
        if(!$taobao){$arr = array('code'=>0,'msg'=>'请传入ID');$this->ajaxReturn($arr);}
    
        $file_name = getcwd().'/Uploads/EXECL/dingdan/order_jiesuan.xls';
        $file_name = str_replace('\\','/',$file_name);
        $fp=fopen($file_name,"w+");
    
        fwrite($fp,$estr[2]);
        $file_size = $estr[1];
        if($file_size>10485760){$res = array('code'=>0,'msg'=>'文件太大');$this->ajaxReturn($res);}
        vendor("PHPExcel");
        $objReader = \PHPExcel_IOFactory::createReader('Excel5');
        $objPHPExcel = $objReader->load($file_name,$encode='utf-8');
        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow(); // 取得总行数
    
        $highestColumn = $sheet->getHighestColumn(); // 取得总列数
    
        if($objPHPExcel->getActiveSheet()->getCell('A1')->getValue() != '创建时间'){$res = array( 'code'=>0,'msg'=>'导入失败,导入的EXECL数据不正确' );$this->ajaxReturn($res);}
        for($i=65;$i<91;$i++){
            $arr_A[] = strtoupper(chr($i));
        }
        foreach ($arr_A as $val){
            if($highestColumn == 'A'.$val){
                $arr_A[]='A'.$val;
                break;
            }else{
                $arr_A[]='A'.$val;
            }
        }
        //清空数据表
        $sql = 'truncate daili_a_order_copy_test_jiesuan';
        M('a_order_copy_test_jiesuan')->execute($sql);
        //查询数据库中的字段
        $sql = 'SHOW COLUMNS FROM daili_a_order_copy_test_jiesuan';
        $res = M('a_order_copy_test_jiesuan')->query($sql);
        unset($res[0]);
        foreach ($res as $key=>$val){
            $fields[$arr_A[$key-1]]=$val['field'];
        }
        $success=0;
        $fail = 0;
        $error=0;
        $other =0;
        for($i=2;$i<=$highestRow;$i++){
            $data = array();
            foreach($arr_A as $val){
                $value = $objPHPExcel->getActiveSheet()->getCell($val.$i)->getValue();
                if($fields[$val]=='CreateTime' || $fields[$val]=='ClickTime'){
                    $value=strtotime($value);
                }
                $data[$fields[$val]] = $value;
            }
            $data['AliMaMaID']=$taobao;
            $w = array(
                'CreateTime'=>$data['CreateTime'],
                'OrderNum'=>$data['OrderNum'],
            );
            $res = M('a_order_copy_test_jiesuan')->field('ID,OrderNum,Num')->where($w)->order('Num desc')->find();
            if($res){
                $num = $res['num']+1;
            }else{
                $num = 1;
            }
            $data['Num']=$num;
            //将订单全部加入到order_copy_test 数据表中
            //获取商品图片信息
            $iteminfo = get_item_infos($data['ItemID']);
            $data['IMG']=$iteminfo['pict_url'].'_200x200';
            M('a_order_copy_test_jiesuan')->add($data);
        }
        $orders = M('a_order_copy_test_jiesuan')->select();
        foreach ($orders as $key=>$val){
            $w = array(
                'CreateTime'=>$val['createtime'],
                'Num'=>$val['num'],
                'OrderNum'=>$val['ordernum'],
            );
            $a = M('a_order')->field('ID,OrderStatue')->where($w)->find();
            //判断原来订单是否有效
            if($a['orderstatue'] != '订单结算'){
                $data = array(
                    'ID'=>$a['id'],
                    'CreateTime' => $val['createtime'],
                    'ClickTime' => $val['clicktime'],
                    'Title' => $val['title'],
                    'ItemID' => $val['itemid'],
                    'ShopUser' => $val['shopuser'],
                    'ShopName' => $val['shopname'],
                    'ItemNum' => $val['itemnum'],
                    'Price' => $val['price'],
                    'OrderStatue' => $val['orderstatue'],
                    'OrderType' => $val['ordertype'],
                    'ShouruBi' => $val['shourubi'],
                    'FenChengBi' => $val['fenchengbi'],
                    'Bay' => $val['pay'],
                    'XiaoGuoYuGu' => $val['xiaoguoyugu'],
                    'JieSuanJinE' => $val['jiesuanjine'],
                    'YuGuShouRu' => $val['yugushouru'],
                    'CompleteTime' => $val['completetime'],
                    'YongJinBi' => $val['yongjinbi'],
                    'YongJinJinE' => $val['yongjinjine'],
                    'BuTieBi' => $val['butiebi'],
                    'BuTieJinE' => $val['butiejine'],
                    'BuTieType' => $val['butietype'],
                    'ChengJiaoPingTai' => $val['chengjiaopingtai'],
                    'ThirdFuWu' => $val['thirdfuwu'],
                    'OrderNum' => $val['ordernum'],
                    'Cate' => $val['cate'],
                    'MediaID' => $val['mediaid'],
                    'MediaName' => $val['medianame'],
                    'AdID' => $val['adid'],
                    'AdName' => $val['adname'],
                    'AliMaMaID' => $val['alimamaid'],
                    'ShouYiStatue' => $val['shouyistatue'],
                    'IMG' => $val['img'],
                    'Num' => $val['num'],
                );
                //修改订单状态为结算
                $res = M('a_order')->where(array('ID'=>$a['id']))->save($data);
                if($res){
                    $success +=1;
                }else{
                    $error += 1;
                    $error_order_msg .= $val['ordernum'].'&'.$val['itemid'].'&'.$val['createtime'].'修改结算订单失败;';
                }
            }
        }
        $arr = array(
            'count'=>$highestRow-1,
            'success'=>$success,
            'error'=>$error,
        );
        AddwxLog($arr,'上传结算订单,修改数据');
        AddwxLog($error_order_msg,'上传结算订单，修改失败的数据');
        $this->ajaxReturn($arr);
    }
    public function UploadExcelJieSuan_new(){
         
        $f=file_get_contents("php://input");
        $estr=explode("|\n|",$f);//使用|\n|划分
        //$taobao = I('id');
        $taobao = $estr[3];
        if(!$taobao){$arr = array('code'=>0,'msg'=>'请传入ID');$this->ajaxReturn($arr);}
    
        $file_name = getcwd().'/Uploads/EXECL/dingdan/order_jiesuan.xls';
        $file_name = str_replace('\\','/',$file_name);
        $fp=fopen($file_name,"w+");
    
        fwrite($fp,$estr[2]);
        $file_size = $estr[1];
        if($file_size>10485760){$res = array('code'=>0,'msg'=>'文件太大');$this->ajaxReturn($res);}
        vendor("PHPExcel");
        $objReader = \PHPExcel_IOFactory::createReader('Excel5');
        $objPHPExcel = $objReader->load($file_name,$encode='utf-8');
        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow(); // 取得总行数
    
        $highestColumn = $sheet->getHighestColumn(); // 取得总列数
    
        if($objPHPExcel->getActiveSheet()->getCell('A1')->getValue() != '创建时间'){$res = array( 'code'=>0,'msg'=>'导入失败,导入的EXECL数据不正确' );$this->ajaxReturn($res);}
        for($i=65;$i<91;$i++){
            $arr_A[] = strtoupper(chr($i));
        }
        foreach ($arr_A as $val){
            if($highestColumn == 'A'.$val){
                $arr_A[]='A'.$val;
                break;
            }else{
                $arr_A[]='A'.$val;
            }
        }
        //清空数据表
        $sql = 'truncate daili_a_order_copy_test_jiesuan';
        M('a_order_copy_test_jiesuan')->execute($sql);
        //查询数据库中的字段
        $sql = 'SHOW COLUMNS FROM daili_a_order_copy_test_jiesuan';
        $res = M('a_order_copy_test_jiesuan')->query($sql);
        unset($res[0]);
        foreach ($res as $key=>$val){
            $fields[$arr_A[$key-1]]=$val['field'];
        }
        $success=0;
        $fail = 0;
        $error=0;
        $other =0;
        for($i=2;$i<=$highestRow;$i++){
            $data = array();
            foreach($arr_A as $val){
                $value = $objPHPExcel->getActiveSheet()->getCell($val.$i)->getValue();
                if($fields[$val]=='CreateTime' || $fields[$val]=='ClickTime'){
                    $value=strtotime($value);
                }
                $data[$fields[$val]] = $value;
            }
            $data['AliMaMaID']=$taobao;
            $w = array(
                'CreateTime'=>$data['CreateTime'],
                'OrderNum'=>$data['OrderNum'],
            );
            $res = M('a_order_copy_test_jiesuan')->field('ID,OrderNum,Num')->where($w)->order('Num desc')->find();
            if($res){
                $num = $res['num']+1;
            }else{
                $num = 1;
            }
            $data['Num']=$num;
            //将订单全部加入到order_copy_test 数据表中
            //获取商品图片信息
            $iteminfo = get_item_infos($data['ItemID']);
            $data['IMG']=$iteminfo['pict_url'].'_200x200';
            M('a_order_copy_test_jiesuan')->add($data);
        }
        $orders = M('a_order_copy_test_jiesuan')->select();
        foreach ($orders as $key=>$val){
            $data = array(
                    'ID'=>$val['id'],
                    'CreateTime' => $val['createtime'],
                    'ClickTime' => $val['clicktime'],
                    'Title' => $val['title'],
                    'ItemID' => $val['itemid'],
                    'ShopUser' => $val['shopuser'],
                    'ShopName' => $val['shopname'],
                    'ItemNum' => $val['itemnum'],
                    'Price' => $val['price'],
                    'OrderStatue' => $val['orderstatue'],
                    'OrderType' => $val['ordertype'],
                    'ShouruBi' => $val['shourubi'],
                    'FenChengBi' => $val['fenchengbi'],
                    'Bay' => $val['pay'],
                    'XiaoGuoYuGu' => $val['xiaoguoyugu'],
                    'JieSuanJinE' => $val['jiesuanjine'],
                    'YuGuShouRu' => $val['yugushouru'],
                    'CompleteTime' => $val['completetime'],
                    'YongJinBi' => $val['yongjinbi'],
                    'YongJinJinE' => $val['yongjinjine'],
                    'BuTieBi' => $val['butiebi'],
                    'BuTieJinE' => $val['butiejine'],
                    'BuTieType' => $val['butietype'],
                    'ChengJiaoPingTai' => $val['chengjiaopingtai'],
                    'ThirdFuWu' => $val['thirdfuwu'],
                    'OrderNum' => $val['ordernum'],
                    'Cate' => $val['cate'],
                    'MediaID' => $val['mediaid'],
                    'MediaName' => $val['medianame'],
                    'AdID' => $val['adid'],
                    'AdName' => $val['adname'],
                    'AliMaMaID' => $val['alimamaid'],
                    'ShouYiStatue' => $val['shouyistatue'],
                    'IMG' => $val['img'],
                    'Num' => $val['num'],
                );
            $w = array(
                'CreateTime'=>$val['createtime'],
                'Num'=>$val['num'],
                'OrderNum'=>$val['ordernum'],
            );
            $a = M('a_order')->field('ID,OrderStatue')->where($w)->find();
            //判断原来订单是否有效
            if($a['orderstatue'] != '订单结算'){
                //修改订单状态为结算
                $res = M('a_order')->where(array('ID'=>$a['id']))->save($data);
                if($res){
                    $success +=1;
                }else{
                    $error += 1;
                    $error_order_msg .= $val['ordernum'].'&'.$val['itemid'].'&'.$val['createtime'].'修改结算订单失败;';
                }
            }
        }
        $arr = array(
            'count'=>$highestRow-1,
            'success'=>$success,
            'error'=>$error,
        );
        AddwxLog($arr,'上传结算订单,修改数据');
        AddwxLog($error_order_msg,'上传结算订单，修改失败的数据');
        $this->ajaxReturn($arr);
    }
    /*
     * 获取要建的推广位的数据
     * @param 
     * 传参   无
     * */
    public function GetTuiGuanWei(){
        //查询阿里妈妈账号
        $alimama = M('a_alimama')->where(array('Statue'=>1))->select();
        foreach ($alimama as $key=>$val){
            $a['name']=$val['name'];
            $a['pass']=$val['password'];
            //根据阿里妈妈账号查询下面正在使用中的媒体位
            $media = M('a_media')->where(array('alimama_id'=>$val['id']))->select();
            foreach ($media as $key_media=>$val_media){
                $b[$key_media]['id']=$val_media['id'];
                $b[$key_media]['name']=$val_media['nick_name'];
                $b[$key_media]['zhanghao']=$val_media['name'];
                $b[$key_media]['MediaID']=$val_media['media_id'];
                //查询这个媒体下面还没有创建推广位的用户
                $w = array(
                    'Statue'=>'-1',
                    'GzhToken'=>$val_media['token'],
                );
                $user = M('wx_user')->field('id,name,phone')->where($w)->select();
                $b[$key_media]['user']=$user;
            }
            
            $a['media']=$b;
            $data[$key]=$a;
        }
        $this->ajaxReturn($data);
    }
    /**
     * 修改生成的媒体位状态
     * @param
     * id   数据库媒体位ID（根据GetTuiGuanWei接口得到的id）
     * */
    public function UpdateMediaStatue(){
        $id = I('id');
        $mediaid=I('mediaid');
        $data = array(
            'id'=>$id,
            'media_id'=>$mediaid
        );
        $res = M('a_media')->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'修改成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    /**
     * 生成推广位成功修改用户推广位ID
     * @param
     * id       用户ID（GetTuiGuanWei接口返回的推广位数据库ID）
     * tgwid    阿里妈妈后台生成的推广位ID例如mm_116133360_21496586_72144353
     * medianame阿里妈妈后台生成的媒体位名称
     * tgwname  阿里妈妈后台生成的推广位名称
     * */
    public function UpdateTuiGuanWei(){
        $id = I('id');
        $tgwid=I('tgwid');
        $arr = explode('_',$tgwid);
        $medianame=urldecode(I('medianame'));
        $tgwname  =urldecode(I('tgwname'));
        $data = array(
            'ID'=>$id,
            'TgwID'=>$tgwid,
            'MediaID'=>$arr[2],
            'MediaName'=>$medianame,
            'AdID'=>$arr[3],
            'AdName'=>$tgwname,
            'Statue'=>1
        );
        $res=M('wx_user')->save($data);
        
        if($res){
            //AddWxLog($data,'创建推广位成功');
            //申请成功给用户发模板消息
            //根据用户id查询token
            $user =M('wx_user')->field('ID,Pid,OpenID,GzhToken,MediaID')->where(array('ID'=>$id))->find();
            $mediaid = $user['gzhtoken'];
            $sql = "select b.*,a.yuming from daili_a_media as a left join daili_a_config_copy as b on a.ID=b.MediaID where a.token='".$mediaid."'";
            $config = M('a_media')->query($sql);
            //用户通过代理审核查询用户是否有上级代理有就加奖励
            if($user['pid']){
                $yaoqingmax = $config[0]['yaoqingmax'];//最大邀请值
                //查询用户已经邀请的用户数量
                $yaoqingcount = M('b_jiangli')->where(array('UID'=>$user['pid']))->count();
                if($yaoqingcount<$yaoqingmax){
                    $jiangli=array(
                        'UID'=>$user['pid'],
                        'XiaJiUID'=>$user['id'],
                        'Money'=>$config[0]['yaoqingjiangli'],
                        'Time'=>time()
                    );
                    M('wx_user')->where(array('ID'=>$user['pid']))->setInc('YuE',$config[0]['yaoqingjiangli']);
                    M('b_jiangli')->add($jiangli);
                }
            }
            $access_token = access_token($user['gzhtoken']);
            //查询公众号的模板消息ID
            $temple = M('wx_template')->where(array('Token'=>$user['gzhtoken'],'Name'=>'审核通过提醒'))->find();
            
            $template_id = $temple['templateid'];
            $url = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=$access_token";
            $post_data = array(
                'touser'=>$user['openid'],
                'template_id'=>$template_id,
                'url'=>$config[0]['yuming'].'/Index/wx_daili.html',
                'data'=>array(
                    'first'=>array(
                        'value'=>'申请成为代理成功通知'
                    ),
                    'keyword1'=>array(
                        'value'=>'申请代理通过审核',
                        'color'=>'#228B22'
                    ),
                    'keyword2'=>array(
                        'value'=>date('Y-m-d H:i:s')
                    ),
                    'remark'=>array(
                        'value'=>'感谢您的支持！'
                    )
                )
            );
            AddwxLog($post_data,'通过审核');
            curl_post($post_data,$url);
            $arr = array(
                'code'=>1,
                'msg'=>'修改成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }

    public function get_curl($api_url){
        //实惠猪参数
        $data = array(
            'APPID: 1704261647308667',
            'APPKEY: 37522767b0efd6ed7daf6f1403ddc12d',
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $data);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        $result = curl_exec($ch);
        curl_close($ch);
        $arrResponse=json_decode($result,true);
        return $arrResponse;
    }
    //每天调用实惠猪接口采集12个分类下的所有商品
    public  function get_shz_shop_all(){
        set_time_limit(0);
        $k = 0;
        $j = 0;
        G('begin');
        //商品分类接口
        $api_cate = "http://gateway.shihuizhu.net/open/cates";
        //处理商品分类数据
        $cate_info = $this->get_curl($api_cate);
        //查询session中的实惠猪保存的分类
        $session_cate = session('shz_cate');
        $cate = $cate_info['result'];
        //判断最新的分类跟上次保存的分类是否有变动,如果有变动发提醒
        if(!empty($session_cate) && $session_cate !=$cate){
            $msg = "实惠猪分类发生变化，停止更新商品 ";
            $target = "http://106.ihuyi.cn/webservice/sms.php?method=Submit";
            //多个手机号码请用英文,号隔开
            $post_data = "account=cf_yuwanqiao&password=ywq523350109&mobile=18771925960&content=".rawurlencode($msg);
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $target);
            curl_setopt($curl, CURLOPT_HEADER, false);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_NOBODY, true);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
            $return_str = curl_exec($curl);
            echo '<pre>';
            print_r($return_str);
            return;
        }
        //将实惠猪分类存入session中
        session('shz_cate',$cate);
        //重新组装要查询的分类数据
        foreach($cate as $k1=>$v1){
            $cate_id  = $v1['id'];
            if($cate_id==13){
                continue;
            }
            switch($cate_id){
                case 1:
                    $local_cate_id = 1;
                    break;
                case 2:
                    $local_cate_id = 2;
                    break;
                case 3:
                    $local_cate_id = 35;
                    break;
                case 4:
                    $local_cate_id = 4;
                    break;
                case 5:
                    $local_cate_id = 6;
                    break;
                case 6:
                    $local_cate_id = 5;
                    break;
                case 7:
                    $local_cate_id = 3;
                    break;
                case 8:
                    $local_cate_id = 3;
                    break;
                case 9:
                    $local_cate_id = 36;
                    break;
                case 10:
                    $local_cate_id = 8;
                    break;
                case 11:
                    $local_cate_id = 9;
                    break;
                case 12:
                    $local_cate_id = 7;
                    break;
            }
            $api_url = "http://gateway.shihuizhu.net/open/goods/".$cate_id."/1";
            $shop_info = $this->get_curl($api_url);
            
            if($shop_info['return'] == 0 && $shop_info['pagecount']>0){
                $page_num = $shop_info['pagecount'];
                //根据符合条件的分类数据去调用接口查询商品列表
                //商品列表接口(获取该分类下的所有数据)
                for($i = 1;$i<=$page_num;$i++){
                    $api_url = "http://gateway.shihuizhu.net/open/goods/".$cate_id."/".$i;
                    $shop_info = $this->get_curl($api_url);
                    if(!$shop_info['result']){
                        return;
                    }
                    //检测该商品是否存在，如果存在不存在就添加
                    foreach($shop_info['result'] as $k2 =>$v2){
                        $data = array(
                            'num_iid'       => $v2['gid'],
                            'cate_id'       => $local_cate_id,
                            'title'         => $v2['title'],
                            'uname'         => '实惠猪',
                            'pic_url'       => strpos($v2['thumb'],'http') !== false ? $v2['thumb'] : 'http:'.$v2['thumb'],
                            'price'         => $v2['prime'],
                            'coupon_price'  => $v2['price'],
                            'ems'           => 1,
                            'shop_type'     => ($v2['site'] == 'tmall'?'B':($v2['site'] == 'taobao'?'C':'其他')),
                            'item_url'      =>$v2['url'],
                            'add_time'      =>time(),
                            'youhuiquan'    => $v2['coupon_url'],
                            'youhuiquan_je' => $v2['coupon_money'],
                            'has_youhuiquan'=> $v2['coupon'],
                            'volume'        => $v2['final_sales'],
                            'recommend_reason'=>$v2['intro_foot'],
                            'short_title'   => $v2['sub_title'],
                        );
                        //商品价格大于500的删除
                        if($data['coupon_price']<=500){
                            //查询app_items表里面是否含有该商品
                            $res_info =  M('a_items')->where(array('num_iid'=>$v2['gid']))->find();
                            if(empty($res_info)){
                                //插入数据
                                $res = M('a_items')->add($data);
                                $k++;
                            }
                        }
                    }
                }
            }
        }
        G('end');
        $ls_time = time();
        $data = array(
            'msg'=>"同步商品结束时间：".date('Y-m-d H:i:s',$ls_time).",同步商品用时：".G('begin','end')."秒,添加商品数量：$k",
            'time'=>time(),
            'type'   =>'根据实惠猪api获取商品'
        );
        M('items_sync_log')->add($data);
    }
    
    
    //通过从大淘客接口获取所有商品
    public function get_dtk_shop_all(){
        set_time_limit(0);
        G('begin');
        $j = 0;
        $k = 0;
        $shop_details_api = "http://api.dataoke.com/index.php?r=Port/index&type=total&appkey=c6tvb2t52s&v=2&page=1";
        $shop_details = $this->get_curl($shop_details_api);
        $count = $shop_details['data']['total_num'];
        $page_num = ceil($count/count($shop_details['result']));
        if($page_num<=0){
            return false;
        }
        for($i=1;$i<=$page_num;$i++){
            $shop_details_api = "http://api.dataoke.com/index.php?r=Port/index&type=total&appkey=c6tvb2t52s&v=2&page=".$i;
            $shop_details = $this->get_curl($shop_details_api);
            foreach($shop_details['result'] as $k2 =>$v2){
                $cate = $v2['Cid'];
                switch($cate){
                    case 1:
                        $local_cate_id = 1;
                        break;
                    case 2:
                        $local_cate_id = 4;
                        break;
                    case 3:
                        $local_cate_id = 6;
                        break;
                    case 4:
                        $local_cate_id = 5;
                        break;
                    case 5:
                        $local_cate_id = 3;
                        break;
                    case 6:
                        $local_cate_id = 8;
                        break;
                    case 7:
                        $local_cate_id = 9;
                        break;
                    case 8:
                        $local_cate_id = 7;
                        break;
                    case 9:
                        $local_cate_id = 2;
                        break;
                    case 10:
                        $local_cate_id = 35;
                        break;
                }
                $pic = $v2['Pic'];
                $youhuiquan=$v2['Quan_link'];
                $data = array(
                    'num_iid'       => $v2['GoodsID'],
                    'cate_id'       => $local_cate_id,
                    'title'         => $v2['Title'],
                    'uname'         => '大淘客',
                    'pic_url'       => strpos($pic,'http') !== false ? $pic : 'http:'.$pic,
                    'price'         => $v2['Org_Price'],
                    'coupon_price'  => $v2['Price'],
                    'ems'           => 1,
                    'shop_type'     => ($v2['IsTmall'] == 1?'B':'C'),
                    'item_url'      =>"https://item.taobao.com/item.htm?id=".$v2['GoodsID'],
                    'add_time'      =>time(),
                    'youhuiquan'    => $v2['Quan_link'],
                    'youhuiquan_je' => $v2['Quan_price'],
                    'has_youhuiquan'=> $v2['Quan_surplus']>0?1:0,
                    'volume'        => $v2['Sales_num'],
                    'recommend_reason'=>$v2['Introduce'],
                    'short_title'   => $v2['D_title'],
    
                );
                if($data['coupon_price']<=500){
                    //检测该商品是否存在，不存在就添加
                    $res_info =  M('a_items')->where(array('num_iid'=>$v2['GoodsID']))->find();
                    if(empty($res_info)){
                        //插入数据
                        $res = M('a_items')->add($data);
                        $j++;
                    }
                }
            }
        }
        $ls_time = time();
        G('end');
        $data = array(
            'msg'=>"同步商品结束时间：".date('Y-m-d H:i:s',$ls_time).",同步商品用时：".G('begin','end')."秒,添加商品数量：$k",
            'time'=>time(),
            'type'   =>'根据大淘客api获取商品'
        );
        M('items_sync_log')->add($data);
    }
    
    //从淘客基地获取商品
    public  function get_tkjd_shop_all(){
        set_time_limit(0);
        $j = 0;
        $k = 0;
        G('begin');
        for($i = 1;$i<2000;$i++){
            $shop_details_api = "http://api.tkjidi.com/getGoodsLink?appkey=5e582d1800f3d1fc8f6e9f3faa5ca10f&type=www_lingquan&page=".$i;
            $shop_details = $this->get_curl($shop_details_api);
            
            if($shop_details['status'] != 200){
                break;
            }else{
                //检测该商品是否存在，如果存在，则更新，否则添加
                foreach($shop_details['data'] as $k2 =>$v2){
                    /*****商品根据标题关键字分类start*****/
                    $title = $v2['goods_name'];
                    
                    /*****商品根据标题关键字分类end*****/
                    $pic = $v2['pic'];
                    $data = array(
                        'num_iid'       => $v2['goods_id'],
                        'title'         => $v2['goods_name'],
                        'uname'         => '淘客基地',
                        'pic_url'       => strpos($pic,'http') !== false ? $pic : 'http:'.$pic,
                        'price'         => $v2['price'],
                        'coupon_price'  => $v2['price_after_coupons'],
                        'ems'           => 1,
                        'shop_type'     => 'C',
                        'item_url'      =>$v2['goods_url'],
                        'add_time'      =>time(),
                        'youhuiquan'    => $v2['quan_link'],
                        'youhuiquan_je' => $v2['price_coupons'],
                        'has_youhuiquan'=> $v2['quan_shengyu']>0?1:0,
                        'volume'        => $v2['sales'],
                        'recommend_reason'=>$v2['quan_guid_content'],
                        //'short_title'   => $v2['goods_name'],
    
                    );
                    if($data['coupon_price']<=500){
                        //查询app_items表里面是否含有该商品
                        $res_info =  M('a_items')->where(array('num_iid'=>$v2['goods_id']))->find();
                        if(empty($res_info)){
                            //插入数据
                            $res = M('a_items')->add($data);
                            $j++;
                        }
                    }
                }
            }
        }
        $ls_time = time();
        G('end');
        $data = array(
            'msg'=>"同步商品结束时间：".date('Y-m-d H:i:s',$ls_time).",同步商品用时：".G('begin','end')."秒,添加商品数量：$k",
            'time'=>time(),
            'type'   =>'根据淘客基地api获取商品'
        );
        M('items_sync_log')->add($data);
    }
    
    /*
     * 把没有优惠券的商品状态更新
     * 2017/7/24
     * chen
     * */
    public function update_yhq_status(){
        set_time_limit(0);
        G('begin');
        //删除5天前的数据
       /*  $where = array(
            'add_time'=>array('elt',strtotime(date('Y-m-d',time()))-3600*24*5)
        );
        $res = M('a_items')->where($where)->delete();
        $data = array("删除5天前总条数：".$res);
        AddLog($data,'删除数据'); */
        $count = M('a_items')->count();
        $page_num = ceil($count/50);
        $page_num = 1;
        $i = 0;
        $j = 0;
        $sql_f[] = '';
        $sql_l[] = '';
        for($s=0;$s<$page_num;$s++){
            $info = M('a_items')->field('id,youhuiquan,num_iid')->limit($s*50,100)->order('ordid asc,add_time desc')->select();
            foreach($info as $k=>$v){
                $youhuiquan=$v['youhuiquan'];
                $pattern ='/activity..?d=(\w+)/';
                preg_match($pattern , $youhuiquan , $matches);
                $activeid=$matches[1];
                $url ='https://uland.taobao.com/cp/coupon?activityId='.$activeid.'&itemId='.$v['num_iid'];
                sleep(1);
                $res = file_get_contents($url);
                $res = json_decode($res,true);
                /* echo '<pre>';
                echo '***'.$v['id'].'***'.$s;
                print_r($res); */
                if(!$res['result']['couponKey']){
                    $status = M('a_items')->delete($v['id']);
                    if($status){
                        $i++;
                    }
                }
            }
        }
        G('end');
        $data = array("删除总条数：".$i.",用时".G('begin','end')."秒");
        AddLog($data,'删除优惠券过期商品');
    }
    /**
     * 转链接并获取佣金比和计算分成金额
     * */
    public function GetItems(){
        //查询所有阿里妈妈账号
        $res = M('a_alimama')->field('ID')->where(array('Statue'=>1))->order('id asc')->select();
        $str_id = '';
        foreach ($res as $key=>$val){
            $str_id .= $val['id'].',';
        }
        $str_id = rtrim($str_id,',');
        //查询未转链接的数据
        
        $map['daili_url_statue'] = array(
            array('neq',$str_id),
            array('EXP','is null'),
            'or'
        );
        $res = M('a_items')->field('id,num_iid,youhuiquan,daili_url_statue')->where($map)->order('id desc')->limit(0,500)->select();
        
        $result['login_user']='余晚桥 ';
        $result['login_password']='qiao@li131';
        $result['media']='DailiSystem代理系统媒体位';
        $result['zhanghao']='yu_wanqiao';
        $result['tgw']='admin';
        foreach ($res as $key=>$val){
            $res[$key]['num_iid']=str_replace(' ','',$val['num_iid']);
        }
        $result['res']=$res;
        $this->ajaxReturn($result);
    }
    /**
     * 修改商品转换后的链接
     * @apram
     * id   数据库id
     * daili_url 转完链接后的URL
     * */
    public function UpdateUrl(){
        $id = I('id');
        $statue = I('statue');
        if($statue==9){
            $res = M('a_items')->delete($id);
            $arr = array(
                'code'=>1,
                'msg'=>'商品下架成功'
            );
            $this->ajaxReturn($arr);
        }
        $commission_rate=I('commission_rate');
        $daili_url = urldecode(I('daili_url'));
        $daili_url_statue = urldecode(I('alimama_id'));
      
        if(!$id || !$daili_url || !$daili_url_statue){
            $arr = array('code'=>0,'msg'=>'参数错误');
            $this->ajaxReturn($arr);
        }
        
        //先查询商品的daili_url_statue
        $res = M('a_items')->field('id,daili_url_statue,coupon_price')->where(array('id'=>$id))->find();
        
        $statue = $res['daili_url_statue'];
        $str =trim($statue.','.$daili_url_statue,',');
        $arr = explode(',',$str);
        sort($arr);
        $str = implode(',',$arr);
        $data = array(
            'id'=>$id,
            'daili_url'=>str_replace('amp;','',$daili_url),
            'daili_url_statue'=>trim($str,','),
            'commission_rate'=>$commission_rate*10000,
            'daili_shouru'=>floor($res['coupon_price']*$commission_rate*0.9*(C('five')/100))/100
        );
        $res = M('a_items')->save($data);
        if($res){
            $arr=array(
                'code'=>1,
                'msg'=>'转链接修改成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'转链接修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    /**
     * 转链接接口
     * */
    public function ZhuanLianJie(){
        $itemID = '13610177464';
        $quan   = 'http://uland.taobao.com/coupon/edetail?activityId=ea4c8a385142432aae095024e9729d6d&pid=mm_120669915_20504735_108668225&itemId=13610177464&src=shz_shz';
        $pid    = 'mm_33702067_35954306_128128901';
        $url = "http://139.199.193.144:8977/".$itemID.'&'.urlencode($quan).'&'.$pid;
        $res = curl_get($url);
        $this->ajaxReturn($res);
    }
   
    
}