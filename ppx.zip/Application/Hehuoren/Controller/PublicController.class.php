<?php
namespace Hehuoren\Controller;
use Think\Controller;
class PublicController extends BaseController {
    public function top(){
        $user = $this->hehuoren;
        $this->assign('user',$user);
        $this->display();
    }
    public function left(){
        $user = $this->hehuoren;
        $uid = $user['id'];
        //查询一级菜单
        $sql = "select b.* from daili_b_group_caidan as a left join daili_b_menu as b on a.MenuID=b.id where a.UID=$uid and a.MenuPID=0 order by b.id asc";
        $caidan = M()->query($sql);
        $res_caidan = array(
            'name' => '首页',
            'second' => Array(
                '-1' => Array(
                    'name' => '系统首页',
                    'url' => U('Main/index')
                ),
                '0' =>  Array(
                    'name'=>'修改密码',
                    'url' => U('Main/update_pass')    
                ),
            )
        );
        $caidan=array(
            array(
                'name' => '数据统计',
                'second' => Array(
                    '-1' => Array(
                        'name' => '我的团队',
                        'url' => U('Main/tuandui')
                    ),
                    
                    '1' =>  Array(
                        'name'=>'收入报表',
                        'url' => U('Main/shouru')
                    ),
                )
            ),
        );
        /* foreach ($caidan as $key=>$val){
            //查询二级菜单
            $pid = $val['id'];
            $sql = "select b.* from daili_b_group_caidan as a left join daili_b_menu as b on a.MenuID=b.id where a.UID=$uid and a.MenuPID=$pid order by b.id asc";
            $res = M('b_group_caidan')->query($sql);
            foreach ($res as $key_1=>$val_1){
                $res[$key_1]['url']=U($val_1['controller'].'/'.$val_1['action']);
            }
            $caidan[$key]['second']=$res;
        } */
        $this->assign('shouye',$res_caidan);
        $this->assign('menu',$caidan);
        $this->display();
    }
    public function main(){
        $url = U('Main/index');
        $this->assign('url',$url);
        $this->display();
    }
}