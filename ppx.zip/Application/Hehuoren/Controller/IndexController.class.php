<?php
/**
 * 运营商和区域合伙人pc端管理系统
 * */
namespace Hehuoren\Controller;
use Think\Controller;
class IndexController extends Controller {
    //登录页面
    public function index(){
        if(IS_POST){
            $user = str_replace(' ','',I('user'));
            $pass = str_replace(' ','',I('pwd'));
            $sql = "select * from daili_wx_user where (username='$user' or Phone='$user') and password='$pass'";
            $user = M('wx_user')->query($sql);
            $user=$user[0];
            if($user){
                if($user['member_level'] != 2 && $user['member_level'] != 3){
                    $arr = array(
                        'code'=>0,
                        'msg'=>'登录失败，您不是运营商或区域合伙人'
                    );
                }else{
                    unset($user['pass']);
                    session('hehuoren',$user);
                    $arr = array(
                        'code'=>1,
                        'msg'=>'登录成功'
                    );
                }
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'登录失败，用户名或密码错误'
                );
            }
            $this->ajaxReturn($arr);
        }ELSE{
            $this->display();
        }
    }
    //用户退出页面
    public function logout(){
        session('hehuoren',null);
        $this->redirect('Index/index');
    }
}