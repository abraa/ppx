<?php
/**
 * 运营商和区域合伙人pc端管理系统
 * */
namespace Hehuoren\Controller;
use Think\Controller;
class BaseController extends Controller {
    public $hehuoren;
    public function _initialize(){
        $hehuoren = session('hehuoren');
        if(!$hehuoren){
            $this->error('请先登录',U('Index/index'));
        }else{
            $this->hehuoren=$hehuoren;
        }
    }
}