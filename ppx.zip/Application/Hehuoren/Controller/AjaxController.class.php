<?php
namespace Hehuoren\Controller;
use Think\Controller;
class AjaxController extends BaseController {
    //添加公众号页面
    public function add_gzh(){
        if(IS_POST){
            $data = I('post.');
            $data['add_time']=time();
            $file = $_FILES['icon'];
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     3145728 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->savePath  =      '/gzh_icon/'; // 设置附件上传目录    // 上传单个文件
            $info   =   $upload->uploadOne($file);
            if($info){
                $path = '/Uploads'.$info['savepath'].$info['savename'];
                $data['icon']=$path;
            }
            $r = M('gzh')->add($data);
            if($r){
                $this->success('添加成功');
            }else{
                $this->error('添加失败');
            }
        }else{
            $this->display();
        }
    }
    //添加公众号菜单
    public function add_menu(){
        if(IS_POST){
            $data = I('post.');
            $gzh_id = $data['gzh_id'];
            $level  = $data['level'];
            //根据公众号ID查询已经添加了几个一级菜单最多只能加三，二级菜单最多5个
            if($level==1){
                $count = M('menu')->where(array('gzh_id'=>$gzh_id,'level'=>$level))->count();
                if($count>=3){$this->error('一级菜单最多3个');}
            }
            if($level==2){
                $count = M('menu')->where(array('gzh_id'=>$gzh_id,'level'=>$level,'pid'=>$data['pid']))->count();
                if($count>=5){$this->error('二级菜单最多5个');}
            }
            if($data['type']=='click'){
//                $data['key']='key_'.$data['key'];
                $data['key']=$data['key'];
            }
            $r = M('menu')->add($data);
            if($r){
                $this->success('添加成功');
            }else{
                $this->error('添加失败');
            }
        }else{
            $gid = I('get.gid');
            if(empty($gid)){
                $this->error('参数丢失');
            }
            //查询公众号
            //$gzh = M('a_media')->field('id,nick_name')->where(array('statue'=>1))->select();
            //$this->assign('gzh',$gzh);
            //查询当前公众号一级菜单
            $w = array(
                'gzh_id'=>$gid,
                'level'=>1,
            );
            $menu = M('menu')->where($w)->select();
            $this->assign('gid',$gid);
            $this->assign('menu',$menu);
            $this->display();
        }
    }
    //编辑公众号菜单
    public function edit_menu(){
        $save = I('save');
        if($save){
            $data = I('post.');
            unset($data['save']);
//            $gzh_id = $data['gzh_id'];
//            $level  = $data['level'];
           
            $r = M('menu')->where(array('id'=>I('post.id'),'gzh_id'=>I('post.gid')))->save($data);
            if($r){
                $this->success('编辑成功');
            }else{
                $this->error('编辑失败');
            }
        }else{
            $id = I('id');
            $gid = I('get.gid');
            $res = M('menu')->where(array('id'=>$id))->find();
            //查询公众号
            //$gzh = M('a_media')->field('id,nick_name')->where(array('statue'=>1))->select();
            //$this->assign('gzh',$gzh);
            //查询当前公众号一级菜单
            $w = array(
                //'gzh_id'=>$gzh[0]['id'],
                'level'=>1,
            );
            $menu = M('menu')->where($w)->select();
            $this->assign('menu',$menu);
            $this->assign('res',$res);
            $this->assign('gid',$gid);
            $this->display();
        }
    }
    /**
     * 添加阿里妈妈账号
     * */
    public function add_alimama(){
        if(IS_POST){
            $data = I('post.');
            $id = $data['ID'];
            if($id){
                $res = M('a_alimama')->save($data);
                if($res){
                    $this->success('编辑成功');
                }else{
                    $this->error('编辑失败');
                }
            }else{
                unset($data['ID']);
                $data['AddTime']=time();
                $res = M('a_alimama')->add($data);
                if($res){
                    $this->success('添加成功');
                }else{
                    $this->error('添加失败');
                }
            }
        }else{
            $id = I('id');
            $res = M('a_alimama')->where(array('ID'=>$id))->find();
            $this->assign('res',$res);
            $this->display();
        }
    }
    /**
     * 添加 媒体位
     * */
    public function add_media(){
        if(IS_POST){
            $data = I('post.');
            $data['nick_name']=$data['qudao_name'];
            $data['add_time']=time();
            $data['short_name']=strtolower(pinyin($data['qudao_name']));
            
            $file = $_FILES['icon'];
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     3145728 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->savePath  =      '/gzh_icon/'; // 设置附件上传目录    // 上传单个文件
            $info   =   $upload->uploadOne($file);
            if($info){
                $path = '/Uploads'.$info['savepath'].$info['savename'];
                $data['icon']=$path;
            }
            $res = M('a_media')->add($data);
            if($res){
                //公众号添加成功后默认添加一个用户
                $user = array(
                    'IsSubscribe'=>1,
                    'SubscribeTime'=>time(),
                    'OpenID'=>'0000000000000000000000000000000000',
                    'HeaderPic'=>'http://home.yinfafa.cn/Public/home/images/getheadimg.png',
                    'NickName'=>$data['nick_name'],
                    'WxNum'=>'admin',
                    'Alipay'=>'admin',
                    'Name'=>$data['nick_name'].'admin',
                    'Phone'=>'18700000000',
                    'Statue'=>-1,
                    'Time'=>time(),
                    'MediaTableID'=>$res,
                    'GzhToken'=>$data['token'],
                    'IsAdmin'=>1
                );
                M('wx_user')->add($user);
                
                $this->success('添加成功');
            }else{
                $this->error('添加失败');
            }
        }else{
            //查询阿里妈妈账号 
            $alimama = M('a_alimama')->where(array('Statue'=>1))->select();
            $this->assign('alimama',$alimama);
            $this->display();
        }
    }
    /**
     * 添加管理员
     * */
    public function add_user(){
        if(IS_POST){
            $user = $this->user;
            $token = $user['token'];
            $data = I('post.');
            $id = $data['id'];
            
            if($id){
                $d = array(
                    'id'=>$id,
                    'name'=>$data['name'],
                    'pass'=>$data['pass']
                );
                $res = M('user')->save($d);
            }else{
                $d = array('name'=>$data['name']);
                $res = M('user')->where($d)->find();
                if($res){
                    $this->error('已经存在相同用户名');
                }
                $d = array(
                    'name'=>$data['name'],
                    'pass'=>$data['pass'],
                    'reg_time'=>time(),
                    'last_login_time'=>time(),
                    'login_time'=>time(),
                    'token'=>$token
                );
                $res = M('user')->add($d);
            }
            if($res){
                $this->success('操作成功');
            }else{
                $this->error('操作失败');
            }
        }else{
            $id = I('id');
            if($id){
                $user = M('user')->where('id='.$id)->find();
                $this->assign('user',$user);
            }
            $this->display();
        }
    }
    /**
     * 设置权限页面
     * */
    public function quanxian(){
        $user = $this->user;
        $this->assign('local_user',$user);
        $token = $user['token'];
        $uid = I('id');
        $user = M('user')->where(array('id'=>$uid))->find();
        if($token){
            //查询type为1的用户的权限
            $u = M('user')->where(array('token'=>$token,'type'=>1))->find();
            $u_id = $u['id'];
            //查询有权限的一级菜单
            $sql ="select a.* from daili_b_menu as a left join daili_b_group_caidan as b on a.ID=b.MenuID where a.PID=0 and b.UID=$u_id order by a.ID asc";
            $caidan_1=M('b_menu')->query($sql);
            foreach ($caidan_1 as $key=>$val){
                $caidan_1_quanxian = M('b_group_caidan')->where(array('MenuID'=>$val['id'],'UID'=>$uid))->find();
                if($caidan_1_quanxian){
                    $caidan_1[$key]['quanxian']=1;
                }
                //查询二级菜单
                $pid = $val['id'];
                $sql ="select a.* from daili_b_menu as a left join daili_b_group_caidan as b on a.ID=b.MenuID where b.UID=$u_id and b.MenuPID=$pid order by a.ID asc";
                $caidan_2 = M('b_menu')->query($sql);
                foreach ($caidan_2 as $key_2=>$val_2){
                    $caidan_2_quanxian = M('b_group_caidan')->where(array('MenuID'=>$val_2['id'],'UID'=>$uid))->find();
                    if($caidan_2_quanxian){
                        $caidan_2[$key_2]['quanxian']=1;
                    }
                }
                $caidan_1[$key]['caidan_2'] = $caidan_2;
            }
            //查询所有渠道
            $sql ="select a.* from daili_a_media as a left join daili_b_group_media as b on a.id=b.MediaID where b.UID=$u_id";
            $qudao = M('a_media')->query($sql);
            foreach ($qudao as $key=>$val){
                $quanxian = M('b_group_media')->where(array('UID'=>$uid,'MediaID'=>$val['id']))->find();
                if($quanxian){
                    $qudao[$key]['quanxian']=1;
                }
            }
            //查询客服系统的淘客账号
            $sql = "select a.* from daili_z_kefu_alimama_new as a left join daili_z_kefu_group as b on a.id=b.alimamaid where b.uid=$u_id";
            $kf_alimama = M('z_kefu_alimama_new')->query($sql);
            //查询阿里妈妈下面的公众号
            foreach ($kf_alimama as $key=>$val){
                //查询是否已经添加权限
                $kf_alimama_quanxian = M('z_kefu_group')->where(array('uid'=>$uid,'alimamaid'=>$val['id']))->find();
                if($kf_alimama_quanxian){
                    $kf_alimama[$key]['quanxian']=1;
                }
                $kf_gzh = M('z_kefu_gzh')->where(array('alimama_id'=>$val['id']))->order('id desc')->select();
                foreach ($kf_gzh as $k=>$v){
                    $q = M('z_kefu_group')->where(array('uid'=>$uid,'gzhid'=>$v['id']))->find();
                    if($q){
                        $kf_gzh[$k]['quanxian']=1;
                    }
                }
                $kf_alimama[$key]['gzh']=$kf_gzh;
            }
            $this->assign('kefu',$kf_alimama);
            $this->assign('caidan',$caidan_1);
            $this->assign('qudao',$qudao);
        }else{
            //查询所有一级菜单和二级菜单
            $caidan_1 = M('b_menu')->where(array('PID'=>0))->select();
            foreach ($caidan_1 as $key=>$val){
                $caidan_2 = M('b_menu')->where(array('PID'=>$val['id']))->select();
                $caidan_1_quanxian = M('b_group_caidan')->where(array('MenuID'=>$val['id'],'UID'=>$uid))->find();
                if($caidan_1_quanxian){
                    $caidan_1[$key]['quanxian']=1;
                }
                foreach ($caidan_2 as $key_2=>$val_2){
                    $caidan_2_quanxian = M('b_group_caidan')->where(array('MenuID'=>$val_2['id'],'UID'=>$uid))->find();
                    if($caidan_2_quanxian){
                        $caidan_2[$key_2]['quanxian']=1;
                    }
                }
                $caidan_1[$key]['caidan_2']=$caidan_2;
            }
            //查询所有渠道
            $qudao = M('a_media')->select();
            foreach ($qudao as $key=>$val){
                $quanxian = M('b_group_media')->where(array('UID'=>$uid,'MediaID'=>$val['id']))->find();
                if($quanxian){
                    $qudao[$key]['quanxian']=1;
                }
            }
            //查询菜单权限
            //$menu_quanxian = M('a_group_caidan')->where(array('UID'=>$uid))->select();
            //查询客服系统的淘客账号
            $kf_alimama = M('z_kefu_alimama_new')->order('id desc')->select();
            //查询阿里妈妈下面的公众号
            foreach ($kf_alimama as $key=>$val){
                //查询是否已经添加权限
                $kf_alimama_quanxian = M('z_kefu_group')->where(array('uid'=>$uid,'alimamaid'=>$val['id']))->find();
                if($kf_alimama_quanxian){
                    $kf_alimama[$key]['quanxian']=1;
                }
                $kf_gzh = M('z_kefu_gzh')->where(array('alimama_id'=>$val['id']))->order('id desc')->select();
                foreach ($kf_gzh as $k=>$v){
                    $q = M('z_kefu_group')->where(array('uid'=>$uid,'gzhid'=>$v['id']))->find();
                    if($q){
                        $kf_gzh[$k]['quanxian']=1;
                    }
                }
                $kf_alimama[$key]['gzh']=$kf_gzh;
                
            }
            $this->assign('kefu',$kf_alimama);
            $this->assign('caidan',$caidan_1);
            $this->assign('qudao',$qudao);
        }
        $this->assign('uid',$uid);
        $this->assign('user',$user);
        $this->display();
    }
    /**
     * 修改用户菜单权限
     * **/
    public function quanxian_menu(){
        $menuid = I('id');
        $uid= I('uid');
        $level=I('level');//level为1表示点的一级菜单，2表示点的二级菜单
        $user = $this->user;
        $token = $user['token'];
        
        $type=I('type');
        //根据ID查询菜单信息
        $res = M('b_menu')->where(array('ID'=>$menuid))->find();
        
        //父级菜单
        $res0 = M('b_menu')->where(array('ID'=>$res['pid']))->find();
        if($token){
            //根据token查询用户
            $u = M('user')->where(array('token'=>$token))->find();
            $u_id = $u['id'];
            $sql = "select a.* from daili_b_menu as a left join daili_b_group_caidan as b on a.ID=b.MenuID where a.PID=$menuid and b.UID=$u_id";
            $res1 = M('b_menu')->query($sql);
        }else{
            //子菜单
            $res1 = M('b_menu')->where(array('PID'=>$menuid))->select();
            
        }
        if($type=='insert'){
                $d = array(
                    'UID'=>$uid,
                    'MenuPID'=>$res['pid'],
                    'MenuID'=>$res['id'],
                );
                M('b_group_caidan')->add($d);
                if($level==1){
                    foreach ($res1 as $val){
                        $d = array(
                            'UID'=>$uid,
                            'MenuPID'=>$val['pid'],
                            'MenuID'=>$val['id'],
                        );
                        M('b_group_caidan')->add($d);
                    }
                }else{
                    $d = array(
                        'UID'=>$uid,
                        'MenuPID'=>$res0['pid'],
                        'MenuID'=>$res0['id'],
                    );
                    $res = M('b_group_caidan')->where($d)->find();
                    if(!$res){
                        M('b_group_caidan')->add($d);
                    }
                }
        }else{
                $w= array(
                    'UID'=>$uid,
                    'MenuPID'=>$res['pid'],
                    'MenuID'=>$menuid
                );
                M('b_group_caidan')->where($w)->delete();
                if($level==1){
                    foreach ($res1 as $val){
                        $d = array(
                            'UID'=>$uid,
                            'MenuPID'=>$val['pid'],
                            'MenuID'=>$val['id'],
                        );
                        M('b_group_caidan')->where($d)->delete();
                    }
                }else{
                    $w =array(
                        "UID"=>$uid,
                        'MenuPID'=>$res0['id'],
                    );
                    $a = M('b_group_caidan')->where($w)->select();
                    if(!$a){
                        $w = array(
                            'UID'=>$uid,
                            'MenuID'=>$res0['id'],
                        );
                        M('b_group_caidan')->where($w)->delete();
                    }
                }
        }
    }
    /**
     * 修改客服系统权限
     * **/
    public function quanxian_kefu(){
        $id = I('id');
        $uid= I('uid');
        $type=I('type');
        $level=I('level');
        if($level=='first'){
            //查询下级id
            $gzh = M('z_kefu_gzh')->where(array('alimama_id'=>$id))->select();
        }
        if($level =='second'){
            $r = M('z_kefu_gzh')->where(array('id'=>$id))->find();
            $gzh = array(
                0=>$r
            );
        }
        if($type=='insert'){
            foreach ($gzh as $val){
                $d = array(
                    'uid'=>$uid,
                    'alimamaid'=>$val['alimama_id'],
                    'gzhid'=>$val['id'],
                );
                M('z_kefu_group')->add($d);
                
            }
        }else{
            foreach ($gzh as $val){
                $d = array(
                    'uid'=>$uid,
                    'alimamaid'=>$val['alimama_id'],
                    'gzhid'=>$val['id'],
                );
                M('z_kefu_group')->where($d)->delete();
            }
        }
    }
    /**
     * 修改用户渠道权限
     * */
    public function quanxian_qudao(){
        $menuid = I('id');
        $uid= I('uid');
        $type=I('type');
        $d = array(
            'UID'=>$uid,
            'MediaID'=>$menuid
        );
        if($type=='insert'){
            
            $res = M('b_group_media')->where($d)->find();
            if(!$res){
                M('b_group_media')->add($d);
            }
        }else{
            M('b_group_media')->where($d)->delete();
        }
    }
    /**
     * 删除数据
     * */
    public function del(){
        $table = I('table');
        $id = I('id');
        $res = M($table)->delete($id);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'删除成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'删除失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    /***
     * 获取公众号信息
     * @param
     * id 公众号ID
     * */
    public function GetGzhInfo(){
        $id = I('id');//传过来的是公众号token
        $arr = explode('/',$id);
        $id = $arr[1];
        //查询阿里妈妈账号和公众号信息
        $sql = "select a.*,b.id as b_id from daili_gzh as a left join daili_a_alimama as b on a.token = b.GzhToken and a.token='$id'";
        $res = M('gzh')->query($sql);
        //根据阿里妈妈查询media表中name的最大值
        $max_name = M('a_media')->where(array('AliMaMaID'=>$res[0]['b_id']))->max('Name');
        $res = array(
            'gzhName'=>$res[0]['nick_name'],
            'Name'=>$max_name+1,
            'ZhangHao'=>$res[0]['name']
        );
        $this->ajaxReturn($res);
    }
    /**
     * 修改媒体位状态
     * @param
     * statue 0表示修改为禁用，1表示修改为可用
     * */
    public function UpdateStatue(){
        $statue = I('statue');
        $id     = I('id');
        $aliID  = I('aliid');
        if($statue == '0'){
            $msg = '禁用';
        }
        if($statue == '1'){
            //查询是否有一个启用中的媒体位，一个阿里账号只能启用一个媒体位
            $count = M('a_media')->where(array('AliMaMaID'=>$aliID,'Statue'=>1))->find();
            if($count){
                $arr = array(
                    'code'=>0,
                    'msg'=>'已经有启用的媒体位了，请先禁用其他媒体位'
                );
                $this->ajaxReturn($arr);
            }
            $msg = '启用';
        }
        $where = array(
            'ID'=>$id,
            'Statue'=>$statue
        );
        $res = M('a_media')->save($where);
        
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>$msg.'成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>$msg.'失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    /**
     * 修改阿里妈妈状态
     * */
    public function updateAlimama(){
        $id = I('id');
        $res = M('a_alimama')->save(array('ID'=>$id,'Statue'=>1));
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'操作成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'操作失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    /**
     * 用户提现申请后后台操作打款成功
     * */
    public function tixian_success(){
        $id=I('id');
        //查询是否打过款
        $w=array(
            'ID'=>$id
        );
        $r = M('a_tixian')->where($w)->find();
        if($r['statue']==1){
            return false;
        }
        
        $d = array(
            'ID'=>$id,
            'Statue'=>1,
            'operation_time'=>time()
        );
        $res = M('a_tixian')->save($d);
        if($res){
            //提现成功用户余额减掉提现的金额
            $money = M('a_tixian')->where(array('ID'=>$id))->find();
            $jine = $money['jine'];
            $uid   = $money['uid'];
            $res = M('wx_user')->where(array('ID'=>$uid))->setDec('YuE',$jine);
            if($res){
                //添加已经提现
                $setinc = M('wx_user')->where(array('ID'=>$uid))->setInc('YiTiXian',$jine);
                AddwxLog(M('wx_user')->getLastSql(),'添加已经提现金额,返回结果'.$setinc);
                /*
                //打款成功给用户发信息
                $user =M('wx_user')->field('ID,Pid,OpenID,Alipay,GzhToken,MediaID')->where(array('ID'=>$uid))->find();
                $token = $user['gzhtoken'];
                $openid= $user['openid'];
                $alipay= $user['alipay'];
                $sql = "select b.*,a.yuming from daili_a_media as a left join daili_a_config_copy as b on a.ID=b.MediaID where a.token='".$token."'";
                $config = M('a_media')->query($sql);
                
                //查询模板ID
                $w = array(
                    'Token'=>$token,
                    'Name'=>'提现成功提醒',
                );
                $template = M('wx_template')->where($w)->find();
                $template_id = $template['templateid'];
                $access_token = access_token($token);
                $url = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=$access_token";
                $post_data = array(
                    'touser'=>$user['openid'],
                    'template_id'=>$template_id,
                    'url'=>$config[0]['yuming'].'/Index/tixian_list.html?token='.$token.'&openid='.$openid,
                    'data'=>array(
                        'first'=>array(
                            'value'=>'提现成功通知'
                        ),
                        'keyword1'=>array(
                            'value'=>'支付宝'.$alipay,
                        ),
                        'keyword2'=>array(
                            'value'=>$jine.'元',
                            'color'=>'#00CC00'
                        ),
                        'keyword3'=>array(
                            'value'=>date('Y-m-d H:i:s')
                        ),
                        'remark'=>array(
                            'value'=>'感谢您的支持！'
                        )
                    )
                );
                AddwxLog($post_data,'通过审核');
                curl_post($post_data,$url); */
                AddwxLog('打款金额'.$money.'操作时间'.date('Y-m-d H:i:s',time()),'打款成功，修改金额成功');
            }else{
                AddwxLog('打款金额'.$money.'操作时间'.date('Y-m-d H:i:s',time()),'打款失败，修改金额失败');
            }
            $arr = array(
                'code'=>1,
                'msg'=>'操作成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'操作失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    /**
     * 拒绝提现
     * */
    public function tixian_fail(){
        $id = I('id');
        $text = I('text');
        $data = array(
            'ID'=>$id,
            'Remark'=>$text,
            'Statue'=>-1,
            'operation_time'=>time()
        );
        $res = M('a_tixian')->save($data);
        if($res){
            /*
            $sql = "select a.GzhToken as token,a.OpenID as openid,b.JinE as jine,b.Time from daili_wx_user as a left join daili_a_tixian as b on a.ID=b.UID where b.ID=$id";
            $user = M('wx_user')->query($sql);
            $token = $user[0]['token'];
            $template = M('wx_template')->where(array('Name'=>'提现失败提醒','Token'=>$token))->find();
            $template_id = $template['templateid'];
            $access_token = access_token($token);
            $url = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=$access_token";
            $post_data = array(
                'touser'=>$user[0]['openid'],
                'template_id'=>$template_id,
                'url'=>'http://'.str_replace('home','weixin',$_SERVER['HTTP_HOST']).'/Index/wx_daili.html',
                'data'=>array(
                    'first'=>array(
                        'value'=>'提现失败通知,请重新申请提现'
                    ),
                    'keyword1'=>array(
                        'value'=>$user[0]['jine'].'元',
                        'color'=>'#FF0000'
                    ),
                    'keyword2'=>array(
                        'value'=>date('Y-m-d H:i:s',$user[0]['time'])
                    ),
                    'keyword3'=>array(
                        'value'=>$text
                    ),
                    'remark'=>array(
                        'value'=>'感谢您的支持！'
                    )
                )
            );
            curl_post($post_data,$url); */
            $arr = array(
                'code'=>1,
                'msg'=>'操作成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'操作失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    /**
     * 批量提现操作
     * */
    public function tixian_piliang(){
        $ids = I('ids');
        $success = 0;$fail=0;
        foreach ($ids as $key=>$id){
            $w=array(
                'ID'=>$id
            );
            $r = M('a_tixian')->where($w)->find();
            if($r['statue']==1){
                $fail += 1;
            }else{
                $d = array(
                    'ID'=>$id,
                    'Statue'=>1,
                    'operation_time'=>time()
                );
                $res = M('a_tixian')->save($d);
                if($res){
                    //提现成功用户余额减掉提现的金额
                    $money = M('a_tixian')->where(array('ID'=>$id))->find();
                    $jine = $money['jine'];
                    $uid   = $money['uid'];
                    $res = M('wx_user')->where(array('ID'=>$uid))->setDec('YuE',$jine);
                    if($res){
                        //添加已经提现
                        $setinc = M('wx_user')->where(array('ID'=>$uid))->setInc('YiTiXian',$jine);
                        AddwxLog(M('wx_user')->getLastSql(),'添加已经提现金额,返回结果'.$setinc);
                        /* //打款成功给用户发信息
                        $user =M('wx_user')->field('ID,Pid,OpenID,Alipay,GzhToken,MediaID')->where(array('ID'=>$uid))->find();
                        $token = $user['gzhtoken'];
                        $openid= $user['openid'];
                        $alipay= $user['alipay'];
                        $sql = "select b.*,a.yuming from daili_a_media as a left join daili_a_config_copy as b on a.ID=b.MediaID where a.token='".$token."'";
                        $config = M('a_media')->query($sql);
                        //查询模板ID
                        $w = array(
                            'Token'=>$token,
                            'Name'=>'提现成功提醒',
                        );
                        $template = M('wx_template')->where($w)->find();
                        $template_id = $template['templateid'];
                        $access_token = access_token($token);
                        $url = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=$access_token";
                        $post_data = array(
                            'touser'=>$user['openid'],
                            'template_id'=>$template_id,
                            'url'=>$config[0]['yuming'].'/Index/tixian_list.html?token='.$token.'&openid='.$openid,
                            'data'=>array(
                                'first'=>array(
                                    'value'=>'提现成功通知'
                                ),
                                'keyword1'=>array(
                                    'value'=>'支付宝'.$alipay,
                                ),
                                'keyword2'=>array(
                                    'value'=>$jine.'元',
                                    'color'=>'#00CC00'
                                ),
                                'keyword3'=>array(
                                    'value'=>date('Y-m-d H:i:s')
                                ),
                                'remark'=>array(
                                    'value'=>'感谢您的支持！'
                                )
                            )
                        );
                        $success += 1;
                        curl_post($post_data,$url);
                         */
                        AddwxLog('打款金额'.$money.'操作时间'.date('Y-m-d H:i:s',time()),'打款成功，修改金额成功');
                    }else{
                        $fail +=1;
                        AddwxLog('打款金额'.$money.'操作时间'.date('Y-m-d H:i:s',time()),'打款失败，修改金额失败');
                    }
                }
            }
        }
        $arr = array(
            'code'=>1,
            'msg'=>'操作成功'.$success.',失败'.$fail
        );
        $this->ajaxReturn($arr);
    }
    /***
     * 添加修改配置项目
     * */
    public function add_config(){
        if(IS_POST){
            $data = I('post.');
            $id = $data['ID'];
            if($id){
                $res = M('a_config')->save($data);
            }else{
                unset($data['ID']);
                $res = M('a_config')->add($data);
            }
            if($res){
                $this->success('操作成功');
            }else{
                $this->error('操作失败');
            }
        }else{
            $id = I('id');
            if($id){
                $res = M('a_config')->where(array('ID'=>$id))->find();
                $this->assign('res',$res);
            }
            $this->display();
        }
    }
    /**
     * 转链接
     * */
    public function zhuanlian_back(){
        $user=session('user');
        $account = $user['name'];
        //查询用户所在组
        $group = M('b_group_media')->where(array('UID'=>$user['id']))->find();
        $mediaid=$group['mediaid'];//得到用户媒体数据表的ID
        //查询用户渠道的配置信息
        $config = M('a_config_copy')->where(array('MediaID'=>$mediaid))->find();
        //查询用户渠道的微信token
        $qudaoinfo = M('a_media')->where(array('id'=>$mediaid))->find();
        $token = $qudaoinfo['token'];
        $itemid = I('itemid');
        if(!$itemid){
            $arr = array(
                'code'=>0,
                'msg'=>'商品id必填'
            );
            $this->ajaxReturn($arr);
        }
        $quan   = urlencode(str_replace('amp;','',I('quan')));
        if($quan){
            //根据优惠券判断优惠券是否过期获取金额
            $pattern ='/activity..?d=(\w+)/';
            $q=urldecode($quan);
            preg_match($pattern , $q , $matches);
            $activeid=$matches[1];
            $url ='https://uland.taobao.com/cp/coupon?activityId='.$activeid.'&itemId='.$itemid;
            $res = file_get_contents($url);
            $res = json_decode($res,true);
            if($res['result']['couponKey']){
                $quan_je = $res['result']['amount'];
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'优惠券无效'
                );
                $this->ajaxReturn($arr);   
            }
        }
        $pid    = I('pid');
        $arr_pid = explode('_',$pid);
        $adzone_id = $arr_pid[3];
        $site_id   = $arr_pid[2];
        $url = "http://api.olivecloud.cn/index/taobao_tbk_privilege_get_daili?youhuiquan=$quan&item_id=$itemid&adzone_id=$adzone_id&site_id=$site_id";
        $res = curl_get($url);
        $url = $res['coupon_click_url'];
        if($url){
            $tbkurl=urlencode($url);
            $url = str_replace('http://','https://',$url);
            $iteminfo = get_item_infos($itemid,1);
            //获取短连接
            $url = "http://dwz.olivecloud.cn/tkbGetDWZ?url=".urlencode($url)."&itemid=$itemid";
            $shorturl_arr = curl_get($url);
            //echo '<pre>';
            //print_r($shorturl_arr);exit;
            $shorturl = $shorturl_arr['msg'];
            $taokouling  = $shorturl_arr['kouling'];
            $tkl = urlencode($taokouling);
            if(!$shorturl){
                $arr = array('code'=>0,'msg'=>'生成短网址失败');
                $this->ajaxReturn($arr);
            }
            $commission = $res['max_commission_rate'];
            //调用上行日志接口
            $report_api ="http://api.olivecloud.cn/index/taobao_tbk_data_report?";
            $report_api .="tbkurl=$tbkurl&";
            $report_api .="token=$token&";
            $report_api .="itemid=$itemid&";
            //$report_api .="text=&";
            $report_api .="kouling=$tkl&";
            $report_api .="account=$account&";
            $report_api .="pid=$pid";
            //echo $report_api;exit;
            curl_get($report_api);
        }else{
            $arr = array('code'=>0,'msg'=>$res['msg']['sub_msg']);
            $this->ajaxReturn($arr);
        }
        if($quan_je){
            $price = $iteminfo['zk_final_price']-$quan_je;
            $final_price = $price;
        }else{
            $price = $iteminfo['zk_final_price'];
            $final_price ='暂无优惠券';
        }
        $a = (rtrim($commission,'%')/100)*$price;
        $d = $a*0.9*$config['shouyibi']/100;
        $res = array(
            'title'=>$iteminfo['title'],
            'logo'=>$iteminfo['pict_url'],
            'y_price'=>$iteminfo['zk_final_price'],
            'price'=>$final_price,
            'shortUrl'=>$shorturl,
            'kouling'=>$taokouling,
            'yongjinbi'=>$commission,
            //'ehy_url'=>$ehy_url
            'a'=>$a,
            'd'=>$d,
        );
        $this->ajaxReturn($res);
    }
    public function zhuanlian_back_test(){
        $user=session('user');
        $account = $user['name'];
        //查询用户所在组
        $group = M('b_group_media')->where(array('UID'=>$user['id']))->find();
        $mediaid=$group['mediaid'];//得到用户媒体数据表的ID
        //查询用户渠道的配置信息
        $config = M('a_config_copy')->where(array('MediaID'=>$mediaid))->find();
        //查询用户渠道的微信token
        $qudaoinfo = M('a_media')->where(array('id'=>$mediaid))->find();
        $token = $qudaoinfo['token'];
        $itemid = I('itemid');
        if(!$itemid){
            $arr = array(
                'code'=>0,
                'msg'=>'商品id必填'
            );
            $this->ajaxReturn($arr);
        }
        $quan   = urlencode(str_replace('amp;','',I('quan')));
        if($quan){
            //根据优惠券判断优惠券是否过期获取金额
            $pattern ='/activity..?d=(\w+)/';
            $q=urldecode($quan);
            preg_match($pattern , $q , $matches);
            $activeid=$matches[1];
            $url ='https://uland.taobao.com/cp/coupon?activityId='.$activeid.'&itemId='.$itemid;
            $res = file_get_contents($url);
            $res = json_decode($res,true);
            if($res['result']['couponKey']){
                $quan_je = $res['result']['amount'];
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'优惠券无效'
                );
                $this->ajaxReturn($arr);
            }
        }
        $pid    = I('pid');
        $arr_pid = explode('_',$pid);
        $adzone_id = $arr_pid[3];
        $site_id   = $arr_pid[2];
        $url = "http://api.olivecloud.cn/index/taobao_tbk_privilege_get_daili?youhuiquan=$quan&item_id=$itemid&adzone_id=$adzone_id&site_id=$site_id";
        $res = curl_get($url);
        if($res){
            $url = $res['coupon_click_url'];
            $tbkurl=urlencode($url);
            $url = str_replace('http://','https://',$url);
            $iteminfo = get_item_infos($itemid,1);
            //获取短连接
            $url = "http://dwz.olivecloud.cn/tkbGetDWZ?url=".urlencode($url)."&itemid=$itemid";
            $shorturl_arr = curl_get($url);
            $shorturl = $shorturl_arr['msg'];
            $taokouling  = $shorturl_arr['kouling'];
            $tkl = urlencode($taokouling);
            if(!$shorturl){
                $arr = array('code'=>0,'msg'=>'生成短网址失败');
                $this->ajaxReturn($arr);
            }
            $commission = $res['max_commission_rate'];
            //调用上行日志接口
            $report_api ="http://api.olivecloud.cn/index/taobao_tbk_data_report?";
            $report_api .="tbkurl=$tbkurl&";
            $report_api .="token=$token&";
            $report_api .="itemid=$itemid&";
            //$report_api .="text=&";
            $report_api .="kouling=$tkl&";
            $report_api .="account=$account&";
            $report_api .="pid=$pid";
            //echo $report_api;exit;
            curl_get($report_api);
        }else{
            $arr = array('code'=>0,'msg'=>'调用Api转链失败');
            $this->ajaxReturn($arr);
        }
        if($quan_je){
            $price = $iteminfo['zk_final_price']-$quan_je;
            $final_price = $price;
        }else{
            $price = $iteminfo['zk_final_price'];
            $final_price ='暂无优惠券';
        }
        $a = (rtrim($commission,'%')/100)*$price;
        $d = $a*0.9*$config['shouyibi']/100;
        $res = array(
            'title'=>$iteminfo['title'],
            'logo'=>$iteminfo['pict_url'],
            'y_price'=>$iteminfo['zk_final_price'],
            'price'=>$final_price,
            'shortUrl'=>$shorturl,
            'kouling'=>$taokouling,
            'yongjinbi'=>$commission,
            //'ehy_url'=>$ehy_url
            'a'=>$a,
            'd'=>$d,
        );
        $this->ajaxReturn($res);
    }
    /**
     * 修改密码
     * */
    public function update_pass(){
        $id = I('id');
        $name = I('name');
        $password = I('password');
        $newpass = I('newpass');
        $repass = I('repass');
        $pic   = I('pic');
        if(empty($password)){
            $arr = array(
                'code'=>0,
                'msg'=>'请输入原密码'
            );
            $this->ajaxReturn($arr);
        }
        if($newpass && strlen($newpass)<6){
            $arr = array(
                'code'=>0,
                'msg'=>'密码长度不得少于6个字符'
            );
            $this->ajaxReturn($arr);
        }
        $where = array(
            'name'=>$name,
            'password'=>$password
        );
        $res = M('user')->where($where)->find();
        
        if(!$res){
            $arr = array(
                'code'=>0,
                'msg'=>'原密码输入错误'
            );
            $this->ajaxReturn($arr);
        }
        if($newpass != $repass){
            $arr = array(
                'code'=>0,
                'msg'=>'两次输入的新密码不一致'
            );
            $this->ajaxReturn($arr);
        }
        $data['id']=$id;
        if($newpass){
             $data['pass']=$newpass;
        }
        if($pic){
            $data['pic']=$pic;
        }
        $res = M('user')->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'修改成功'
            );
            $this->ajaxReturn($arr);
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'修改失败'
            );
            $this->ajaxReturn($arr);
        }
    }
    /**
     * 修改排序
     * */
    public function update_paixu(){
        $id = I('id');
        $ordid = I('num');
        if(is_numeric($ordid)){
            $data = array(
                'id'=>$id,
                'ordid'=>$ordid
            );
            $res = M('a_items')->save($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'修改成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'修改失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'请输入正确的数字'
            );
            $this->ajaxReturn($arr);
        }
    }
    /**
     * 修改分类
     * */
    public function update_cate(){
        $id = I('id');
        $cate_id=I('cate_id');
        $data=array(
            'id'=>$id,
            'cate_id'=>$cate_id
        );
        $res = M('a_items')->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'修改成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    /**
     * 修改用户信息
     * */
    public function update_user_info(){
        $id = I('id');
        $value=I('value');
        $field=I('field');
        $data = array(
            'ID'=>$id,
            $field=>$value
        );
        $ress = M('wx_user')->save($data);
        if($ress){
            $arr = array(
                'code'=>1,
                'msg'=>'修改成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    
    /**
     * 修改渠道备注
     * */
    public function update_media_remark(){
        $id = I('id');
        //查询数据
        $value=I('value');
        
        $data = array(
            'id'=>$id,
            'remark'=>$value
        );
        $ress = M('a_media')->save($data);
        if($ress){
            $arr = array(
                'code'=>1,
                'msg'=>'修改成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    /***
     * 清理商品排序
     * */
    public function clear_paixu(){
        $s = I('s');
        $e = I('e');
        $w['ordid'] = array('between',array($s,$e));
        $d=array('ordid'=>99999);
        $re = M('a_items')->where($w)->save($d);
        if($re){
            $arr = array(
                'code'=>1,
                'msg'=>'操作成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'操作失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    /**
     * 导出用户信息excel
     * */
    public function explode_user_excel(){
        $where = S('where');
        $sql = "select a.*, b.ID as b_ID,
        b.Pid           as b_Pid,
        b.IsSubscribe   as b_IsSubscribe,
        b.OpenID        as b_OpenID,
        b.HeaderPic     as b_HeaderPic,
        b.NickName      as b_NickName,
        b.Address       as b_Address,
        b.WxNum         as b_WxNum,
        b.Alipay        as b_Alipay,
        b.Name          as b_Name,
        b.Phone         as b_Phone,
        b.TgwId         as b_TgwId,
        b.MediaID       as b_MediaID,
        b.MediaName     as b_MediaName,
        b.AdID          as b_AdID,
        b.AdName        as b_AdName,
        b.YiTiXian      as b_YiTiXian,
        b.Statue        as b_Statue,
        b.IsUseSoftware as b_IsUseSoftware
        from daili_wx_user as a left join daili_wx_user as b on a.Pid=b.ID where $where order by a.ID desc";
        //echo $sql;exit;
        $list = M('wx_user')->query($sql);
        $expTitle=date('Y-m-d/H/i/s',time()).'用户列表';//文件名
        $expCellName=array(
            array('id','用户编号'),
            array('nickname','用户昵称'),
            array('address','用户地址'),
            array('wxnum','微信号'),
            array('alipay','支付宝账号'),
            array('name','真实姓名'),
            array('phone','手机号'),
            array('tgwid','推广位ID'),
            array('medianame','媒体名称'),
            array('adname','广告位名称'),
            array('yitixian','已经提现金额'),
            array('yue','账户余额'),
            array('subscribetime','关注时间'),
            array('time','申请成为代理时间')
            
        );//每列的字段名称
        foreach ($list as $key=>$val){
            foreach ($val as $key1=>$val1){
                if($key1=='wxnum'){
                    $list[$key]['wxnum']='`'.$val['wxnum'];
                }
                if($key1=='alipay'){
                    $list[$key]['alipay']='`'.$val['alipay'];
                }
                if($key1=='phone'){
                    $list[$key]['phone']='`'.$val['phone'];
                }
                if($key1=='adname'){
                    $list[$key]['adname']='`'.$val['adname'];
                }
                if($key1=='subscribetime'){
                    $list[$key]['subscribetime']='`'.date('Y-m-d H:i:s',$val['subscribetime']);
                }
                if($key1=='time'){
                    $list[$key]['time']='`'.date('Y-m-d H:i:s',$val['time']);
                }
            }
        }
        $expTableData=$list;//需要导出的数据
        exportExcel($expTitle,$expCellName,$expTableData);
    }
    /**
     * 导出收益Excel
     * **/
    public function shouyi_excel(){
        set_time_limit(0);
        ini_set('memory_limit','-1');
        $search_token = S('search_token');
        $order_num = str_replace(' ','',I('order_num'));
        if($order_num){
            $where = "a.OrderNum like '%".$order_num."%' and ";
        }
        $startTime = I('start');
        $endTime   = I('end');

        $js_startTime = I('js_start');
        $js_endTime   = I('js_end');

        if(!$js_startTime && !$js_endTime){
            if(!$startTime){
                $startTime = date('Y-m-d',time());
            }
            if(!$endTime){
                $endTime = date('Y-m-d',time());
            }
        }
        if($startTime && empty($endTime)){
            $str_starttime = strtotime($startTime);
            $where_t0 = " b.CreateTime>$str_starttime";
        }
        if($endTime && empty($startTime)){
            $str_endtime = strtotime($endTime)+3600*24-1;
            $where_t0 = " b.CreateTime<$str_endtime";
        }
        if($startTime && $endTime){
            $str_starttime = strtotime($startTime);
            $str_endtime = strtotime($endTime)+3600*24;
            $where_t0=" b.CreateTime between $str_starttime and $str_endtime";;
        }
        //$end   = strtotime($endTime)+24*3600;
        //S('shouru_start',$start);
        //S('shouru_end',$end);
        if($where_t0){
            $where .=$where.$where_t0.' and';
        }
        if($js_startTime && empty($js_endTime)){
            $str_js_starttime = strtotime($js_startTime);
            $where_t1 = " b.CompleteTime>=$str_js_starttime";
        }
        if($js_endTime && empty($js_startTime)){
            $str_js_endtime = strtotime($js_endTime)+3600*24-1;
            $where_t1 = " b.CompleteTime between 1493913600 and $str_js_endtime";
        }
        if($js_startTime && $js_endTime){
            $str_js_starttime = strtotime($js_startTime);
            $str_js_endtime = strtotime($js_endTime)+3600*24-1;
            $where_t1=" b.CompleteTime between $str_js_starttime and $str_js_endtime";;
        }

        if($where_t1){
            $where .=$where.$where_t1.' and ';
        }
        $sql = "select b.*,
        b.XiaoGuoYuGu*0.9 as a_xiaoguoyugu,
        a.ID as b_id,
        a.UID as b_uid,
        a.OrderID as b_orderid,
        a.CreateTime as b_createtime,
        a.ShouYi as b_shouyi,
        a.ShangJiUID as b_shangjiuid,
        a.ShangJiShouYi as b_shangjishouyi,
        a.ShangShangJiUID as b_shangshangjiuid,
        a.ShangShangJiShouYi as b_shangshangjishouyi,
        a.OrderStatue as b_orderstatue
        from daili_a_shouyi as a left join daili_a_order as b on a.OrderID = b.ID left join daili_wx_user as c on a.UID=c.ID where $where c.GzhToken in($search_token) order by b.CreateTime desc";
//        echo $sql;exit;
        $list=M('a_shouyi')->query($sql);
        //echo '<pre>';
       // print_r($list);exit;
        $expTitle=date('Y-m-d/H/i/s',time()).'收益明细';//文件名
        $expCellName=array(
            array('id','编号'),
            array('createtime','下单时间'),
            array('completetime','结算时间'),
            array('ordernum','订单号'),
            array('orderstatue','订单转态'),
            array('title','商品标题'),
            array('itemid','商品链接'),
            array('pay','用户支付'),
            array('xiaoguoyugu','总佣金'),
            array('a_xiaoguoyugu','总收入'),
            array('b_user','代理'),
            array('b_userphone','代理手机号'),
            array('b_shouyi','代理收人'),
            array('b_shangjiuser','上级代理'),
            array('b_shangjiuserphone','上级代理手机号'),
            array('b_shangjishouyi','上级代理收人'),
            array('b_shangshangjiuser','上上级代理'),
            array('b_shangshangjiuserphone','上上级代理手机号'),
            array('b_shangshangjishouyi','上上级代理收人'),
            array('pingtaishouyi','平台收人'),
        );//每列的字段名称
        foreach ($list as $key=>$val){
            $uid = $val['b_uid'];
            $shangji_uid = $val['b_shangjiuid'];
            $shangshangji_uid = $val['b_shangshangjiuid'];
            if($uid){
                $user = M('wx_user')->where(array('ID'=>$uid))->find();
                $list[$key]['b_user']=$user['name'];
                $list[$key]['b_userphone']='`'.$user['phone'];
            }
            if($shangji_uid){
                $shangjiuser = M('wx_user')->where(array('ID'=>$shangji_uid))->find();
                $list[$key]['b_shangjiuser']=$shangjiuser['name'];
                $list[$key]['b_shangjiuserphone']='`'.$shangjiuser['phone'];
            }
            if($shangshangji_uid){
                $shangshangjiuser = M('wx_user')->where(array('ID'=>$shangshangji_uid))->find();
                $list[$key]['b_shangshangjiuser']=$shangshangjiuser['name'];
                $list[$key]['b_shangshangjiuserphone']='`'.$shangshangjiuser['phone'];
            }
            $pingtaishouyi = $val['a_xiaoguoyugu']-$val['b_shouyi']-$val['b_shangjishouyi']-$val['b_shangshangjishouyi'];
            $list[$key]['pingtaishouyi']=$pingtaishouyi;
            foreach ($val as $key1=>$val1){
                if($key1=='createtime'){
                    $list[$key]['createtime']='`'.date('Y-m-d H:i:s',$val['createtime']);
                }
                if($key1=='completetime'){
                    $list[$key]['completetime']='`'.date('Y-m-d H:i:s',$val['completetime']);
                 }
                if($key1=='ordernum'){
                    $list[$key]['ordernum']='`'.$val['ordernum'];
                }
                if($key1=='itemid'){
                    $list[$key]['itemid']='`https://item.taobao.com/item.htm?id='.$val['itemid'];
                }
            }
        }
        $expTableData=$list;//需要导出的数据
        exportExcel($expTitle,$expCellName,$expTableData);
    }

    /**
     * 2017/12/14
     * 导出个人收益Excel
     * **/
    public function explode_person_excel(){
        set_time_limit(0);
        ini_set('memory_limit','-1');
        $lists = "";
        $uid = I('id');
        //查询用户邀请的奖励
        $count_yaoqing = M('b_jiangli')->where(array('UID'=>$uid))->sum('Money');
        if(!$count_yaoqing){
            $count_yaoqing=0;
        }
        $this->assign('count_yaoqing',$count_yaoqing);
        $startTime = I('start');
        $endTime   = I('end');
        if(!$startTime){
            $startTime = "2017-08-01";
        }
        $start = strtotime($startTime);
        if(!$endTime){
            $endTime = date('Y-m-d',time());
        }
        $end   = strtotime($endTime)+24*3600;
        $p = I('p',1);
        $num = 20;
        $startnum = ($p-1)*$num;
        $User = M('a_order'); // 实例化User对象
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where a.CreateTime between $start and $end and (b.UID=$uid or b.ShangJiUID=$uid or b.ShangShangJiUID=$uid)";

        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count = $count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性

        $sql = "select a.*,
        a.XiaoGuoYuGu*0.9 as a_xiaoguoyugu,
        b.ID as b_id,
        b.UID as b_uid,
        b.OrderID as b_orderid,
        b.CreateTime as b_createtime,
        b.ShouYi as b_shouyi,
        b.ShangJiUID as b_shangjiuid,
        b.ShangJiShouYi as b_shangjishouyi,
        b.ShangShangJiUID as b_shangshangjiuid,
        b.ShangShangJiShouYi as b_shangshangjishouyi,
        b.OrderStatue as b_orderstatue
        from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where a.CreateTime between $start and $end and (b.UID=$uid or b.ShangJiUID=$uid or b.ShangShangJiUID=$uid) order by a.CreateTime desc";
        //echo $sql;exit;
        $list=$User->query($sql);
        //总预估收入
        $count_yugushouru = 0;
        //代理总收入
        $count_dailishouru=0;
        foreach ($list as $key=>$val){
            $daili_uid = $val['b_uid'];
            $shangji_uid = $val['b_shangjiuid'];
            $shangshangji_uid = $val['b_shangshangjiuid'];
            if($daili_uid){
                $user = M('wx_user')->where(array('ID'=>$daili_uid))->find();
                $list[$key]['b_user']=$user['name'];
                $list[$key]['b_user_phone']=$user['phone'];
            }
            if($shangji_uid){
                $shangjiuser = M('wx_user')->where(array('ID'=>$shangji_uid))->find();
                $list[$key]['b_shangjiuser']=$shangjiuser['name'];
                $list[$key]['b_shangjiuser_phone']=$shangjiuser['phone'];
            }
            if($shangshangji_uid){
                $shangshangjiuser = M('wx_user')->where(array('ID'=>$shangshangji_uid))->find();
                $list[$key]['b_shangshangjiuser']=$shangshangjiuser['name'];
                $list[$key]['b_shangshangjiuser_phone']=$shangshangjiuser['phone'];
            }
            $pingtaishouyi = $val['xiaoguoyugu']*0.9-$val['b_shouyi']-$val['b_shangjishouyi']-$val['b_shangshangjishouyi'];
            $list[$key]['pingtaishouyi']=$pingtaishouyi;

            //组装导表数据
            $lists[$key]['id'] = $val['id'];
            $lists[$key]['createtime'] = '`'.date('Y-m-d',$val['createtime']);
            $lists[$key]['completetime'] = $val['orderstatue']=="订单结算"?date('Y-m-d H:i:s',$val['completetime']):"";
            $lists[$key]['ordernum'] = '`'.$val['ordernum'];
            $lists[$key]['orderstatue'] = $val['orderstatue'];
            $lists[$key]['pay'] = $val['pay'];
            $lists[$key]['xiaoguoyugu'] = $val['xiaoguoyugu'];
            $lists[$key]['b_user'] = $list[$key]['b_user'];
            $lists[$key]['b_user_phone'] = '`'.$list[$key]['b_user_phone'];
            $lists[$key]['b_shouyi'] = $list[$key]['b_shouyi'];
            $lists[$key]['b_shangjiuser'] = $list[$key]['b_shangjiuser'];
            $lists[$key]['b_shangjiuser_phone'] = '`'.$list[$key]['b_shangjiuser_phone'];
            $lists[$key]['b_shangjishouyi'] = $list[$key]['b_shangjishouyi'];
            $lists[$key]['b_shangshangjiuser'] = $list[$key]['b_shangshangjiuser'];
            $lists[$key]['b_shangshangjiuser_phone'] = '`'.$list[$key]['b_shangshangjiuser_phone'];
            $lists[$key]['b_shangshangjishouyi'] = $list[$key]['b_shangshangjishouyi'];
            $lists[$key]['pingtaishouyi'] = $list[$key]['pingtaishouyi'];
        }
        unset($list);
        $expTitle=date('Y-m-d/H/i/s',time()).'个人收益明细';//文件名
        $expCellName=array(
            array('id','编号'),
            array('createtime','下单时间'),
            array('completetime','结算时间'),
            array('ordernum','订单号'),
            array('orderstatue','订单状态'),
            array('orderstatue','用户支付（元）'),
            array('pay','佣金'),
            array('xiaoguoyugu','收入（元）'),
            array('b_user','代理姓名'),
            array('b_user_phone','代理手机号'),
            array('b_shouyi','代理收入（元）'),
            array('b_shangjiuser','上级代理姓名'),
            array('b_shangjiuser_phone','上级代理手机号'),
            array('b_shangjishouyi','上级代理收入（元）'),
            array('b_shangshangjiuser','上上级代理姓名'),
            array('b_shangshangjiuser_phone','上上级代理手机号'),
            array('b_shangshangjishouyi','上上级代理收入（元）'),
            array('pingtaishouyi','平台收入（元）'),
        );//每列的字段名称
        $expTableData=$lists;//需要导出的数据
        exportExcel($expTitle,$expCellName,$expTableData);
    }

    /**
     * 导出提现记录
     * */
    public function tixian_list(){
        /* $user = $this->user;
        $uid = $user['id'];
        //根据用户id查询有权限的媒体
        $sql = "select b.* from daili_b_group_media as a left join daili_a_media as b on a.MediaId=b.ID where a.UID = $uid";
        $q = M('b_group_media')->query($sql);
        if($q){
            //得到媒体下面公众号的token
            foreach ($q as $val){
                $where .= '"'.$val['token'].'",';
            }
            $where = rtrim($where,',');
        }
        
        $start = S('tixian_start');
        $end = S('tixian_end'); */
        $where = S('tixian_where');
        $sql = "select a.*,
        b.Name as b_name,
        b.Phone as b_phone,
        b.Alipay as b_alipay
        from daili_a_tixian as a left join
        daili_wx_user as b on a.UID=b.ID $where order by a.ID desc";
        $list = M('a_tixian')->query($sql);
        $expTitle=date('Y-m-d/H/i/s',time()).'提现明细';//文件名
        $expCellName=array(
            array('id','编号'),
            array('b_name','姓名'),
            array('b_phone','手机号'),
            array('b_alipay','支付宝账号'),
            array('jine','提现金额'),
            array('time','申请时间'),
            array('statue','提现状态'),
            array('remark','备注'),
        );//每列的字段名称
        foreach ($list as $key=>$val){
            foreach ($val as $key1=>$val1){
                if($key1=='b_phone'){
                    $list[$key]['b_phone']='`'.$val['b_phone'];
                }
                if($key1=='b_alipay'){
                    $list[$key]['b_alipay']='`'.$val['b_alipay'];
                }
                if($key1=='time'){
                    $list[$key]['time']='`'.date('Y-m-d H:i:s',$val['time']);
                }
                if($key1=='statue'){
                    if($val['statue']==1){
                        $list[$key]['statue']='提现成功';
                    }
                    if($val['statue']==-1){
                        $list[$key]['statue']='提现失败';
                    }
                    if($val['statue']==0){
                        $list[$key]['statue']='申请中';
                    }
                }
            }
        }
        $expTableData=$list;//需要导出的数据
        exportExcel($expTitle,$expCellName,$expTableData);
    }
    //修改商品状态为轮播图或专场
    public function update_type_id(){
        $id = I('id');
        $type_id = I('keyword');
        $res = M('a_items')->where(array('id'=>$id))->find();
        $now_type_id = $res['type_id'];
        if($now_type_id){
            $t .= $now_type_id.','.$type_id;
        }else{
            $t = $type_id;
        }
        $data = array(
            'id'=>$id,
            'type_id'=>$t
        );
        $res = M('a_items')->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'添加成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'添加失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //获取专场或轮播图
    public function get_type(){
        $type = I('type');
        $user = $this->user;
        $token = $user['token'];
        $arr_token = array('gh_26c51afe50df','gh_b676e24225c8','chuankeyouhui2');

        if($token){
            if(in_array($token,$arr_token)){
                $w = array(
                    'type'=>$type,
                    'token'=>array('in',$arr_token)
                );
            }else{
                $w = array(
                    'type'=>$type,
                    'token'=>$token
                );
            }
        }else{
            $w = array('type'=>$type);
        }
        $type_list = M('a_lunbotu')->field('id,title')->where($w)->order('ordid')->select();
        $html = '';
        $html .="<div style='overflow:hidden;'>";
        $html .='<div style="float:left;width:30%;line-height:32px;">选择分类</div>';
        $html .='<select id="select" style="width:70%;float:left;font-weight:bold;font-size:15px;text-align:center;border:1px solid gray;border-radius:5px;">';
    
        foreach($type_list as $val){
            if($type == $val['title']){
                $select = 'selected';
            }else{
                $select = '';
            }
            $html .='<option style="padding:5px;font-weight:bold;font-size:15px;" '.$select.'  value="'.$val['id'].'">'.$val['title'].'</option>';
        }
        $html .='</select>';
        $html .='</div>';
        echo $html;
    }
    //修改商品状态添加到微淘
    public function update_weitao_id(){
        $id = I('id');
        $type_id = I('keyword');
        $res = M('a_items')->where(array('id'=>$id))->find();
        $now_type_id = $res['weitao_id'];
        if($now_type_id){
            $t .= $now_type_id.','.$type_id;
        }else{
            $t = $type_id;
        }
        $data = array(
            'id'=>$id,
            'weitao_id'=>$t
        );
        $res = M('a_items')->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'添加成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'添加失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //获取微淘列表
    public function get_weitao(){
        $user = $this->user;
        $token = $user['token'];
        $arr_token = array('gh_26c51afe50df','gh_b676e24225c8','chuankeyouhui2');
        if($token){
            if(in_array($token,$arr_token)){
                $w = array(
                    'token'=>array('in',$arr_token)
                );
            }else{
                $w = array(
                    'token'=>$token
                );
            }
        }
        $type_list = M('a_weitao')->field('id,title')->where($w)->order('ordid asc,add_time desc')->select();
        $html = '';
        $html .="<div style='overflow:hidden;'>";
        $html .='<div style="float:left;width:30%;line-height:32px;">选择微淘文章</div>';
        $html .='<select id="select" style="width:70%;float:left;font-weight:bold;font-size:15px;text-align:center;border:1px solid gray;border-radius:5px;">';
    
        foreach($type_list as $val){
            if($type == $val['title']){
                $select = 'selected';
            }else{
                $select = '';
            }
            $html .='<option style="padding:5px;font-weight:bold;font-size:15px;" '.$select.'  value="'.$val['id'].'">'.$val['title'].'</option>';
        }
        $html .='</select>';
        $html .='</div>';
        echo $html;
    }
    //获取专场和录播图名称
    public function get_zc_lbt(){
        $id = rtrim(I('id'),',');
        $arr = explode(',',$id);
        $a=array();
        if($arr){
            foreach ($arr as $key=>$val){
                $res = M('a_lunbotu')->where(array('id'=>$val))->find();
                $a[$key]=$res['title'];
            }
        }
        $this->ajaxReturn(array_values($a));
    }
    //获取微淘标题
    public function get_wt_lbt(){
        $id = rtrim(I('id'),',');
        $arr = explode(',',$id);
        $a=array();
        if($arr){
            foreach ($arr as $key=>$val){
                $res = M('a_weitao')->where(array('id'=>$val))->find();
                $a[$key]=$res['title'];
            }
        }
        $this->ajaxReturn(array_values($a));
    }
    //修改商品状态添加到微淘
    public function update_brand_id(){
        $id = I('id');
        $type_id = I('keyword');
        $res = M('a_items')->where(array('id'=>$id))->find();
        $now_type_id = $res['brand_id'];
        if($now_type_id){
            $t .= $now_type_id.','.$type_id;
        }else{
            $t = $type_id;
        }
        $data = array(
            'id'=>$id,
            'brand_id'=>$t
        );
        $res = M('a_items')->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'添加成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'添加失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //获取微淘列表
    public function get_brand(){
        $user = $this->user;
        $token = $user['token'];
        $arr_token = array('gh_26c51afe50df','gh_b676e24225c8','chuankeyouhui2');
        if($token){
            if(in_array($token,$arr_token)){
                $w = array(
                    'token'=>array('in',$arr_token)
                );
            }else{
                $w = array(
                    'token'=>$token
                );
            }
        }
        $type_list = M('a_brand')->field('id,title')->where($w)->order('ordid')->select();
        $html = '';
        $html .="<div style='overflow:hidden;'>";
        $html .='<div style="float:left;width:30%;line-height:32px;">选择品牌</div>';
        $html .='<select id="select" style="width:70%;float:left;font-weight:bold;font-size:15px;text-align:center;border:1px solid gray;border-radius:5px;">';
    
        foreach($type_list as $val){
            if($type == $val['title']){
                $select = 'selected';
            }else{
                $select = '';
            }
            $html .='<option style="padding:5px;font-weight:bold;font-size:15px;" '.$select.'  value="'.$val['id'].'">'.$val['title'].'</option>';
        }
        $html .='</select>';
        $html .='</div>';
        echo $html;
    }
    //获取品牌标题
    public function get_pp_lbt(){
        $id = rtrim(I('id'),',');
        $arr = explode(',',$id);
        $a=array();
        if($arr){
            foreach ($arr as $key=>$val){
                $res = M('a_brand')->where(array('id'=>$val))->find();
                $a[$key]=$res['title'];
            }
        }
        $this->ajaxReturn(array_values($a));
    }
    //后台ajax修改字段
    public function update_field(){
        $id = I('id');
        $key = I('keyword');
        $field=I('field');
        $table=I('table');
        if($field == 'start_time' || $field == 'end_time'){
            $key = strtotime($key);
        }
        $data = array(
            'id'=>$id,
            $field=>$key,
            'last_update_time'=>time()
        );
        $res = M($table)->save($data);
        if($res){
            $arr = array(
                'code'=>'1',
                'msg'=>'修改成功'
            );
        }else{
            $arr = array(
                'code'=>'0',
                'msg'=>'修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //上传图片
    public function upload(){
        $type = I('type');
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize   =     3145728 ;// 设置附件上传大小
        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->savePath  =      '/ITEM_IMG/'; // 设置附件上传目录
        // 上传文件
        $info   =   $upload->uploadOne($_FILES['image']);
        if(!$info){
            $res = array(
                'code'=>0,
                'msg'=>'上传失败'
            );
            $this->ajaxReturn($res);
        }else{
            $file_path = 'http://img.taokehelp.cn/Uploads'.$info['savepath'].$info['savename'];
            
            $res = array(
            'code'=>1,
            'msg'=>'上传成功',
            'img_url'=>$file_path,
            );
            $this->ajaxReturn($res);
        }
    }
    //修改上传的图片
    public function updateimg(){
        $id = I('id');
        $img = I('img');
        $table = I('table');
        $field = I('field');
        if($field){
            if($table=='wx_user'){
                $data = array(
                    'ID'=>$id,
                    $field=>$img
                );
            }else{
                $data = array(
                    'id'=>$id,
                    $field=>$img
                );
            }
            
        }else{
            $data = array(
                'id'=>$id,
                'pic_url'=>$img
            );
        }
        $res = M($table)->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'修改成功',
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'修改失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //删除数据
    public function del_data(){
        $table = I('table');
        $id = I('id');
        if($table=='a_lunbotu'){
            //如果删除的是专场就先要将专场中的商品转态修改为没有专场
            $d = array(
                'type_id'=>null
            );
            M('a_items')->where('type_id='.$id)->save($d);
        }
        $res = M($table)->where('id='.$id)->delete();
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'删除成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'删除失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //删除专场数据
    public function del_zc_data(){
        $table = I('table');
        $id = I('id');
        $d = array(
            'id'=>$id,
            'type_id'=>null
        );
        $res = M($table)->save($d);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'删除成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'删除失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //删除微淘数据
    public function del_wt_data(){
        $table = I('table');
        $id = I('id');
        $d = array(
            'id'=>$id,
            'weitao_id'=>null
        );
        $res = M($table)->save($d);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'删除成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'删除失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //删除品牌数据
    public function del_pp_data(){
        $table = I('table');
        $id = I('id');
        $d = array(
            'id'=>$id,
            'brand_id'=>null
        );
        $res = M($table)->save($d);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'删除成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'删除失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //添加专场
    public function add_zhuanchang(){
        $data = I('post.');
        $id = $data['id'];
        $add_items=$data['add_items'];
        
        $data = M('a_lunbotu')->create($data);
        $text = html_entity_decode(html_entity_decode($data['text']));
        $data['text']=$text;
        $data['add_time']=time();
        $data['start_time']=strtotime($data['start_time']);
        $data['end_time']=strtotime($data['end_time']);
        $title = $data['title'];
        if($id){
            $res = M('a_lunbotu')->save($data);
            if($res){
                if($add_items==1){
                    $a = array(
                        'id'=>$id,
                        'url'=>'http://'.$_SERVER['HTTP_HOST'].'/Index/page/id/'.$id
                    );
                    M('a_lunbotu')->save($a);
                }
                $arr = array(
                    'code'=>1,
                    'msg' =>'编辑成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'编辑失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $zhuanchang = M('a_lunbotu')->where('title="'.$title.'"')->find();
            if($zhuanchang){
                $arr = array(
                    'code'=>0,
                    'msg'=>'已经添加了同名专场'
                );
                $this->ajaxReturn($arr);
            }
            $res = M('a_lunbotu')->add($data);
            if($res){
                if($add_items==1){
                    $a = array(
                        'id'=>$res,
                        'url'=>'http://'.$_SERVER['HTTP_HOST'].'/Index/page/id/'.$res
                    );
                    M('a_lunbotu')->save($a);
                }
                $arr = array(
                    'code'=>1,
                    'msg' =>'添加成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'添加专场失败'
                );
            }
            $this->ajaxReturn($arr);
        }
        
    }
    //创客优汇修改用户余额
    public function update_yue(){
        $yue = I('yue');
        $pass= I('pass');
        $uid = I('uid');
        $adminid=I('adminid');
        //根据UID查询用户金额
        $u = M('wx_user')->field('ID,YuE')->where(array('ID'=>$uid))->find();
        $yuan_jine = $u['yue'];
        if($pass=='ckyh2017$'){
            $d = array(
                'YuE'=>$yue,
                'ID'=>$uid
            );
            $r = M('wx_user')->save($d);
            if($r){
                $data = array(
                    'uid'=>$uid,
                    'update_uid'=>$adminid,
                    'yuan_jine'=>$yuan_jine,
                    'end_jine'=>$yue,
                    'time'=>time()
                );
                M('wx_user_update_yue')->add($data);
                $arr = array(
                    'code'=>1,
                    'msg'=>'修改成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'修改失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'口令错误'
            );
            $this->ajaxReturn($arr);
        }
    }
    //修改用户上级代理
    public function update_pid(){
        $pid = I('pid');
        $id  = I('uid');
        //查询当前用户的信息
        //修改PID的同时要修改客服
        $r = M('wx_user')->where(array('ID'=>$id))->find();
        $w = array(
            'GzhToken'=>$r['gzhtoken'],
            'ID'=>$pid
        );
        $u = M('wx_user')->where($w)->find();
        if($u){
            $d = array(
                'ID'=>$id,
                'Pid'=>$pid,
                'kefu_id'=>$u['kefu_id']
            );
            $res = M('wx_user')->save($d);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'修改成功'
                );
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'修改失败'
                );
            }
            $this->ajaxReturn($arr);
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'用户编号（ID）输入错误'
            );
            $this->ajaxReturn($arr);
        }
    }

    public function finish_pay(){
        $id = I('post.id');
        $user = $this->user;
        if(empty($id)){
            $data = array(
                 'msg'=>'参数丢失，请刷新页面重试',
                'statue'=>0
            );
        }else{
            $order_info = M('a_order')->where(array('ID'=>$id))->find();
            //检测是否存在该订单
            if(empty($order_info)){
                $data = array(
                    'msg'=>'不存在该订单，请刷新页面重试'
                );
            }else{
                //检测该订单状态
                if($order_info['orderstatue']!="订单付款"){
                    $data = array(
                        'msg'=>'该订单状态为'.$order_info['orderstatue'].'，不能进行当前操作，请刷新页面重试'
                    );
                }else{
                    //获取当前订单的用户所属渠道的配置项
                    $field = "daili_a_config_copy.ShouYiBi,daili_a_config_copy.ShangJiShouYiBi,daili_wx_user.ID,daili_wx_user.Pid";
                    $join = " left join daili_a_media on daili_wx_user.GzhToken=daili_a_media.token left join daili_a_config_copy on daili_a_media.id=daili_a_config_copy.MediaID";
                    $where = array('daili_wx_user.Phone'=>$order_info['adname'],'daili_wx_user.MediaName'=>$order_info['medianame'],'daili_wx_user.AdID'=>$order_info['adid']);
                    $config = M('wx_user')->field($field)->where($where)->join($join)->find();
                    //检测收益表是否存在该订单的收益数据
                    $shouyi_info = M('a_shouyi')->where(array('OrderID'=>$id))->find();
                    $shouyi = M('a_shouyi');
                    $wx_user = M('wx_user');
                    $wx_users = M('wx_user');
                    if(empty($shouyi_info)){
                        //添加收益数据
                        $shouyi->startTrans();
                        $shouyi->add(
                            array(
                                'OrderID'=>$id,
                                'CreateTime'=>$order_info['createtime'],
                                'UID'=>$config['id'],
                                'ShouYi'=>0.9*$config['shouyibi']*$order_info['xiaoguoyugu'],
                                'ShangJiUID'=>$config['pid'],
                                'ShangJiShouYi'=>0.9*$config['shangjishouyibi']*$order_info['xiaoguoyugu'],
                                'OrderStatue'=>1
                            )
                        );
                        if($shouyi){
                            //添加收益表数据成功
                            $shouyi->commit();
                            //查询当前订单所属用户和上级的余额信息，并更新余额
                            $yu_e = $wx_user->where(array('ID'=>$config['id']))->getField('YuE');
                            $shangji_yu_e = $wx_user->where(array('ID'=>$config['pid']))->getField('YuE');
                            $wx_user->startTrans();
                            $wx_users->startTrans();
                            $wx_user->where(array('ID'=>$config['id']))->save(array('YuE'=>($yu_e+0.9*$config['shouyibi']*$order_info['xiaoguoyugu'])));
                            $wx_users->where(array('ID'=>$config['pid']))->save(array('YuE'=>($shangji_yu_e+0.9*$config['shangjishouyibi']*$order_info['xiaoguoyugu'])));
                            if($wx_user && $wx_users){
                                $wx_user->commit();
                                $wx_users->commit();
                                M('a_order')->where(array('ID'=>$id))->save(array('OrderStatue'=>'订单结算'));
                                $this->updata_order_log(
                                    array(
                                        'edit_time'=>time(),
                                        'edit_userid'=>$user['id'],
                                        'uid'=>$config['id'],
                                        'shangjiuid'=>$config['pid'],
                                        'uid_old_yue'=>$yu_e,
                                        'shangjiuid_old_yue'=>$shangji_yu_e,
                                        'uid_yue'=>($yu_e+0.9*$config['shouyibi']*$order_info['xiaoguoyugu']),
                                        'shangjiuid_yue'=>($shangji_yu_e+0.9*$config['shangjishouyibi']*$order_info['xiaoguoyugu']),
                                        'ordernum'=>$order_info['ordernum'],
                                        'orderid'=>$order_info['id'],
                                    )
                                );
                                $data = array(
                                    'msg'=>"同步收益成功",
                                    'statue'=>1
                                );
                            }else{
                                $wx_user->rollback();
                                $wx_users->rollback();
                                $data = array(
                                    'msg'=>"同步收益失败",
                                    'statue'=>0
                                );
                            }
                        }else{
                            $shouyi->rollback();
                            $data = array(
                                'msg'=>"同步收益失败，请刷新重试",
                                'statue'=>0
                            );
                        }
                    }else{
                        //查询当前订单所属用户的信息，以及上级用户的信息，同步更新这些用户的余额
                        $yu_e = $wx_user->where(array('ID'=>$config['id']))->getField('YuE');
                        $shangji_yu_e = $wx_user->where(array('ID'=>$config['pid']))->getField('YuE');
                        $wx_user->startTrans();
                        $wx_users->startTrans();
                        $wx_user->where(array('ID'=>$config['id']))->save(array('YuE'=>($yu_e+$shouyi_info['shouyi'])));
                        $wx_users->where(array('ID'=>$config['pid']))->save(array('YuE'=>($shangji_yu_e+$shouyi_info['shangjishouyi'])));
                        if($wx_user && $wx_users){
                            $wx_user->commit();
                            $wx_users->commit();
                            M('a_order')->where(array('ID'=>$id))->save(array('OrderStatue'=>'订单结算'));
                            $this->updata_order_log(
                                array(
                                    'edit_time'=>time(),
                                    'edit_userid'=>$user['id'],
                                    'uid'=>$config['id'],
                                    'shangjiuid'=>$config['pid'],
                                    'uid_old_yue'=>$yu_e,
                                    'shangjiuid_old_yue'=>$shangji_yu_e,
                                    'uid_yue'=>($yu_e+$shouyi_info['shouyi']),
                                    'shangjiuid_yue'=>($shangji_yu_e+$shouyi_info['shangjishouyi']),
                                    'ordernum'=>$order_info['ordernum'],
                                    'orderid'=>$order_info['id'],
                                )
                            );
                            $data = array(
                                'msg'=>"同步收益成功",
                                'statue'=>1
                            );
                        }else{
                            $wx_user->rollback();
                            $wx_users->rollback();
                            $data = array(
                                'msg'=>"同步收益失败",
                                'statue'=>0
                            );
                        }
                    }
                }
            }

        }
        $this->ajaxReturn($data);
    }

    //  订单失效操作
    public function invalid_pay(){
        $id = I('post.id');
        $user = $this->user;
        if(empty($id)){
            $data = array(
                'msg'=>'参数丢失，请刷新页面重试',
                'statue'=>0
            );
        }else{
            $order_info = M('a_order')->where(array('ID'=>$id))->find();
            //检测是否存在该订单
            if(empty($order_info)){
                $data = array(
                    'msg'=>'不存在该订单，请刷新页面重试'
                );
            }else{
                //检测该订单状态
                if($order_info['orderstatue']!="订单付款"){
                    $data = array(
                        'msg'=>'该订单状态为'.$order_info['orderstatue'].'，不能进行当前操作，请刷新页面重试'
                    );
                }else{
                    //获取当前订单的用户所属渠道的配置项
                    $field = "daili_a_config_copy.ShouYiBi,daili_a_config_copy.ShangJiShouYiBi,daili_wx_user.ID,daili_wx_user.Pid";
                    $join = " left join daili_a_media on daili_wx_user.GzhToken=daili_a_media.token left join daili_a_config_copy on daili_a_media.id=daili_a_config_copy.MediaID";
                    $where = array('daili_wx_user.Phone'=>$order_info['adname'],'daili_wx_user.MediaName'=>$order_info['medianame']);
                    $config = M('wx_user')->field($field)->where($where)->join($join)->find();
                    //检测收益表是否存在该订单的收益数据
                    $shouyi_info = M('a_shouyi')->where(array('OrderID'=>$id))->find();
                    $shouyi = M('a_shouyi');
                    $wx_user = M('wx_user');
                    $wx_users = M('wx_user');
                    if(empty($shouyi_info)){
                        //添加收益数据
                        $shouyi->startTrans();
                        $shouyi->add(
                            array(
                                'OrderID'=>$id,
                                'CreateTime'=>$order_info['createtime'],
                                'UID'=>$config['id'],
                                'ShouYi'=>0,
                                'ShangJiUID'=>$config['pid'],
                                'ShangJiShouYi'=>0,
                                'OrderStatue'=>0
                            )
                        );
                        if($shouyi){
                            //查询当前订单所属用户和上级的余额信息，并更新余额
                            $yu_e = $wx_user->where(array('ID'=>$config['id']))->getField('YuE');
                            $shangji_yu_e = $wx_user->where(array('ID'=>$config['pid']))->getField('YuE');
                            M('a_order')->where(array('ID'=>$id))->save(array('OrderStatue'=>'订单失效'));
                            $this->updata_order_log(
                                array(
                                    'edit_time'=>time(),
                                    'edit_userid'=>$user['id'],
                                    'uid'=>$config['id'],
                                    'shangjiuid'=>$config['pid'],
                                    'uid_old_yue'=>$yu_e,
                                    'shangjiuid_old_yue'=>$shangji_yu_e,
                                    'uid_yue'=>0,
                                    'shangjiuid_yue'=>0,
                                    'ordernum'=>$order_info['ordernum'],
                                    'orderid'=>$order_info['id'],
                                )
                            );
                            $data = array(
                                'msg'=>"订单失效成功",
                                'statue'=>1
                            );
                        }else{
                            $shouyi->rollback();
                            $data = array(
                                'msg'=>"订单失效失败，请刷新重试",
                                'statue'=>0
                            );
                        }
                    }else{
                        M('a_shouyi')->where(array('OrderID'=>$id))->save(array(
                            'ShouYi'=>0,
                            'ShangJiShouYi'=>0,
                            'OrderStatue'=>0
                        ));
                        $shouyi_infos = M('a_shouyi')->where(array('OrderID'=>$id))->find();
                        $yu_e = $wx_user->where(array('ID'=>$config['id']))->getField('YuE');
                        $shangji_yu_e = $wx_user->where(array('ID'=>$config['pid']))->getField('YuE');
                        M('a_order')->where(array('ID'=>$id))->save(array('OrderStatue'=>'订单失效'));
                        $this->updata_order_log(
                            array(
                                'edit_time'=>time(),
                                'edit_userid'=>$user['id'],
                                'uid'=>$config['id'],
                                'shangjiuid'=>$config['pid'],
                                'uid_old_yue'=>$yu_e,
                                'shangjiuid_old_yue'=>$shangji_yu_e,
                                'uid_yue'=>$yu_e,
                                'shangjiuid_yue'=>$shangji_yu_e,
                                'ordernum'=>$order_info['ordernum'],
                                'orderid'=>$order_info['id'],
                            )
                        );
                        $data = array(
                            'msg'=>"订单失效成功",
                            'statue'=>1
                        );
                    }
                }
            }
        }
        $this->ajaxReturn($data);
    }


    //更新订单操作日志
    public function updata_order_log($data){
        M('a_order_log')->add(
            array(
                'edit_time'=>time(),
                'edit_userid'=>$data['edit_userid'],
                'data'=>json_encode(array(
                    'uid'=>$data['uid'],
                    'shangjiuid'=>$data['shangjiuid'],
                    'uid_old_yue'=>$data['uid_old_yue'],
                    'shangjiuid_old_yue'=>$data['shangjiuid_old_yue'],
                    'uid_yue'=>$data['uid_yue'],
                    'shangjiuid_yue'=>$data['shangjiuid_yue'],
                    'ordernum'=>$data['ordernum'],
                    'orderid'=>$data['orderid']
                ))
            )
        );
    }
    //冻结余额功能
    public function dongjie(){
        $id = I('id');
        $statue=I('dongjie');
        if($statue==1){
            //表示取消冻结
            $data = array(
                'ID'=>$id,
                'dongjie'=>''
            );
        }else{
            //表示冻结
            $data = array(
                'ID'=>$id,
                'dongjie'=>1
            );
        }
        $res = M('wx_user')->save($data);
        if($res){
            $arr = array(
                'code'=>1,
                'msg'=>'操作成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'操作失败'
            );
        }
        $this->ajaxReturn($arr);
    }
}
