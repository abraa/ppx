<?php
/**
 * 运营商和区域合伙人pc端管理系统
 * */
namespace Hehuoren\Controller;
use Think\Controller;
class MainController extends BaseController {
    //后台首页
    public function index(){
        $userinfo = session('hehuoren');
        $hour = intval(date('H',time()));
        if($hour>12){
            $welcome_msg = "下午好";
        }else{
            $welcome_msg = '上午好';
        }
        $this->assign('userinfo',$userinfo);
        $this->assign('welcome_msg',$welcome_msg);
        $this->display();
    }
    /**
     * 修改密码
     * */
    public function update_pass(){
        if(IS_POST){
            $id = I('id');
            $name = I('name');
            $password = I('password');
            $newpass = I('newpass');
            $repass = I('repass');
            $pic   = I('pic');
            if(empty($password)){
                $arr = array(
                    'code'=>0,
                    'msg'=>'请输入原密码'
                );
                $this->ajaxReturn($arr);
            }
            if($newpass && strlen($newpass)<6){
                $arr = array(
                    'code'=>0,
                    'msg'=>'密码长度不得少于6个字符'
                );
                $this->ajaxReturn($arr);
            }
            $sql ="select * from daili_wx_user where (username='$name' or Phone='$name') and password='$password'";
            $res = M('wx_user')->query($sql);
            $res = $res['0'];
            if(!$res){
                $arr = array(
                    'code'=>0,
                    'msg'=>'原密码输入错误'
                );
                $this->ajaxReturn($arr);
            }
            if($newpass != $repass){
                $arr = array(
                    'code'=>0,
                    'msg'=>'两次输入的新密码不一致'
                );
                $this->ajaxReturn($arr);
            }
            $data['ID']=$id;
            if($newpass){
                $data['password']=$newpass;
            }
            if($pic){
                $data['HeaderPic']=$pic;
            }
            $res = M('wx_user')->save($data);
            if($res){
                $arr = array(
                    'code'=>1,
                    'msg'=>'修改成功'
                );
                $this->ajaxReturn($arr);
            }else{
                $arr = array(
                    'code'=>0,
                    'msg'=>'修改失败'
                );
                $this->ajaxReturn($arr);
            }
        }else{
            $user = $this->hehuoren;
            $this->assign('user',$user);
            $this->display();
        }
    }
    //我的团队
    public function tuandui(){
        $id = I('id');
        if($id){
            $w = " a.ID=$id and ";
            $this->assign('id',$id);
        }
        $statue=I('statue');
        if($statue){
            if($statue==2){
                $w .=" a.ID=a.kefu_id and ";
            }else{
                $w .=" a.Statue=$statue and ";
            }
            $this->assign('statue',$statue);
        }
        $paixu=I('paixu');
        if($paixu){
            if($paixu==1){
                $order = " a.YiTiXian desc,";
            }
            if($paixu==2){
                $order = " a.YuE desc,";
            }
            $this->assign('paixu',$paixu);
        }
        $text1=I('text1');
        if($text1){
            $w .= " (a.Phone=$text1 or a.Name=$text1 or a.username=$text1) and ";
            $this->assign('text1',$text1);
        }
        $start = I('start');
        $end   = I('end');
        $start_time = strtotime($start);
        $end_time   = strtotime($end)+3600*24;
        if($start && !$end){
            $this->assign('start',$start);
            $w .= " (a.SubscribeTime >=$start_time or a.reg_app_time >= $start_time) and ";
        }
        if(!$start && $end){
            $this->assign('end',$end);
            $w .= " (a.SubscribeTime <=$end_time or a.reg_app_time >= $end_time) and ";
        }
        if($start && $end){
            $this->assign('start',$start);
            $this->assign('end',$end);
            $w .= " ((a.SubscribeTime between $start_time and $end_time) or (a.reg_app_time between $start_time and $end_time)) and ";
        }
        
        $user = $this->hehuoren;
        $uid = $user['id'];
        $member_level=$user['member_level'];
        $p = I('p',1);
        $num = 20;
        $start=($p-1)*$num;
        if($member_level==2){
            //表示运营商
            $w .= "a.member_agent=$uid and ";
        }
        if($member_level==3){
            //表示区域合伙人
            $w .= "a.member_area=$uid and ";
        }
        
        $w = rtrim($w,' and ');
        $sql ="select count(*) as count from daili_wx_user as a where $w";
        $count = M('wx_user')->query($sql);
        $count = $count[0]['count'];
        $page = new \Think\Page($count,$num);
        $show = $page->show();
        $sql ="select a.*,b.Phone as b_phone,b.Name as b_name from 
            daili_wx_user as a 
            left join daili_wx_user as b on a.Pid=b.ID
            where $w order by $order a.id desc limit $start,$num";

        //echo $sql;
        $res = M('wx_user')->query($sql);
//        echo M('wx_user')->getLastSql();
        foreach ($res as $key=>$val){
            switch ($val['member_level']){
                case -1:
                    $res[$key]['member_level_str']='普通粉丝';
                    break;
                case 0:
                    $res[$key]['member_level_str']='会员';
                    break;
                case 1:
                    $res[$key]['member_level_str']='超级会员';
                    break;
                case 2:
                    $res[$key]['member_level_str']='运营商';
                    break;
                case 3:
                    $res[$key]['member_level_str']='区域合伙人';
                    break;
            }
            //查询下级代理
            $count_xiaji = M('wx_user')->where(array('Pid'=>$val['id']))->count();
            $res[$key]['count_xiaji']=$count_xiaji;
            //查询贡献金额

            $v_id=$val['id'];
            if($member_level==2){
                //先查作为运营商的收益
                $sql = "select sum(b.agent_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=$v_id and b.agent_id=$uid";
                $sum1 = M('a_order')->query($sql);
                $sum1 = $sum1[0]['sum'];
                //再查作为上级运营商的收益
                $sql = "select sum(b.shangji_agent_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=$v_id and b.shangji_agent_id=$uid";
                $sum2 = M('a_order')->query($sql);
                $sum2 = $sum2[0]['sum'];
                $sum  = $sum1+$sum2;
            }
            if($member_level==3){
                //查询总贡献金
                $sql = "select sum(b.area_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID=$v_id";
                $sum = M('a_order')->query($sql);
                $sum = $sum[0]['sum'];
            }
            $res[$key]['count_je']=$sum;
        }
        $this->assign('list',$res);
        $this->assign('count',$count);
        $this->assign('p',$p);
        $this->assign('page',$show);
        $this->display();
    }

    //添加代理
    public function add_daili(){
        if(IS_POST){
            $code = $_SESSION['hehuoren']['invitation_code'];
            $username = I('post.username','','trim');
            $password = I('post.password','','trim');

            if(empty($_SESSION['hehuoren'])){
                $this->error('请重新登录');
            }
            if(empty($username)){
                $this->error('请填写手机号');
            }
            if(empty($password)){
                $this->error('请填写密码');
            }
            if(!preg_match("/^1[34578]{1}\d{9}$/",$username)){
                $this->error('请填写正确手机号');
            }
            $userinfo = M('wx_user')->where(array('Phone'=>$username))->find();
            if(!empty($userinfo)){
                $this->error('该手机号已被注册');
            }
            $url = "http://api.olivecloud.cn/index/taobao_tbk_adzone_create?&siteid=%s&adzone=%s";
            $site_id = $_SESSION['hehuoren']['mediaid'];
            $adzone_id=$username;
            $res = vget(sprintf($url,trim($site_id),trim($adzone_id)));
            $ress = json_decode($res,true);
            $tgwid = $ress['pid'];
            $arr_tgwid = explode('_',$tgwid);
            $mediaid = $arr_tgwid[2];
            $adid    = $arr_tgwid[3];
            $member_level=$_SESSION['hehuoren']['memer_level'];
            if($member_level==2){
                $member_agent=$_SESSION['hehuoren']['id'];
                $member_area =$_SESSION['hehuoren']['member_area'];
            }elseif($member_level==3){
                $member_agent=$_SESSION['hehuoren']['member_agent'];
                $member_area=$_SESSION['hehuoren']['id'];
            }else{
                $member_agent=$_SESSION['hehuoren']['member_agent'];
                $member_area=$_SESSION['hehuoren']['member_area'];
            }
            $data = array(
                'Phone'=>$username,
                'username'=>$username,
                'password'=>$password,
                'kefu_id'=>$_SESSION['hehuoren']['kefu_id'],
                'Pid'=>$_SESSION['hehuoren']['id'],
                'Statue'=>($tgwid=="")?-1:1,
                'Time'=>time(),
                'TgwID'=>$tgwid,
                'GzhToken'=>$_SESSION['hehuoren']['gzhtoken'],
                'MediaName'=>$_SESSION['hehuoren']['medianame'],
                'MediaTableID'=>$_SESSION['hehuoren']['mediatableid'],
                'MediaID'=>$mediaid,
                'AdID'=>$adid,
                'AdName'=>$username,
                'IsSubscribe'=>0,
                'is_app'=>5,
                'reg_app_time'=>time(),
                'member_agent'=>$member_agent,
                'member_area'=>$member_area,
                'invitation_code'=>set_invitation_code(),
            );
            $add_res = M('wx_user')->add($data);
            if($add_res){
                $this->success('添加成功');
            }else{
                $this->error('添加失败');
            }
        }else{
            $this->display();
        }
    }

    //用户收入
    public function shouru(){
        $user = $this->hehuoren;
        $uid = $user['id'];
        $member_level=$user['member_level'];
        if($member_level==2){
            //用户为运营商时
            $w = " (b.agent_id=$uid or b.shangji_agent_id=$uid or b.UID=$uid) and ";
        }
        if($member_level==3){
            //用户为区域合伙人时
            $w = " (b.area_id=$uid or b.UID=$uid) and ";
        }
        $order_num = str_replace(' ','',I('order_num'));
        if($order_num){
            $where = " a.OrderNum like '%".$order_num."%' and ";
            $this->assign('order_num',$order_num);
        }
        $startTime = I('start');
        $endTime   = I('end');
        
        $js_startTime = I('js_start');
        $js_endTime   = I('js_end');
        
        if(!$js_startTime && !$js_endTime){
            if(!$startTime){
                $startTime = date('Y-m-d',time());
            }
            if(!$endTime){
                $endTime = date('Y-m-d',time());
            }
        }
        if($startTime && empty($endTime)){
            $str_starttime = strtotime($startTime);
            $where_t0 = " a.CreateTime>$str_starttime";
        }
        if($endTime && empty($startTime)){
            $str_endtime = strtotime($endTime)+3600*24-1;
            $where_t0 = " a.CreateTime<$str_endtime";
        }
        if($startTime && $endTime){
            $str_starttime = strtotime($startTime);
            $str_endtime = strtotime($endTime)+3600*24;
            $where_t0=" a.CreateTime between $str_starttime and $str_endtime";;
        }
        
        
        if($js_startTime && empty($js_endTime)){
            $str_js_starttime = strtotime($js_startTime);
            $where_t1 = " a.CompleteTime>=$str_js_starttime";
        }
        if($js_endTime && empty($js_startTime)){
            $str_js_endtime = strtotime($js_endTime)+3600*24-1;
            $where_t1 = " a.CompleteTime between 1493913600 and $str_js_endtime";
        }
        if($js_startTime && $js_endTime){
            $str_js_starttime = strtotime($js_startTime);
            $str_js_endtime = strtotime($js_endTime)+3600*24-1;
            $where_t1=" a.CompleteTime between $str_js_starttime and $str_js_endtime";
        }
        if($where_t0){
            $where .= $where_t0.' and ';
        }
        if($where_t1){
            $where .= $where_t1.' and ';
        }
        $where1 = $where;
        $where .= $w;
        $where = rtrim($where,' and ');
        S('hehuoren_shouru_where',$where);
        $p = I('p',1);
        $num = 20;
        $startnum = ($p-1)*$num;
        $User = M('a_order'); // 实例化User对象
        //查询失效订单数据
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on b.OrderID = a.ID where $where and a.OrderStatue='订单失效'";
        $count_shixiao      = $User->query($sql);// 查询满足要求的总记录数
        $count_shixiao      = $count_shixiao[0]['count'];
        $this->assign('count_shixiao',$count_shixiao);
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on b.OrderID = a.ID where $where";
        
        $count      = $User->query($sql);// 查询满足要求的总记录数
        
        $count = $count[0]['count'];
        $this->assign('count_youxiao',$count-$count_shixiao);
        
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        
        $sql = "select a.*,
        b.ID as b_id,
        b.UID as b_uid,
        b.OrderID as b_orderid,
        b.CreateTime as b_createtime,
        b.ShouYi as b_shouyi,
        b.ShangJiUID as b_shangjiuid,
        b.ShangJiShouYi as b_shangjishouyi,
        b.ShangShangJiUID as b_shangshangjiuid,
        b.ShangShangJiShouYi as b_shangshangjishouyi,
        b.OrderStatue as b_orderstatue,
        b.agent_id as b_agent_id,
        b.agent_shouyi as b_agent_shouyi,
        b.shangji_agent_id as b_shangji_agent_id,
        b.shangji_agent_shouyi as b_shangji_agent_shouyi,
        b.area_id as b_area_id,
        b.area_shouyi as b_area_shouyi,
        c.Phone as c_phone,
        c.Name as c_name
        from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID left join daili_wx_user as c on b.UID=c.ID where $where order by a.CreateTime desc limit $startnum,$num";
        $list=$User->query($sql);
        //查询总的预估收入
        if($member_level==2){
            //运营商
            //贡献预估作为代理
            $sql = "select sum(b.ShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where1 b.UID=$uid";
            $yugushouru0 = M('a_order')->query($sql);
            $yugushouru0 = $yugushouru0[0]['sum'];
            //查询结算收入
            $sql = "select sum(b.ShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where1 b.UID=$uid and a.OrderStatue='订单结算'";
            $jiesuanshouru0 = M('a_order')->query($sql);
            $jiesuanshouru0 = $jiesuanshouru0[0]['sum'];
            //贡献预估作为一级运营商
            $sql = "select sum(b.agent_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where1 b.agent_id=$uid";
            $yugushouru1 = M('a_order')->query($sql);
            $yugushouru1 = $yugushouru1[0]['sum'];
            //查询结算收入
            $sql = "select sum(b.agent_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where1 b.agent_id=$uid and a.OrderStatue='订单结算'";
            $jiesuanshouru1 = M('a_order')->query($sql);
            $jiesuanshouru1 = $jiesuanshouru1[0]['sum'];
            //贡献预估作为二级运营商
            $sql = "select sum(b.shangji_agent_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where1 b.shangji_agent_id=$uid";
            $yugushouru2 = M('a_order')->query($sql);
            $yugushouru2 = $yugushouru2[0]['sum'];
            //查询结算收入
            $sql = "select sum(b.shangji_agent_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where1 b.shangji_agent_id=$uid and a.OrderStatue='订单结算'";
            $jiesuanshouru2 = M('a_order')->query($sql);
            $jiesuanshouru2 = $jiesuanshouru2[0]['sum'];
            $yugushouru=$yugushouru1+$yugushouru2+$yugushouru0;
            $jiesuanshouru=$jiesuanshouru1+$jiesuanshouru2+$jiesuanshouru0;
            
        }
        if($member_level==3){
            //区域合伙人
            //作为代理
            $sql = "select sum(b.ShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where1 b.UID=$uid";
            $yugushouru0 = M('a_order')->query($sql);
            $yugushouru0 = $yugushouru0[0]['sum'];
            $sql = "select sum(b.area_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where1 b.area_id=$uid";
            $yugushouru1 = M('a_order')->query($sql);
            $yugushouru1 = $yugushouru1[0]['sum'];
            //查询结算收入
            $sql = "select sum(b.ShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where1 b.UID=$uid and a.OrderStatue='订单结算'";
            $jiesuanshouru0 = M('a_order')->query($sql);
            $jiesuanshouru0 = $jiesuanshouru0[0]['sum'];
            $sql = "select sum(b.area_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where $where1 b.area_id=$uid and a.OrderStatue='订单结算'";
            $jiesuanshouru1 = M('a_order')->query($sql);
            $jiesuanshouru1 = $jiesuanshouru1[0]['sum'];
            $yugushouru=$yugushouru1+$yugushouru0;
            $jiesuanshouru=$jiesuanshouru1+$jiesuanshouru0;
            
        }
        $search = array(
            'start'=>$startTime,
            'end'=>$endTime,
            'qudao'=>$qd,
            'js_start'=>$js_startTime,
            'js_end'=>$js_endTime
        );
        $this->assign('yugushouru',$yugushouru);
        $this->assign('jiesuanshouru',$jiesuanshouru);
        $this->assign('search',$search);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('uid',$uid);
        $this->assign('p',$p);
        $this->display();
    }
    //根据用户信息生成推广二维码
    public function qrcode_download(){
        $id = I('id');
        $info = M('wx_user')->where(array('ID'=>$id))->find();
        //验证是否存在当前公众号token文件夹
        if (!file_exists('./Uploads/RJ_VERSION/AppVersion')){
            mkdir ('./Uploads/RJ_VERSION/AppVersion',0777,true);
            mkdir ('./Uploads/RJ_VERSION/AppVersion/qrcode',0777,true);
            mkdir ('./Uploads/RJ_VERSION/AppVersion/version',0777,true);
        }
        copy("./Uploads/RJ_VERSION/kf_code_bg.png","./Uploads/RJ_VERSION/AppVersion/version/user_".$id.".jpg");
        import('Org.Images.Images');
        $img = new \Images();
    
        //通过百度二维码接口生成二维码
        file_put_contents('./Uploads/RJ_VERSION/AppVersion/qrcode/user_'.$id.'.jpg',
        http_get_data("http://pan.baidu.com/share/qrcode?w=150&h=150&url=http://app.taokehelp.cn/Index/download?code=".$info['invitation_code']));
    
        //上图与二维码合成
        $img-> imageWaterMark("./Uploads/RJ_VERSION/AppVersion/version/user_".$id.".jpg",
            10,'./Uploads/RJ_VERSION/AppVersion/qrcode/user_'.$id.'.jpg',
            "","","",400,248);
    
        $file ="http://".$_SERVER['HTTP_HOST']."/Uploads/RJ_VERSION/AppVersion/version/user_".$id.".jpg";
        header("Location:".$file);
        //        header("Content-type: octet/stream");
        //        header("Content-disposition:attachment;filename=".$file.";");
        //        header("Content-Length:".filesize($file));
        //        readfile($file);
        //        exit;
    }
    /*
     * 查询用户收入明细
     */
    public function daili_mingxi(){
        $hehuoren=$this->hehuoren;
        $uid = $hehuoren['id'];
        $id = I('id');
        $startTime = I('start');
        $endTime   = I('end');
        
        if(!$startTime){
            $startTime = "2017-08-01";
        }
        $start = strtotime($startTime);
        if(!$endTime){
            $endTime = date('Y-m-d',time());
        }
        $search = array(
            'start'=>$startTime,
            'end'=>$endTime
        );
        $end   = strtotime($endTime)+24*3600;
        $p = I('p',1);
        $num = 20;
        $startnum = ($p-1)*$num;
        $User = M('a_order'); // 实例化User对象
        //查询失效订单
        
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where (a.CreateTime between $start and $end) and b.UID=$id and b.area_id=$uid and a.OrderStatue='订单失效'";
        $count_shixiao      = $User->query($sql);// 查询满足要求的总记录数
        $this->assign('count_shixiao',$count_shixiao[0]['count']);
       
        $sql = "select count(*) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID where (a.CreateTime between $start and $end) and b.UID=$id and b.area_id=$uid";
        $count      = $User->query($sql);// 查询满足要求的总记录数
        $count = $count[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        
        $sql = "select a.*,
        b.ID as b_id,
        b.UID as b_uid,
        b.OrderID as b_orderid,
        b.CreateTime as b_createtime,
        b.ShouYi as b_shouyi,
        b.ShangJiUID as b_shangjiuid,
        b.ShangJiShouYi as b_shangjishouyi,
        b.ShangShangJiUID as b_shangshangjiuid,
        b.ShangShangJiShouYi as b_shangshangjishouyi,
        b.OrderStatue as b_orderstatue,
        b.agent_id as b_agent_id,
        b.agent_shouyi as b_agent_shouyi,
        b.shangji_agent_id as b_shangji_agent_id,
        b.shangji_agent_shouyi as b_shangji_agent_shouyi,
        b.area_id as b_area_id,
        b.area_shouyi as b_area_shouyi,
        c.username as c_username,
        c.Phone as c_phone,
        c.Name as c_name
        from daili_a_order as a left join daili_a_shouyi as b on a.ID = b.OrderID left join daili_wx_user as c on b.UID=c.ID where (a.CreateTime between $start and $end) and b.UID=$id and b.area_id=$uid order by a.CreateTime desc limit $startnum,$num";
        //echo $sql;exit;
        $list=$User->query($sql);
        
        //查询总的贡献金额
        
        $sql = "select sum(b.area_shouyi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where (a.CreateTime between $start and $end) and b.UID=$id and b.area_id=$uid";
        $sum = M('a_order')->query($sql);
        $sum = $sum[0]['sum'];
        if(!$sum){$sum=0;}
        $this->assign('search',$search);
        $this->assign('countshouru',$sum);
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('count',$count);
        $this->assign('p',$p);
        $user = M('wx_user')->where(array('ID'=>$id))->find();
        $this->assign('user',$user);
        $this->display();
    }
    //客服的下级用户
    public function sub_user(){
        $user = $this->user;
        $uid = $user['id'];
        $start_time = I('start');
        $end_time   = I('end');
        $sort = I('sort');
        $order = '';
        if($sort==1){
            $order = ' order by YiTiXian desc';
        }
        if($sort == 2){
            $order = ' order by YuE desc';
        }
        $search = array(
            'start'=>$start_time,
            'end'=>$end_time
        );
        $this->assign('search',$search);
        $pre_id = I('pre_id');
        //根据ID查询客服信息
        $kefu = M('wx_user')->where(array('ID'=>$pre_id))->find();
        $this->assign('kefu',$kefu);
        //查询客服的下级用户 包括用户自己
        $where = "where kefu_id=$pre_id";
        $p = I('p',1);
        $num = 20;
        $start = ($p-1)*$num;
        $sql = "select count(*) as count from daili_wx_user $where";
        $res = M('wx_user')->query($sql);
        $count = $res[0]['count'];
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $sql = "select * from daili_wx_user $where $order limit $start,$num";
        $res = M('wx_user')->query($sql);
        foreach ($res as $key=>$val){
            $b = M('wx_user')->field('ID,Name,Phone,WxNum,NickName,Address')->where(array('ID'=>$val['pid']))->find();
            $res[$key]['b_name']=$b['name'];
            $res[$key]['b_phone']=$b['phone'];
            $res[$key]['b_id']=$b['id'];
            $res[$key]['b_wxnum']=$b['wxnum'];
            $res[$key]['b_nickname']=$b['nickname'];
            $res[$key]['b_address']=$b['address'];
        }
        //查询所有客服导入的用户的ID
        /*  $sql = "select ID,AdID from daili_wx_user where kefu_id=$pre_id and ID <> $pre_id";
         $all_user_id = M('wx_user')->query($sql);
         foreach ($all_user_id as $key=>$val){
         $str_user_id .= $val['id'].',';
         $str_user_adid.=$val['adid'].',';
         }
         $str_user_id = rtrim($str_user_id,',');
         $str_user_adid=rtrim($str_user_adid,',');
         if(!$str_user_adid){
         $str_user_adid=1;
         } */
        if($start_time && !$end_time){
    
            $start_time = strtotime($start_time);
            $w1 = " and a.CreateTime >= $start_time";
        }
        if(!$start_time && $end_time){
            $end_time = strtotime($end_time)+3600*24;
            $w1 = " and a.CreateTime<=$end_time";
        }
        if($start_time && $end_time){
            $start_time=strtotime($start_time);
            $end_time  =strtotime($end_time)+3600*24;
            $w1 = " and a.CreateTime between $start_time and $end_time";
        }
        //查询客服导入的用户所有收入情况
        $sql = "select ID from daili_wx_user $where";
        $r = M('wx_user')->query($sql);
        foreach ($r as $val){
            $str_uid .= $val['id'].',';
        }
        $str_uid = rtrim($str_uid,',');
        $sql = "select
        count(a.id) as count_order,
        sum(a.XiaoGuoYuGu) as c_shouyi,
        sum(b.ShouYi) as b_shouyi,
        sum(b.ShangJiShouYi) as b_shangjishouyi,
        sum(b.ShangShangJiShouYi) as b_shangshangjishouyi
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID in ($str_uid) $w1";
        $res_tongji = M('a_order')->query($sql);
        //查询有效订单
        $sql = "select
        count(a.id) as count_order
        from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where b.UID in ($str_uid) and a.OrderStatue='订单失效' $w1";
        $count_shixiao = M('a_order')->query($sql);
        $this->assign('count_shixiao',$count_shixiao[0]['count_order']);
        /* $sql = "select
        count(a.id) as count_order,
                sum(a.XiaoGuoYuGu) as c_shouyi,
                sum(b.ShouYi) as b_shouyi,
                sum(b.ShangJiShouYi) as b_shangjishouyi,
                sum(b.ShangShangJiShouYi) as b_shangshangjishouyi
                from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID left join daili_wx_user as c on c.ID=b.ShangJiUId where c.kefu_id=$pre_id $w1";
                $res_tongji_shangji = M('a_order')->query($sql);
                $sql = "select
                count(a.id) as count_order,
                sum(a.XiaoGuoYuGu) as c_shouyi,
                sum(b.ShouYi) as b_shouyi,
                sum(b.ShangJiShouYi) as b_shangjishouyi,
                sum(b.ShangShangJiShouYi) as b_shangshangjishouyi
                from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID left join daili_wx_user as c on c.ID=b.ShangShangJiUID where c.kefu_id=$pre_id $w1";
                $res_tongji_shangshangji = M('a_order')->query($sql);
                */
                $tongji = $res_tongji[0]['count_order'];
    
                    $count_daili_shouyi =
                    $res_tongji[0]['b_shouyi']+$res_tongji[0]['b_shangjishouyi']+$res_tongji[0]['b_shangshangjishouyi'];
    
                        $this->assign('count_daili_shouyi',$count_daili_shouyi);
                        $this->assign('tongji',$tongji);
                    $c = $res_tongji[0]['c_shouyi'];
        $this->assign('count_ali',$c*0.1);
        $this->assign('count_pt',$c-$c*0.1-$count_daili_shouyi);
        $this->assign('count_shouyi',$c);
        $this->assign('p',$p);
        $this->assign('count',$count);
        $this->assign('list',$res);
        $this->assign('page',$show);
        $this->assign('pre_id',$pre_id);
        $this->assign('uid',$uid);
        $this->display();
    }
    /**
     *设置用户为客服
     */
    public function set_kefu(){
        $id = I('get.id');
        $is_kefu = I('is_kefu');
        $data = array(
            'ID'=>$id,
            'kefu_id'=>$id,
        );
        if($is_kefu==2){
            $info = M('wx_user')->where(array('ID'=>$id))->find();
            if($info['statue'] != 1){
                $arr = array(
                    'code'=>0,
                    'msg'=>'成为代理后才可设置为客服'
                );
                $this->ajaxReturn($arr);
            }
            $r = M('wx_user')->save($data);
        }else{
             
            $data = array(
                'ID'=>$id,
                'kefu_id'=>null
            );
            $r = M('wx_user')->save($data);
        }
        if($r){
            $this->update_kefu_id($id,$id);
            $arr = array(
                'code'=>1,
                'msg'=>'设置成功'
            );
        }else{
            $arr = array(
                'code'=>0,
                'msg'=>'设置失败'
            );
        }
        $this->ajaxReturn($arr);
    }
    //设置客服后将这个客服邀请的所有下级kefu_id设置为这个客服
    public function update_kefu_id($id,$kefu_id){
        //这个$id 为被设置的用户的ID，也是下级的kefu_id;
        $user = M('wx_user')->field('ID')->where(array('Pid'=>$id))->select();
        if($user){
            foreach($user as $key=>$val){
                $d = array(
                    'ID'=>$val['id'],
                    'kefu_id'=>$kefu_id
                );
                M('wx_user')->save($d);
                $this->update_kefu_id($val['id'],$kefu_id);
            }
        }
    }
}