<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>欢迎登录产品管理系统</title>
<link href="<?php echo C('HOME_CSS');?>style.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" src="<?php echo C('HOME_JS');?>jquery.js"></script>
<script src="<?php echo C('HOME_JS');?>cloud.js" type="text/javascript"></script>
<script src="<?php echo C('LAYUI');?>layui.js"></script>
<script language="javascript">
	$(function(){
    $('.loginbox').css({'position':'absolute','left':($(window).width()-692)/2});
	$(window).resize(function(){  
    $('.loginbox').css({'position':'absolute','left':($(window).width()-692)/2});
    })  
});  
	document.onkeydown=function mykeyDown(e){ 
        e=e||event; 
        if(e.keyCode==13){
			$('.loginbtn').click();	
        } 
        return; 
    } 
</script> 

</head>

<body style="background-color:#df7611; background-image:url(images/light.png); background-repeat:no-repeat; background-position:center top; overflow:hidden;">



    <div id="mainBody">
      <div id="cloud1" class="cloud"></div>
      <div id="cloud2" class="cloud"></div>
    </div>  


<div class="logintop">    
    <span>欢迎登录产品管理界面平台</span>    
    <!-- <ul>
    <li><a href="#">回首页</a></li>
    <li><a href="#">帮助</a></li>
    <li><a href="#">关于</a></li>
    </ul>   -->  
    </div>
    
    <div class="loginbody">
    
    <span class="systemlogo"></span> 
       
    <div class="loginbox">
    
    <ul>
    <li><input name="" type="text" class="loginuser" placeholder="用户名" value=""/></li>
    <li><input name="" type="password" class="loginpwd" placeholder="密码" value="" /></li>
    <li><input name="" type="button" class="loginbtn" value="登录"   />
	    <!-- <label><input name="" type="checkbox" value="" checked="checked" />记住密码</label>
	    <label><a href="#">忘记密码？</a></label> -->
    </li>
    </ul>
    
    
    </div>
    
    </div>
    
    
    
    <!-- <div class="loginbm">版权所有  2014  <a href="http://www.uimaker.com">uimaker.com</a>  仅供学习交流，勿用于任何商业用途</div>
	 -->
    
</body>
  <script>
layui.use(['layer', 'form'], function(){
  var layer = layui.layer
  ,form = layui.form();
});
</script> 
 <script>
    	$('.loginbtn').click(function(){
    		var loginuser=$('.loginuser').val();
    		var loginpwd =$('.loginpwd').val();
    		if(!loginuser){
    			layer.msg('请填写用户名');
    			return false;
    		}
    		if(!loginpwd){
    			layer.msg('请填写密码');
    			return false;
    		}
    		var data = {user:loginuser,pwd:loginpwd}
    		var url = "<?php echo U('Index/index');?>";
    		$.post(url,data,function(res){
    			if(res.code==1){
    				layer.msg('登录成功',{time:1000},function(){
    					window.location.href="<?php echo U('Public/main');?>";
    				})
    			}else{
    				layer.msg(res.msg);
    			}
    		})
    	})
    </script>
</html>