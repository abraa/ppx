<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <link rel="stylesheet" href="<?php echo C('APP_CSS');?>fan_fs.css">
  <script type="text/javascript" src="<?php echo C('APP_JS');?>jquery.min.js"></script>
  <script type="text/javascript" src="<?php echo C('LAYUI2');?>layui.all.js?version=<?php echo C('VERSION');?>"></script>
  
  
  <style>

  </style>
</head>
<body>
	
<ul class="flow-default" id="LAY_demo1"></ul>

</body>
</html>
<script>
layui.use('flow', function(){
  var flow = layui.flow;
 
  flow.load({
    elem: '#LAY_demo1', //流加载容器
    done: function(page, next){ //执行下一页的回调
      //模拟数据插入
      setTimeout(function(){
        var lis = [];
        for(var i = 0; i < 8; i++){
          lis.push('<li>'+ ( (page-1)*8 + i + 1 ) +'</li>')
        }
        
        //执行下一页渲染，第二参数为：满足“加载更多”的条件，即后面仍有分页
        //pages为Ajax返回的总页数，只有当前页小于总页数的情况下，才会继续出现加载更多
        next(lis.join(''), page < 10); //假设总页数为 10
      }, 500);
    }
  });
})
  </script>