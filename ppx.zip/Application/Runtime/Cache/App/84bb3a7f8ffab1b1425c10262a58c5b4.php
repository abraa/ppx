<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <link rel="stylesheet" href="<?php echo C('APP_CSS');?>fan_fs.css">
  <script type="text/javascript" src="<?php echo C('APP_JS');?>jquery.min.js"></script>
  <script type="text/javascript" src="<?php echo C('LAYUI2');?>layui.all.js?version=<?php echo C('VERSION');?>"></script>
  <script>

    $(function(){
      var ua = navigator.userAgent.toLowerCase();
      if(ua.match(/ios_ppx/i)=="ios_ppx"){
        window.location.href = 'ppx_title&'+'<?php echo urlencode("粉丝") ?>'+'&0';
      }else if(ua.match(/android_ppx/i)=="android_ppx"){
        android.setCurTitle('粉丝',2)
      }else{
      }
    })
  </script>
  <script>
    var url = "<?php echo U('get_team_data');?>"
    window.ppx = {};
    ppx.getUrlParams = function () {
      var search = location.search;
      var params = {};
      if (search.indexOf('?') == 0) {
        search = search.substr(1);
        var arr = search.split('&');
        for (var i = 0; i < arr.length; i++) {
          var itemArr = arr[i].split('=');
          params[itemArr[0]] = itemArr[1];
        }
      }
      return params;
    }
  </script>
  <style>

  </style>
</head>
<body>
<div class="all">
  <header class="top">
    <div class="qb">
      <div class="qb1" >
        <span>全部</span>
        <img src="<?php echo C('APP_IMAGE');?>fs/hk.png" alt="" width="48%">
      </div>
      <div class="qb2" >
        <span>全部</span>
      </div>
    </div>
    <div class="zsfs">
      <div class="zs1">
        <span>直属粉丝</span>
      </div>
      <div class="zs2" >
        <span>直属粉丝</span>
        <img src="<?php echo C('APP_IMAGE');?>fs/hk.png" alt="" width="48%">
      </div>
    </div>
    <div class="tjfs">
      <div class="tj1">
        <span>推荐粉丝</span>
      </div>
      <div class="tj2" >
        <span>推荐粉丝</span>
        <img src="<?php echo C('APP_IMAGE');?>fs/hk.png" alt="" width="48%">
      </div>
    </div>
  </header>
  <!-- 全部 -->
  <div class="yhu" style="padding-bottom: 70px">
  </div>
  <!-- 推荐 -->
  <div class="tuij" style="padding-bottom: 70px">

  </div>
  <!-- 直属 -->
  <div class="zsu" style="padding-bottom: 70px">

  </div>
  <footer class="zh">

  </footer>
  <footer class="zh1">
  </footer>
  <footer class="zh2">

  </footer>
</div>

</body>
</html>
<script>
</script>
<script type="text/javascript" src="<?php echo C('LAYUI2');?>layui.all.js?version=<?php echo C('VERSION');?>"></script>
<script>
	//全部粉丝页面
  var code = "<?php echo ($code); ?>";
  var type = 1;
  var page = 1;
  var token="<?php echo ($token); ?>";
  name(code, type,page,token)
  
  function name(code, type,page,token) {
    var url = "<?php echo U('get_team_datas');?>";
    var data = {
      code:code,
      type : type,
      page:page,
      token:token
    }
    $.post(url,data,function (params) {
      var l = "0";
      var html = '';
      var vvv = '';
      var mmm = '';
      var r = params.info;
      var hy = params.vip_count;
      var dz = params.dz_count;
      if (r) {
        l = r.length;
      }
      for (var i = 0; i < r.length; i++) {
        var a = r[i];
        var hrefs = "#";
        if(a.count>0){
//          var tj_count =
//                  '<a class="a2" href="#">'
//                  +  '<span class="yi">推荐'+ a.count + '人 >  </span>'
//                  +  '</a>'
          var tj_count = "";
        }else{
          var tj_count = "";
        }

//        var hrefs = "<?php echo U('details_fs');?>?code="+a.invitation_code;
        html    += '<div class="yh" >'
                +  '<div class="yongh">'
                +  '<a class="a1" href='+hrefs+'>'
                +  '<img src="../../../../Public/app/images/fs/tx@2x.png" height="52" alt="">'
                +  '<span class="yhm">用户名</span>'
                +  '<div class="dz">'+ a.identity+'</div>'
                +  '<p class="sz">'+ a.user_phone
                +  '<span>'+ a.reg_time+'</span>'
                +  '</p>'
                +  '</a>'
                +  tj_count
                +  '</div>'
                +  '</div>'
        vvv += '<div class="dy">店主:'+ dz +'位</div>'
                +'<div class="dy">会员:'+ hy +'位</div>';
      }
      $('.more').remove();
      if (l == 0) {
        html += '<div class="yh" style="text-align: center;font-weight: bold;">没有更多数据了!</div>';
        vvv += '<div class="dy">店主:0位</div>'
        + '<div class="dy">会员:0位</div>';

      }else{
    	  html +='<div class="more" style="text-align:center;line-height:35px;">点击加载更多~</div>';
          
      }
      //console.log(l);
      $('.yhu').append(html);
      $('.zh').append(vvv);
      $('.more').click(function(){
    	  //name(code, type,page+1,token)
      })
    })
  }
  
  //直属粉丝页面
  var code = "<?php echo ($code); ?>"
  var type = $('.zsfs').find('.zs2') ? '2':'';
  var token ="<?php echo ($token); ?>";
  var page = 1;
  zhishu(code,type,page,token)

  function zhishu(code, type,page,token) {
    var url = "<?php echo U('get_team_datas');?>";
    var data = {
      code:code,
      type : type,
      token:token
    }
    $.get(url,data,function (params) {
      var l = "0";
      var html = '';
      var hhh = '';
      var r = params.info;
      var hy = params.vip_count;
      var dz = params.dz_count;
      if (r) {
        l = r.length;
      }

     if(l > 0) {
         for (var i = 0; i < l; i++) {
         var b = r[i];
         var hrefs = "#";
         if (b.count > 0) {
           var tj_count =
             '<a class="a2" href="#">'
             + '<span class="yi">推荐' + b.count + '人 >  </span>'
             + '</a>'
         } else {
           var tj_count = "";
         }
         //        var hrefs = "<?php echo U('details_fs');?>?code="+b.invitation_code;
         html += '<div class="yh">'
           + '<div class="yongh">'
           + '<a class="a1" href=' + hrefs + '>'
           + '<img src="../../../../Public/app/images/fs/tx@2x.png" height="52" alt="">'
           + '<span class="yhm">用户名</span>'
           + '<div class="dz">' + b.identity + '</div>'
           + '<p class="sz">' + b.user_phone
           + '<span>' + b.reg_time + '</span>'
           + '</p>'
           + '</a>'
           + tj_count
           + '</div>'
           + '</div>';
         hhh += '<div class="dw">店主:' + dz + '位</div>';
       }
         $('.more1').remove();
         html +='<div class="more1" style="text-align:center;line-height:35px;">点击加载更多~</div>';
         
     } else {
        html +=  '<div class="yh" style = "text-align: center;font-weight: bold;" > 没有更多数据了!</div >';
        hhh += '<div class="dw">店主:0位</div>';

      }
      $('.zsu').append(html);
      $('.zh1').append(hhh)
      $('.more1').click(function(){
    	  zhishu(code, type,page+1,token)
      })
    })
  }
  
  //推荐粉丝页面
  var code = "<?php echo ($code); ?>"
  var type = $('.tjfs').find('.tj2') ? '3' : '';
	var token = "<?php echo ($token); ?>";
	var page =1;
  tuijian(code, type,page,token)

  function tuijian(code, type,page,token) {
    var url = "<?php echo U('get_team_datas');?>";
    var data = {
      code: code,
      type: type,
      token:token
    }
    $.get(url, data, function (params) {
      var l = "0";
      var html = '';
      var sss = '';
      var r = params.info;
      var hy = params.vip_count;
      var dz = params.dz_count;
      if (r) {
        l = r.length;
      }
      for (var i = 0; i < l; i++) {
        var b = r[i];
        var hrefs = "#";
        if(b.count>0){
//          var tj_count =
//                  '<a class="a2" href="#">'
//                  +  '<span class="yi">推荐'+ b.count + '人 >  </span>'
//                  +  '</a>'
          var tj_count = "";
        }else{
          var tj_count = "";
        }
//        var hrefs = "<?php echo U('details_fs');?>?code="+b.invitation_code;
        html += '<div class="yh">'
                + '<div class="yongh">'
                + '<a class="a1" href='+hrefs+'>'
                + '<img src="../../../../Public/app/images/fs/tx@2x.png" height="52" alt="">'
                + '<span class="yhm">用户名</span>'
                + '<div class="dz">'+ b.identity+'</div>'
                + '<p class="sz">' + b.user_phone
                + '<span>' + b.reg_time + '</span>'
                + '</p>'
                + '</a>'
                + tj_count
                + '</div>'
                + '</div>';
        sss += '<div class="huiy">会员:'+ hy +'位</div>';
      }
      $('.more2').remove();
      if (l == 0) {
        html += '<div class="yh" style="text-align: center;font-weight: bold;">没有更多数据了!</div>';
        sss += '<div class="huiy">会员:0位</div>';
      }else{
    	  html+="<div class='more2' style='text-align:center'>点击加载更多~</div>";
      }
      $('.tuij').append(html);
      $('.zh2').append(sss)
      $('.more2').click(function(){
    	  tuijian(code, type,page+1,token)
      })
    })
  }
</script>
<script src="<?php echo C('APP_JS');?>fan_fs.js"></script>