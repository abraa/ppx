<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<script type="text/javascript" src="<?php echo C('HOME_JS');?>jquery.js?version=<?php echo C('VERSION');?>"></script>
	<link href="<?php echo C('LAYUI2');?>css/layui.css?version=<?php echo C('VERSION');?>" rel="stylesheet" type="text/css" />
	<title>我的团队页面</title>
	<link href="<?php echo C('MUI');?>css/mui.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="<?php echo C('APP_CSS');?>yqxjjie.css?version=<?php echo C('VERSION');?>">
	<link rel="stylesheet" href="<?php echo C('APP_CSS');?>yqxjjianglijin.css?version=<?php echo C('VERSION');?>">
	
	<script src="<?php echo C('MUI');?>js/mui.min.js"></script>

	<link rel="stylesheet" href="<?php echo C('APP_CSS');?>yqxjjie.css?version=<?php echo C('VERSION');?>">
	<script>
		var type = "<?php echo ($type); ?>";
		if (type == 1) {
			var title = "邀请下级";
		}
		if (type == 2) {
			var title = "店主奖励";
		}
		if (type == 3) {
			var title = "团队奖励";
		}
		$(function () {
			var ua = navigator.userAgent.toLowerCase();
			if (ua.match(/ios_ppx/i) == "ios_ppx") {
				window.location.href = 'ppx_title&' + '<?php echo urlencode("' + title + '") ?>' + '&2';
			} else if (ua.match(/android_ppx/i) == "android_ppx") {
				android.setCurTitle(title, 0)
			} else {

			}
		})
	</script>
	<style>
		.more {
			text-align: center;
			height: 40px;
			line-height: 40px;
		}

		.zh {
			height: 58px;
			width: 100%;
			position: absolute;
			bottom: 0;
			left: 0;
			background-color: #f84c4c;
			color: #ffffff;
			z-index: 9999;
		}

		.zh .zh1 {
			font-size: 16px;
			height: 58px;
			line-height: 58px;
			width: 50%;
			text-align: center;
			float: left;
			/* font-weight: bold; */
			font-family: "微软雅黑 Regular";
			letter-spacing: 0.5px;
		}

		.tsy {
			display: none;
			height: 30px;
			width: 100%;
			color: #ff9999;
			font-size: 15px;
			line-height: 30px;
			background-color: #fef1f1;
			position: fixed;
			bottom: 58px;
			left: 0;
			z-index: 9999;
		}

		.tsy .tsy1 {
			margin-left: 20px;
		}

		.mui-scroll-wrapper {
			height: 100%;
			width: 100%;
			overflow: hidden;
			position: relative;
			background-color: #fff;
			text-align: center;
			padding-bottom: 75px;
		}
		
	</style>

</head>

<body>
	<div class="all">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="yhu">

				</div>
			</div>
		</div>

		<div class="tsy">
		</div>
		<footer class="zh">

		</footer>
	</div>
	<script type="text/javascript" src="<?php echo C('LAYUI2');?>layui.all.js?version=<?php echo C('VERSION');?>"></script>

	<script>
		var all = document.querySelector('.all')
		var wrapper = document.querySelector('.mui-scroll-wrapper')
		var scroll = document.querySelector('.mui-scroll')
		var yhu = document.querySelector('.yhu')
		var yh1 = document.querySelector('.yh1')
		var yongh1 = document.querySelector('.yongh1')
		var a1 = document.querySelector('.a1')
		var money = document.querySelector('.money')
		var tsy = document.querySelector('.tsy')
		mui('.mui-scroll-wrapper').scroll({
			indicators: false,
			deceleration: 0.0005
		});
		mui('body').on('tap', 'a', function () {
				window.top.location.href = this.href;
			});
		mui('body').on('tap', '.yh1 .money', function () {
			if ($(".tsy").css("display") == "none") {

				$(".tsy").show();

			} else {

				$(".tsy").hide();

			}
			});
		var code = "<?php echo ($code); ?>";
		var type = "<?php echo ($type); ?>";
		var page = 1;
		get_data(code, type, page);

		function get_data(code, type, page) {
			var url = "<?php echo U('get_reward_list_api');?>";
			var data = {
				code: code,
				type: type,
				page: page
			};
			$.post(url, data, function (bool) {
				var l = 0;
				var html = '';
				var text = '';
				var num = bool.num;
				var tishiyu = '';
				//var page = bool.page;
				var r = bool.data;
				var rs = bool.reward_count;
				var jeje = bool.reward_sum;
				if (r) {
					l = r.length;
				}
				for (var i = 0; i < l; i++) {
					var res = r[i];
					var reason = res.reason;
					if (type == 3) {
						var url = '<?php echo U("Ucenter/order_list");?>?code=' + code + '&uid=' + res.id;
					} else {
						var url = "javascript:;";
					}
					if (reason == '') {
						html += '<div class="yh">' +
							'<div class="yongh">' +
							'<a class="a1" href="javascript:;">' +
							'<img src="<?php echo C('APP_IMAGE');?>fs/tx@2x.png" height="52" alt="">' +
							'<span class="yhm" style=" position: absolute;top: 7px;left: 39 %;style="font-size: 16px;"">用户名</span>' +
							'<div class="dz">' + res.identity + '</div>' +
							'<p class="sz" style=" position: absolute;bottom: -9px;left: 23 %;font-size: 13px;color: #A6A6A6;">' + res.tel +
							'<span>' + res.reg_times + '</span>' +
							'</p>' +
							'<p class="jlije" style="color:red;position: absolute;right: 8 %;top: 8px;">奖励金额</p>' +
							'<span class="money"  style="color:red;position: absolute;right: 8 %;bottom: 1px;">' + res.money + '</span>' +
							'</a>' +
							'</div>' +
							'</div>';

					} else {
						html += '<div class="yh1">' +
							'<div class="yongh1">' +
							'<a class="a1" href="javascript:;">' +
							'<img class="img2" src="<?php echo C('APP_IMAGE');?>fs/tx@2x.png" height="52" alt="">' +
							'<span class="yhm" style="font-size: 16px;">用户名</span>' +
							'<div class="dz">' + res.identity + '</div>' +
							'<p class="sz" style=" position: absolute;bottom: -9px;left: 23%;font-size: 13px;color: #A6A6A6;">' + res.tel +
							'<span>' + res.reg_times + '</span>' +
							'</p>' +
							'<p class="jlije" style="color:#999999;position: absolute;right:7%;top: 9px;">奖励金额</p>' +
							'<span style="color:#999999;position: absolute;right: 6%;bottom: 1px;" class="money" onclick ="changeStyle(tsy)">' + res.money +
							' <img class="wenhao" src = "<?php echo C('APP_IMAGE');?>wenhao.png" width=13px>' +
							'</span>' +
							'</a>' +
							'</div>' +
							'</div>';
						tishiyu += '<div class="tsy1">' + reason + '</div>';
					}
					text += '<div class="zh1">累计邀请：' + rs + '位</div>' +
						'<div class="zh1">累计奖励金:' + jeje + '</div>'
				}
				$('.more').remove();
				if (l == 0) {
					html += '<div class="yh" style="text-align:center;">没有更多数据了~</div>'
					text += '<div class="zh1">累计邀请：0位</div>' +
						'<div class="zh1">累计奖励金:0.00</div>';
					mui.init({
						pullRefresh: {
							container: ".mui-scroll-wrapper",
							up: {
								height: 50,
								contentover: "释放立即刷新",
								contentfresh: '正在加载中...',
								contentnomore: '没有更多数据了',
								callback: function () {
									var that = this;
									setTimeout(function () {
										that.endPullupToRefresh();
									}, 1000);
								}
							}
						}
					})
					mui('.mui-scroll-wrapper').pullRefresh().disablePullupToRefresh();
				}
				mui.init({
					pullRefresh: {
						container: ".mui-scroll-wrapper",
						up: {
							tap: true,
							height: 50,
							contentover: "释放立即刷新",
							contentfresh: '正在加载中...',
							contentnomore: '没有更多数据了',
							callback: function () {
								var that = this;
								setTimeout(function () {
									that.endPullupToRefresh();
								}, 1000);
								page ++;
								get_data(code, type, page, function () {
									that.endPullupToRefresh(true);
								});
							}
						}
					}
				})
				$('.yhu').append(html)
				$('.zh').append(text)
				$('.tsy').append(tishiyu)
			})
		}
	</script>
</body>

</html>