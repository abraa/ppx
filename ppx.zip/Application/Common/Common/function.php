<?php
/**
 * 字符串截取，支持中文和其他编码
 *
 * @access public
 * @param string $str
 *        	需要转换的字符串
 * @param string $start
 *        	开始位置
 * @param string $length
 *        	截取长度
 * @param string $charset
 *        	编码格式
 * @param string $suffix
 *        	截断显示字符
 * @return string
 */
function msubstr($str, $start = 0, $length, $charset = "utf-8", $suffix = true) {
    if (function_exists ( "mb_substr" ))
        $slice = mb_substr ( $str, $start, $length, $charset );
    elseif (function_exists ( 'iconv_substr' )) {
        $slice = iconv_substr ( $str, $start, $length, $charset );
        if (false === $slice) {
            $slice = '';
        }
    } else {
        $re ['utf-8'] = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
        $re ['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";
        $re ['gbk'] = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";
        $re ['big5'] = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";
        preg_match_all ( $re [$charset], $str, $match );
        $slice = join ( "", array_slice ( $match [0], $start, $length ) );
    }

    return $suffix && $str != $slice ? $slice . '...' : $slice;
}

//导出excel表的函数
function exportExcel($expTitle,$expCellName,$expTableData){

    $xlsTitle = iconv('utf-8', 'gb2312', $expTitle);//文件名称
    //$fileName = $_SESSION['account'].date('Y-m-d/H:i:s');//or $xlsTitle 文件名称可根据自己情况设定
    $fileName = $_SESSION['account'].$xlsTitle;//or $xlsTitle 文件名称可根据自己情况设定

    $cellNum = count($expCellName);
    $dataNum = count($expTableData);
    vendor("PHPExcel");
    $objPHPExcel = new PHPExcel();
    $cellName = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW','AX','AY','AZ');
    $objPHPExcel->getActiveSheet(0)->mergeCells('A1:'.$cellName[$cellNum-1].'1');//合并单元格
    //$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', $expTitle.'  Export time:'.date('Y-m-d H:i:s'));
    for($i=0;$i<$cellNum;$i++){
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue($cellName[$i].'2', $expCellName[$i][1]);
    }
    // Miscellaneous glyphs, UTF-8
    for($i=0;$i<$dataNum;$i++){
        for($j=0;$j<$cellNum;$j++){
            $objPHPExcel->getActiveSheet(0)->setCellValue($cellName[$j].($i+3), $expTableData[$i][$expCellName[$j][0]]);
        }
    }
    header('pragma:public');
    header('Content-type:application/vnd.ms-excel;charset=utf-8;name="'.$xlsTitle.'.xls"');
    header("Content-Disposition:attachment;filename=$fileName.xls");//attachment新窗口打印inline本窗口打印
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output');
    return $objWriter;
}
//对象转数组
function obj_to_arr($array) {
    if(is_object($array)) {
        $array = (array)$array;
    } if(is_array($array)) {
        foreach($array as $key=>$value) {
            $array[$key] = obj_to_arr($value);
        }
    }
    return $array;
}
//添加日志
function AddLog($data,$msg=null){
    $arr = array(
        'time'=>date('Y-m-d H:i:s',time()),
        'msg'=>json_encode($data,JSON_UNESCAPED_UNICODE),
        'type'=>$msg
    );
    M('items_sync_log')->add($arr);
}
//添加微信日志
function AddwxLog($data,$msg=null){
    $arr = array(
        'time'=>date('Y-m-d H:i:s',time()),
        'data'=>json_encode($data,JSON_UNESCAPED_UNICODE),
        'msg'=>$msg
    );
    M('wx_log')->add($arr);
}
//xml转换为数组
function xmlToArray($xml){
    //禁止引用外部xml实体
    libxml_disable_entity_loader(true);

    $xmlstring = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA);

    $val = json_decode(json_encode($xmlstring),true);

    return $val;
}
/**
 * TODO 基础分页的相同代码封装，使前台的代码更少
 * @param $count 要分页的总记录数
 * @param int $pagesize 每页查询条数
 * @return \Think\Page
 */
function getpage($count, $pagesize = 10) {
    $p = new \Think\Page($count, $pagesize);
    $p->setConfig('header', '<font class="page_rows">共<b>%TOTAL_ROW%</b>条记录&nbsp;第<b>%NOW_PAGE%</b>页/共<b>%TOTAL_PAGE%</b>页</font>');
    $p->setConfig('prev', '上一页');
    $p->setConfig('next', '下一页');
    $p->setConfig('last', '末页');
    $p->setConfig('first', '首页');
    $p->setConfig('theme', '%FIRST%%UP_PAGE%%LINK_PAGE%%DOWN_PAGE%%END%%HEADER%');
    $p->lastSuffix = false;//最后一页不显示为总页数
    return $p;
}



/***********微信接口方法************/
/**
 * 微信接口操作公用函数
 */
//获取access_token
function access_token($token){
    $w=array(
        'token'=>$token,
    );
    $r = M('a_access_token')->where($w)->order('id desc')->limit(1)->find();
    if(!$r || time()-$r['time']>=7000){
    /* $access_token = S($token); */
        //if(!$access_token){
        $gzh0 = M('a_media')->where(array('token'=>$token))->find();
        $gzh1 = M('z_kefu_gzh')->where(array('token'=>$token))->find();
        if($gzh0){
            $gzh=$gzh0;
        }
        if($gzh1){
            $gzh=$gzh1;
        }

        $appid = $gzh['appid'];
        $appsecret=$gzh['appsecret'];
        $url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$appsecret;
        $res = file_get_contents($url);
        $obj=json_decode($res,true);
        $access_token=$obj['access_token'];
        $d = array(
            'token'=>$token,
            'access_token'=>$access_token,
            'time'=>time(),
            'str'=>date('Y-m-d H:i:s',time()).$_SERVER['HTTP_HOST'].'1'.$url.$_SERVER['REQUEST_URI']
            
        );
        M('a_access_token')->add($d);
        $data = array(
            'token'=>$token,
            'access_token'=>$access_token,
            'url'=>$url,
            'access'=>$obj,
            'gzh'=>$gzh
        );
//        AddwxLog($data,'获取access_token_a');
    }else{
        if(empty($r['access_token'])){
            $gzh0 = M('a_media')->where(array('token'=>$token))->find();
            $gzh1 = M('z_kefu_gzh')->where(array('token'=>$token))->find();
            if($gzh0){
                $gzh=$gzh0;
            }
            if($gzh1){
                $gzh=$gzh1;
            }
            $appid = $gzh['appid'];
            $appsecret=$gzh['appsecret'];
            $url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$appsecret;
            $res = file_get_contents($url);
            $obj=json_decode($res,true);
            $access_token=$obj['access_token'];
            $d = array(
                'token'=>$token,
                'access_token'=>$access_token,
                'time'=>time(),
                'str'=>date('Y-m-d H:i:s',time()).$_SERVER['HTTP_HOST'].'2'.$url.$_SERVER['REQUEST_URI']
            );
            M('a_access_token')->add($d);
            $data = array(
                'token'=>$token,
                'access_token'=>$access_token,
                'url'=>$url,
                'access'=>$obj,
                'gzh'=>$gzh
            );
//            AddwxLog($data,'获取access_token_b');

        }else{
            $access_token=$r['access_token'];
        }
    }
    $data = array(
        'token'=>$token,
        'access_token'=>$access_token
    );
//    AddwxLog($data,'返回access_token');
    return $access_token;
}
//获取微信服务器ip地址列表
function ip_list(){
    $access_token = access_token();
    $url ='https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token='.$access_token;
    $ip_list = file_get_contents($url);
    $ip_list = json_decode($ip_list);
    return $ip_list->ip_list;
}
//用户普通渠道关注后的操作
function subscribe($postObj){
    $fromUsername = $postObj['FromUserName'];
    $toUsername   = $postObj['ToUserName'];//这个参数对应的是gzh数据表中的token
    $CreateTime   = $postObj['CreateTime'];
    //查询公众号appid等信息
    $gzh = M('a_media')->where(array('token'=>$toUsername))->find();
    //用户关注后
    $access_token = access_token($postObj['ToUserName']);
    $info = get_userinfo($fromUsername,$access_token);
//    $data = array(
//        'ToUserName'=>$fromUsername,
//        'FromUserName'=>$toUsername,
//        'msgtype'=>'text',
//        'content'=>$fromUsername."+++".$access_token
//    );
//    text($data);
    //插叙当前公众号token所对应的媒体id
//    $m_id =  M('a_media')->where(array('AliMaMaID'=>$a_id,'Statue'=>1))->getField('id');
    $m_id =  M('a_media')->where(array('token'=>$toUsername))->getField('id');
    if($info['openid']!=''){
        $res = M('wx_user')->where(array('OpenID'=>$fromUsername))->find();
        if(empty($res)){
            $tx = M('wx_user');
            $tx->startTrans();
            $tx->add(array(
                'IsSubscribe'=>$info['subscribe'],
                'OpenID'=>$info['openid'],
                'NickName'=>$info['nickname'],
                'Address'=>$info['country']."-".$info['province']."-".$info['city'],
                'HeaderPic'=>$info['headimgurl'],
                'GzhToken'=>$toUsername,
                'MediaTableID'=>$m_id,
                'SubscribeTime'=>time()
            ));
            if($tx){
                $tx->commit();
            }else{
                $tx->rollback();
            }
//            M('wx_user')->add(array(
//                'IsSubscribe'=>$info['subscribe'],
//                'OpenID'=>$info['openid'],
//                'NickName'=>$info['nickname'],
//                'Address'=>$info['country']."-".$info['province']."-".$info['city'],
//                'HeaderPic'=>$info['headimgurl'],
//                'GzhToken'=>$toUsername,
//                'MediaTableID'=>$m_id,
//                'SubscribeTime'=>time()
//            ));
        }else{
            M('wx_user')->where(array('OpenID'=>$fromUsername))->save(array(
                'IsSubscribe'=>$info['subscribe'],
                'OpenID'=>$info['openid'],
                'NickName'=>$info['nickname'],
                'Address'=>$info['country']."-".$info['province']."-".$info['city'],
                'HeaderPic'=>$info['headimgurl'],
                'GzhToken'=>$toUsername,
                'SubscribeTime'=>time()
                //'MediaTableID'=>$m_id
            ));
        }
    }
    $gid = M('a_media')->where(array('token'=>$toUsername))->getField('id');
    //查询文本消息
    $resText = M('wx_replay_text')->where(array('gid'=>$gid))->find();
    $gzh_info =  M('a_media')->where(array('token'=>$toUsername))->find();
    if($resText['home'] == 0){
        $data = array(
            'ToUserName'=>$fromUsername,
            'FromUserName'=>$toUsername,
            'msgtype'=>'text',
            'content'=>$resText['content']
        );
        AddwxLog($data,'用户关注发文本消息');
        text($data);
    }elseif($resText['home'] == 1){
        //图文类型
        $back = M('wx_img')->where(array('id'=>$resText['imageid']))->find();
        if ($back ['url'] != false) {
            $url = $back ['url'];
        } else {
            $url = $gzh_info['yuming'].'/Index/index.html?token='.$toUsername;
        }
        $return [0] = array (
            'title'=>$back ['title'],
            'discription'=>$back ['text'],
            'picurl'=>$back ['pic'],
            'url'=>$url
        );
        $backchild = M ( 'wx_img' )->field ( 'id,text,pic,url,title' )->limit ( 5 )->order ( 'id desc' )->where ( array ('parentid' => $back ['id'] ) )->select ();
        if ($backchild !== false) {
            foreach ( $backchild as $keya => $infot ) {
                if ($infot ['url'] != false) {
                    $urls = $infot ['url'];
                } else {
                    $urls = $gzh_info['yuming'].'/Index/index.html?token='.$toUsername;
                }
                $return [] = array (
                    'title'=>$infot ['title'],
                    'discription'=>$infot ['text'],
                    'picurl'=>$infot ['pic'],
                    'url'=>$urls
                );
            }
        }
        $data = array(
            'content'=>$return,
            'ToUserName'=>$fromUsername,
            'FromUserName'=>$toUsername,
        );
        AddwxLog($data,'用户关注发图文消息');
        tuwen_message($data);
    }else{
        $field = "daili_wx_replay_img.*";
        $join = " left join daili_wx_replay_img on daili_wx_replay_text.imageid = daili_wx_replay_img.id";
        $img_info = M('wx_replay_text')->field($field)->where(array('daili_wx_replay_text.gid'=>$gid,'home'=>2))->join($join)->find();

        $data = array(
            'ToUserName'=>$fromUsername,
            'FromUserName'=>$toUsername,
            'msgtype'=>'image',
            'media_id'=>$img_info['code_media_id']
        );
        img_media($data);
    }


//    if($resText['statue']==1){
//        $data = array(
//            'ToUserName'=>$fromUsername,
//            'FromUserName'=>$toUsername,
//            'msgtype'=>'text',
//            'content'=>$resText['content']
//        );
//        //客服消息接口
//        //$url = 'https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token='.access_token($gzh['appid'],$gzh['appsecret'],$gzh['id']);
//        //curl_post($data,$url);
//        AddwxLog($data,'用户关注发文本消息');
//        text($data);
//    }
    //tuwen_message($postObj);
}
//用户扫描带参数的二维码关注后的操作
function qrcode_subscribe($postObj){
    $fromUsername = $postObj['FromUserName'];
    $toUsername   = $postObj['ToUserName'];
    $CreateTime   = $postObj['CreateTime'];
    $EventKey     = $postObj['EventKey'];
    $access_token = access_token($toUsername);
    $EventKey     = str_replace('qrscene_','',$EventKey);
    //先查询用户是否已经关注过然后取消了关注，如果是则修改关注时间和状态
//    $data = array(
//        'ToUserName'=>$fromUsername,
//        'FromUserName'=>$toUsername,
//        'msgtype'=>'text',
//        'content'=>$postObj['FromUserName']
//    );
//    // AddwxLog($data,'用户关注发文本消息');
//    text($data);
//    exit;

    $w = array(
        'OpenID'=>$fromUsername,
        'GzhToken'=>$toUsername
    );
    $subscribe_user = M('wx_user')->where($w)->find();
    if($subscribe_user){
        M('wx_user')->where(array('ID'=>$subscribe_user['id']))->save(array('IsSubscribe'=>1,'SubscribeTime'=>time()));
    }else{
        //插叙当前公众号token所对应的媒体id
//    $m_id =  M('a_media')->where(array('AliMaMaID'=>$a_id,'Statue'=>1))->getField('id');
        $m_id =  M('a_media')->where(array('token'=>$toUsername))->getField('id');
        $on_user = M('wx_user')->where(array('ID'=>$EventKey))->find();
        if(empty($on_user)){
            $kefu_id = "";
        }else{
            $kefu_id = $on_user['kefu_id'];
        }
        $user_info = get_userinfo($fromUsername,$access_token);
        $datas['OpenID']=$user_info['openid'];
        $datas['IsSubscribe'] = 1;
        $datas['HeaderPic']=$user_info['headimgurl'];
        $datas['NickName']=$user_info['nickname'];
        $datas['Address']=$user_info['country']."-".$user_info['province']."-".$user_info['city'];
        $datas['Pid'] = $EventKey;
        $datas['MediaTableID'] = $m_id;
        $datas['GzhToken'] = $toUsername;
        $datas['kefu_id'] = $kefu_id;
        $datas['SubscribeTime'] = time();
        $tx = M('wx_user');
        $tx->startTrans();
        $tx->add($datas);
        if($tx){
            $tx->commit();
        }else{
            $tx->rollback();
        }
        $arr = array(
            'content'=>'用户'.$user_info['openid'].'通过公众号token为“'.$toUsername.'”扫描用户id为“'.$EventKey.'”的用户进行关注',
            'time'=>time()
        );
        AddwxLog($arr,'用户扫描带参二维码关注');
    }

    file_put_contents('add.txt', M('wx_user')->getLastSql());
    $gid = M('a_media')->where(array('token'=>$toUsername))->getField('id');
    //查询文本消息
    $resText = M('wx_replay_text')->where(array('gid'=>$gid))->find();
    $gzh_info =  M('a_media')->where(array('token'=>$toUsername))->find();
    if($resText['home'] == 0){
        $data = array(
            'ToUserName'=>$fromUsername,
            'FromUserName'=>$toUsername,
            'msgtype'=>'text',
            'content'=>$resText['content']
        );
        AddwxLog($data,'用户关注发文本消息');
        text($data);
    }elseif($resText['home'] == 1){
        //图文类型
        $back = M('wx_img')->where(array('id'=>$resText['imageid']))->find();
        if ($back ['url'] != false) {
            $url = $back ['url'];
        } else {
            $url = $gzh_info['yuming'].'/Index/index.html?token='.$toUsername;
        }
        $return [0] = array (
            'title'=>$back ['title'],
            'discription'=>$back ['text'],
            'picurl'=>$back ['pic'],
            'url'=>$url
        );
        $backchild = M ( 'wx_img' )->field ( 'id,text,pic,url,title' )->limit ( 5 )->order ( 'id desc' )->where ( array ('parentid' => $back ['id'] ) )->select ();
        if ($backchild !== false) {
            foreach ( $backchild as $keya => $infot ) {
                if ($infot ['url'] != false) {
                    $urls = $infot ['url'];
                } else {
                    $urls = $gzh_info['yuming'].'/Index/index.html?token='.$toUsername;
                }
                $return [] = array (
                    'title'=>$infot ['title'],
                    'discription'=>$infot ['text'],
                    'picurl'=>$infot ['pic'],
                    'url'=>$urls
                );
            }
        }
        $data = array(
            'content'=>$return,
            'FromUserName'=>$postObj['FromUserName'],
            'ToUserName' =>$postObj['ToUserName']
        );
        AddwxLog($data,'用户关注发图文消息');
        tuwen_message($data);
    }else{
        $field = "daili_wx_replay_img.*";
        $join = " left join daili_wx_replay_img on daili_wx_replay_text.imageid = daili_wx_replay_img.id";
        $img_info = M('wx_replay_text')->field($field)->where(array('daili_wx_replay_text.gid'=>$gid,'home'=>2))->join($join)->find();

        $data = array(
            'ToUserName'=>$fromUsername,
            'FromUserName'=>$toUsername,
            'msgtype'=>'image',
            'media_id'=>$img_info['code_media_id']
        );
        img_media($data);
    }
}
//用户关注后扫描带参数二维码操作
function scan($postObj){
    $fromUsername = $postObj['FromUserName'];
    $toUsername   = $postObj['ToUserName'];
    $CreateTime   = $postObj['CreateTime'];
    $EventKey     = $postObj['EventKey'];
    $access_token = access_token($toUsername);
    $EventKey     = str_replace('qrscene_','',$EventKey);
    //先查询用户是否已经关注过然后取消了关注，如果是则修改关注时间和状态
    $w = array(
        'OpenID'=>$fromUsername,
        'GzhToken'=>$toUsername
    );
    $subscribe_user = M('wx_user')->where($w)->find();
    if(!$subscribe_user){
//    $m_id =  M('a_media')->where(array('AliMaMaID'=>$a_id,'Statue'=>1))->getField('id');
        $m_id =  M('a_media')->where(array('token'=>$toUsername))->getField('id');
        $user_info = get_userinfo($fromUsername,$access_token);
        $datas['OpenID']=$user_info['openid'];
        $datas['IsSubscribe'] = 1;
        $datas['HeaderPic']=$user_info['headimgurl'];
        $datas['NickName']=$user_info['nickname'];
        $datas['Address']=$user_info['country']."-".$user_info['province']."-".$user_info['city'];
        $datas['Pid'] = $EventKey;
        $datas['MediaTableID'] = $m_id;
        $datas['GzhToken'] = $toUsername;
        $tx = M('wx_user');
        $tx->startTrans();
        $tx->add($datas);
        if($tx){
            $tx->commit();
        }else{
            $tx->rollback();
        }
        $arr = array(
            'content'=>'用户'.$user_info['openid'].'通过公众号token为“'.$toUsername.'”扫描用户id为“'.$EventKey.'”的用户进行关注',
            'time'=>time()
        );
        AddwxLog($arr,'用户扫描带参二维码关注');
    }else{
        M('wx_user')->where(array('ID'=>$subscribe_user['id']))->save(array('IsSubscribe'=>1));
    }
    $data = array(
        'ToUserName'=>$fromUsername,
        'FromUserName'=>$toUsername,
        'msgtype'=>'text',
        'content'=>'欢迎再次回来'
    );
    text($data);

}
//用户取消关注
function unsubscribe($postObj){
    $fromUsername = $postObj['FromUserName'];
    $toUsername   = $postObj['ToUserName'];
    $CreateTime   = $postObj['CreateTime'];
    $where = array(
        'OpenID'=>$fromUsername,
        'GzhToken'=>$toUsername
    );
    $data = array(
        'IsSubscribe'=>0,
        'SubscribeTime'=>time()
    );
    M('wx_user')->where($where)->save($data);

    $arr = array(
        'content'=>'用户'.$fromUsername.'取消关注公众号token“'.$toUsername,
        'time'=>time()
    );
    AddwxLog($arr,'用户取消关注');
    file_put_contents('save.txt', M('wx_user')->getLastSql());
}
//用户上报地理位置
function location($postObj){
    $fromUsername = $postObj['FromUserName'];
    $toUsername   = $postObj['ToUserName'];
    $createTime   = $postObj['CreateTime'];
    $latitude     = $postObj['Latitude'];//地理位置纬度
    $longitude    = $postObj['Longitude'];//地理位置经度
    $precision    = $postObj['Precision'];//地理位置精度
    //查询数据库中上报的用户id
    $w = array(
        'fromusername'=>$fromUsername,
        'tousername'=>$toUsername
    );
    $subscribe_user = M('wx_subscribe_user')->where($w)->find();
    $userid = $subscribe_user['id'];
    $data = array(
        'uid'=>$userid,
        'FromUserName'=>$fromUsername,
        'ToUserName'=>$toUsername,
        'CreateTime'=>$createTime,
        'Latitude'=>$latitude,
        'Longitude'=>$longitude,
        'PrecisionLocation'=>$precision
    );
    M('wx_location')->add($data);
}
//点击菜单拉取消息时的事件推送
function click($postObj){
    
    $_SESSION['gzh_token'] = $postObj['ToUserName'];
    $key = $postObj['EventKey'];
    $key_info = M('menu')->where(array('key'=>$key))->find();
    $fromUsername = $postObj['FromUserName'];
    $toUsername   = $postObj['ToUserName'];
    $info = M('wx_user')->where(array('OpenID'=>$fromUsername,'GzhToken'=>$toUsername,'Statue'=>1))->find();
    $gzh_info =  M('a_media')->where(array('token'=>$toUsername))->find();
    if($key_info['key'] == '代理海报'){
        if(empty($info)){
            $data = array(
                'ToUserName'=>$fromUsername,
                'FromUserName'=>$toUsername,
                'msgtype'=>'text',
                'content'=>'<a href='.'"'.$gzh_info['yuming'].'/Index/my_daili.html?token='.$toUsername.'"> ☞点我成为代理</a>'
            );
            text($data);
        }else{
            set_pic($postObj);
        }
    }elseif($key_info['key'] == '我的商城'){
        if(empty($info)){
            $data = array(
                'ToUserName'=>$fromUsername,
                'FromUserName'=>$toUsername,
                'msgtype'=>'text',
                'content'=>'<a href='.'"'.$gzh_info['yuming'].'/Index/my_daili.html?token='.$toUsername.'"> ☞点我成为代理</a>'
            );
            text($data);
        }else{
            set_myshop_img($postObj);
        }
    }else{
        $key_info = M('wx_rule')->where(array('keyword'=>$key_info['key'],'gid'=>$gzh_info['id']))->find();
        if(empty($key_info)){
            $data = array(
                'ToUserName'=>$fromUsername,
                'FromUserName'=>$toUsername,
                'msgtype'=>'text',
                'content'=>'服务商没有设置该关键词内容，请与服务商联系'
            );
            text($data);
        }else{
            if($key_info['type'] == 1){
                //文本类型
                $data = array(
                    'ToUserName'=>$fromUsername,
                    'FromUserName'=>$toUsername,
                    'msgtype'=>'text',
                    'content'=>$key_info['content']
                );
                text($data);
            }elseif($key_info['type'] == 2){
                //图文类型
                $back = M('wx_img')->where(array('id'=>$key_info['imageid']))->find();
                if ($back ['url'] != false) {
                    $url = $back ['url'];
                } else {
                    $url = $gzh_info['yuming'].'/Index/index.html?token='.$toUsername;
                }
                $return [0] = array (
                    'title'=>$back ['title'],
                    'discription'=>$back ['text'],
                    'picurl'=>$back ['pic'],
                    'url'=>$url
                );
                $backchild = M ( 'wx_img' )->field ( 'id,text,pic,url,title' )->limit ( 5 )->order ( 'id desc' )->where ( array ('parentid' => $back ['id'] ) )->select ();
                if ($backchild !== false) {
                    foreach ( $backchild as $keya => $infot ) {
                        if ($infot ['url'] != false) {
                            $urls = $infot ['url'];
                        } else {
                            $urls = $gzh_info['yuming'].'/Index/index.html?token='.$toUsername;
                        }
                        $return [] = array (
                            'title'=>$infot ['title'],
                            'discription'=>$infot ['text'],
                            'picurl'=>$infot ['pic'],
                            'url'=>$urls
                        );
                    }
                }
                $data = array(
                    'content'=>$return,
                    'FromUserName'=>$postObj['FromUserName'],
                    'ToUserName' =>$postObj['ToUserName']
                );
                tuwen_message($data);
            }
        }
    }
}

//关键字回复
function keyword($postObj){
    $_SESSION['gzh_token'] = $postObj['ToUserName'];
    $fromUsername = $postObj['FromUserName'];
    $toUsername   = $postObj['ToUserName'];
    $gzh_info =  M('a_media')->where(array('token'=>$toUsername))->find();
    $key_info = M('wx_rule')->where(array('keyword'=>$postObj['Content'],'gid'=>$gzh_info['id']))->find();

    if(empty($key_info)){
        $data = array(
            'ToUserName'=>$fromUsername,
            'FromUserName'=>$toUsername,
            'msgtype'=>'text',
            'content'=>'服务商没有设置该关键词内容，请与服务商联系'
        );
        text($data);
    }else{
        if($key_info['type'] == 1){
            //文本类型
            $data = array(
                'ToUserName'=>$fromUsername,
                'FromUserName'=>$toUsername,
                'msgtype'=>'text',
                'content'=>$key_info['content']
            );
            text($data);
        }elseif($key_info['type'] == 2){
            //图文类型
            $back = M('wx_img')->where(array('id'=>$key_info['imageid']))->find();
            if ($back ['url'] != false) {
                $url = $back ['url'];
            } else {
                $url = $gzh_info['yuming'].'/Index/index.html?token='.$toUsername;
            }
            $return [0] = array (
                'title'=>$back ['title'],
                'discription'=>$back ['text'],
                'picurl'=>$back ['pic'],
                'url'=>$url
            );
            $backchild = M ( 'wx_img' )->field ( 'id,text,pic,url,title' )->limit ( 5 )->order ( 'id desc' )->where ( array ('parentid' => $back ['id'] ) )->select ();
            if ($backchild !== false) {
                foreach ( $backchild as $keya => $infot ) {
                    if ($infot ['url'] != false) {
                        $urls = $infot ['url'];
                    } else {
                        $urls = $gzh_info['yuming'].'/Index/index.html?token='.$toUsername;
                    }
                    $return [] = array (
                        'title'=>$infot ['title'],
                        'discription'=>$infot ['text'],
                        'picurl'=>$infot ['pic'],
                        'url'=>$urls
                    );
                }
            }
            $data = array(
                'content'=>$return,
                'FromUserName'=>$postObj['FromUserName'],
                'ToUserName' =>$postObj['ToUserName']
            );
            tuwen_message($data);
        }elseif($key_info['type'] == 3){
            $field = "daili_wx_replay_img.*";
            $join = " left join daili_wx_replay_img on daili_wx_rule.imageid = daili_wx_replay_img.id";
            $img_info = M('wx_rule')->field($field)->where(array('daili_wx_rule.keyword'=>$postObj['Content'],'daili_wx_rule.gid'=>$gzh_info['id']))->join($join)->find();
            $data = array(
                'FromUserName'=>$postObj['ToUserName'],
                'ToUserName' =>$postObj['FromUserName'],
                'msgtype'=>'image',
                'media_id'=>$img_info['code_media_id']
            );
            img_media($data);
        }
    }
}

//点击菜单跳转链接时的事件推送
function view($postObj){

 }
/*******************下面是模板消息函数方法******************************/
//发送文本消息
function text($data){
    $time = time();
    $textTpl = "<xml>
					<ToUserName><![CDATA[%s]]></ToUserName>
					<FromUserName><![CDATA[%s]]></FromUserName>
					<CreateTime>%s</CreateTime>
					<MsgType><![CDATA[%s]]></MsgType>
					<Content><![CDATA[%s]]></Content>
					<FuncFlag>0</FuncFlag>
					</xml>";
    $msgType = "text";
    $contentStr   = $data['content'];
    $fromUsername = $data['FromUserName'];
    $toUsername   = $data['ToUserName'];
    $resultStr = sprintf($textTpl, $toUsername, $fromUsername,$time, $msgType, $contentStr);
    file_put_contents('text.txt',$resultStr);
    echo $resultStr;
}
//发送图文消息
function tuwen_message($data){
//    $data = array(
//        'content'=>array(
//            array(
//                'title'=>'test1',
//                'discription'=>'test2222222',
//                'picurl'=>'http://img.baicaibuy.cn/Uploads/ITEM_IMG/2016-10-21/5809f66c3556b_thumb.png',
//                'url'=>'http://www.baidu.com'
//            ),
//            array(
//                'title'=>'test1',
//                'discription'=>'test1',
//                'picurl'=>'http://img.baicaibuy.cn/Uploads/ITEM_IMG/2016-10-21/5809f66c3556b_thumb.png',
//                'url'=>'http://www.baidu.com'
//            ),
//            array(
//                'title'=>'test1',
//                'discription'=>'test1',
//                'picurl'=>'http://img.baicaibuy.cn/Uploads/ITEM_IMG/2016-10-21/5809f66c3556b_thumb.png',
//                'url'=>'http://www.baidu.com'
//            ),
//        ),
//        'FromUserName'=>$postObj['FromUserName'],
//        'ToUserName' =>$postObj['ToUserName']
//    );
    $list = "";
    $time=time();
    $content = $data['content'];
    $count = count($content);
    foreach ($content as $val){
        $list .= "<item>
        <Title><![CDATA[".$val['title']."]]></Title>
        <Description><![CDATA[".$val['discription']."]]></Description>
        <PicUrl><![CDATA[".$val['picurl']."]]></PicUrl>
        <Url><![CDATA[".$val['url']."]]></Url>
        </item>";
    }
    $textTpl="<xml>
        <ToUserName><![CDATA[%s]]></ToUserName>
        <FromUserName><![CDATA[%s]]></FromUserName>
        <CreateTime>%s</CreateTime>
        <MsgType><![CDATA[news]]></MsgType>
        <ArticleCount>".$count."</ArticleCount>
        <Articles>".$list."
        </Articles>
        </xml>";
    $fromUsername = $data['ToUserName'];
    $toUsername   = $data['FromUserName'];
    $resultStr = sprintf($textTpl, $toUsername, $fromUsername, $time);
    echo $resultStr;
}

////发送图片消息
function img_media($data){
    $time = time();
    $msgType = "image";
    $fromUsername = $data['FromUserName'];
    $toUsername   = $data['ToUserName'];
    $media_id     = $data['media_id'];
    $imageTpl = "<xml>
                                    <ToUserName><![CDATA[%s]]></ToUserName>
                                    <FromUserName><![CDATA[%s]]></FromUserName>
                                    <CreateTime>%s</CreateTime>
                                    <MsgType><![CDATA[%s]]></MsgType>
                                    <Image>
                                    <MediaId><![CDATA[%s]]></MediaId>
                                    </Image>
                                    </xml>";
    $resultStr = sprintf($imageTpl, $toUsername, $fromUsername, $time, $msgType, $media_id);
    echo $resultStr;
}
/************************模板消息结束************************/
//获取用户的openid
function get_openid($url,$scope){
    $code = $_GET['code'];
    $url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.C('Appid').'&redirect_uri='.$url.'&response_type=code&scope='.$scope.'&state=STATE#wechat_redirect';
    if(!$code){
        redirect($url);
    }
    $url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid='.C('Appid').'&secret='.C('Appsecret').'&code='.$code.'&grant_type=authorization_code';
    //return $url;
    $res = file_get_contents($url);
    $res = json_decode($res);
    $openid=$res->openid;
    return $openid;
}
//关注后直接获取用户信息
function get_userinfo($openid,$access_token){
    $url ='https://api.weixin.qq.com/cgi-bin/user/info?access_token='.$access_token.'&openid='.$openid.'&lang=zh_CN';
    $res = file_get_contents($url);
    $res = json_decode($res,true);
    return $res;
}
//curl_post调用微信接口
function curl_post($post_data,$url){
    $post_data = json_encode($post_data,JSON_UNESCAPED_UNICODE);
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($curl);
    curl_close($curl);
    $output = json_decode($output,true);
    return $output;
}
//curl_get调用接口
function curl_get($url){
    //初始化
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    $output = curl_exec($ch);
    curl_close($ch);
    $output = json_decode($output,true);
    return $output;
}

function http_get_data($url) {

    $ch = curl_init ();
    curl_setopt ( $ch, CURLOPT_CUSTOMREQUEST, 'GET' );
    curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, false );
    curl_setopt ( $ch, CURLOPT_URL, $url );
    ob_start ();
    curl_exec ( $ch );
    $return_content = ob_get_contents ();
    ob_end_clean ();

    $return_code = curl_getinfo ( $ch, CURLINFO_HTTP_CODE );
    return $return_content;
}

function https_request($url, $data = null)
{
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SAFE_UPLOAD, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
    if (!empty($data)){
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

    }
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($curl);
    curl_close($curl);
    return $output;
}

//生成带参二维码
function set_qrcode($access_token,$pid){
    $post_data = array(
        'action_name'=>'QR_LIMIT_SCENE',
        'action_info'=>array(
            'scene'=>array(
                'scene_id'=>$pid
            ),
        )
    );
    $url="https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=%s";
    $res = curl_post( $post_data,sprintf($url, $access_token));
//    file_put_contents('test.txt',$res);
    return $res;
}

//合成图片
function set_pic($postObj){
    //查询公众号appid等信息
    $gzh = M('a_media')->where(array('token'=>$postObj['ToUserName']))->find();
    //查询用户信息
    $user_info = M('wx_user')->where(array('OpenID'=>$postObj['FromUserName']))->find();
    //用户关注后
    //验证当前用户是否已经生产专属海报
    $hb = M('qrcode')->where(array('pid'=>$user_info['id']))->find();
    $access_token = access_token($postObj['ToUserName']);
//    $data = array(
//        'FromUserName'=>$postObj['ToUserName'],
//        'ToUserName' =>$postObj['FromUserName'],
//        'msgtype'=>'text',
//        'content'=>$access_token
//    );
//    text($data);
//    exit;
//    if(empty($hb['ticket'])){
//    if(!file_exists("./Uploads/".$postObj['ToUserName']."/poster/qrcode/Now/poster_".$user_info['id'].".jpg") || empty($hb['code_media_id'])){
    if(!file_exists("./Uploads/haibao_qrcode/haibao/".$user_info['id'].".png") || empty($hb['code_media_id'])){
        //海报没有生成，则生成海报，上传素材到媒体库
        $infos =  M('qrcode')->where(array('pid'=>$user_info['id']))->find();
        if(empty($infos['ticket'])){
            $qrcode = set_qrcode($access_token,$user_info['id']);
            M('qrcode')->add(array(
                'pid'=>$user_info['id'],
                'qrcode_time'=>time(),
                'ticket'=>$qrcode['ticket'],
                'qrcode_url'=>$qrcode['url']
            ));
        }

        //保存二维码
        $url = "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=".$qrcode['ticket'];
        $res = file_get_contents($url);
        $imgDir = str_replace('\\','/',getcwd()).'/Uploads/haibao_qrcode/qrcode/';
        //要生成的图片名字
        $filename = $user_info['id'].".png"; //新图片名称
        $newFilePath = $imgDir.$filename;
        $data = $res;
        $newFile = fopen($newFilePath,"w"); //打开文件准备写入
        fwrite($newFile,$data); //写入二进制流到文件
        fclose($newFile); //关闭文件



        //保存头像
//        $ress = file_get_contents($user_info['headerpic']);
//        $imgDirs = str_replace('\\','/',getcwd()).'/Uploads/haibao_qrcode/headpic/';
//        //要生成的图片名字
//        $filenames = $user_info['id'].".png"; //新图片名称
//        $newFilePaths = $imgDirs.$filenames;
//        $datas = $ress;
//        $newFiles = fopen($newFilePaths,"w"); //打开文件准备写入
//        fwrite($newFiles,$datas); //写入二进制流到文件
//        fclose($newFiles); //关闭文件

        $qrcode_url = "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=".$qrcode['ticket'];
        set_pic_src(str_replace('\\','/',getcwd())."/Uploads/haibao_qrcode/headpic/".$user_info['id'].".png"
                ,$user_info['nickname'],str_replace('\\','/',getcwd())."/Uploads/haibao_qrcode/qrcode/".$user_info['id'].".png",$user_info['id']);
//        $data = array(
//            'FromUserName'=>$postObj['ToUserName'],
//            'ToUserName' =>$postObj['FromUserName'],
//            'msgtype'=>'text',
//            'content'=>$user_info['headerpic']
//        );
//        text($data);
//        exit;

        //验证是否存在当前公众号token文件夹
//        if (!file_exists('./Uploads/'.$postObj['ToUserName'])){
//            mkdir ('./Uploads/'.$postObj['ToUserName'],0777,true);
//            mkdir ('./Uploads/'.$postObj['ToUserName'].'/poster',0777,true);
//            mkdir ('./Uploads/'.$postObj['ToUserName'].'/poster/headpic',0777,true);
//            mkdir ('./Uploads/'.$postObj['ToUserName'].'/poster/qrcode',0777,true);
//            mkdir ('./Uploads/'.$postObj['ToUserName'].'/poster/qrcode/Now',0777,true);
//            mkdir ('./Uploads/'.$postObj['ToUserName'].'/poster/qrcode/Original',0777,true);
//        }
//        //获取用户头像
//        file_put_contents('./Uploads/'.$postObj['ToUserName'].'/poster/headpic/headpic_'.$user_info['id'].'.jpg',
//            http_get_data($user_info['headerpic']));
//        //重新定义图片大小
//        resizejpg('./Uploads/'.$postObj['ToUserName'].'/poster/headpic/headpic_'.$user_info['id'].'.jpg','',82,
//            82,'./Uploads/'.$postObj['ToUserName'].'/poster/headpic/headpic_'.$user_info['id'].'.jpg');
//        //获取带参二维码图
//        $ticket = urlencode($qrcode['ticket']);
//        $url = "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=".$ticket;
//        file_put_contents('./Uploads/'.$postObj['ToUserName'].'/poster/qrcode/Original/qrcode_'.$user_info['id'].'.jpg',
//            http_get_data($url));
//        sleep(4);
//        //重新定义图片大小
//        resizejpg('./Uploads/'.$postObj['ToUserName'].'/poster/qrcode/Original/qrcode_'.$user_info['id'].'.jpg','',172,
//            172,'./Uploads/'.$postObj['ToUserName'].'/poster/qrcode/Original/qrcode_'.$user_info['id'].'.jpg');
//        //复制海报背景用于合成
//        copy("./Uploads/bg.jpg","./Uploads/".$postObj['ToUserName']."/poster/qrcode/Now/poster_".$user_info['id'].".jpg");
//        if(!file_exists("./Uploads/".$postObj['ToUserName']."/poster/qrcode/Now/poster_".$user_info['id'].".jpg")){
//            copy("./Uploads/bg.jpg","./Uploads/".$postObj['ToUserName']."/poster/qrcode/Now/poster_".$user_info['id'].".jpg");
//        }
//        import('Org.Images.Images');
//        $img = new \Images();
//        //背景图与头像合成
//        $img-> imageWaterMark("./Uploads/".$postObj['ToUserName']."/poster/qrcode/Now/poster_".$user_info['id'].".jpg",
//            10,'./Uploads/'.$postObj['ToUserName'].'/poster/headpic/headpic_'.$user_info['id'].'.jpg',
//            "","","",640,406);
//        //上图与带参二维码合成
//        $img-> imageWaterMark("./Uploads/".$postObj['ToUserName']."/poster/qrcode/Now/poster_".$user_info['id'].".jpg",
//            10,'./Uploads/'.$postObj['ToUserName'].'/poster/qrcode/Original/qrcode_'.$user_info['id'].'.jpg',
//            "","","",262,352);
//        //上图与微信昵称合成
////        $user_info['nickname'] = iconv("gb2312","utf-8",$user_info['nickname']);
//        $img-> imageWaterMark("./Uploads/".$postObj['ToUserName']."/poster/qrcode/Now/poster_".$user_info['id'].".jpg",
//            8,"",$user_info['nickname'],5);
//        sleep(2);
        //图片上传到微信服务器（仅保存3天）
        //上传图片
        $type = "image";
        //windows服务器下的路径
//        $filepath = dirname(dirname(dirname(dirname(dirname(__FILE__)))))."\\DailiSystem\\Uploads\\"
//            .$postObj['ToUserName']."\\poster\\qrcode\\Now\\poster_".$user_info['id'].".jpg";
//        $filepath = "D:\\xampp\\htdocs\\DailiSystem\\Uploads\\"
//            .$postObj['ToUserName']."\\poster\\qrcode\\Now\\poster_".$user_info['id'].".jpg";
//        $filepath = "E:\\xampp\\htdocs\\DailiSystem\\Uploads\\haibao_qrcode\\haibao\\".$user_info['id'].".png";
        $filepath = dirname(dirname(dirname(dirname(dirname(__FILE__)))))."\\DailiSystem\\Uploads\\haibao_qrcode\\haibao\\".$user_info['id'].".png";
        $filedata = array("media"  => "@".$filepath);
        $url = "http://file.api.weixin.qq.com/cgi-bin/media/upload?access_token=$access_token&type=$type";
        $result = https_request($url,$filedata);
        $result = json_decode($result,1);
        $data['code_media_id'] = $result['media_id'];
        $data['media_id_time'] = $result['created_at'];
        //存储media_id到数据库，用于调用微信素材库
        M('qrcode')->where(array('pid'=>$user_info['id']))->save(array(
//            'zs_qrcode_url'=>dirname(dirname(dirname(dirname(dirname(__FILE__)))))."\\DailiSystem\\Uploads\\"
//                .$postObj['ToUserName']."\\poster\\qrcode\\Now\\poster_".$user_info['id'].".jpg",
//            'zs_qrcode_url'=>"E:\\xampp\\htdocs\\DailiSystem\\Uploads\\haibao_qrcode\\haibao\\".$user_info['id'].".png",
            'zs_qrcode_url'=>dirname(dirname(dirname(dirname(dirname(__FILE__)))))."\\DailiSystem\\Uploads\\haibao_qrcode\\haibao\\".$user_info['id'].".png",
            'code_media_id'=>$result['media_id'],
            'media_id_time'=>$result['created_at']
        ));
    }else{
        if((time()-$hb['media_id_time'])>216000){
            //图片上传到微信服务器（仅保存3天）
            //上传图片
            $type = "image";
            //windows服务器下的路径
            $pic_url = M('qrcode')->where(array('pid'=>$user_info['id']))->getField('zs_qrcode_url');
            $filepath = $pic_url;
            $filedata = array("media"  => "@".$filepath);
            $url = "http://file.api.weixin.qq.com/cgi-bin/media/upload?access_token=$access_token&type=$type";
            $result = https_request($url,$filedata);
            $result = json_decode($result,1);
            $data['code_media_id'] = $result['media_id'];
            $data['media_id_time'] = $result['created_at'];
            //存储media_id到数据库，用于调用微信素材库
            M('qrcode')->where(array('pid'=>$user_info['id']))->save(array(
                'code_media_id'=>$result['media_id'],
                'media_id_time'=>$result['created_at']
            ));
        }
    }
    $media = M('qrcode')->where(array('pid'=>$user_info['id']))->find();
    $data = array(
        'FromUserName'=>$postObj['ToUserName'],
        'ToUserName' =>$postObj['FromUserName'],
        'msgtype'=>'image',
        'media_id'=>$media['code_media_id']
    );
    img_media($data);
}
function set_pic_src($pic,$nickname,$qrcode_url,$uid){
    $im = imagecreatetruecolor(400, 700);
    $bg = imagecolorallocate($im, 255, 255, 255); //设置画布的背景为白色
    imagefill($im, 0, 0, $bg);
    $src_path = str_replace('\\','/',getcwd()).'/Uploads/bg.jpg';
    $src = imagecreatefromstring(file_get_contents($src_path));
    list($src_w, $src_h) = getimagesize($src_path);//获取水印图片高度
    imagecopyresampled($im,$src,0,0,0,0,400,700,$src_w,$src_h);

    $src = imagecreatefromstring(file_get_contents($pic));
    //list($src_w, $src_h) = getimagesize($pic);//获取水印图片高度
    imagecopyresampled($im,$src,61,489,0,0,40,40,750,728);

    $src = imagecreatefromstring(file_get_contents($qrcode_url));
    //list($src_w, $src_h) = getimagesize($qrcode_url);//获取水印图片高度
    imagecopyresampled($im,$src,265,520,0,0,82,82,430,430);

    $font = str_replace('\\','/',getcwd()).'/Arial.ttf';
    $black = imagecolorallocate($im, 255, 0, 0); //设置一个颜色变量为黑色
    imageTtfText($im, 10, 0 , 150, 515, $black,$font,$nickname); //水平的将字符串输出到图像中
    header('Content-type:image/png');
    $filename=$uid.'.png';
    $res = imagepng($im,str_replace('\\','/',getcwd()).'/Uploads/haibao_qrcode/haibao/'.$filename);
    imagedestroy($im);
}
//修改图片尺寸
function resizejpg($imgsrc,$imgdst,$imgwidth,$imgheight,$filename)
{
//$imgsrc jpg格式图像路径 $imgdst jpg格式图像保存文件名 $imgwidth要改变的宽度 $imgheight要改变的高度
//取得图片的宽度,高度值
    $arr = getimagesize($imgsrc);
    $imgWidth = $imgwidth;
    $imgHeight = $imgheight;
// Create image and define colors
    $imgsrc = imagecreatefromjpeg($imgsrc);
    $image = imagecreatetruecolor($imgWidth, $imgHeight); //创建一个彩色的底图
    imagecopyresampled($image, $imgsrc, 0, 0, 0, 0,$imgWidth,$imgHeight,$arr[0], $arr[1]);
    imagepng($image,$filename);
    imagedestroy($image);
}
/**
 * 调用淘宝接口搜索商品
 * */
function search($key,$page,$pid){
    Vendor(C('Vendor_file'));
    $c = new \TopClient;
    $c->appkey = C('TB_appid');//优惠乐园3294401375@qq.com账号的淘宝开放平台
    $c->secretKey = C('TB_appsecret');
    $req = new \TbkItemCouponGetRequest;
    $req->setPlatform("2");
    $req->setPageSize("100");
    $req->setQ("$key");
    $req->setPageNo("$page");
//    $req->setPid(C('PID_WX'));
    $req->setPid($pid);
    $resp = $c->execute($req);
    $resp = json_encode($resp);
    $resp = json_decode($resp,true);
    return $resp;
}

/**
 * 调用淘宝接口获取拉新的用户
 * */
function get_new_tb_user($page,$adid,$mediaid,$sessionKey){
    Vendor(C('Vendor_file_20180207'));
    $c = new \TopClient;
    $c->appkey = C('TB_appid');//优惠乐园3294401375@qq.com账号的淘宝开放平台
    $c->secretKey = C('TB_appsecret');
    $req = new \TbkScNewuserOrderGetRequest;
    $req->setPageSize("100");
    $req->setAdzoneId($adid);
    $req->setPageNo("$page");
    $req->setSiteId($mediaid);
    $resp = $c->execute($req, $sessionKey);
    $resp = json_encode($resp);
    $resp = json_decode($resp,true);
    return $resp;
}


/**
 * 根据商品ID查询商品信息
 * */
//根据商品id查询淘宝商品的图片
function get_item_infos($item_id,$type=NULL){
    Vendor(C('Vendor_file_new'));
    $c = new \TopClient;
    $c->appkey = C('TB_appid_new');//优惠乐园3294401375@qq.com账号的淘宝开放平台
    $c->secretKey = C('TB_appsecret_new');
    $req = new \TbkItemInfoGetRequest;
    if($type){
        $req->setFields("num_iid,title,pict_url,small_images,reserve_price,zk_final_price,user_type,provcity,item_url,seller_id,volume,nick");
    }else{
        $req->setFields("num_iid,title,pict_url,small_images,item_url");
    }
    $req->setPlatform("1");
    $req->setNumIids($item_id);
    $resp = $c->execute($req);
    $resp = obj_to_arr($resp);
    $resp = $resp['results'];
    if($resp){
        $resp = $resp['n_tbk_item'];
        $res  = $resp;
    }else{
        $res  = '';
    }
    return $res;
}


//每天定时通过接口获取公众号关注用户，更新数据库
function get_gz_user($token){
    set_time_limit(0);
    $access_token = access_token($token);
    echo $access_token;
    echo '<hr>';
    $result[0] = get_openid_list($access_token);
    echo '<pre>';
    print_r($result);
    exit;
    //更新获取到的openid到数据库
    foreach($result[0]['data']['openid'] as $val){
        $info = M('wx_user')->where(array('OpenID'=>$val,'GzhToken'=>$token))->find();
        $user_info = get_userinfo($val,$access_token);
        $m_id =  M('a_media')->where(array('token'=>$token))->getField('id');
        if(empty($info)){
            $data = array(
                'OpenID'=>$val,
                'GzhToken' =>$token,
                'IsSubscribe'=>1,
                'HeaderPic'=>$user_info['headimgurl'],
                'NickName'=>$user_info['nickname'],
                'Address'=>$user_info['country']."-".$user_info['province']."-".$user_info['city'],
                'MediaTableID'=>$m_id,
                'SubscribeTime'=>$user_info['subscribe_time']
            );
            $res = M('wx_user')->add($data);

            echo '<pre>';
            $data['img']='<img src="'.$user_info['headimgurl'].'">';
            print_r($data);
        }else{
            $res = M('wx_user')->where(array('OpenID'=>$val,'GzhToken'=>$token))->save(array('IsSubscribe'=>1,'SubscribeTime'=>$user_info['subscribe_time']));
        }
    }
    //验证是否要多次调取接口
    $page = ceil($result[0]['total']/$result[0]['count']);
    if($page>1){
        for($i=0;$i<$page;$i++){
            $result[$i+1] = get_openid_list($access_token,$result[$i]['next_openid']);
            foreach($result[$i+1]['data']['openid'] as $val[$i+1]){
                $info = M('wx_user')->where(array('OpenID'=>$val[$i+1],'GzhToken'=>$token))->find();
                $user_infos = get_userinfo($val[$i+1],$access_token);
                if(empty($info)){
                    $datas = array(
                        'OpenID'=>$val[$i+1],
                        'GzhToken' =>$token,
                        'IsSubscribe'=>1,
                        'HeaderPic'=>$user_infos['headimgurl'],
                        'NickName'=>$user_infos['nickname'],
                        'Address'=>$user_infos['country']."-".$user_infos['province']."-".$user_infos['city'],
                        'MediaTableID'=>$m_id
                    );
                    $res = M('wx_user')->add($datas);
                }else{
                    $res = M('wx_user')->where(array('OpenID'=>$val[$i+1],'GzhToken'=>$token))->save(array('IsSubscribe'=>1));
                }
            }
        }
    }
    $re = "执行完毕";
    return $re;
}

//获取openid列表
function get_openid_list($access_token,$next_openid){
    $openid_url = "https://api.weixin.qq.com/cgi-bin/user/get?access_token=%s&next_openid=%s";
    $jsonResult = vget(sprintf($openid_url, trim($access_token), trim($next_openid)));
    $result = json_decode($jsonResult,true);
    return $result;
}

function vget($url)
{
    // 模拟提交数据函数
    $curl = curl_init(); // 启动一个CURL会话
    curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE); // 对认证证书来源的检查
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE); // 从证书中检查SSL加密算法是否存在
    curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)'); // 模拟用户使用的浏览器
    // curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
    // curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
    curl_setopt($curl, CURLOPT_POST, 0); // 发送一个常规的Post请求
    curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环
    curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回
    $tmpInfo = curl_exec($curl); // 执行操作
    if (curl_errno($curl))
    {
        echo 'Errno'.curl_error($curl);//捕抓异常
    }
    curl_close($curl); // 关闭CURL会话
    return $tmpInfo; // 返回数据
}


function set_myshop_img($postObj){
    //查询公众号appid等信息
    $gzh = M('a_media')->where(array('token' => $postObj['ToUserName']))->find();
    //查询用户信息
    $user_info = M('wx_user')->where(array('OpenID' => $postObj['FromUserName']))->find();
    //用户关注后
    //验证当前用户是否已经生产专属分享链接图片
    $hb = M('myshop_img')->where(array('token' => $postObj['ToUserName'], 'openid' => $postObj['FromUserName']))->find();
    $access_token = access_token($postObj['ToUserName']);
    if (empty($hb)) {
        //验证是否存在当前公众号token文件夹
        if (!file_exists('./Uploads/' . $postObj['ToUserName'])) {
            mkdir('./Uploads/' . $postObj['ToUserName'], 0777, true);
            mkdir('./Uploads/' . $postObj['ToUserName'] . '/poster', 0777, true);
            mkdir('./Uploads/' . $postObj['ToUserName'] . '/poster/headpic', 0777, true);
            mkdir('./Uploads/' . $postObj['ToUserName'] . '/poster/qrcode', 0777, true);
            mkdir('./Uploads/' . $postObj['ToUserName'] . '/poster/qrcode/Now', 0777, true);
            mkdir('./Uploads/' . $postObj['ToUserName'] . '/poster/qrcode/Original', 0777, true);
        }
        //验证是否存在当前公众号token文件夹下的myshop_img文件夹
        if (!file_exists('./Uploads/' . $postObj['ToUserName'] . '/myshop_img')) {
            mkdir('./Uploads/' . $postObj['ToUserName'] . '/myshop_img', 0777, true);
            mkdir('./Uploads/' . $postObj['ToUserName'] . '/myshop_img/headpic', 0777, true);
            mkdir('./Uploads/' . $postObj['ToUserName'] . '/myshop_img/qrcode_img', 0777, true);
            mkdir('./Uploads/' . $postObj['ToUserName'] . '/myshop_img/my_img', 0777, true);
        }

        //获取用户头像
        file_put_contents('./Uploads/' . $postObj['ToUserName'] . '/myshop_img/headpic/headpic_' . $user_info['id'] . '.jpg',
            http_get_data($user_info['headerpic']));
        //重新定义图片大小
        resizejpg('./Uploads/' . $postObj['ToUserName'] . '/myshop_img/headpic/headpic_' . $user_info['id'] . '.jpg', '', 82,
            82, './Uploads/' . $postObj['ToUserName'] . '/myshop_img/headpic/headpic_' . $user_info['id'] . '.jpg');

        //复制背景用于合成
        copy("./Uploads/my_shop_bg.jpg", "./Uploads/" . $postObj['ToUserName'] . "/myshop_img/my_img/" . $postObj['FromUserName'] . "_myshop.jpg");

        import('Org.Images.Images');
        $img = new \Images();
        //通过百度二维码接口生成二维码
        $qr_data = $gzh['yuming'] . "/index/fx_index?token=" . $postObj['ToUserName'] . "&openid=" . $postObj['FromUserName']."&tz=true";
        file_put_contents('./Uploads/' . $postObj['ToUserName'] . '/myshop_img/qrcode_img/' . $postObj['FromUserName'] . '.jpg',
            http_get_data("http://pan.baidu.com/share/qrcode?w=175&h=175&url=" . urlencode($qr_data)));

        //背景图与二维码合成
        $img->imageWaterMark("./Uploads/" . $postObj['ToUserName'] . "/myshop_img/my_img/" . $postObj['FromUserName'] . "_myshop.jpg",
            10, './Uploads/' . $postObj['ToUserName'] . '/myshop_img/qrcode_img/' . $postObj['FromUserName'] . '.jpg',
            "", "", "", 270, 355);

        //背景图与头像合成
//        $img->imageWaterMark("./Uploads/" . $postObj['ToUserName'] . "/myshop_img/my_img/" . $postObj['FromUserName'] . "_myshop.jpg",
//            10, './Uploads/' . $postObj['ToUserName'] . '/myshop_img/headpic/headpic_' . $user_info['id'] . '.jpg',
//            "", "", "", 665, 406);
        //上图与微信昵称合成
        $img->imageWaterMark("./Uploads/" . $postObj['ToUserName'] . "/myshop_img/my_img/" . $postObj['FromUserName'] . "_myshop.jpg",
            8, "", $user_info['nickname'], 5);

        //图片上传到微信服务器（仅保存3天）
        //上传图片
        $type = "image";
        //windows服务器下的路径
        $filepath = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "\\DailiSystem\\Uploads\\"
            . $postObj['ToUserName'] . "\\myshop_img\\my_img\\" . $postObj['FromUserName'] . "_myshop.jpg";
        $filedata = array("media" => "@" . $filepath);
        $url = "http://file.api.weixin.qq.com/cgi-bin/media/upload?access_token=$access_token&type=$type";
        $result = https_request($url, $filedata);
        $result = json_decode($result, 1);echo $filepath; var_dump($result);
        $data['code_media_id'] = $result['media_id'];
        $data['media_id_time'] = $result['created_at'];
        if(!empty($data['code_media_id'])){
            //存储media_id到数据库，用于调用微信素材库
            M('myshop_img')->add(array(
                'url' => dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "\\DailiSystem\\Uploads\\"
                    . $postObj['ToUserName'] . "\\myshop_img\\my_img\\" . $postObj['FromUserName'] . "_myshop.jpg",
                'code_media_id' => $result['media_id'],
                'media_id_time' => $result['created_at'],
                'add_time' => time(),
                'token' => $postObj['ToUserName'],
                'openid' => $postObj['FromUserName']
            ));
        }

    } else {
        if ((time() - $hb['media_id_time']) > 216000) {
            //图片上传到微信服务器（仅保存3天）
            //上传图片
            $type = "image";
            //windows服务器下的路径
            $pic_url = M('myshop_img')->where(array('openid' => $postObj['FromUserName'], 'token' => $postObj['ToUserName']))->getField('url');
            $filepath = $pic_url;
            $filedata = array("media" => "@" . $filepath);
            $url = "http://file.api.weixin.qq.com/cgi-bin/media/upload?access_token=$access_token&type=$type";
            $result = https_request($url, $filedata);
            $result = json_decode($result, 1);
            $data['code_media_id'] = $result['media_id'];
            $data['media_id_time'] = $result['created_at'];
            if(!empty($data['code_media_id'])){
                //存储media_id到数据库，用于调用微信素材库
                M('myshop_img')->where(array('openid' => $postObj['FromUserName'], 'token' => $postObj['ToUserName']))->save(array(
                    'code_media_id' => $result['media_id'],
                    'media_id_time' => $result['created_at']
                ));
            }
        }
    }


    $media = M('myshop_img')->where(array('openid'=>$postObj['FromUserName'],'token'=>$postObj['ToUserName']))->find();
    $data = array(
        'FromUserName'=>$postObj['ToUserName'],
        'ToUserName' =>$postObj['FromUserName'],
        'msgtype'=>'image',
        'media_id'=>$media['code_media_id']
    );
    img_media($data);

}

function download_img($openid,$numid,$img_url,$qr_data){
    //验证是否存在当前公众号token文件夹
    if (!file_exists('./Uploads/'.$_SESSION['gzh_token'])){
        mkdir ('./Uploads/'.$_SESSION['gzh_token'],0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/poster',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/poster/headpic',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/poster/qrcode',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/poster/qrcode/Now',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/poster/qrcode/Original',0777,true);
    }
    //验证是否存在当前公众号token文件夹下的shop_img文件夹
    if (!file_exists('./Uploads/'.$_SESSION['gzh_token'].'/shop_img')){
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/shop_img',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/tb_img',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/qrcode_img',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/shopimg',0777,true);
    }

    //获取商品图片
    file_put_contents('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/tb_img/'.$openid.'_'.$numid.'.jpg',
        http_get_data($img_url));
    //重新定义图片大小
    resizejpg('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/tb_img/'.$openid.'_'.$numid.'.jpg','',400,
        400,'./Uploads/'.$_SESSION['gzh_token'].'/shop_img/tb_img/'.$openid.'_'.$numid.'.jpg');
    //通过百度二维码接口生成二维码
    file_put_contents('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/qrcode_img/'.$openid.'_'.$numid.'.jpg',
        http_get_data("http://pan.baidu.com/share/qrcode?w=120&h=120&url=".$qr_data));

    if(file_exists('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/tb_img/'.$openid.'_'.$numid.'.jpg') && file_exists('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/qrcode_img/'.$openid.'_'.$numid.'.jpg')){
        return true;
    }

}

function set_shop_img($numid,$img_url,$openid,$shop_title,$qr_data,$price,$coupon_price,$yhq){

    //验证是否存在当前公众号token文件夹
    if (!file_exists('./Uploads/'.$_SESSION['gzh_token'])){
        mkdir ('./Uploads/'.$_SESSION['gzh_token'],0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/poster',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/poster/headpic',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/poster/qrcode',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/poster/qrcode/Now',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/poster/qrcode/Original',0777,true);
    }
    //验证是否存在当前公众号token文件夹下的shop_img文件夹
    if (!file_exists('./Uploads/'.$_SESSION['gzh_token'].'/shop_img')){
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/shop_img',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/tb_img',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/qrcode_img',0777,true);
        mkdir ('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/shopimg',0777,true);
    }
    //获取商品图片
    file_put_contents('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/tb_img/'.$openid.'_'.$numid.'.jpg',
        http_get_data($img_url));
    //重新定义图片大小
    resizejpg('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/tb_img/'.$openid.'_'.$numid.'.jpg','',400,
        400,'./Uploads/'.$_SESSION['gzh_token'].'/shop_img/tb_img/'.$openid.'_'.$numid.'.jpg');
    //复制商品图背景用于合成
    copy("./Uploads/shop_img_bg.jpg","./Uploads/".$_SESSION['gzh_token']."/shop_img/shopimg/".$openid.'_'.$numid.".jpg");
    import('Org.Images.Images');
    $img = new \Images();

    //背景图与商品图合成
    $img-> imageWaterMark("./Uploads/".$_SESSION['gzh_token']."/shop_img/shopimg/".$openid.'_'.$numid.".jpg",
        10,'./Uploads/'.$_SESSION['gzh_token'].'/shop_img/tb_img/'.$openid.'_'.$numid.'.jpg',
        "","","",400,590);

    //通过百度二维码接口生成二维码
    file_put_contents('./Uploads/'.$_SESSION['gzh_token'].'/shop_img/qrcode_img/'.$openid.'_'.$numid.'.jpg',
        http_get_data("http://pan.baidu.com/share/qrcode?w=120&h=120&url=".$qr_data));

    //上图与二维码合成
    $img-> imageWaterMark("./Uploads/".$_SESSION['gzh_token']."/shop_img/shopimg/".$openid.'_'.$numid.".jpg",
        10,'./Uploads/'.$_SESSION['gzh_token'].'/shop_img/qrcode_img/'.$openid.'_'.$numid.'.jpg',
        "","","",155,158);

//        $user_info['nickname'] = iconv("gb2312","utf-8",$user_info['nickname']);
    //上图与商品券后价合成
    $img-> imageWaterMark("./Uploads/".$_SESSION['gzh_token']."/shop_img/shopimg/".$openid.'_'.$numid.".jpg",
        8,"",$coupon_price,5,'#FF0000','','',22,140,562,'orange');
    //上图与商品优惠券合成
    $img-> imageWaterMark("./Uploads/".$_SESSION['gzh_token']."/shop_img/shopimg/".$openid.'_'.$numid.".jpg",
        8,"",$yhq,5,'#FF0000','','',12,31,559,'orange');
    //上图与商品现价合成
    $img-> imageWaterMark("./Uploads/".$_SESSION['gzh_token']."/shop_img/shopimg/".$openid.'_'.$numid.".jpg",
        8,"",$price,5,'','','',11,65,520,'gray');

    //计算标题长度
    preg_match_all("/./u", $shop_title, $matches);
    $len =  count(current($matches));
    $j = 0;
    $g = 0;
    $z = 0;
    for($i=0;$i<$len;$i++){
        if($i<11){
            $str = mb_substr($shop_title,$i,1,'utf-8');
            $img-> imageWaterMark("./Uploads/".$_SESSION['gzh_token']."/shop_img/shopimg/".$openid.'_'.$numid.".jpg",
                8,"",$str,5,'','','',12,(42+$i*15),429,'black',"./simhei.ttf");
        }elseif($i>=11 && $i<24){
            $str = mb_substr($shop_title,$i,1,'utf-8');
            $img-> imageWaterMark("./Uploads/".$_SESSION['gzh_token']."/shop_img/shopimg/".$openid.'_'.$numid.".jpg",
                8,"",$str,5,'','','',12,(10+$j*15),450,'black',"./simhei.ttf");
            $j++;
        }elseif($i>=24 && $i<37){
            $str = mb_substr($shop_title,$i,1,'utf-8');
            $img-> imageWaterMark("./Uploads/".$_SESSION['gzh_token']."/shop_img/shopimg/".$openid.'_'.$numid.".jpg",
                8,"",$str,5,'','','',12,(10+$g*15),471,'black',"./simhei.ttf");
            $g++;
        }elseif($i>=37 && $i<+50){
            $str = mb_substr($shop_title,$i,1,'utf-8');
            $img-> imageWaterMark("./Uploads/".$_SESSION['gzh_token']."/shop_img/shopimg/".$openid.'_'.$numid.".jpg",
                8,"",$str,5,'','','',12,(10+$z*15),492,'black',"./simhei.ttf");
            $z++;
        }
    }
    $set_img_url = "/Uploads/".$_SESSION['gzh_token']."/shop_img/shopimg/".$openid.'_'.$numid.".jpg";
    return $set_img_url;
}
//生成淘口令
function taokouling_new($data){
    Vendor(C('Vendor_file_new'));
    $c = new \TopClient;
    $c->appkey = C('TB_appid_new');//lost_ding账号的淘宝开放平台
    $c->secretKey = C('TB_appsecret_new');
    $req = new \TbkTpwdCreateRequest;
    $req->setText($data['title']);
    $req->setUrl($data['url']);
    $req->setLogo($data['logo']);
    $resp = $c->execute($req);
    $resp = obj_to_arr(json_decode(json_encode($resp)));
    //return $resp;
    $resp = $resp['data']['model'];
    return $resp;
}

//记录替换pid信息日志
function add_pid_log($uid,$aimama_id,$num_id,$first_url,$last_url,$from,$token,$openid,$url,$commission,$shop_info){
    $arr = array(
        'pid'=>$aimama_id,
        'num_id'=>$num_id,
        'first_url'=>$first_url,
        'last_url'=>$last_url,
        'from_action'=>$from,
        'token'=>$token,
        'openid'=>$openid,
        'url'=>$url,
        'commission'=>$commission,
        'shop_info'=>$shop_info
    );
    $res = M('pid_log')->add(
        array(
            'uid'=>$uid,
            'add_time'=>time(),
            'openid'=>$openid,
            'log_info'=>json_encode($arr)
        )
    );
    return $res;
}

//记录访问详情页的各个参数值
function add_details_parameter_log($function,$openid,$token,$url,$num_id,$info,$error){
    $arr = array(
        'function'=>$function,
        'openid'=>$openid,
        'token'=>$token,
        'url'=>$url,
        'numid'=>$num_id,
        'time'=>date('Y-m-d H:i:s',time()),
        'error_title'=>$info,
        'error'=>$error
    );
    $data = array(
        'info'=>json_encode($arr),
        'add_time'=>time(),
        'openid'=>$openid,
        'token'=>$token
    );
    M('a_details_error_log')->add($data);
}

/**获取Unix毫秒时间戳
 * @return float Unix毫秒时间戳
 */
function msectime()
{
    list($msec, $sec) = explode(' ', microtime());
    return (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
}

//从淘宝联盟获取商品
function alimama_shopinfo($key="",$page=1,$queryType="",$sortType="",$shopTag = ""){
    $time = msectime();
    $auctionTag = "";
    $pagesize = 50;
//    $shopTag = "dpyhq";
    $t = msectime()+rand(100000,999999);
    $url = "http://pub.alimama.com/items/search.json?q=%s&_t=%s&toPage=%s&queryType=%s&sortType=%s&auctionTag=%s&perPageSize=%s&shopTag=%s&t=%s";
    $res = vget(sprintf($url,urlencode($key),trim($time),trim($page),
        trim($queryType),trim($sortType),trim($auctionTag),trim($pagesize),trim($shopTag),trim($t)));
    $ress = json_decode($res,true);
    return $ress['data']['pageList'];
}
// php获取当前访问的完整url地址
function GetCurUrl() {
    $url = 'http://';
    if (isset ( $_SERVER ['HTTPS'] ) && $_SERVER ['HTTPS'] == 'on') {
        $url = 'https://';
    }
    if ($_SERVER ['SERVER_PORT'] != '80') {
        $url .= $_SERVER ['HTTP_HOST'] . ':' . $_SERVER ['SERVER_PORT'] . $_SERVER ['REQUEST_URI'];
    } else {
        $url .= $_SERVER ['HTTP_HOST'] . $_SERVER ['REQUEST_URI'];
    }
    // 兼容后面的参数组装
    if (stripos ( $url, '?' ) === false) {
        $url .= '?t=' . time ();
    }
    return $url;
}
//微信授权
function OAuthWeixin($callback,$token) {
    //根据token获取公众号信息
    $info1 = M('a_media')->where(array('token'=>$token))->find();
    $info2 = M('z_kefu_gzh')->where(array('token'=>$token))->find();
    if($info1){
        $info = $info1;
    }
    if($info2){
        $info = $info2;
    }
    $appid     = $info['appid'];
    $appsecret = $info['appsecret'];
    if(isset($_GET['code'])){
        $code=$_GET['code'];
        $url2 ="https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$appid."&secret=".$appsecret."&code=".$code."&grant_type=authorization_code";
        $res = file_get_contents($url2);
        AddwxLog($token.'----'.$res,$token.'微信获取openid');
        $res = json_decode($res);
        return $res;
    }else{
        $url1="https://open.weixin.qq.com/connect/oauth2/authorize?appid=$appid&redirect_uri=$callback&response_type=code&scope=snsapi_base&state=STATE#wechat_redirect";
        header("Location:".$url1);
    }
}
// 获取当前用户的OpenId
function get_auth_openid($token) {
    $openid = session ('openid_'.$token);
    Addwxlog($openid,$token.'获取session的openid');
    if (empty ( $openid )) {
        $callback = GetCurUrl ();
        $res = OAuthWeixin ( $callback ,$token);
        $openid = $res->openid;
        if(!$openid){
            $res= OAuthWeixin ( $callback ,$token);
            $openid = $res->openid;
        }
        Addwxlog($openid,$token.'获取session的openid—new');
        session('openid_'.$token,$openid);
    }
    return $openid;
}


//生成代理专属邀请码
function set_invitation_code(){
    $length = 8;
    $chars = "abcdefghjkmnpqrstuvwxyz23456789";
    $str = "";
    for ($i = 0; $i < $length; $i++) {
        $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    $res = M('wx_user')->where(array('invitation_code'=>$str))->find();
    if(!empty($res)){
        set_invitation_code();
    }else{
        return $str;
    }

}
//合成商品图片和二维码
function qrcode_img($qrcode_url,$src_path,$title,$price,$quan_je){
    /* $qrcode_url=urldecode(I('qrcode_url'));
    $src_path  =urldecode(I('pic_url'));
    $title     =urldecode(I('title'));
    $price     =I('price');
    $quan_je   =I('quan_je'); */
    //$qrcode_url="http://img3.tbcdn.cn/tfscom/i4/704435704/TB2ZGx6axPI8KJjSspoXXX6MFXa_!!704435704.jpg_120x120";
    //$src_path="http://img1.tbcdn.cn/tfscom/i4/3314228580/TB2IjOYg_SPY1JjSZPcXXXIwpXa_!!3314228580.jpg_400x400";
    //$title   = "卡通印花图案回头率够高的潮流时尚卫衣，2017新款随性又休闲的连帽，属于你的卫衣，让你穿得既舒适又潮流！";
    //$price   = "59.00";
    //$quan_je = "15";
    $title_   ="       ";
    $title   = $title_.$title;
    $im = imagecreatetruecolor(400, 590);
    //$im = @imagecreate(400, 590);
    $bg = imagecolorallocate($im, 255, 255, 255); //设置画布的背景为白色
    imagefill($im, 0, 0, $bg);
    $src = imagecreatefromstring(file_get_contents($src_path));
    list($src_w, $src_h) = getimagesize($src_path);//获取水印图片高度
    //imagecopymerge($im, $src, 0, 0, 0, 0, $src_w, $src_h, 100);
    imagecopyresampled($im,$src,0,0,0,0,400,400,$src_w,$src_h);
    $font = str_replace('\\','/',getcwd()).'/Arial.ttf';
    $black = imagecolorallocate($im, 0, 0, 0); //设置一个颜色变量为黑色
    $title = autowrap(12, 0, $font, $title, 220);
    imageTtfText($im, 12, 0 , 10, 420, $black,$font,$title); //水平的将字符串输出到图像中
    $orange = imagecolorallocate($im,255,165,0);
    imagefilledrectangle($im,10,405,45,425,$orange);
    imageTtfText($im, 10, 0 , 10, 420, $bg,$font,' 包邮'); //水平的将字符串输出到图像中
    $gray = imagecolorallocate($im,112,128,144);
    $price_str = '现价：￥'.$price;
    imageTtfText($im, 12, 0 , 10, 530, $gray,$font,$price_str); //水平的将字符串输出到图像中
    imagefilledrectangle($im,10,550,35,570,$orange);
    imageTtfText($im, 12, 0 , 15, 566, $bg,$font,'券'); //水平的将字符串输出到图像中
    imagefilledrectangle($im,35,550,75,570,$orange);
    imagefilledrectangle($im,35,551,74,569,$bg);
    $quan_je_str = $quan_je.' 元';
    imageTtfText($im, 12, 0 , 35, 567, $orange,$font,$quan_je_str); //水平的将字符串输出到图像中
    imageTtfText($im, 12, 0 , 80, 567, $gray,$font,'券后价：'); //水平的将字符串输出到图像中
    $quanhou = $price-$quan_je;
    imageTtfText($im, 18, 0 , 140, 567, $orange,$font,'￥'.$quanhou); //水平的将字符串输出到图像中
    $src = imagecreatefromstring(file_get_contents($qrcode_url));
    imagecopymerge($im, $src, 250, 430, 0, 0, 120, 120, 100);
    imageline($im, 235, 415, 260, 415, $orange);
    imageline($im, 235, 415, 235, 440, $orange);
    imageline($im, 235, 540, 235, 565, $orange);
    imageline($im, 235, 565, 260, 565, $orange);

    imageline($im, 360, 415, 385, 415, $orange);
    imageline($im, 385, 415, 385, 440, $orange);
    imageline($im, 360, 565, 385, 565, $orange);
    imageline($im, 385, 540, 385, 565, $orange);

    imageTtfText($im, 10, 0 , 266, 570, $orange,$font,'长按识别二维码'); //水平的将字符串输出到图像中

    header('Content-type:image/png');
    imagepng($im);
    imagedestroy($im);
}
//合成商品图片和二维码
function qrcode_img_src($qrcode_url,$src_path,$title,$price,$quan_je,$uid,$num_iid){
    /* 
     $qrcode_url=urldecode(I('qrcode_url'));
     $src_path  =urldecode(I('pic_url'));
     $title     =urldecode(I('title'));
     $price     =I('price');
     $quan_je   =I('quan_je');
     */
    /* $qrcode_url="http://img3.tbcdn.cn/tfscom/i4/704435704/TB2ZGx6axPI8KJjSspoXXX6MFXa_!!704435704.jpg_120x120";
    $src_path="http://img1.tbcdn.cn/tfscom/i4/3314228580/TB2IjOYg_SPY1JjSZPcXXXIwpXa_!!3314228580.jpg_400x400";
    $title   = "卡通印花图案回头率够高的潮流时尚卫衣，2017新款随性又休闲的连帽，属于你的卫衣，让你穿得既舒适又潮流！";
    $price   = "59.00";
    $quan_je = "15"; */
    $title_   ="       ";
    $title   = $title_.$title;
    $im = imagecreatetruecolor(400, 590);
    //$im = @imagecreate(400, 590);
    $bg = imagecolorallocate($im, 255, 255, 255); //设置画布的背景为白色
    imagefill($im, 0, 0, $bg);
    $src = imagecreatefromstring(file_get_contents($src_path));
    list($src_w, $src_h) = getimagesize($src_path);//获取水印图片高度
    //imagecopymerge($im, $src, 0, 0, 0, 0, $src_w, $src_h, 100);
    imagecopyresampled($im,$src,0,0,0,0,400,400,$src_w,$src_h);
    $font = str_replace('\\','/',getcwd()).'/Arial.ttf';
    $black = imagecolorallocate($im, 0, 0, 0); //设置一个颜色变量为黑色
    $title = autowrap(12, 0, $font, $title, 220);
    imageTtfText($im, 12, 0 , 10, 420, $black,$font,$title); //水平的将字符串输出到图像中
    $orange = imagecolorallocate($im,255,165,0);
    imagefilledrectangle($im,10,405,45,425,$orange);
    imageTtfText($im, 10, 0 , 10, 420, $bg,$font,' 包邮'); //水平的将字符串输出到图像中
    $gray = imagecolorallocate($im,112,128,144);
    $price_str = '现价：￥'.$price;
    imageTtfText($im, 12, 0 , 10, 530, $gray,$font,$price_str); //水平的将字符串输出到图像中
    imagefilledrectangle($im,10,550,35,570,$orange);
    imageTtfText($im, 12, 0 , 15, 566, $bg,$font,'券'); //水平的将字符串输出到图像中
    imagefilledrectangle($im,35,550,75,570,$orange);
    imagefilledrectangle($im,35,551,74,569,$bg);
    $quan_je_str = $quan_je.' 元';
    imageTtfText($im, 12, 0 , 35, 567, $orange,$font,$quan_je_str); //水平的将字符串输出到图像中
    imageTtfText($im, 12, 0 , 80, 567, $gray,$font,'券后价：'); //水平的将字符串输出到图像中
    $quanhou = $price-$quan_je;
    imageTtfText($im, 18, 0 , 140, 567, $orange,$font,'￥'.$quanhou); //水平的将字符串输出到图像中
    $src = imagecreatefromstring(file_get_contents($qrcode_url));
    imagecopymerge($im, $src, 250, 430, 0, 0, 120, 120, 100);
    imageline($im, 235, 415, 260, 415, $orange);
    imageline($im, 235, 415, 235, 440, $orange);
    imageline($im, 235, 540, 235, 565, $orange);
    imageline($im, 235, 565, 260, 565, $orange);

    imageline($im, 360, 415, 385, 415, $orange);
    imageline($im, 385, 415, 385, 440, $orange);
    imageline($im, 360, 565, 385, 565, $orange);
    imageline($im, 385, 540, 385, 565, $orange);
    imageTtfText($im, 10, 0 , 266, 570, $orange,$font,'长按识别二维码'); //水平的将字符串输出到图像中
    header('Content-type:image/png');
    $filename=$uid.'_'.$num_iid.'.png';
    $res = imagepng($im,str_replace('\\','/',getcwd()).'/Uploads/item_qrcode/'.$filename);
    imagedestroy($im);
    return $res;
}

function autowrap($fontsize, $angle, $fontface, $string, $width) {
    // 这几个变量分别是 字体大小, 角度, 字体名称, 字符串, 预设宽度
    $content = "";
    // 将字符串拆分成一个个单字 保存到数组 letter 中
    for ($i=0;$i<mb_strlen($string);$i++) {
        $letter[] = mb_substr($string, $i, 1);
    }

    foreach ($letter as $l) {
        $teststr = $content." ".$l;
        $testbox = imagettfbbox($fontsize, $angle, $fontface, $teststr);
        // 判断拼接后的字符串是否超过预设的宽度
        if (($testbox[2] > $width) && ($content !== "")) {
            $content .= "\n";
        }
        $content .= $l;
    }
    return $content;
}
//写文件日志方法
function add_file_log($dir,$info){
    $path = str_replace("\\","/",getcwd()."/Logs/".$dir);
    if (!file_exists($path)){
        mkdir($path);
    }
    $file = $path."/".date("Y-m-d",time()).".log";
    $f = fopen($file, "a");
    $filesize = filesize($file);
    $str_key='';$str_val='';
    foreach ($info as $key=>$val){
        $str_key .= $key."      ";
        $str_val .= $val."      ";
    }
    if($filesize==0){
        fwrite($f, rtrim($str_key,"     ")."\r\n");
        fwrite($f, rtrim($str_val,"     ")."\r\n");
    }else{
        fwrite($f, rtrim($str_val,"     ")."\r\n");
    }
}
/**
 * @name: getfirstchar
 * @description: 获取汉子首字母
 * @param: string
 * @return: mixed
 * @author:
 * @create: 2014-09-17 21:46:52
 **/
function getfirstchar($s0){
    $fchar = ord($s0{0});
    if($fchar >= ord("A") and $fchar <= ord("z") )return strtoupper($s0{0});
    //$s1 = iconv("UTF-8","gb2312//IGNORE", $s0);
    // $s2 = iconv("gb2312","UTF-8//IGNORE", $s1);
    $s1 = get_encoding($s0,'GB2312');
    $s2 = get_encoding($s1,'UTF-8');
    if($s2 == $s0){$s = $s1;}else{$s = $s0;}
    $asc = ord($s{0}) * 256 + ord($s{1}) - 65536;
    if($asc >= -20319 and $asc <= -20284) return "A";
    if($asc >= -20283 and $asc <= -19776) return "B";
    if($asc >= -19775 and $asc <= -19219) return "C";
    if($asc >= -19218 and $asc <= -18711) return "D";
    if($asc >= -18710 and $asc <= -18527) return "E";
    if($asc >= -18526 and $asc <= -18240) return "F";
    if($asc >= -18239 and $asc <= -17923) return "G";
    if($asc >= -17922 and $asc <= -17418) return "I";
    if($asc >= -17417 and $asc <= -16475) return "J";
    if($asc >= -16474 and $asc <= -16213) return "K";
    if($asc >= -16212 and $asc <= -15641) return "L";
    if($asc >= -15640 and $asc <= -15166) return "M";
    if($asc >= -15165 and $asc <= -14923) return "N";
    if($asc >= -14922 and $asc <= -14915) return "O";
    if($asc >= -14914 and $asc <= -14631) return "P";
    if($asc >= -14630 and $asc <= -14150) return "Q";
    if($asc >= -14149 and $asc <= -14091) return "R";
    if($asc >= -14090 and $asc <= -13319) return "S";
    if($asc >= -13318 and $asc <= -12839) return "T";
    if($asc >= -12838 and $asc <= -12557) return "W";
    if($asc >= -12556 and $asc <= -11848) return "X";
    if($asc >= -11847 and $asc <= -11056) return "Y";
    if($asc >= -11055 and $asc <= -10247) return "Z";
    return null;
}
/**
 * @name: get_encoding
 * @description: 自动检测内容编码进行转换
 * @param: string data
 * @param: string to  目标编码
 * @return: string
 **/
function get_encoding($data,$to){
    $encode_arr=array('UTF-8','ASCII','GBK','GB2312','BIG5','JIS','eucjp-win','sjis-win','EUC-JP');
    $encoded=mb_detect_encoding($data, $encode_arr);
    $data = mb_convert_encoding($data,$to,$encoded);
    return $data;
}
 
function pinyin($zh){
    $ret = "";
    $s1 = iconv("UTF-8","gb2312", $zh);
    $s2 = iconv("gb2312","UTF-8", $s1);
    if($s2 == $zh){$zh = $s1;}
    for($i = 0; $i < strlen($zh); $i++){
        $s1 = substr($zh,$i,1);
        $p = ord($s1);
        if($p > 160){
            $s2 = substr($zh,$i++,2);
            $ret .= getfirstchar($s2);
        }else{
            $ret .= $s1;
        }
    }
    return $ret;
}
//判断用户等级
function get_level($id,$member_level,$token){
    $uid = $id;
    //查询用户分成比
    $m_l = $member_level;
    switch ($m_l){
        case -1://表示普通粉丝，购买无收益
            //查询默认系统用户
            $sql = "select c.ShouYiBi as b_level1,c.ShangJiShouYiBi as b_level2,c.ShangShangJiShouYiBi as b_level3,c.YaoQingJiangLi as b_yqjl,c.ZuiDiTiXian as b_zdtx,c.YaoQingMax as b_yqmax,a.TgwID as a_pid from daili_wx_user as a left join daili_a_media as b on a.GzhToken=b.token left join daili_a_config_copy as c on c.MediaID=b.id where a.GzhToken='$token' and a.ID=$uid";
            $res = M('wx_user')->query($sql);
            $res[0]['b_level1']=0;
            $res[0]['b_level2']=0;
            $res[0]['b_level3']=0;
            break;
        case 0://表示会员
            $sql = "select c.ShouYiBi as b_level1,c.ShangJiShouYiBi as b_level2,c.ShangShangJiShouYiBi as b_level3,c.YaoQingJiangLi as b_yqjl,c.ZuiDiTiXian as b_zdtx,c.YaoQingMax as b_yqmax,a.TgwID as a_pid from daili_wx_user as a left join daili_a_media as b on a.GzhToken=b.token left join daili_a_config_copy as c on c.MediaID=b.id where a.GzhToken='$token' and a.ID=$uid";
            $res = M('wx_user')->query($sql);
            break;
        case 1://表示店主
            $sql = "select b.level1 as b_level1,b.level2 as b_level2,b.level3 as b_level3,b.yaoqingjiangli as b_yqjl,b.zuiditixian as b_zdtx,b.yaoqingmax as b_yqmax,a.TgwID as a_pid from daili_wx_user as a left join daili_wx_user_level as b on a.GzhToken=b.token where a.GzhToken='$token' and a.ID=$uid and b.member_level=$m_l";
            $res = M('wx_user')->query($sql);
            break;
        case 2://表示销售经理
            $sql = "select b.level1 as b_level1,b.level2 as b_level2,b.level3 as b_level3,b.yaoqingjiangli as b_yqjl,b.zuiditixian as b_zdtx,b.yaoqingmax as b_yqmax,a.TgwID as a_pid from daili_wx_user as a left join daili_wx_user_level as b on a.GzhToken=b.token where a.GzhToken='$token' and a.ID=$uid and b.member_level=$m_l";
            $res = M('wx_user')->query($sql);
            break;
        case 3://表示服务经理
            $sql = "select b.level1 as b_level1,b.level2 as b_level2,b.level3 as b_level3,b.yaoqingjiangli as b_yqjl,b.zuiditixian as b_zdtx,b.yaoqingmax as b_yqmax,a.TgwID as a_pid from daili_wx_user as a left join daili_wx_user_level as b on a.GzhToken=b.token where a.GzhToken='$token' and a.ID=$uid and b.member_level=$m_l";
            $res = M('wx_user')->query($sql);
            break;
    }
    $res[0]['member_level']=$m_l;
    return $res[0];
}
//判断用户等级获取各个级别用户的分成比率
function get_shouyi_info($xiaoguoyugu,$user){
    $xiaoguoyugu=$xiaoguoyugu*0.9;
    $w = array(
        'MediaID'=>$mediaid,
        'AdID'=>$adid
    );
    $m_l=$user['member_level'];
    $token=$user['gzhtoken'];
    $uid=$user['id'];
    //如果有上级用户就查询上级用户
    if($user['pid'] && $user['pid'] != $user['id']){
        $w=array(
            'ID'=>$user['pid'],
        );
        $shangjiuser=M('wx_user')->where($w)->find();
    }
    //如果有上上级用户就查询上上级用户
    if($shangjiuser['pid'] && $shangjiuser['pid'] != $shangjiuser['id']){
        $w = array(
            'ID'=>$shangjiuser['pid']
        );
        $shangshangjiuser=M('wx_user')->where($w)->find();
    }
    //如果有区域和伙人就查询区域合伙人
    if($user['member_area'] && $user['member_area'] != $user['id'] && $user['member_area'] != $user['pid']){
        $w = array(
            'ID'=>$user['member_area']
        );
        $area = M('wx_user')->where($w)->find();
    }
    //查询当前渠道会员的分成比
    $config0 = M('a_config_copy')->where(array('token'=>$token))->find();
    $config1 = M('wx_user_level')->where(array('token'=>$token,'member_level'=>1))->find();
    $config2 = M('wx_user_level')->where(array('token'=>$token,'member_level'=>2))->find();
    $config3 = M('wx_user_level')->where(array('token'=>$token,'member_level'=>3))->find();
    //查询用户分成比
    switch ($m_l){
        case 0://表示普通合伙人
            //查询普通合伙人对应的收益配置
            $shouyi=($config0['shouyibi']/100)*$xiaoguoyugu;
            break;
        case 1://表示超级会员
            //查询超级会员对应的收益配置
            $shouyi=($config1['level1']/100)*$xiaoguoyugu;
            break;
        case 2://表示运营商
            //查询运营商对应的收益配置
            $shouyi=($config2['level1']/100)*$xiaoguoyugu;
            break;
        case 3://表示区域合伙人
            //查询区域合伙人对应的收益配置
            $shouyi=($config3['level1']/100)*$xiaoguoyugu;
            break;
    }
    //return $xiaoguoyugu;
    if($shangjiuser){
        
        if($shangjiuser['member_level']==0){
            $shangji_shouyi=($config0['shangjijianglibi']/100)*($config0['shouyibi']/100)*$xiaoguoyugu;
        }
        if($shangjiuser['member_level']==1){
            $shangji_shouyi=($config1['level2']/100)*($config0['shouyibi']/100)*$xiaoguoyugu;
         
        }
        if($shangjiuser['member_level']==2){
            $shangji_shouyi=($config2['level2']/100)*($config0['shouyibi']/100)*$xiaoguoyugu;
        }
        if($shangjiuser['member_level']==3){
            $shangji_shouyi=($config3['level2']/100)*($config0['shouyibi']/100)*$xiaoguoyugu;
        }
    }else{
        $shangji_shouyi=0;
    }
    if($shangshangjiuser){
        if($shangshangjiuser['member_level']==2){
            $shangshangji_shouyi=($config2['level3']/100)*($config0['shouyibi']/100)*$xiaoguoyugu;
        }
    }else{
        $shangshangji_shouyi=0;
    }
    if($area){
        $area_shouyi = ($config3['level3']/100)*($config0['shouyibi']/100)*$xiaoguoyugu;
    }else{
        $area_shouyi = 0;
    }
    $res = array(
        'uid'=>$user['id'],
        'shouyi'=>$shouyi,
        'shangjiuid'=>$shangjiuser['id'],
        'shangjishouyi'=>$shangji_shouyi,
        'shangshangjiuid'=>$shangshangjiuser['id'],
        'shangshangjishouyi'=>$shangshangji_shouyi,
        'area_id'=>$area['id'],
        'area_shouyi'=>$area_shouyi
    );
    return $res;
}
//设置代理等级
function set_level($uid){
    return false;
     $user = M('wx_user')->field('ID,Pid,GzhToken,member_level')->where(array('ID'=>$id))->find();
     user_shengji($uid);
     
     $pid = $user['pid'];
     if($pid){
         user_shengji($pid);
     }
     
}
    function user_shengji($uid){
        $user = M('wx_user')->field('ID,Pid,GzhToken,member_level')->where(array('ID'=>$uid))->find();
        $member_level=$user['member_level'];
        $token = $user['gzhtoken'];
        $y = date('Y',time());
        $m = date('m',time());
        $start_time = strtotime($y.'-'.$m.'-01 00:00:00');
        $end_time   = time();
        switch ($member_level){
            case -1:
                //查询下级用户代理
                $xiaji = M('wx_user')->field('ID')->where(array('Pid'=>$uid,'Statue'=>1))->select();
                if($xiaji){
                    $xiaji_ids = '';
                    foreach ($xiaji as $key=>$val){
                        $xiaji_ids .= $val['id'].',';
                    }
                    $xiaji_ids = rtrim($xiaji_ids,',');
                    //查询下级代理的下单数量
                    $sql="select count(a.ID) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.CompleteTime between $start_time and $end_time and b.UID in ($xiaji_ids) and a.OrderStatue <> '订单失效'";
                    $count_xiaji = M('a_order')->query($sql);
                }
                //判断是否满足成为普通合伙人条件
                $sql = "select count(a.ID) as count from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.CompleteTime between $start_time and $end_time and b.UID=$uid";
                $res = M('a_order')->query($sql);
                $count_order=$res[0]['count'];
                $count_order = $count_order+$count_xiaji[0]['count'];
                if($count_order>=3){
                    //判断是否满足成黄金合伙人条件
                    $sql = "select sum(b.ShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.CompleteTime between $start_time and $end_time and b.UID=$uid";
                    $res = M('a_order')->query($sql);
                    $sum = $res[0]['sum'];
                    //查询下级代理增加数
                    $sql = "select count(ID) as count from daili_wx_user where (SubscribeTime between $start_time and $end_time) or (reg_app_time between $start_time and $end_time) and Pid=$uid and Statue=1";
                    $res = M('wx_user')->query($sql);
                    $count = $res[0]['count'];
                    if($sum>=50 && $count>=5){
                        $m_l=1;
                    }else{
                        $m_l=0;
                    }
                    $d = array(
                        'ID'=>$uid,
                        'member_level'=>$m_l
                    );
                    $l = array(
                        'content'=>json_encode($d),
                        'type'=>'修改等级-1'
                    );
                    M('z_logtest')->add($l);
                    M('wx_user')->save($d);
                }
                //判断上级用户是否可以升级
        
                break;
            case 0:
                //判断是否满足成黄金合伙人条件
                $sql = "select sum(b.ShouYi) as sum from daili_a_order as a left join daili_a_shouyi as b on a.ID=b.OrderID where a.CompleteTime between $start_time and $end_time and b.UID=$uid";
                $res = M('a_order')->query($sql);
                $sum = $res[0]['sum'];
                //查询下级代理增加数
                $sql = "select count(ID) as count from daili_wx_user where (SubscribeTime between $start_time and $end_time) or (reg_app_time between $start_time and $end_time) and Pid=$uid and Statue=1";
                $res = M('wx_user')->query($sql);
                $count = $res[0]['count'];
                if($sum>=50 && $count>=5){
                    $m_l=1;
                    $d = array(
                        'ID'=>$uid,
                        'member_level'=>$m_l
                    );
                    $l = array(
                        'content'=>json_encode($d),
                        'type'=>'修改等级0'
                    );
                    M('z_logtest')->add($l);
                    M('wx_user')->save($d);
                }
                break;
        }
    }
    ////通过xunsearch搜索商品
 function search_items($key,$type){
        //$key=urldecode(I('key'));
        //$type=I('type');
        require_once '/data/wwwroot/default/xunsearch/sdk/php/lib/XS.php';
        $xs = new \XS('items');
        $index = $xs->index;
        $search = $xs->search;
        $total1 = $search->dbTotal;//获取索引库内的数据总数
        $search->setQuery($key)->setLimit(10,$total1)->search();
        $count  = $search->getLastCount();
        $num = 20;
        $page=I('p',1);
        switch ($type){
            case 1:
                $sorts = array('coupon_price' => true);
                $search->setMultiSort($sorts);
                break;
            case 2:
                $sorts = array('volume' => false);
                $search->setMultiSort($sorts);
                break;
            case 3:
                $sorts = array('youhuiquan_je' => false);
                $search->setMultiSort($sorts);
                break;
        }
        $docs = $search->setQuery($key)->addWeight('title', $key)->setLimit($num,($page-1)*$num)->search(); // 执行搜索，将搜索结果文档保存在 $docs 数组中
        $count_page = ceil($count/$num);
        $Page       = new \Think\Page($count,$num);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $show       = $Page->show();// 分页显示输出
        foreach ($docs as $key=>$doc){
            //$short_title = $search->highlight($doc->short_title); // 高亮处理 subject 字段
            //$title = $search->highlight($doc->title); // 高亮处理 message 字段
            $data[$key]['id']=$doc->id;
            //$data[$key]['num']=$doc->rank();
            $data[$key]['short_title']=$doc->short_title;
            $data[$key]['title']=$doc->title;
            $data[$key]['volume']=$doc->volume;
            $data[$key]['price']=$doc->price;
            $data[$key]['coupon_price']=($doc->price)-($doc->youhuiquan_je);
            $data[$key]['youhuiquan_je']=$doc->youhuiquan_je;
            $data[$key]['num_iid']=$doc->num_iid;
            $data[$key]['shop_type']=$doc->shop_type;
            $data[$key]['movie_url']=$doc->movie_url;
            $data[$key]['pic_url']=$doc->pic_url;
            $data[$key]['commission_rate']=$doc->commission_rate;
        }
        $res = array(
            'total'=>$total1,
            'count_page'=>$count_page,
            'count'=>$count,
            'items'=>$data
        );
        return $res;
    }