<?php
return array(
	//'配置项'=>'配置值'
    'UPLOADS'       =>__ROOT__.'/Uploads/',
    //微信(手机端)js，css，img地址
    'MUI'=>'/Public/mui/',
    'WEIXIN_CSS'         =>__ROOT__.'/Public/weixin/css/',
    'WEIXIN_JS'          =>__ROOT__.'/Public/weixin/js/',
    'WEIXIN_IMAGE'       =>__ROOT__.'/Public/weixin/images/',
    'WEIXIN_PICTURE'       =>__ROOT__.'/Public/weixin/picture/',
    //前台js，css，img地址
    'HOME_CSS'         =>__ROOT__.'/Public/home/css/',
    'HOME_JS'          =>__ROOT__.'/Public/home/js/',
    'HOME_IMAGE'       =>__ROOT__.'/Public/home/images/',
    'HOME_EMOJI'       =>__ROOT__.'/Public/home/emoji/',
    //APP端js，css，img地址
    'APP_CSS'         =>__ROOT__.'/Public/app/css/',
    'APP_JS'          =>__ROOT__.'/Public/app/js/',
    'APP_IMAGE'       =>__ROOT__.'/Public/app/images/',
    'APP_PICTURE'     =>__ROOT__.'/Public/app/picture/',
    //后台公众号设置相关页面的js，css，img地址
    'WX_CSS'         =>__ROOT__.'/Public/wx/css/',
    'WX_JS'          =>__ROOT__.'/Public/wx/js/',
    'WX_IMAGE'       =>__ROOT__.'/Public/wx/images/',
    //公用插件地址
    'LAYUI'             =>__ROOT__.'/Public/layui-v1.0.7/',
    'LAYUI2'        =>__ROOT__.'/Public/layui-v2.0.2/',
    'MUI'        =>__ROOT__.'/Public/mui/',
    'UPLOAD'            =>__ROOT__.'/Public/upload/',
    'Uedit'             =>__ROOT__.'/Public/uedit-utf8/',
    //设置默认模块
    'DEFAULT_MODULE'    => 'Home',
    //url模式
    'URL_MODEL'         =>2,
    //版本控制，加在css和js之后用于清除css和js的缓存
    'VERSION'           =>time(),
    //启页面Trace输出更多的调试信息
    //'SHOW_PAGE_TRACE'   =>false,
    //显示页面错误信息
    'SHOW_ERROR_MSG'    =>  true,
    'APP_SUB_DOMAIN_DEPLOY'   =>    1, // 开启子域名配置
    'APP_SUB_DOMAIN_RULES'    =>    array(     
        'app.yunbace.cn'=>'App',
        'home.yunbace.cn'=>'Home',
        'app.gelohui.cn'=>'App',
        'app.jikuaida.cn'=>'App',
        'app.sopianyi.com'=>'App',
        'app.leader678.com'=>'App',
        'app.yinfafa.cn'=>'App',
        'app.ws.cn'=>'App',
        'home.ws.cn'=>'Home',
    ),
    'TB_appid'=>'23386401',
    'TB_appsecret'=>'bee522f15d729685fa41c5069b897dee',
    'Vendor_file'=>'taobao-sdk-PHP-auto_20170328.TopSdk',
    'TB_appid_new'=>'23386401',
    'TB_appsecret_new'=>'bee522f15d729685fa41c5069b897dee',
    'Vendor_file_new'=>'taobao-sdk-PHP-auto_20170807.TopSdk',
    'Vendor_file_20180207'=>'taobao-sdk-PHP-auto_20180207.TopSdk',
    'Vendor_file_20180306'=>'taobao-sdk-PHP-auto_20180306.TopSdk',
    //转短网址接口链接
    'DWZ_API_URL'=>'http://dwz.yunbace.cn',
    //高效转链接口链接
    'GXZL_API_URL'=>'http://api.yunbace.cn',
    //本地图片域名
    'LOCAL_IMG_URL'=>'http://img.yunbace.cn',
    //APP接口调用域名
    'APP_API_URL'=>'http://app.yunbace.cn',
    //北京的推广位ID
    'MEDIA_ID'=>'44200086',
    //用户下单满足金额可活动奖励
    'PAY_MONEY'=>'15'
);