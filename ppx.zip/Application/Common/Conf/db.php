<?php
$config = array(
    //'配置项'=>'配置值'
    //数据库配置信息
    // 数据库类型
    'DB_TYPE'   =>'mysql',
    'DB_HOST'   => 'rm-2ze73dowpcr78599azo.mysql.rds.aliyuncs.com',
    // 服务器地址
    'DB_NAME'   => 'dailisystem',
    // 数据库名
    'DB_USER'   => 'pinpinxia',
    // 用户名
    'DB_PWD'    => 'pinpinxia2018$',
    //'DB_PWD'    => 'ad33561213',
    // 密码
    'DB_PORT'   => '3306',
    // 端口
    'DB_PREFIX' => 'daili_',
    // 数据库表前缀
    'DB_CHARSET'=> 'utf8', // 字符集
    //服务器本地Mysql数据库连接配置
 

    //本地ailinew数据库
    'DB_READ' => array(
        //'配置项'=>'配置值'
        //数据库配置信息
        // 数据库类型
        'DB_TYPE'   =>'mysql',
        'DB_HOST'   => 'rr-2zesf93a67c5hq9ax0o.mysql.rds.aliyuncs.com',
        // 服务器地址
        'DB_NAME'   => 'dailisystem',
        // 数据库名
        'DB_USER'   => 'pinpinxia',
        // 用户名
        // 'DB_PWD'    => 'dingding2015',
        'DB_PWD'    => 'pinpinxia2018$',
        //'DB_PWD'    => 'ad33561213',
        // 密码
        'DB_PORT'   => '3306',
        // 端口
        'DB_PREFIX' => 'daili_',
        // 数据库表前缀
        'DB_CHARSET'=> 'utf8', // 字符集
    ),
    'DB_DAILI' => array(
            // 数据库类型
        'DB_TYPE'   =>'mysql',
        'DB_HOST'   => 'rm-2ze8a6om3rzi6505wo.mysql.rds.aliyuncs.com',
        // 服务器地址
        'DB_NAME'   => 'dailisystem',
        // 数据库名
        'DB_USER'   => 'baicaibuy',
        // 用户名
        'DB_PWD'    => 'baicaibuy2016$',
        //'DB_PWD'    => 'ad33561213',
        // 密码
        'DB_PORT'   => '3306',
        // 端口
        'DB_PREFIX' => 'daili_',
        // 数据库表前缀
        'DB_CHARSET'=> 'utf8', // 字符集
        //服务器本地Mysql数据库连接配置
    ),
    //本地ailinew数据库
    'DB_DAILI_READ' => array(
        //'配置项'=>'配置值'
        //数据库配置信息
        // 数据库类型
        'DB_TYPE'   =>'mysql',
        'DB_HOST'   => 'rr-2ze49v6zkvmwnz6mico.mysql.rds.aliyuncs.com',
        // 服务器地址
        'DB_NAME'   => 'dailisystem',
        // 数据库名
        'DB_USER'   => 'baicaibuy',
        // 用户名
        // 'DB_PWD'    => 'dingding2015',
        'DB_PWD'    => 'baicaibuy2016$',
        //'DB_PWD'    => 'ad33561213',
        // 密码
        'DB_PORT'   => '3306',
        // 端口
        'DB_PREFIX' => 'daili_',
        // 数据库表前缀
        'DB_CHARSET'=> 'utf8', // 字符集
    ),
/*
    //本地daili数据库
    'DB_BENDI2' => array(
        //'配置项'=>'配置值'
        //数据库配置信息
        // 数据库类型
        'DB_TYPE'   =>'mysql',
        'DB_HOST'   => 'localhost',
        // 服务器地址
        'DB_NAME'   => 'dailisystem',
        // 数据库名
        'DB_USER'   => 'root',
        // 用户名
        // 'DB_PWD'    => 'dingding2015',
        'DB_PWD'    => '',
        //'DB_PWD'    => 'ad33561213',
        // 密码
        'DB_PORT'   => '3306',
        // 端口
        'DB_PREFIX' => 'ftxia_',
        // 数据库表前缀
        'DB_CHARSET'=> 'utf8', // 字符集
    ),

    //服务器本地Mysql数据库连接配置
    'DB_AILINEW' => array(
        //'配置项'=>'配置值'
        //数据库配置信息
        // 数据库类型
        'DB_TYPE'   =>'mysql',
        'DB_HOST'   => 'rm-2ze8a6om3rzi6505w.mysql.rds.aliyuncs.com',
        // 服务器地址
        'DB_NAME'   => 'ailinew',
        // 数据库名
        'DB_USER'   => 'baicaibuy',
        // 用户名
        'DB_PWD'    => 'baicaibuy2016$',
        //'DB_PWD'    => 'ad33561213',
        // 密码
        'DB_PORT'   => '3306',
        // 端口
        'DB_PREFIX' => 'ftxia_',
        // 数据库表前缀
        'DB_CHARSET'=> 'utf8', // 字符集
    ), */
);
return $config;


