/**
 * 
 */
	$('.tablelist tbody tr:odd').addClass('odd');
	//通过ajax获取淘宝上面的商品图片
	function get_item_img(url,loading_img){
		$('.refresh_img').each(function(){
			var obj = $(this);
			var obj_td = obj.parent();
			obj.click(function(){
				var item_id = obj.attr('data_id');
				obj_td.empty().append('<img style="padding:2px 0;margin-left:13px;" src="'+loading_img+'" width=\'25px\'">');
				var data ={item_id:item_id};
				$.post(url,data,function(res){
					if(res.code==1){
						obj_td.empty().append('<img class="small_img" style="padding:2px 0;" src="'+res.img+'_70x70.jpg'+'">');
						big_img();
					}else{
						obj_td.empty().append('<span class="refresh_img" data_id="'+item_id+'" style="cursor:pointer;color:red;">'+res.msg+'</span>')
						get_item_img(url,loading_img);
					}
				})
			})
		})
	}
	//订单管理中鼠标放上图片放大
	function big_img(type){
		if(type==2){
			var x = -100;
			var y = -300;
		}else{
			var x = 10;
			var y = -150;
		}
		
		$('.small_img').each(function(){
			var obj = $(this);
			obj.mouseover(function(e){
				if(type==0){
					var big_src = this.src;
					//var big_src = src.substring(0,src.length-9);
					var tooltip = "<div id='tooltip'><img src='" + big_src + "' width='250px' height='250px'/></div>";
				}else if(type==1){
					var src = this.src;
					var big_src = src.substring(0,src.length-9)+'250x250.jpg';
					var tooltip = "<div id='tooltip'><img src='" + big_src + "' /></div>";
				}else if(type==2){
					var big_src = this.src;
					//var big_src = src.substring(0,src.length-9);
					var tooltip = "<div id='tooltip'><img src='" + big_src + "' width='250px' height='250px'/></div>";
				}
				$("body").append(tooltip);
				$("#tooltip").css({"top": (e.pageY + y) + "px","left": (e.pageX + x) + "px"}).show("fast");
			});
			obj.mouseout(function(e){
				$("#tooltip").remove();
			});
		});
	}
	//订单管理中鼠标放上图片放大
	function big_img_up(type){
		if(type==2){
			var x = -100;
			var y = -300;
		}else{
			var x = 10;
			var y = -150;
		}
		
		$('.small_img_up').each(function(){
			var obj = $(this);
			obj.mouseover(function(e){
				if(type==0){
					var big_src = this.src;
					//var big_src = src.substring(0,src.length-9);
					var tooltip = "<div id='tooltip'><img src='" + big_src + "' width='250px' height='250px'/></div>";
				}else if(type==1){
					var src = this.src;
					var big_src = src.substring(0,src.length-9)+'250x250.jpg';
					var tooltip = "<div id='tooltip'><img src='" + big_src + "' /></div>";
				}else if(type==2){
					var big_src = this.src;
					//var big_src = src.substring(0,src.length-9);
					var tooltip = "<div id='tooltip'><img src='" + big_src + "' width='250px' height='250px'/></div>";
				}
				$("body").append(tooltip);
				$("#tooltip").css({"top": (e.pageY + y) + "px","left": (e.pageX + x) + "px"}).show("fast");
			});
			obj.mouseout(function(e){
				$("#tooltip").remove();
			});
		});
	}
	//商品管理中鼠标放上去图片变大
	function big_img1(){
		var x = 10;
		var y = -150;
		$('.upload input').each(function(){
			var obj = $(this);
			obj.mouseover(function(e){
				var tooltip = "<div id='tooltip'><img src='" + this.src + "' width='250px' height='250px' /></div>";
				$("body").append(tooltip);
				$("#tooltip").css({
							"top": (e.pageY + y) + "px",
							"left": (e.pageX + x) + "px"
						}).show("fast");
			}).mouseout(function(e){
				$("#tooltip").remove();
			}).mousemove(function(e){
				$("#tooltip").css({
					"top": (e.pageY + y) + "px",
					"left": (e.pageX + x) + "px"
				});
			});
		});
	}
	//App管理中轮播图和专场图片鼠标放上去图片变大
	function big_img2(){
		var x = 10;
		var y = -150;
		$('.upload input').each(function(){
			var obj = $(this);
			obj.mouseover(function(e){
				var tooltip = "<div id='tooltip'><img src='" + this.src + "' height='250px' /></div>";
				$("body").append(tooltip);
				$("#tooltip").css({
							"position":'absolute',
							"top": (e.pageY + y) + "px",
							"left": (e.pageX + x) + "px"
						}).show("fast");
			}).mouseout(function(e){
				$("#tooltip").remove();
			}).mousemove(function(e){
				$("#tooltip").css({
					"top": (e.pageY + y) + "px",
					"left": (e.pageX + x) + "px"
				});
			});
		});
	}
	//点击table中的td变成input
	function td_2_input(url,class_name,field,table,width){
		$('table .'+class_name).each(function(){
			var obj = $(this);
			obj.click(function(){
				var id = obj.attr('dataid');
				var key = obj.text();
				var type = obj.attr('type');
				if(type==1){
					obj.attr({type:0})
					obj.empty()
					//obj.append('<textarea type="text">'+key+'</textarea>');
					obj.append('<input style="width:'+width+';padding:5px;margin-left:-10px;" type="text" value="'+key+'">')
					obj.children('input').focus();
					obj.children('input').blur(function(){
						var key_new = $(this).val();
						if(key == key_new){
							obj.attr({type:1})
							obj.text(key)
							return false;
						}
						var data = {id:id,keyword:key_new,field:field,table:table}
						$.post(url,data,function(res){
							if(res.code==1){
								layer.msg('修改成功',{time:1000},function(){
									obj.attr({type:1})
									obj.empty();
									obj.text(key_new);
								})
							}else{
								layer.msg('修改失败')
							}
						})
					})
				}
			})
		})
	}
	//点击table中的td变成textarea
	function td_2_textarea(url,class_name,field,table,area_type,width){
		$('table .'+class_name).each(function(){
			var obj = $(this);
			obj.click(function(){
				
			var id = obj.attr('dataid');
			if(area_type==1){
				var key = obj.text();
				var key_value=key;
				/*if(field=='remark'){
					var width="150px";
				}else{
					var width="100px";
				}*/
			}else{
				var key = obj.attr('title');
				var key_value=obj.text();
				/*var width="150px";*/
			}
			var type = obj.attr('type');
			if(type==1){
				obj.attr({type:0})
				obj.empty()
				obj.append('<textarea type="text" style="height:80px;width:'+width+';margin-left:-10px;resize:vertical">'+key+'</textarea>');
				//obj.append('<input style="width:'+width+';padding:5px;" type="text" value="'+key+'">')
				obj.children('textarea').focus();
				obj.children('textarea').blur(function(){
					var key_new = $(this).val();
					if(key == key_new){
						obj.attr({type:1})
						obj.text(key_value)
						return false;
					}
					var data = {id:id,keyword:key_new,field:field,table:table}
					$.post(url,data,function(res){
						if(res.code==1){
							layer.msg('修改成功',{time:1000},function(){
								obj.attr({type:1});
								obj.attr({title:key_new});
								obj.empty();
								if(area_type == 0){
									if(key_new.length>20){
										obj.text(key_new.substring(0,20)+'...');
									}else{
										obj.text(key_new.substring(0,20));
									}
								}else{
									obj.text(key_new);
								}
							})
						}else{
							layer.msg('修改失败')
						}
					})
				})
			}

			})
		})
	}
	//点击table中的td变成input
	function td_2_input_time(url,class_name,field,table){
		var width="100px";
		$('table td .'+class_name).each(function(){
			var obj = $(this);
			obj.click(function(){
				var id = obj.attr('dataid');
				if(field=='start_time'){
					var obj_time = '#start_'+id;
				}
				if(field=='end_time'){
					var obj_time ='#end_'+id;
				}
				var key = obj.text();
				var type = obj.attr('type');
				if(type==1){
					layui.use('laydate', function(){
				    	  var laydate = layui.laydate;
				    	  //常规用法
				    	  laydate.render({
					    	   elem: obj_time,
					    	   done:function(value, date, endDate){
									var key_new = value;
									if(key == key_new){
										obj.attr({type:1})
										obj.text(key)
										return false;
									}
									var data = {id:id,keyword:key_new,field:field,table:table}
									$.post(url,data,function(res){
										if(res.code==1){
											layer.msg('修改成功',{time:1000},function(){
												obj.attr({type:1})
												obj.empty();
												obj.text(key_new);
											})
										}else{
											layer.msg('修改失败')
										}
									})
								}
				    	  });
				    })
				}
			})
		})
	}
	//修改图片
	function update_img(upload_url,url,table,type,field){
		
		if(type){
			type=type;
		}else{
			type=0;
		}
		$('.upload input').each(function(){
			var obj = $(this);
			var id = obj.attr('data_id');
			//var upload_url = '{:U("Ajax/upload")}';
			//var upload_url='http://img.baicaibuy.cn/Upload/upload';
			obj.wrap("<form id='myupload' action='"+upload_url+"' method='post' enctype='multipart/form-data'></form>");
			obj.change(function(){
				obj.parent('form').ajaxSubmit({
					dataType:  'json',
					data:{type:type},
					success: function(data) {
						if(data.code==1){
							var img_url = data.img_url;
							
							var data = {id:id,img:img_url,table:table,field:field}
							
							$.post(url,data,function(res){
								if(res.code == 1){
									layer.msg('修改图片成功',{time:1000},function(){
										var html='<img height="70px" src="'+img_url+'"/>';
										obj.parent().prev('.upload-img-box').html(html);
										obj.attr('src', img_url);
									})
								}else{
									layer.msg('修改图片失败');
								}
							})
							
						}else{
							layer.msg('上传图片失败');
						}
					},
				})
			});
		})
	}
	//上传图片
	//修改图片
	function upload_img(upload_url){
		$('.upload input').each(function(){
			var obj = $(this);
			//var upload_url = '{:U("Ajax/upload")}';
			//var upload_url='http://img.baicaibuy.cn/Upload/upload';
			obj.wrap("<form id='myupload' action='"+upload_url+"' method='post' enctype='multipart/form-data'></form>");
			obj.change(function(){
				obj.parent('form').ajaxSubmit({
					dataType:  'json',
					success: function(data) {
						if(data.code==1){
							var img_url = data.img_url;
							//var url = "{:U('Ajax/updateimg')}";
							layer.msg('上传图片成功',{time:1000},function(){
								var html='<img height="70px" style="padding:2px 0" src="'+img_url+'"/>';
								obj.parent().prev('.upload-img-box').html(html);
								obj.attr('src', img_url);
							})
						}else{
							layer.msg('上传图片失败');
						}
					},
				})
			});
		})
	}
	//上传图片
	function upload_imgs(upload_url,del_img_url){
		$('.upload input').each(function(){
			var obj = $(this);
			//var upload_url = '{:U("Ajax/upload")}';
			//var upload_url='http://img.baicaibuy.cn/Upload/upload';
			obj.wrap("<form id='myupload' action='"+upload_url+"' method='post' enctype='multipart/form-data'></form>");
			obj.change(function(){
				var images_num = $('.images').length
				if(images_num>=9){
					layer.msg('最多只能上传9张图片');
					return false;
				}
				obj.parent('form').ajaxSubmit({
					dataType:  'json',
					success: function(data) {
						if(data.code==1){
							var img_url = data.img_url;
							//var url = "{:U('Ajax/updateimg')}";
							layer.msg('上传图片成功',{time:1000},function(){
								var html='<img class="small_img images" src="'+img_url+'"/><img class="del_img" src="'+del_img_url+'">';
								obj.parent().prev('.upload-img-box').append(html);
								obj.attr('src', img_url);
								$('.del_img').each(function(){
									var obj = $(this);
									obj.click(function(){
										obj.prev().remove();
										obj.remove();
									})
								})
								big_img(0)
							})
						}else{
							layer.msg('上传图片失败');
						}
					},
				})
			});
		})
	}
	//上传图片
	function upload_imgs1(upload_url,del_img_url){
		$('.upload input').each(function(){
			var obj = $(this);
			//var upload_url = '{:U("Ajax/upload")}';
			//var upload_url='http://img.baicaibuy.cn/Upload/upload';
			obj.wrap("<form id='myupload' action='"+upload_url+"' method='post' enctype='multipart/form-data'></form>");
			obj.change(function(){
				var images_num = $('.images').length
				if(images_num>=3){
					layer.msg('最多只能上传3张图片');
					return false;
				}
				obj.parent('form').ajaxSubmit({
					dataType:  'json',
					success: function(data) {
						if(data.code==1){
							var img_url = data.img_url;
							//var url = "{:U('Ajax/updateimg')}";
							layer.msg('上传图片成功',{time:1000},function(){
								var html='<img class="small_img_up images" src="'+img_url+'"/><img class="del_img_up" src="'+del_img_url+'">';
								obj.parent().prev('.upload-img-box').append(html);
								obj.attr('src', img_url);
								$('.del_img_up').each(function(){
									var obj = $(this);
									obj.click(function(){
										obj.prev().remove();
										obj.remove();
									})
								})
								big_img_up(0)
							})
						}else{
							layer.msg('上传图片失败');
						}
					},
				})
			});
		})
	}
	//修改分类
	function update_cate(cate_url,update_url){
		$('.cate').each(function(){
			var obj = $(this);
			obj.click(function(){
				var id = obj.attr('dataid');
				var cate = obj.text();
				var data = {cate:cate};
				//var url = "{:U('index/get_cate')}";
				$.post(cate_url,data,function(res){
					var html= res;
					layer.open({
					  title:'修改分类',
					  btn:['确定','取消'],
					  content: html,
					  yes: function(index, layero){
					    var data_id = id;
					    var value = $('#select option:selected').val();
					    var text = $('#select option:selected').text();
					    var data = {id:data_id,keyword:value,field:'cate_id',table:'app_items'};
					    $.post(update_url,data,function(r){
					    	if(r.code == 1){
					    		layer.msg('修改分类成功',{time:1000},function(){
					    			obj.text(text);
					    		})
					    	}else{
					    		layer.msg('修改分类失败')
					    	}
					    })
					    
					  }
					});  
				})
			})
		})
	}
	//修改为轮播图或专场
	function update_type(type,url,update_url,id,obj){
		if(type=='lunbotu'){
			var type_id = 1;
			var title ='轮播图列表';
			var res_msg='添加为轮播图中商品'
		}
		if(type=='zhuanchang'){
			var type_id = 2;
			var title ='专场列表';
			var res_msg='添加为专场中商品'
		}
		var data = {type:type_id};
		$.post(url,data,function(res){
			var html= res;
			layer.open({
			  title:title,
			  btn:['确定','取消'],
			  content: html,
			  yes: function(index, layero){
			    var value = $('#select option:selected').val();
			    var text = $('#select option:selected').text();
			    var data = {id:id,keyword:value};
			    $.post(update_url,data,function(r){ 
			    	if(r.code == 1){
			    		layer.msg(res_msg+'成功',{time:1000},function(){
			    			obj.parent().prev().text(text);
			    			layer.closeAll();
			    		})
			    	}else{
			    		layer.msg(res_msg+'失败')
			    	}
			    })
			  }
			});  
		})
	}
	