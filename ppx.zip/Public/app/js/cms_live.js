
var t = 0;
//评论功能
function input(data){
    if(istalk == 1) {
        $(".fq-comment-list").append('<div class="js_chat_content am-margin-bottom-xs"><span class="am-text-xs am-inline-block">'+data.nickname+' : '+ data.content +'</span></div>');
        if(t == 0) {
           t = setInterval(function() {
                var chat = $('.js_chat_content');
                if(chat.length > 0) {
                    chat.eq(0).fadeOut(1500,function() {
                        chat.eq(0).remove();
                    })
                } else {
                    clearInterval(t);
                    t = 0;
                }
            },2000);
        } 
    }
}

//展示部分======================>

function api_get_time(timestamp) {
    var time = new Date(timestamp*1000);
    var hours = time.getHours();
    var minutes = time.getMinutes();
    var seconds = time.getSeconds();
    if(hours < 10) {
        hours = '0'+hours;
    }
    if(minutes < 10 ) {
        minutes = '0' + minutes;
    }
    if(seconds < 10) {
        seconds = '0'+seconds;
    }
    return hours+':'+minutes+':'+seconds;
}

function change(id) {
    $('.js_'+id).css('height','auto');
    //fqScroll.refresh();
    if(fqScroll != undefined) {
        fqScroll.refresh();
    }
}
//商品组装
function api_studio_item(item,headimgurl,type) {

    var html = '<div class="am-cf am-padding-vertical-sm am-padding-horizontal-xs js_item">';
    html += '<div class="fq-goods-time fq-text-white am-padding-bottom-sm am-center am-text-xs am-text-center">';
    html += '<span class="am-padding-horizontal-xs">';
    html += api_get_time(item.send_time);
    html += '</span></div>';
    html += '<div class="am-padding-bottom am-cf"><div class="fq-online-moderator am-fl am-padding-right">';
    if(headimgurl.length == 0) {
        html += '<img src="'+item.headimgurl+'" />';
    } else {
         html += '<img src="'+headimg+'" />';
    }
    var image = '';
    var recommended = '';
    var res = item.recommend_reason.match(/(<|&lt;)img\s+src=(\"|&quot;)([^>]*)(\"|&quot;)\s{0,}?(<|&gt;)/);
    if(res) {
        image = res[3];
        recommended = item.recommend_reason.replace(res[0],'');
    } else {
        image = item.pic_url;
        recommended = item.recommend_reason;
    }
    recommended = recommended.replace(/(\t|\r|\'|\")/,'');
    html += '</div>';
    html += '<div class="fq-goods-img am-padding-0 am-fl">';
    html += '<img src="'+image+'" style="height:150px;" onload="change('+item.num_iid+');" class="js_'+item.num_iid+' js_item_img" />';
    html += '</div></div>';
    html += '<div class="am-cf"><div class="fq-online-moderator am-fl am-padding-right">';
    if(headimgurl.length == 0) {
        html += '<img src="'+item.headimgurl+'" />';
    } else {
         html += '<img src="'+headimg+'" />';
    }
    html += '</div>';
    html += '<div class="fq-goods-massage fq-background-white am-fl"><div class="am-padding-sm  js_create_words" data-id="' + item.id + '">';
    html +='<div class="fq-color-black am-text-sm">';
    html += item.title;
    html += '</div><div class="fq-color-glay am-padding-top-xs am-text-sm">';
    if(recommended) {
        if(recommended.match(/(\n|\r\n|<br>)/)) {
            html += recommended.replace(/(\n|\r\n|<br>)/,'<br>');
        } else {
            html += '推荐理由：'+recommended;
        }
    }
    html += '</div><div class="am-cf am-padding-top-sm am-text-sm"><div class="fq-color-orange am-fl">';
    html += item.youhuiquan_je+'元优惠券';
    html += '</div><div class="fq-color-red am-fr">';
    html += '券后￥'+item.coupon_price;
    html += ' <span class="fq-goods-postage fq-background-white fq-color-red am-padding-horizontal-xs" style="display: inline-flex;align-items: center;justify-content: center;height:22px;line-height:22px;">包邮</span></div></div></div>';
    html += '<div class="fq-online-buy am-padding-horizontal-sm">';
    if(h_commission == 1) {
        html += '<button type="button" class="fq-copy-password am-btn fq-color-glay am-text-center am-text-sm js_create_words" data-id="' + item.id + '">获取口令</button>';
    }
    html += '<a class="fq-color-glay am-text-sm " href="javascript:void(0);" onclick="href_details('+item.num_iid+')">';
    html += '<span class="fq-color-glay am-text-sm"><i class="iconfont icon-gouwuche02 am-margin-right-xs"></i>查看详情</span></a></div></div></div></div>';
    return html;
}



function api_get_item_pull_down() {
    $.ajax({
        url:live_room_data_url,
        type:'POST',
        data:{
            "id":itemid,
            "code":code,
        },
        success:function(res){
            $('#js_more_item_tip').html('');
            if(res.statue == 1) {
                itemid = res.itemid;
                var item_count = res.info.length;
                var html = '',imgbox = [];

                for(var i = 0 ; i < item_count; i++) {
                    if(item[res.info[i]['id']] == undefined) item[res.info[i]['id']] = res.info[i];
                    html += api_studio_item(res.info[i],headimg,1);
                    imgbox.push(res.info[i]['num_iid']);
                }

                $('#js_more_item_tip').html('');
                $('#js_studio_item').prepend(html);
                var className = '';
                for(var i = 0; i < item_count; i++){
                    className = '.js_'+imgbox[i];
                    /*$(className).onload(function(){
                     fqScroll.refresh();
                     });*/
                }
                if(item_count < 10) $('#js_studio_item').addClass('finish');

                if(item_count > 0) {
                    //setTimeout(function() {
                    fqScroll.refresh();
                    fqScroll.scrollToElement(document.querySelectorAll('.js_item')[item_count],0);
                    fqScroll.scrollToElement(document.querySelectorAll('.js_item')[item_count-1],1500);
                    //},500);

                }

                if(res.info.minid == -1) {
                    $('#js_more_item_tip').html('<span class="am-round am-padding-vertical-xs am-padding-horizontal-sm am-text-xs">已经到顶了，回头看看吧</span>');
                    setTimeout(function() {
                        $('#js_more_item_tip').html('');
                    },3000);
                }
            }else{
                $('#js_more_item_tip').html('<span class="am-round am-padding-vertical-xs am-padding-horizontal-sm am-text-xs">已经到顶了，回头看看吧</span>');
                setTimeout(function() {
                    $('#js_more_item_tip').html('');
                },3000);
            }
            $('#js_studio_item').removeClass('load').removeClass('isloading');
        },
        fail:function(){
            $('#js_studio_item').removeClass('load').removeClass('isloading');
            setTimeout(function() {
                $('#js_more_item_tip').html('');
            },1000);
        }
    })
}

// scroll
var fqScroll;

function loadScroll() {
    fqScroll = new IScroll('#js_main',{
        probeType:2,
        preventDefault:false
    });

    fqScroll.on('scroll', function () {
       if(this.y > 5 && !$('#js_studio_item').hasClass('load')) {
            if($('#js_studio_item').hasClass('finish')) {
                $('#js_more_item_tip').html('<span class="am-round am-padding-vertical-xs am-padding-horizontal-sm am-text-xs">已经到顶了，回头看看吧</span>');
                setTimeout(function() {
                     $('#js_more_item_tip').html('');
                },3000);
            } else {
                $('#js_more_item_tip').html('<span class="am-round am-padding-vertical-xs am-padding-horizontal-sm am-text-xs">松手加载更多</span>');
                $('#js_studio_item').addClass('load')
            }
        }
    });
    fqScroll.on('scrollEnd',function() {
        if(this.y == 0 && $('#js_studio_item').hasClass('load') && !$('#js_studio_item').hasClass('isloading')) {
            $('#js_studio_item').addClass('isloading');
            $('#js_more_item_tip').html('<span class="am-round am-padding-vertical-xs am-padding-horizontal-sm"><i class="am-icon-spinner am-icon-spin am-padding-right-xs"></i>商品加载中</span>');
            api_get_item_pull_down();
        } else if(!$('#js_studio_item').hasClass('isloading')) {
            if(!$('#js_studio_item').hasClass('finish')) {
                $('#js_more_item_tip').html('');
            }
        }
        var transform = $('#js_studio_box').css('transform');
        try{
            var top = Math.abs(transform.match(/-[0-9]+/)[0]);
        }catch(err){
            var top = 0;
        }
        var boxHeight = $('#js_studio_box').height();
        if(boxHeight - top < 1500) {
            $('#js_has_new_item').addClass('am-hide');
            newitem = 0;
        }
    });
    fqScroll.refresh();
    if($('.js_item').length > 0) {
        fqScroll.scrollToElement(document.querySelector('.js_item:last-child'),1500);
        fqScroll.refresh();
    }
}

//禁止touchmove事件
var preHandler = function(e){
    e.preventDefault();
}
document.addEventListener('touchmove', preHandler, false);
//点击口令复制框时把允许touchmove事件
$('#copy_key_android,#copy_key_ios').on('touchstart',function() {
    document.removeEventListener('touchmove', preHandler, false);
});
//手指离开口令复制框时禁用touchmove
$('#copy_key_android,#copy_key_ios').on('touchend',function() {
    document.addEventListener('touchmove', preHandler, false);
});
/*
document.addEventListener('touchmove', function(e) {
    e.preventDefault();
},false);
*/
//页面加载完毕，延迟100毫秒实例化IScroll类
document.addEventListener('DOMContentLoaded',function() {
    setTimeout(loadScroll,100);
}, false);



function api_index_get_agent_word(id,code) {
    var share_array = new Array();
    var content = '';
    $.ajax({
        type:'post',
        url:get_liveroom_coupon_url,
        data:{
            'id':id,
            'code':code
        },
        success:function(res){
            if(res.statue==1){
                share_array = template.split("#");
                if(res.info.recommend_reason==''){
                    recommended = res.info.recommend_reason.replace(/(<|&lt;)img\s+src=(\"|&quot;)[^>]*(\"|&quot;)\s{0,}?(<|&gt;)/,'');
                }else{
                    recommended = '';
                }

                for(var i in share_array){
                    if(share_array[i].indexOf(res.info.recommend_reason) >= 0 && recommended == ''){

                    } else if(share_array[i].indexOf(res.info.coupon_price) >= 0){
                        var coupons_array = share_array[i].split("|");
                        if(coupons > 0) {
                            content = content + coupons_array[0] + "\n";
                        } else {
                            content = content + coupons_array[1] + "\n";
                        }
                    }else{
                        content = content + share_array[i] + "\n";
                    }
                }
                content = content.replace(/{recommended}/g,recommended);
                content = content.replace(/{title}/g,res.info.title);
                content = content.replace(/{price}/g,res.info.price);
                content = content.replace(/{coupons}/g,res.info.youhuiquan_je);
                content = content.replace(/{end_price}/g,res.info.coupon_price);
                content = content.replace(/{br}/g,"\n");
                content = content.replace(/{words}/g,res.tkl);
                content = content.replace(/{url}/g,res.ehy);
                $('.js_copy_words').attr('data-words',content).show();
                if(ua.match(/iphone/i) == "iphone" || ua.match(/ipad/i) == "ipad"){
                    content =  content.replace(/\n/g,'<br>');
                    $('#copy_key_ios').html(content);
                }else{
                    $('#copy_key_android').val(content).attr('data-words',res.info.word).show();
                }
            }else{
                if(ua.match(/iphone/i) == "iphone" || ua.match(/ipad/i) == "ipad"){
                    $('#copy_key_ios').html('系统繁忙，请刷新重试');
                }else{
                    $('#copy_key_android').val('系统繁忙，请刷新重试').show();
                }
                $('.js_copy_words').hide();
            }
        },
        fail:function(){
            if(ua.match(/iphone/i) == "iphone" || ua.match(/ipad/i) == "ipad"){
                $('#copy_key_ios').html('系统繁忙，请刷新重试');
            }else{
                $('#copy_key_android').val('系统繁忙，请刷新重试').show();
            }
            $('.js_copy_words').hide();
        }
    })
}


var isShow = 0;
if(ua.match(/iphone/i) == "iphone"){
    //获取iOS版本
    var iphoneInfo = ua.match(/iphone os (\d{1,})/i);
    var iosVersion = iphoneInfo[1];
    //IOS10以上显示一键复制按钮
    if(iosVersion >= 10) {
       isShow = 1;
    }
} else {
   isShow = 1;
}
if(isShow == 1) {
    $('.copy_words').show();
    var clipboard = new Clipboard('.js_copy_words', {
        //动态设置复制内容
        text:function(trigger) {
            return trigger.getAttribute('data-words');
        }
    });



    clipboard.on('success', function(e){
        if(e.trigger.disabled == false || e.trigger.disabled == undefined) {
            e.trigger.innerHTML="已复制";
            e.trigger.style.backgroundColor="#9ED29E";
            e.trigger.style.borderColor="#9ED29E";
            e.clearSelection();
            e.trigger.disabled = true;
            //2秒后按钮恢复原状
            setTimeout(function() {
                e.trigger.innerHTML="一键复制";
                e.trigger.style.backgroundColor="#f54d23";
                e.trigger.style.borderColor="#f54d23";
                e.trigger.disabled = false;
            },2000);
        }
    });

    clipboard.on('error', function(e) {
        if(ua.match(/iphone/i) == "iphone" || ua.match(/ipad/i) == "ipad"){
            var copy_text = $('#copy_key_ios').val();
        }else{
            var copy_text = $('#copy_key_android').val();
        }
        android.copyText(copy_text);
        window.location.href = 'zdd_copytext&'+encodeURIComponent(copy_text);
        e.trigger.innerHTML="已复制";
        e.trigger.style.backgroundColor="#9ED29E";
        e.trigger.style.borderColor="#9ED29E";
        e.clearSelection();
        e.trigger.disabled = true;
        //2秒后按钮恢复原状
        setTimeout(function() {
            e.trigger.innerHTML="一键复制";
            e.trigger.style.backgroundColor="#f54d23";
            e.trigger.style.borderColor="#f54d23";
            e.trigger.disabled = false;
        },2000);
        //e.trigger.innerHTML="复制失败";
        //e.trigger.style.backgroundColor="#8f8f8f";
        //e.trigger.style.borderColor="#8f8f8f";
    });
}

document.addEventListener("selectionchange", function (e) {
    if(window.getSelection().anchorNode != null){
        if (window.getSelection().anchorNode.parentNode.id == 'copy_key_ios' && document.getElementById('copy_key_ios').innerText != window.getSelection()) {
            var key = document.getElementById('copy_key_ios');
            window.getSelection().selectAllChildren(key);
        }
    }
}, false);

if (document.getElementById("copy_key_android")) {
    function regain() {
        var words = document.getElementById("copy_key_android").getAttribute('data-words');
        document.getElementById('copy_key_android').value = words;
    }
}



$(function(){

    $('#js_chat').keydown(function(e) {
        if(e.keyCode == 13) {
            chat();
        }
    });
    $('#js_own_info').click(function() {
        window.localStorage.removeItem('adzone_pname');
        if(is_location == 1) {
            if(status == 1) {
                window.location.href = "/Login/index?return=/studio/index/pname/{$pid|str_replace='mm_','',###|str_replace='_','-',###}";
            } else {
                window.location.href = "/Login/index?return=studio/index";
            }
        }
    })
    
    $('#js_has_new_item').click(function() {
        $('#js_has_new_item').addClass('am-hide');
        fqScroll.scrollToElement(document.querySelector('.js_item:last-child'),1500);
        newitem = 0;
    }); 

    $(document).on('click','.js_create_words',function() {
        $('#js_show_words').modal()
        var _this = $(this);
        var id = _this.attr('data-id');
        api_index_get_agent_word(id,code);

    });
    function getBase64Image(src) {
               
                 /*if(seller_id == 71349 || seller_id == 67766) {
                      
                      if(ua.match(/platform\/ios/i)) {
                          window.webkit.messageHandlers.showImage.postMessage({methodName:"showImage","imageUrl":src});
                          return;
                      } else if(ua.match(/iphone/i) == "iphone") {
                         showImage(src);
                         return;
                      }
                  }*/
                  if(ua.match(/platform\/ios/i)) {
                    window.webkit.messageHandlers.showImage.postMessage({methodName:"showImage","imageUrl":src});
                    return;
                  } else if(ua.match(/iphone/i) == "iphone") {
                    showImage(src);
                    return;
                  }
                    /*if(ua.match(/iphone/i) == "iphone") {
                         //window.webkit.messageHandlers.showImage.postMessage({methodName:"showImage","imageUrl":src});
                         showImage(src);
                         return;
                    }*/
               
                src = src.replace('_600','');
                
                window.android.showImageWithUrl(src);
                /*
                var canvas = document.createElement("canvas");
                var ctx = canvas.getContext("2d");
                var img = new Image();
                img.setAttribute('crossOrigin','anonymous');
                img.src = src;
                //img.setAttribute('crossOrigin','anonymous');
                img.onload = function() {
                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.drawImage(img, 0, 0,canvas.width,canvas.height);
                    var data =  canvas.toDataURL("image/jpeg");
                    if(seller_id == 71349 || seller_id == 67766) {
                        if(ua.match(/iphone/i) == "iphone") {
                            showImage(data);
                            return;
                        }
                    }
                    //window.android.showImage(data);
                    window.android.showImageWithUrl(src);
                }*/
            
    }
    $(document).on('click','.js_item_img',function() {
        getBase64Image($(this).attr('src'));
    });
});