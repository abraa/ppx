

var ws;
function wsConnect() {
    $.ajax({
        type:'get',
        url:get_user_pic_url,
        data:{
            'code':'x66mdnaa'
        },
        success:function(res){
            userLogin(res.data,res.data.user_list);
            setTimeout(function() {
                wsConnect();
            },3000000);
        }
    })
    headid = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21];
    //ws = new WebSocket('wss://'+url+':'+port);
    //ws.onopen = function() {
    //    var data = '{"code":"login","uid":"uid_'+uid+'"}';
    //    ws.send(data);
    //}
    //ws.onmessage = wxMessage;
    //ws.onclose = function() {
    //    setTimeout(function() {
    //         wsConnect();
    //    },2000);
    //}
}

//通讯
function wxMessage(msg) {
    var data = eval('('+msg.data+')');
    switch(data['code']) {
        case 'login':
            userLogin(data,headid);
            break;
        case 'newuser':
            newuser(data);
            break;
        case 'logout':
            userLogout(data,headid);
            break;
        case 'chat':
            input(data);
            break;
        case 'newitem':
            liveItem(data);
            break;
        case 'ping':
            ws.send('{"code":"pong"}');
            break;
        case 'istalk':
            istalk = data['istalk'];
            if(istalk == 1) {
                $('.js_talk_box').show();
                $('#js_back_to_index').css('position','initial').css('right',0);
                $('#js_main').css('bottom','50px');
            } else {
                $('.js_talk_box').hide();
                $('#js_back_to_index').css('position','absolute').css('right',0);
                $('#js_main').css('bottom','0');
            }
            fqScroll.refresh();
            break;
        default:
            break;
    }
}

//登录
function userLogin(data,head) {
    user_list = data.user_list;//会员信息
    user_count = data.user_count;//会员打开客户端个数信息
    //记录头像是否已经展示
    var user_box = {};

    //头像展示
    var j = 0;//头像显示个数
    var html = '';//头像代码


    for(x=0;x<user_count;x++){
        html += '<img class="am-round js_headimg_'+user_list[x]['id']+'" src="'+user_list[x]['headerpic']+'" />';
    }


    //for(var i in user_list) {
    //    if(user_list[i]['uid'] != undefined) {
    //        if(user_list[i]['uid'] == 'uid_0') {
    //
    //            html += '<img class="am-round js_headimg_'+ i +'" src="'+user_list[i]['headimgurl']+'" />';
    //            j++;
    //            if(j >= 20) {
    //                break;
    //            }
    //
    //        } else {
    //
    //            if(user_list[i]['uid'] != 'uid_' + uid) {
    //                if(user_box[user_list[i]['uid']] == undefined || user_box[user_list[i]['uid']] == 0) {
    //                    user_box[user_list[i]['uid']] = 1;
    //                    html += '<img class="am-round js_headimg_'+user_list[i]['uid']+'" src="'+user_list[i]['headimgurl']+'" />';
    //                    j++;
    //                    if(j >= 20) {
    //                        break;
    //                    }
    //                }
    //            }
    //        }
    //    }
    //}

    //显示头像少于5个并且开启了虚拟在线人数
    if(j < 20 && virtual > 0 ) {
        //虚拟在线人数 大于 在线人数 并且在线人数少于5个
        if(j < virtual) {
            //var head = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21];
            var times = virtual > 10?10- j:virtual-j;
            var n = 0,m = head.length,index;
            for(var k = 0 ; k < times ; k++ ) {
                index = Math.floor(Math.random()*(m-n)+n);
                html += '<img class="am-round js_virtual" src="' + head[index]['headerpic'] + '" data-id="'+head[index]['id']+'" />';
                head.splice(index,1);
                m--;
            }
        }
    }
    $('#js_user_headimg').html(html);

    //在线人数
    var num = parseInt(virtual) + parseInt(user_count);
    $('#js_online_num').text(num);
}

//新用户
function newuser(data) {
    var client_id = data['client_id'];
    //将新用户添加到用户信息数组中
    var user_info = data['user_info'];
    user_list[client_id] = user_info;
    //头像展示
    var user_uid = user_info['uid'];
    //当前用户未开启过客户端
    if(user_uid != ('uid_' + uid) && user_uid != 'uid_0') {
        if(user_count[user_uid] == undefined || user_count[user_uid] == 0) {
            user_count[user_uid] = 1;
            $('#js_user_headimg').prepend('<img class="am-round js_headimg_'+user_uid+'" src="'+user_info['headimgurl']+'" />');
        } else {
            user_count[user_uid] = user_count[user_uid] + 1;
            $('.js_headimg_'+user_uid).remove();
            $('#js_user_headimg').prepend('<img class="am-round js_headimg_'+user_uid+'" src="'+user_info['headimgurl']+'" />');
        }
        var imgLen = $('#js_user_headimg img').length;
        if(imgLen > 20) {
            var index;
            for(var i = 1; i <= imgLen - 20 ; i++) {
                index = $('#js_user_headimg img:last-child').attr('data-id')
                if(index) {
                    headid.push(index);
                }
                $('#js_user_headimg img:last-child').remove();
            }
        }
    } else {
        if(user_uid == 'uid_0') {
            //游客身份
            $('#js_user_headimg').prepend('<img class="am-round js_headimg_'+client_id+'" src="'+user_info['headimgurl']+'" />');
            var imgLen = $('#js_user_headimg img').length;
            if(imgLen > 20) {
                var index;
                for(var i = 1; i <= imgLen - 20 ; i++) {
                    index = $('#js_user_headimg img:last-child').attr('data-id')
                    if(index) {
                        headid.push(index);
                    }
                    $('#js_user_headimg img:last-child').remove();
                }
            }
            if(user_count['uid_0'] == undefined || user_count['uid_0'] == 0) {
                user_count['uid_0'] = 1;
            } else {
                user_count['uid_0'] = user_count['uid_0'] + 1;
            }
        } else {
            if(user_count[user_uid] == undefined || user_count[user_uid] == 0) {
                user_count[user_uid] = 1;
            } else {
                user_count[user_uid] = user_count[user_uid] + 1;
            }
        }
    }
    //在线人数
    var num = parseInt(virtual) + parseInt(data['count']);
    $('#js_online_num').text(num);
}

//有客户端关闭
function userLogout(data,head) {
    var i = data['uid'];
    //删除对应客户端的用户资料
    if(user_list[data['clientId']] != undefined) {
        delete user_list[data['clientId']];
    }
  
    //退出的用户当前只打开一个客户端
    if(user_count[i] != undefined && (user_count[i] - 1 == 0 || i == 'uid_0')) {

        if(i == 'uid_0') {
            $('.js_headimg_'+data['clientId']).remove();
        } else {
            $('.js_headimg_'+i).remove();
        }
        $('#js_online_num').text(parseInt($('#js_online_num').text()) - 1);
        if(i == 'uid_0') {
            if(user_count[i] - 1 == 0) {
                delete user_count[i];
            } else {
                user_count[i] = user_count[i] - 1;
            }
        } else {
            delete user_count[i];
        }
        var imgLen = $('#js_user_headimg img').length;
        //显示头像少于20个并且开启了虚拟在线人数
        if(imgLen < 20 && virtual > 0) {
            var times = 20 - imgLen;
            var n = 0,m = head.length,index;
            for(var k = 0 ; k < times ; k++ ) {
                index = Math.floor(Math.random()*(m-n)+n);
                html = '<img class="am-round js_virtual" src="/Public/assets/mobile/images/studio/' + head[index] + '.jpg" data-id="'+head[index]+'" />';
                $('#js_user_headimg').append(html);
                head.splice(index,1);
                m--;
            }
        }
    } else {
        //退出的用户当前只打开多个客户端
        user_count[i] = user_count[i] - 1;
    } 

}

//添加直播商品
function liveItem(data) {
    var html = api_studio_item(data,'',0);
    $('#js_studio_item').append(html);
    delete data['code'];
    delete data['seller_id'];
    item[data['id']] = data;
    var transform = $('#js_studio_box').css('transform');
    var boxHeight = $('#js_studio_box').height();
    try{
        var top = Math.abs(transform.match(/-[0-9]+/)[0]);
    }catch(err){
        var top = 0;
    }
    fqScroll.refresh();
    if(boxHeight - top>1500){
        if(newitem == 0) {
            scrollTop = top;
        }
        newitem = newitem + 1;
        $('#js_new_item').text(newitem);
        $('#js_has_new_item').removeClass('am-hide');
    }else{
        fqScroll.scrollToElement(document.querySelector('.js_item:last-child'),1500);
    }

    var img = new Image();
    img.src = data.image;
    img.onload = function() {
        $('.js_'+data.tb_itemid).css('height',img.height*(150/img.width));
         fqScroll.refresh();
        if(boxHeight - top>1500){
        
        }else{
            fqScroll.scrollToElement(document.querySelector('.js_item:last-child'),1500);
        }
    }
}

//聊天
function chat() {
    if(istalk == 1) {
        var content = $('#js_chat').val();
        content = content.replace(/\"|\'|\t|\r\n|\r|\n/g,'');
        $('#js_chat').val('');
        if(content.length == 0) {
            return;
        }
        ws.send('{"code":"chat","nickname":"'+nickname+'","content":"'+content+'"}');
    }
}

$(function() {
    $('#js_send_chat').click(function() {chat();});
    $('#js_chat').on('keydown',function(e) {if(e.keyCode == 13) chat();});
});